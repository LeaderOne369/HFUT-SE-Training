/*
 Navicat Premium Data Transfer

 Source Server         : lecture
 Source Server Type    : MySQL
 Source Server Version : 80033 (8.0.33)
 Source Host           : localhost:3306
 Source Schema         : ksp2

 Target Server Type    : MySQL
 Target Server Version : 80033 (8.0.33)
 File Encoding         : 65001

 Date: 12/01/2025 23:22:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for citation
-- ----------------------------
DROP TABLE IF EXISTS `citation`;
CREATE TABLE `citation`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '引用ID，唯一标识一条引用记录，主键，自增',
  `post_id` bigint NULL DEFAULT NULL COMMENT '帖子ID，使用引用的帖子ID，外键，关联帖子实体（假设为post）的id字段',
  `citation_type_id` bigint NULL DEFAULT NULL COMMENT '引用类型ID，外键，关联引用类型实体（假设为citation_type）的id字段',
  `citation_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '引用的具体内容或文本，通常是从其他文献、资料或帖子中提取的',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '引用内容的来源信息，例如书籍、文章、网页等的标题或链接',
  `citation_time` datetime NULL DEFAULT NULL COMMENT '引用时间，用户添加引用的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '是否删除，0表示未删除，1表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_citation_post_id`(`post_id` ASC) USING BTREE,
  INDEX `fk_citation_citation_type_id`(`citation_type_id` ASC) USING BTREE,
  CONSTRAINT `fk_citation_citation_type_id` FOREIGN KEY (`citation_type_id`) REFERENCES `citation_type` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_citation_post_id` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of citation
-- ----------------------------

-- ----------------------------
-- Table structure for citation_type
-- ----------------------------
DROP TABLE IF EXISTS `citation_type`;
CREATE TABLE `citation_type`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '引用类型ID，唯一标识一个引用类型，主键，自增',
  `type_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '引用类型的名称，如书籍、期刊文章、网站、报告等',
  `type_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '对引用类型进行详细描述，可包括该类型引用的标准格式、常见引用场景等',
  `is_active` int NULL DEFAULT NULL COMMENT '是否启用，0表示未启用，1表示启用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of citation_type
-- ----------------------------

-- ----------------------------
-- Table structure for collection
-- ----------------------------
DROP TABLE IF EXISTS `collection`;
CREATE TABLE `collection`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个合集，自增',
  `collection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '合集的名称，用于用户识别和展示',
  `collection_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '合集的详细描述，可以包含合集的主题、目的和包含内容的概述',
  `creator_id` bigint NULL DEFAULT NULL COMMENT '关联用户表的id，创建该合集的用户ID',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '合集创建的时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '合集信息最后一次更新的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '表示合集是否被删除，1表示是，0表示否',
  `like_count` int NULL DEFAULT NULL COMMENT '合集获得的点赞数量',
  `comment_count` int NULL DEFAULT NULL COMMENT '合集下的评论数量',
  `subscribe_count` int NULL DEFAULT NULL COMMENT '合集被订阅的次数',
  `share_count` int NULL DEFAULT NULL COMMENT '合集被分享的次数',
  `visibility` int NULL DEFAULT NULL COMMENT '分区的可见性，0表示自己可见，1表示公开',
  `review_status` int NULL DEFAULT NULL COMMENT '审核状态，0-待审核，1-已通过，2-已拒绝',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_collection_creator_id`(`creator_id` ASC) USING BTREE,
  CONSTRAINT `fk_collection_creator_id` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of collection
-- ----------------------------

-- ----------------------------
-- Table structure for collection_subscriptions
-- ----------------------------
DROP TABLE IF EXISTS `collection_subscriptions`;
CREATE TABLE `collection_subscriptions`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，自增且唯一标识一条订阅记录',
  `users_id` bigint NULL DEFAULT NULL COMMENT '订阅合集的用户ID，外键，关联用户实体（users）的id',
  `collections_id` bigint NULL DEFAULT NULL COMMENT '被订阅的合集ID，外键，关联合集实体（collections）的id',
  `is_deleted` int NULL DEFAULT NULL COMMENT '区分位，例如1表示有效，0表示无效',
  `subscription_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '用户订阅的时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_cs_users_id`(`users_id` ASC) USING BTREE,
  INDEX `idx_cs_collections_id`(`collections_id` ASC) USING BTREE,
  CONSTRAINT `fk_cs_collections_id` FOREIGN KEY (`collections_id`) REFERENCES `collection` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cs_users_id` FOREIGN KEY (`users_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of collection_subscriptions
-- ----------------------------

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条评论记录，自增',
  `commenter_id` bigint NULL DEFAULT NULL COMMENT '发表评论的用户ID，外键，关联用户表（假设为user）的id字段',
  `commentable_id` bigint NULL DEFAULT NULL COMMENT '被评论的对象ID，可能是帖子、合集或其他评论的ID',
  `commentable_type` int NULL DEFAULT NULL COMMENT '被评论对象的类型，1表示帖子，2表示合集，3表示其他评论',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '评论的具体文本内容',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '评论创建的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '是否删除，0表示未删除，1表示已删除',
  `parent_comment_id` bigint NULL DEFAULT NULL COMMENT '如果评论是回复另一条评论的，此字段指向被回复的评论ID，外键，自关联到评论实体（即本表comment）的id字段',
  `like_count` int NULL DEFAULT NULL COMMENT '评论获得的点赞数量',
  `reply_count` int NULL DEFAULT NULL COMMENT '评论收到的回复数量',
  `is_public` int NULL DEFAULT NULL COMMENT '是否是公开的，0表示否，1表示是',
  `review_status` int NULL DEFAULT NULL COMMENT '审核状态，0表示待审核，1表示已通过，2表示已拒绝',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_cm_commenter_id`(`commenter_id` ASC) USING BTREE,
  INDEX `fk_cm_parent_comment_id`(`parent_comment_id` ASC) USING BTREE,
  CONSTRAINT `fk_cm_commenter_id` FOREIGN KEY (`commenter_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cm_parent_comment_id` FOREIGN KEY (`parent_comment_id`) REFERENCES `comment` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (1, 1, 101, 1, '这是用户1对帖子101的评论,有本事举报我', '2024-01-01 10:00:00', 0, NULL, 5, 2, 1, 1);
INSERT INTO `comment` VALUES (2, 2, 102, 2, '这是用户2对合集102的评论', '2024-01-02 14:30:25', 0, NULL, 3, 1, 1, 1);
INSERT INTO `comment` VALUES (3, 3, 101, 1, '这是用户3对帖子101的评论（待审核）', '2024-01-03 18:45:10', 0, NULL, 0, 0, 1, 0);
INSERT INTO `comment` VALUES (4, 4, 103, 3, '这是用户4对评论103的回复', '2024-01-04 09:15:55', 0, 1, 2, 0, 1, 1);
INSERT INTO `comment` VALUES (5, 5, 104, 1, '这是用户5对帖子104的评论（已删除）', '2024-01-05 21:50:20', 1, NULL, 0, 0, 0, 1);
INSERT INTO `comment` VALUES (6, 6, 104, 1, '用户6对帖子104的第1次回复', '2024-01-06 11:20:33', 0, 4, 1, 0, 1, 1);
INSERT INTO `comment` VALUES (7, 7, 104, 1, '用户7对帖子104的第2次回复', '2024-01-07 16:45:50', 0, 4, 2, 1, 1, 1);
INSERT INTO `comment` VALUES (8, 8, 105, 1, '用户8对帖子105的评论', '2024-01-08 08:00:00', 0, NULL, 0, 0, 1, 1);
INSERT INTO `comment` VALUES (9, 8, 105, 3, '用户8对评论8的回复', '2024-01-08 08:05:10', 0, 8, 0, 0, 1, 1);
INSERT INTO `comment` VALUES (10, 9, 106, 1, '待审核的评论', '2024-01-09 00:15:30', 0, NULL, 0, 0, 1, 0);
INSERT INTO `comment` VALUES (11, 10, 107, 1, '被拒绝的评论', '2024-01-10 13:25:45', 0, NULL, 0, 0, 1, 2);
INSERT INTO `comment` VALUES (12, 11, 108, 1, '热门评论1', '2024-01-11 19:35:55', 0, NULL, 120, 5, 1, 1);
INSERT INTO `comment` VALUES (13, 12, 108, 1, '热门评论2', '2024-01-12 15:45:00', 0, NULL, 150, 8, 1, 1);
INSERT INTO `comment` VALUES (14, 13, 109, 3, '对评论12的回复', '2024-01-13 10:20:00', 0, 12, 5, 1, 1, 1);
INSERT INTO `comment` VALUES (15, 14, 110, 3, '对评论13的二级回复', '2024-01-14 14:40:00', 0, 13, 2, 0, 1, 1);
INSERT INTO `comment` VALUES (16, 15, 111, 1, '去年的评论', '2023-12-25 12:00:00', 0, NULL, 10, 1, 1, 1);
INSERT INTO `comment` VALUES (17, 16, 112, 1, '去年的回复', '2023-12-26 15:00:00', 0, 15, 3, 1, 1, 1);
INSERT INTO `comment` VALUES (18, 17, 113, 1, '被删除的评论', '2024-03-15 16:30:00', 1, NULL, 0, 0, 0, 1);
INSERT INTO `comment` VALUES (19, 18, 114, 1, '被删除的回复', '2024-04-20 17:00:00', 1, 17, 0, 0, 0, 1);
INSERT INTO `comment` VALUES (20, 21, 101, 1, '21对101pl', NULL, 0, NULL, 5, 0, 1, 1);
INSERT INTO `comment` VALUES (21, 21, 24, 1, '666', '2025-01-05 17:42:04', 0, NULL, 0, 0, 1, 1);
INSERT INTO `comment` VALUES (23, 21, 1, 3, '泻药，已举报', '2025-01-05 17:46:39', 0, NULL, 0, 0, 1, 1);
INSERT INTO `comment` VALUES (24, 21, 1, 3, '泻药，已举报', '2025-01-05 17:46:49', 0, NULL, 0, 0, 1, 1);

-- ----------------------------
-- Table structure for favorite
-- ----------------------------
DROP TABLE IF EXISTS `favorite`;
CREATE TABLE `favorite`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个收藏记录，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '进行收藏的用户ID，外键，关联用户实体（User）',
  `post_id` bigint NULL DEFAULT NULL COMMENT '被收藏的帖子ID，外键，关联帖子实体（Post）',
  `folder_id` bigint NULL DEFAULT NULL COMMENT '收藏所属的收藏夹ID，外键，关联收藏夹实体（CollectionFolder）',
  `favorite_time` datetime NULL DEFAULT NULL COMMENT '用户收藏帖子的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除标识，0表示未删除，1表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_favorite_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_favorite_post_id`(`post_id` ASC) USING BTREE,
  INDEX `fk_favorite_folder_id`(`folder_id` ASC) USING BTREE,
  CONSTRAINT `fk_favorite_folder_id` FOREIGN KEY (`folder_id`) REFERENCES `favorite_folder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_favorite_post_id` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_favorite_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of favorite
-- ----------------------------
INSERT INTO `favorite` VALUES (1, 21, 101, 1, '2025-01-03 14:15:00', 0);
INSERT INTO `favorite` VALUES (2, 21, 102, 1, '2025-01-03 14:20:00', 0);
INSERT INTO `favorite` VALUES (3, 21, 103, 2, '2025-01-03 14:25:00', 0);
INSERT INTO `favorite` VALUES (4, 21, 101, 3, '2025-01-03 14:30:00', 0);

-- ----------------------------
-- Table structure for favorite_folder
-- ----------------------------
DROP TABLE IF EXISTS `favorite_folder`;
CREATE TABLE `favorite_folder`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个收藏夹，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '创建收藏夹的用户ID，关联用户表user的id',
  `folder_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '收藏夹的名称，用于用户识别和展示',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '收藏夹创建的时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '收藏夹信息最后一次更新的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除标识，0表示未删除，1表示已删除',
  `review_status` int NULL DEFAULT NULL COMMENT '审核状态，0表示待审核，1表示已通过，2表示已拒绝',
  `visibility` int NULL DEFAULT NULL COMMENT '可见性，0表示自己可见，1表示可见',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_f_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `fk_favorite_folder_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of favorite_folder
-- ----------------------------
INSERT INTO `favorite_folder` VALUES (1, 21, '我的最爱', '2025-01-03 14:00:00', '2025-01-03 14:00:00', 0, 1, 1);
INSERT INTO `favorite_folder` VALUES (2, 21, '技术相关', '2025-01-03 14:05:00', '2025-01-03 14:05:00', 0, 1, 1);
INSERT INTO `favorite_folder` VALUES (3, 21, '私人收藏', '2025-01-03 14:10:00', '2025-01-03 14:10:00', 0, 0, 0);

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条反馈记录，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '提供反馈的用户ID，外键，关联用户实体（User）',
  `feedback_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户提交的反馈的具体内容，可以是文本形式',
  `feedback_time` datetime NULL DEFAULT NULL COMMENT '用户提交反馈的时间',
  `status` int NULL DEFAULT NULL COMMENT '反馈的处理状态，0表示未处理，1表示已处理，2表示已回复',
  `is_deleted` int NULL DEFAULT NULL COMMENT '是否删除，0表示未删除，1表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_feedback_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `fk_feedback_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of feedback
-- ----------------------------
INSERT INTO `feedback` VALUES (1, 1, '这个应用的界面设计很棒，用户体验很好，但希望能增加一个夜间模式功能，保护眼睛。', '2024-12-01 10:30:00', 0, 0);
INSERT INTO `feedback` VALUES (2, 2, '在使用搜索功能时，发现搜索结果不够准确，希望能优化一下搜索算法。', '2024-12-02 14:45:00', 1, 0);
INSERT INTO `feedback` VALUES (3, 3, '我遇到了一个bug，当我在编辑文章时，保存后内容丢失了。', '2024-12-03 09:20:00', 2, 0);
INSERT INTO `feedback` VALUES (4, 4, '社区互动功能很有趣，但希望能增加更多的互动方式，比如视频聊天。', '2024-12-04 16:10:00', 0, 0);
INSERT INTO `feedback` VALUES (5, 5, '应用的启动速度有点慢，希望能优化一下性能。', '2024-12-05 18:30:00', 1, 0);
INSERT INTO `feedback` VALUES (6, 6, '我非常喜欢这个应用，但希望能增加一个收藏夹功能，方便保存喜欢的内容。', '2024-12-06 11:00:00', 0, 0);
INSERT INTO `feedback` VALUES (7, 7, '在使用过程中，发现有些功能不够直观，希望能增加一些引导提示。', '2024-12-07 13:50:00', 2, 0);
INSERT INTO `feedback` VALUES (8, 8, '应用的广告有点多，希望能减少一些广告，或者提供一个付费去广告版本。', '2024-12-08 08:25:00', 0, 0);
INSERT INTO `feedback` VALUES (9, 9, '我遇到了一个问题，当我在上传图片时，系统提示文件格式不支持。', '2024-12-09 15:15:00', 1, 0);
INSERT INTO `feedback` VALUES (10, 10, '这个应用的功能很全面，但希望能增加一个语音输入功能，方便快速输入。', '2024-12-10 17:40:00', 0, 0);
INSERT INTO `feedback` VALUES (11, 11, '在使用过程中，发现有些页面加载速度很慢，希望能优化一下。', '2024-12-11 12:05:00', 2, 0);
INSERT INTO `feedback` VALUES (12, 12, '我非常喜欢这个应用的社区氛围，但希望能增加一些主题讨论区。', '2024-12-12 14:30:00', 0, 0);
INSERT INTO `feedback` VALUES (13, 13, '应用的稳定性还不错，但希望能增加一个自动备份功能，防止数据丢失。', '2024-12-13 09:50:00', 1, 0);
INSERT INTO `feedback` VALUES (14, 14, '我遇到了一个问题，当我在使用翻译功能时，结果不够准确。', '2024-12-14 16:00:00', 0, 0);
INSERT INTO `feedback` VALUES (15, 15, '这个应用的界面设计很简洁，但希望能增加一些个性化设置选项。', '2024-12-15 18:15:00', 2, 0);
INSERT INTO `feedback` VALUES (16, 16, '在使用过程中，发现有些功能不够稳定，希望能优化一下。', '2024-12-16 11:30:00', 0, 0);
INSERT INTO `feedback` VALUES (17, 17, '我非常喜欢这个应用的用户体验，但希望能增加一个日历功能，方便安排日程。', '2024-12-17 13:45:00', 1, 0);
INSERT INTO `feedback` VALUES (18, 18, '应用的性能还不错，但希望能增加一个离线下载功能，方便在没有网络的情况下使用。', '2024-12-18 08:10:00', 0, 0);
INSERT INTO `feedback` VALUES (19, 19, '在使用过程中，发现有些功能不够人性化，希望能增加一些智能提示。', '2024-12-19 15:20:00', 2, 0);
INSERT INTO `feedback` VALUES (20, 20, '我遇到了一个问题，当我在使用语音识别功能时，识别准确率不高。', '2024-12-20 17:55:00', 0, 0);

-- ----------------------------
-- Table structure for follow
-- ----------------------------
DROP TABLE IF EXISTS `follow`;
CREATE TABLE `follow`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条关注记录，即关注ID（follow_id）',
  `follower_id` bigint NULL DEFAULT NULL COMMENT '关注者ID，外键，关联用户实体（User）的id',
  `followee_id` bigint NULL DEFAULT NULL COMMENT '被关注者ID，外键，关联用户实体（User）的id',
  `follow_time` timestamp NULL DEFAULT NULL COMMENT '用户关注的时间',
  `is_deleted` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '区分位，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_f_follower_id`(`follower_id` ASC) USING BTREE,
  INDEX `fk_f_followee_id`(`followee_id` ASC) USING BTREE,
  INDEX `idx_f_follow_time`(`follow_time` ASC) USING BTREE,
  CONSTRAINT `fk_f_followee_id` FOREIGN KEY (`followee_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_f_follower_id` FOREIGN KEY (`follower_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of follow
-- ----------------------------
INSERT INTO `follow` VALUES (1, 21, 2, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (2, 21, 3, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (3, 21, 4, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (4, 4, 21, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (5, 5, 21, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (6, 6, 7, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (7, 7, 8, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (8, 8, 21, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (9, 9, 10, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (10, 10, 11, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (11, 11, 12, '2024-12-31 18:20:15', '0');
INSERT INTO `follow` VALUES (12, 12, 13, '2024-12-31 18:20:15', '0');

-- ----------------------------
-- Table structure for like
-- ----------------------------
DROP TABLE IF EXISTS `like`;
CREATE TABLE `like`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个点赞记录，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '进行点赞的用户ID，外键，关联用户实体（User）',
  `like_object_id` bigint NULL DEFAULT NULL COMMENT '被点赞的对象ID，外键，关联对应的对象实体（如帖子、合集、评论）',
  `like_object_type` int NULL DEFAULT NULL COMMENT '喜欢对象类型，1表示帖子，2表示合集，3表示评论',
  `like_time` datetime NULL DEFAULT NULL COMMENT '用户点赞的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除标识，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_like_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `fk_like_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of like
-- ----------------------------
INSERT INTO `like` VALUES (21, 1, 1, 1, '2024-06-01 10:15:00', 0);
INSERT INTO `like` VALUES (22, 2, 2, 2, '2024-06-02 11:30:25', 0);
INSERT INTO `like` VALUES (23, 3, 3, 3, '2024-06-03 14:45:10', 1);
INSERT INTO `like` VALUES (24, 4, 4, 1, '2024-06-04 16:20:35', 0);
INSERT INTO `like` VALUES (25, 5, 5, 2, '2024-06-05 18:05:50', 1);
INSERT INTO `like` VALUES (26, 6, 6, 3, '2024-06-06 19:40:15', 0);
INSERT INTO `like` VALUES (27, 7, 7, 1, '2024-06-07 21:55:45', 0);
INSERT INTO `like` VALUES (28, 8, 8, 2, '2024-06-08 23:10:30', 1);
INSERT INTO `like` VALUES (29, 9, 9, 3, '2024-06-09 08:25:55', 0);
INSERT INTO `like` VALUES (30, 10, 10, 1, '2024-06-10 09:35:20', 0);
INSERT INTO `like` VALUES (31, 11, 11, 2, '2024-06-11 10:50:45', 1);
INSERT INTO `like` VALUES (32, 12, 12, 3, '2024-06-12 12:15:30', 0);
INSERT INTO `like` VALUES (33, 13, 13, 1, '2024-06-13 14:25:10', 0);
INSERT INTO `like` VALUES (34, 14, 14, 2, '2024-06-14 15:30:45', 1);
INSERT INTO `like` VALUES (35, 15, 15, 3, '2024-06-15 17:45:00', 0);
INSERT INTO `like` VALUES (36, 16, 16, 1, '2024-06-16 19:00:25', 0);
INSERT INTO `like` VALUES (37, 17, 17, 2, '2024-06-17 21:15:40', 1);
INSERT INTO `like` VALUES (38, 18, 18, 3, '2024-06-18 22:20:55', 0);
INSERT INTO `like` VALUES (39, 19, 19, 1, '2024-06-19 23:35:30', 0);
INSERT INTO `like` VALUES (40, 20, 20, 2, '2024-06-20 08:50:15', 1);
INSERT INTO `like` VALUES (41, 21, 1, 1, '2024-06-21 09:00:00', 0);
INSERT INTO `like` VALUES (42, 21, 2, 2, '2024-06-21 10:15:25', 1);
INSERT INTO `like` VALUES (43, 21, 3, 3, '2024-06-21 11:30:50', 0);
INSERT INTO `like` VALUES (44, 21, 4, 1, '2024-06-21 12:45:15', 1);
INSERT INTO `like` VALUES (45, 21, 5, 2, '2024-06-21 14:00:30', 0);
INSERT INTO `like` VALUES (46, 21, 6, 3, '2024-06-21 15:15:45', 1);

-- ----------------------------
-- Table structure for notification
-- ----------------------------
DROP TABLE IF EXISTS `notification`;
CREATE TABLE `notification`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条消息通知记录',
  `user_sender_id` bigint NULL DEFAULT NULL COMMENT '发送通知的用户或系统ID，关联用户表的id，若为系统通知可空或为系统账户',
  `user_receiver_id` bigint NULL DEFAULT NULL COMMENT '接收通知的用户ID，关联用户表的id',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '通知的标题或主题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '通知的具体内容或消息',
  `type` int NULL DEFAULT NULL COMMENT '通知类型，1代表评论回复，2代表点赞，3代表系统通知',
  `status` int NULL DEFAULT NULL COMMENT '通知状态，0代表未读，1代表已读',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '通知创建的时间',
  `read_time` datetime NULL DEFAULT NULL COMMENT '通知被阅读的时间，未读则为空',
  `is_deleted` int NULL DEFAULT NULL COMMENT '区分位，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_notification_user_sender_id`(`user_sender_id` ASC) USING BTREE,
  INDEX `fk_notification_user_receiver_id`(`user_receiver_id` ASC) USING BTREE,
  CONSTRAINT `fk_notification_user_receiver_id` FOREIGN KEY (`user_receiver_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notification_user_sender_id` FOREIGN KEY (`user_sender_id`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 73 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notification
-- ----------------------------
INSERT INTO `notification` VALUES (55, NULL, 21, '你的帖子有新评论', '你发布的帖子《如何学习编程》有新评论，快去查看吧！', 1, 0, '2025-01-01 10:00:00', NULL, 0);
INSERT INTO `notification` VALUES (56, 15, 21, '点赞提醒', '用户15给你的帖子《Python编程指南》点赞了！', 2, 0, '2025-01-01 12:00:00', NULL, 0);
INSERT INTO `notification` VALUES (57, NULL, 1, '系统通知', '你有一条系统消息，需要处理！', 3, 0, '2025-01-01 14:00:00', NULL, 0);
INSERT INTO `notification` VALUES (58, NULL, 21, '你有新私信', '用户22给你发送了一个私信，快去查看吧！', 3, 0, '2025-01-02 09:00:00', NULL, 0);
INSERT INTO `notification` VALUES (59, 21, 21, '帖子内容更新', '你发布的帖子《编程技巧分享》已被编辑，内容已更新。', 3, 1, '2025-01-02 11:00:00', '2025-01-02 12:00:00', 0);
INSERT INTO `notification` VALUES (60, 21, 1, '评论回复提醒', '你发布的评论在帖子《如何学好Java》中有新回复，请查看！', 1, 1, '2025-01-02 15:00:00', '2025-01-02 16:00:00', 0);
INSERT INTO `notification` VALUES (61, NULL, 1, '点赞提醒', '用户25点赞了你的评论《如何写好代码》', 2, 0, '2025-01-03 08:00:00', NULL, 0);
INSERT INTO `notification` VALUES (62, NULL, 21, '新帖子发布', '用户30发布了新帖子《如何高效学习》, 快去查看！', 3, 0, '2025-01-03 09:30:00', NULL, 0);
INSERT INTO `notification` VALUES (63, 21, 20, '评论提醒', '你对帖子《C++编程技巧》下的评论获得了新回复。', 1, 0, '2025-01-03 10:00:00', NULL, 0);
INSERT INTO `notification` VALUES (64, 19, 21, '帖子举报', '你的帖子《编程入门》被举报，系统正在审核中。', 3, 1, '2025-01-03 12:00:00', '2025-01-03 12:15:00', 0);
INSERT INTO `notification` VALUES (65, 21, 21, '系统升级提醒', '系统将在24小时内进行维护，期间可能会有短暂的停机。', 3, 0, '2025-01-03 14:00:00', NULL, 0);
INSERT INTO `notification` VALUES (66, 21, 1, '账户信息更新', '你的账户信息已成功更新。', 3, 1, '2025-01-03 15:00:00', '2025-01-03 15:05:00', 0);
INSERT INTO `notification` VALUES (67, 21, 2, '新评论提醒', '你对帖子《深入理解计算机网络》的评论有新的回复，快去查看！', 1, 1, '2025-01-04 09:00:00', '2025-01-04 09:05:00', 0);
INSERT INTO `notification` VALUES (68, 21, 3, '评论回复提醒', '你的评论《如何优化代码》获得了新的回复。', 1, 1, '2025-01-04 12:00:00', '2025-01-04 12:10:00', 0);
INSERT INTO `notification` VALUES (69, NULL, 21, '好友请求', '用户28向你发送了好友请求，快去查看吧！', 3, 0, '2025-01-04 15:30:00', NULL, 0);
INSERT INTO `notification` VALUES (70, 21, 21, '系统消息', '您的账号将在1小时后进行安全检查，请勿操作不明链接。', 3, 1, '2025-01-05 08:00:00', '2025-01-05 08:05:00', 0);
INSERT INTO `notification` VALUES (71, 21, 21, '评论提醒', '你对帖子《深入理解Java》下的评论被点赞了，快来看看！', 2, 0, '2025-01-05 10:00:00', NULL, 0);
INSERT INTO `notification` VALUES (72, 21, 21, '系统通知', '您的账户存在异常登录尝试，建议更改密码。', 3, 0, '2025-01-05 12:00:00', NULL, 0);

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个帖子，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '关联用户表的id，发布帖子的用户ID',
  `section_id` bigint NULL DEFAULT NULL COMMENT '关联分区表的id，帖子所属的分区ID',
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '帖子的标签，用于分类和搜索，可以是多个标签的字符串，例如 \"标签1, 标签2\"',
  `cover` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '帖子封面图片的路径或URL',
  `summary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '帖子内容的简短描述，用于快速预览',
  `citation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '帖子中引用的其他内容或来源的详细信息',
  `collection_id` bigint NULL DEFAULT NULL COMMENT '关联合集表的id，帖子所属的合集ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '帖子的标题',
  `content_file_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'minio的文件id，用于标识富文本内容的文件',
  `content_file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT 'minio文件的路径，指向富文本内容的文件',
  `publish_time` datetime NULL DEFAULT NULL COMMENT '帖子发布的时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '帖子最后一次更新的时间',
  `view_count` int NULL DEFAULT NULL COMMENT '帖子被浏览的次数',
  `comment_count` int NULL DEFAULT NULL COMMENT '帖子下的评论数量',
  `like_count` int NULL DEFAULT NULL COMMENT '帖子获得的点赞数量',
  `share_count` int NULL DEFAULT NULL COMMENT '帖子被分享的次数',
  `status` int NULL DEFAULT NULL COMMENT '帖子的状态，1表示已发布，0表示草稿',
  `is_pinned` int NULL DEFAULT NULL COMMENT '区分位，表示帖子是否被置顶显示，1表示是，0表示否',
  `is_essence` int NULL DEFAULT NULL COMMENT '区分位，表示帖子是否被标记为精华，1表示是，0表示否',
  `visibility` int NULL DEFAULT NULL COMMENT '定义谁可以查看帖子，0：自己；1：公开',
  `review_status` int NULL DEFAULT NULL COMMENT '审核状态，0-待审核，1-已通过，2-已拒绝',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除字段，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_p_publish_time`(`publish_time` ASC) USING BTREE,
  INDEX `idx_p_update_time`(`update_time` ASC) USING BTREE,
  INDEX `fk_post_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_post_section_id`(`section_id` ASC) USING BTREE,
  INDEX `fk_post_collection_id`(`collection_id` ASC) USING BTREE,
  CONSTRAINT `fk_post_collection_id` FOREIGN KEY (`collection_id`) REFERENCES `collection` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_post_section_id` FOREIGN KEY (`section_id`) REFERENCES `section` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_post_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 146 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (24, 12, 11, '健康, 营养', 'path/to/cover12.jpg', '关于营养的帖子', '引用来源12', NULL, '健康饮食和营养', 'file_id_12', 'path/to/content12', '2024-01-12 08:00:00', '2024-01-12 08:00:00', 650, 131, 160, 60, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (101, 1, 1, '科技,前沿科技', 'path/to/cover1.jpg', '这是一个关于编程的帖子', '引用来源1', NULL, '编程入门教程', 'file_id_1', 'path/to/content1', '2025-01-01 10:00:00', '2025-01-01 10:00:00', 100, 20, 50, 5, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (102, 2, 1, 'AI, 机器学习', 'path/to/cover2.jpg', '关于机器学习的帖子', '引用来源2', NULL, '机器学习进阶', 'file_id_2', 'path/to/content2', '2025-01-02 14:30:25', '2025-01-02 14:30:25', 150, 30, 60, 10, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (103, 3, 2, '健康, 运动', 'path/to/cover3.jpg', '关于健康的帖子', '引用来源3', NULL, '健康生活方式', 'file_id_3', 'path/to/content3', '2025-01-03 18:45:10', '2025-01-03 18:45:10', 200, 50, 70, 15, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (104, 11, 10, '教育, 学习', 'path/to/cover11.jpg', '教育培训相关的帖子', '引用来源11', NULL, '在线教育平台推荐', 'file_id_11', 'path/to/content11', '2024-01-11 19:35:55', '2024-01-11 19:35:55', 600, 120, 150, 55, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (106, 4, 3, '旅行, 探索', 'path/to/cover4.jpg', '旅行相关的帖子', '引用来源4', NULL, '全球旅游推荐', 'file_id_4', 'path/to/content4', '2025-01-04 09:15:55', '2025-01-04 09:15:55', 250, 40, 80, 20, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (107, 5, 4, '美食, 健康', 'path/to/cover5.jpg', '关于美食的帖子', '引用来源5', NULL, '美食与健康', 'file_id_5', 'path/to/content5', '2024-01-05 21:50:20', '2024-01-05 21:50:20', 300, 60, 90, 25, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (108, 6, 5, '电影, 娱乐', 'path/to/cover6.jpg', '关于电影的帖子', '引用来源6', NULL, '电影推荐清单', 'file_id_6', 'path/to/content6', '2024-01-06 11:20:33', '2024-01-06 11:20:33', 350, 70, 100, 30, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (109, 7, 6, '前沿科技, 电子', 'path/to/cover7.jpg', '电子产品相关的帖子', '引用来源7', NULL, '最新电子产品测评', 'file_id_7', 'path/to/content7', '2024-01-07 16:45:50', '2024-01-07 16:45:50', 400, 80, 110, 35, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (110, 8, 7, '编程, 软件开发', 'path/to/cover8.jpg', '关于软件开发的帖子', '引用来源8', NULL, '软件开发最佳实践', 'file_id_8', 'path/to/content8', '2024-01-08 08:00:00', '2024-01-08 08:00:00', 450, 90, 120, 40, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (111, 9, 8, '艺术, 设计', 'path/to/cover9.jpg', '关于艺术的帖子', '引用来源9', NULL, '现代艺术趋势', 'file_id_9', 'path/to/content9', '2024-01-09 00:15:30', '2024-01-09 00:15:30', 500, 100, 130, 45, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (112, 10, 9, '运动, 健身', 'path/to/cover10.jpg', '健身相关的帖子', '引用来源10', NULL, '如何进行有效的健身训练', 'file_id_10', 'path/to/content10', '2024-01-10 13:25:45', '2024-01-10 13:25:45', 550, 110, 140, 50, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (122, 1, 1, '前沿科技, 编程', 'path/to/cover1.jpg', '这是一个关于编程的帖子', '引用来源1', NULL, '编程入门教程', 'file_id_1', 'path/to/content1', '2024-01-01 10:00:00', '2024-01-01 10:00:00', 100, 20, 50, 5, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (123, 2, 1, 'AI, 机器学习', 'path/to/cover2.jpg', '关于机器学习的帖子', '引用来源2', NULL, '机器学习进阶', 'file_id_2', 'path/to/content2', '2024-01-02 14:30:25', '2024-01-02 14:30:25', 150, 30, 60, 10, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (124, 3, 2, '健康, 运动', 'path/to/cover3.jpg', '关于健康的帖子', '引用来源3', NULL, '健康生活方式', 'file_id_3', 'path/to/content3', '2024-01-03 18:45:10', '2024-01-03 18:45:10', 200, 50, 70, 15, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (125, 4, 3, '旅行, 探索', 'path/to/cover4.jpg', '旅行相关的帖子', '引用来源4', NULL, '全球旅游推荐', 'file_id_4', 'path/to/content4', '2024-01-04 09:15:55', '2024-01-04 09:15:55', 250, 40, 80, 20, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (126, 5, 4, '美食, 健康', 'path/to/cover5.jpg', '关于美食的帖子', '引用来源5', NULL, '美食与健康', 'file_id_5', 'path/to/content5', '2024-01-05 21:50:20', '2024-01-05 21:50:20', 300, 60, 90, 25, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (127, 6, 5, '电影, 娱乐', 'path/to/cover6.jpg', '关于电影的帖子', '引用来源6', NULL, '电影推荐清单', 'file_id_6', 'path/to/content6', '2024-01-06 11:20:33', '2024-01-06 11:20:33', 350, 70, 100, 30, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (128, 7, 6, '科技, 电子', 'path/to/cover7.jpg', '电子产品相关的帖子', '引用来源7', NULL, '最新电子产品测评', 'file_id_7', 'path/to/content7', '2024-01-07 16:45:50', '2024-01-07 16:45:50', 400, 80, 110, 35, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (129, 8, 7, '编程, 软件开发', 'path/to/cover8.jpg', '关于软件开发的帖子', '引用来源8', NULL, '软件开发最佳实践', 'file_id_8', 'path/to/content8', '2024-01-08 08:00:00', '2024-01-08 08:00:00', 450, 90, 120, 40, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (130, 9, 8, '艺术, 设计', 'path/to/cover9.jpg', '关于艺术的帖子', '引用来源9', NULL, '现代艺术趋势', 'file_id_9', 'path/to/content9', '2024-01-09 00:15:30', '2024-01-09 00:15:30', 500, 100, 130, 45, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (131, 10, 9, '运动, 健身', 'path/to/cover10.jpg', '健身相关的帖子', '引用来源10', NULL, '如何进行有效的健身训练', 'file_id_10', 'path/to/content10', '2024-01-10 13:25:45', '2024-01-10 13:25:45', 550, 110, 140, 50, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (132, 11, 10, '教育, 学习', 'path/to/cover11.jpg', '教育培训相关的帖子', '引用来源11', NULL, '在线教育平台推荐', 'file_id_11', 'path/to/content11', '2024-01-11 19:35:55', '2024-01-11 19:35:55', 600, 120, 150, 55, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (133, 12, 11, '健康, 营养', 'path/to/cover12.jpg', '关于营养的帖子', '引用来源12', NULL, '健康饮食和营养', 'file_id_12', 'path/to/content12', '2024-01-12 08:00:00', '2024-01-12 08:00:00', 650, 130, 160, 60, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (134, 1, 1, '科技, 编程', 'path/to/cover1.jpg', '这是一个关于编程的帖子', '引用来源1', NULL, '编程入门教程', 'file_id_1', 'path/to/content1', '2024-01-01 10:00:00', '2024-01-01 10:00:00', 100, 20, 50, 5, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (135, 2, 1, 'AI, 机器学习', 'path/to/cover2.jpg', '关于机器学习的帖子', '引用来源2', NULL, '机器学习进阶', 'file_id_2', 'path/to/content2', '2024-01-02 14:30:25', '2024-01-02 14:30:25', 150, 30, 60, 10, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (136, 3, 2, '健康, 运动', 'path/to/cover3.jpg', '关于健康的帖子', '引用来源3', NULL, '健康生活方式', 'file_id_3', 'path/to/content3', '2024-01-03 18:45:10', '2024-01-03 18:45:10', 200, 50, 70, 15, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (137, 4, 3, '旅行, 探索', 'path/to/cover4.jpg', '旅行相关的帖子', '引用来源4', NULL, '全球旅游推荐', 'file_id_4', 'path/to/content4', '2024-01-04 09:15:55', '2024-01-04 09:15:55', 250, 40, 80, 20, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (138, 5, 4, '美食, 健康', 'path/to/cover5.jpg', '关于美食的帖子', '引用来源5', NULL, '美食与健康', 'file_id_5', 'path/to/content5', '2024-01-05 21:50:20', '2024-01-05 21:50:20', 300, 60, 90, 25, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (139, 6, 5, '电影, 娱乐', 'path/to/cover6.jpg', '关于电影的帖子', '引用来源6', NULL, '电影推荐清单', 'file_id_6', 'path/to/content6', '2024-01-06 11:20:33', '2024-01-06 11:20:33', 350, 70, 100, 30, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (140, 7, 6, '科技, 电子', 'path/to/cover7.jpg', '电子产品相关的帖子', '引用来源7', NULL, '最新电子产品测评', 'file_id_7', 'path/to/content7', '2024-01-07 16:45:50', '2024-01-07 16:45:50', 400, 80, 110, 35, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (141, 8, 7, '编程, 软件开发', 'path/to/cover8.jpg', '关于软件开发的帖子', '引用来源8', NULL, '软件开发最佳实践', 'file_id_8', 'path/to/content8', '2024-01-08 08:00:00', '2024-01-08 08:00:00', 450, 90, 120, 40, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (142, 9, 8, '艺术, 设计', 'path/to/cover9.jpg', '关于艺术的帖子', '引用来源9', NULL, '现代艺术趋势', 'file_id_9', 'path/to/content9', '2024-01-09 00:15:30', '2024-01-09 00:15:30', 500, 100, 130, 45, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (143, 10, 9, '运动, 健身', 'path/to/cover10.jpg', '健身相关的帖子', '引用来源10', NULL, '如何进行有效的健身训练', 'file_id_10', 'path/to/content10', '2024-01-10 13:25:45', '2024-01-10 13:25:45', 550, 110, 140, 50, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (144, 11, 10, '教育, 学习', 'path/to/cover11.jpg', '教育培训相关的帖子', '引用来源11', NULL, '在线教育平台推荐', 'file_id_11', 'path/to/content11', '2024-01-11 19:35:55', '2024-01-11 19:35:55', 600, 120, 150, 55, 1, 0, 0, 1, 1, 0);
INSERT INTO `post` VALUES (145, 12, 11, '健康, 营养', 'path/to/cover12.jpg', '关于营养的发帖子', '引用来源12', NULL, '健康饮食和营养', 'file_id_12', 'path/to/content12', '2024-01-12 08:00:00', '2024-01-12 08:00:00', 650, 130, 160, 60, 1, 0, 0, 1, 1, 0);

-- ----------------------------
-- Table structure for post_citations
-- ----------------------------
DROP TABLE IF EXISTS `post_citations`;
CREATE TABLE `post_citations`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，自增',
  `citation_post_id` bigint NULL DEFAULT NULL COMMENT '关联引用表的帖子ID',
  `post_citation_id` bigint NULL DEFAULT NULL COMMENT '关联帖子表的引用ID',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除标识，0表示未删除，1表示已删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_pc_citation_post_id`(`citation_post_id` ASC) USING BTREE,
  INDEX `fk_pc_post_citation_id`(`post_citation_id` ASC) USING BTREE,
  CONSTRAINT `fk_pc_citation_post_id` FOREIGN KEY (`citation_post_id`) REFERENCES `citation` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pc_post_citation_id` FOREIGN KEY (`post_citation_id`) REFERENCES `post` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of post_citations
-- ----------------------------

-- ----------------------------
-- Table structure for report
-- ----------------------------
DROP TABLE IF EXISTS `report`;
CREATE TABLE `report`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条举报记录，即举报ID（report_id）',
  `user_id` bigint NULL DEFAULT NULL COMMENT '进行举报的用户ID，外键，关联用户实体（User）的id',
  `reported_content_id` bigint NULL DEFAULT NULL COMMENT '被举报的内容ID，具体取决于被举报的对象类型',
  `reported_type_id` bigint NULL DEFAULT NULL COMMENT '标识被举报内容的类型，外键，关联举报对象类型实体（ReportedType）的id',
  `report_type_id` bigint NULL DEFAULT NULL COMMENT '标识举报的类型，外键，关联举报类型实体（ReportType）的id',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户举报的具体理由或描述',
  `report_time` datetime NULL DEFAULT NULL COMMENT '用户提交举报的时间',
  `status` int NULL DEFAULT NULL COMMENT '举报的处理状态，0：待处理，1：正在处理，2：已处理，3：无需处理',
  `outcome` int NULL DEFAULT NULL COMMENT '举报处理的结果，0：无行动，1：内容已删除，2：警告用户，3：用户禁言，4：用户封禁',
  `is_deleted` int NULL DEFAULT NULL COMMENT '区分位，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_r_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_r_reported_type_id`(`reported_type_id` ASC) USING BTREE,
  INDEX `fk_r_report_type_id`(`report_type_id` ASC) USING BTREE,
  INDEX `idx_r_report_time`(`report_time` ASC) USING BTREE,
  CONSTRAINT `fk_r_report_type_id` FOREIGN KEY (`report_type_id`) REFERENCES `report_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_r_reported_type_id` FOREIGN KEY (`reported_type_id`) REFERENCES `reported_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_r_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of report
-- ----------------------------
INSERT INTO `report` VALUES (1, 21, 1, 2, 2, '他叫我举报他', '2025-01-05 17:06:19', 0, 0, 0);

-- ----------------------------
-- Table structure for report_type
-- ----------------------------
DROP TABLE IF EXISTS `report_type`;
CREATE TABLE `report_type`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个举报类型，即举报类型ID（report_type_id）',
  `type_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '举报类型的名称，如不当言论、色情内容、抄袭、欺诈行为等',
  `type_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '对举报类型进行详细描述，包括该类型的具体定义和举报标准',
  `is_active` int NULL DEFAULT NULL COMMENT '区分位，1表示启用，0表示未启用',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_rt_type_name`(`type_name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of report_type
-- ----------------------------
INSERT INTO `report_type` VALUES (1, '不当言论', '包括发表的言论中存在歧视、侮辱、攻击他人或群体的内容，违反社会公德和法律法规。', 1);
INSERT INTO `report_type` VALUES (2, '色情内容', '包含色情、淫秽、低俗的图片、视频或文字内容，违反社会道德和法律法规。', 1);
INSERT INTO `report_type` VALUES (3, '抄袭', '未经原作者同意，将他人的作品或内容作为自己的作品发布，侵犯了原作者的版权。', 1);
INSERT INTO `report_type` VALUES (4, '欺诈行为', '通过虚假信息、诈骗手段等骗取他人财物或利益，违反法律法规。', 1);
INSERT INTO `report_type` VALUES (5, '虚假信息', '发布虚假的新闻、谣言、不实信息等，误导他人，扰乱社会秩序。', 1);
INSERT INTO `report_type` VALUES (6, '暴力内容', '展示暴力、血腥、恐怖等画面或内容，可能对他人造成心理伤害。', 1);
INSERT INTO `report_type` VALUES (7, '骚扰他人', '通过私信、评论等方式对他人进行骚扰、威胁、恐吓等行为。', 1);
INSERT INTO `report_type` VALUES (8, '广告垃圾', '发布大量无关的广告、垃圾信息，干扰正常用户使用体验。', 1);
INSERT INTO `report_type` VALUES (9, '恶意攻击', '对平台或他人进行恶意攻击、破坏，如恶意刷单、恶意举报等。', 1);
INSERT INTO `report_type` VALUES (10, '其他', '不属于以上类型的其他违规行为或内容。', 1);
INSERT INTO `report_type` VALUES (11, '测试类型', '用于测试目的的举报类型，不适用于实际举报。', 0);

-- ----------------------------
-- Table structure for reported_type
-- ----------------------------
DROP TABLE IF EXISTS `reported_type`;
CREATE TABLE `reported_type`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个举报对象类型，即举报对象类型ID（reported_type_id）',
  `type_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '举报对象类型的名称，如帖子、评论、用户等',
  `type_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '对举报对象类型进行详细描述，包括该类型的对象范围和特点',
  `is_active` int NULL DEFAULT NULL COMMENT '区分位，1表示启用，0表示未启用',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_rpt_type_name`(`type_name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of reported_type
-- ----------------------------
INSERT INTO `reported_type` VALUES (1, '帖子', '用户在平台上发布的文章或内容，可以是文字、图片、视频等多种形式。', 1);
INSERT INTO `reported_type` VALUES (2, '评论', '用户对帖子或其他评论的回复，通常为文字形式，用于表达观点或交流。', 1);
INSERT INTO `reported_type` VALUES (3, '用户', '平台上的注册用户，包括其个人资料、头像、昵称等信息。', 1);
INSERT INTO `reported_type` VALUES (4, '视频', '用户上传的视频内容，可以是原创视频或转载视频。', 1);
INSERT INTO `reported_type` VALUES (5, '图片', '用户上传的图片内容，可以是摄影作品、截图等。', 1);
INSERT INTO `reported_type` VALUES (6, '动态', '用户发布的简短动态信息，通常包含文字和图片，用于分享生活点滴。', 1);
INSERT INTO `reported_type` VALUES (7, '直播', '用户进行的直播活动，可以是游戏直播、生活直播等。', 1);
INSERT INTO `reported_type` VALUES (8, '文章', '用户发布的长篇文章，通常包含详细的文字内容和图片。', 1);
INSERT INTO `reported_type` VALUES (9, '问答', '用户在问答板块提出的或回答的问题，用于交流知识和经验。', 1);
INSERT INTO `reported_type` VALUES (10, '群组', '用户创建的群组，用于特定主题的讨论和交流。', 1);
INSERT INTO `reported_type` VALUES (11, '测试对象', '用于测试目的的举报对象类型，不适用于实际举报。', 0);

-- ----------------------------
-- Table structure for section
-- ----------------------------
DROP TABLE IF EXISTS `section`;
CREATE TABLE `section`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个分区，自增',
  `section_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '分区的名称，用于用户识别和展示',
  `section_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '分区的详细描述，可以包含分区的主题、目的和包含内容的概述',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '分区创建的时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '分区信息最后一次更新的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '表示分区是否被删除，1表示是，0表示否',
  `visibility` int NULL DEFAULT NULL COMMENT '分区的可见性，0表示隐藏，1表示公开',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of section
-- ----------------------------
INSERT INTO `section` VALUES (1, '科技', '关于科技和创新的讨论', '2024-01-01 10:00:00', '2024-01-01 10:00:00', 0, 1);
INSERT INTO `section` VALUES (2, 'AI与机器学习', '人工智能与机器学习相关内容', '2024-01-02 14:30:25', '2024-01-02 14:30:25', 0, 1);
INSERT INTO `section` VALUES (3, '健康与运动', '关于健康、健身和运动的内容', '2024-01-03 18:45:10', '2024-01-03 18:45:10', 0, 1);
INSERT INTO `section` VALUES (4, '旅行', '全球旅行和旅游的推荐与体验', '2024-01-04 09:15:55', '2024-01-04 09:15:55', 0, 1);
INSERT INTO `section` VALUES (5, '美食', '关于美食和烹饪的讨论', '2024-01-05 21:50:20', '2024-01-05 21:50:20', 0, 1);
INSERT INTO `section` VALUES (6, '电影与娱乐', '最新电影和娱乐行业资讯', '2024-01-06 11:20:33', '2024-01-06 11:20:33', 0, 1);
INSERT INTO `section` VALUES (7, '科技产品', '最新的电子科技产品和测评', '2024-01-07 16:45:50', '2024-01-07 16:45:50', 0, 1);
INSERT INTO `section` VALUES (8, '艺术与设计', '现代艺术和设计趋势', '2024-01-08 08:00:00', '2024-01-08 08:00:00', 0, 1);
INSERT INTO `section` VALUES (9, '运动', '健身与运动技巧', '2024-01-09 00:15:30', '2024-01-09 00:15:30', 0, 1);
INSERT INTO `section` VALUES (10, '教育', '在线教育平台与学习资源', '2024-01-10 13:25:45', '2024-01-10 13:25:45', 0, 1);
INSERT INTO `section` VALUES (11, '营养与健康', '营养学与健康生活方式的内容', '2024-01-11 19:35:55', '2024-01-11 19:35:55', 0, 1);
INSERT INTO `section` VALUES (12, '科技', '关于科技和创新的讨论', '2024-01-01 10:00:00', '2024-01-01 10:00:00', 0, 1);
INSERT INTO `section` VALUES (13, 'AI与机器学习', '人工智能与机器学习相关内容', '2024-01-02 14:30:25', '2024-01-02 14:30:25', 0, 1);
INSERT INTO `section` VALUES (14, '健康与运动', '关于健康、健身和运动的内容', '2024-01-03 18:45:10', '2024-01-03 18:45:10', 0, 1);
INSERT INTO `section` VALUES (15, '旅行', '全球旅行和旅游的推荐与体验', '2024-01-04 09:15:55', '2024-01-04 09:15:55', 0, 1);
INSERT INTO `section` VALUES (16, '美食', '关于美食和烹饪的讨论', '2024-01-05 21:50:20', '2024-01-05 21:50:20', 0, 1);
INSERT INTO `section` VALUES (17, '电影与娱乐', '最新电影和娱乐行业资讯', '2024-01-06 11:20:33', '2024-01-06 11:20:33', 0, 1);
INSERT INTO `section` VALUES (18, '科技产品', '最新的电子科技产品和测评', '2024-01-07 16:45:50', '2024-01-07 16:45:50', 0, 1);
INSERT INTO `section` VALUES (19, '艺术与设计', '现代艺术和设计趋势', '2024-01-08 08:00:00', '2024-01-08 08:00:00', 0, 1);
INSERT INTO `section` VALUES (20, '运动', '健身与运动技巧', '2024-01-09 00:15:30', '2024-01-09 00:15:30', 0, 1);
INSERT INTO `section` VALUES (21, '教育', '在线教育平台与学习资源', '2024-01-10 13:25:45', '2024-01-10 13:25:45', 0, 1);
INSERT INTO `section` VALUES (22, '营养与健康', '营养学与健康生活方式的内容', '2024-01-11 19:35:55', '2024-01-11 19:35:55', 0, 1);

-- ----------------------------
-- Table structure for share
-- ----------------------------
DROP TABLE IF EXISTS `share`;
CREATE TABLE `share`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个分享记录，自增',
  `user_id` bigint NULL DEFAULT NULL COMMENT '进行分享的用户ID，外键，关联用户实体（User）',
  `share_object_id` bigint NULL DEFAULT NULL COMMENT '被分享的对象ID，外键，关联对应的对象实体（如帖子、合集）',
  `share_object_type` int NULL DEFAULT NULL COMMENT '分享对象类型，1表示帖子，2表示合集',
  `share_link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '分享内容生成的链接，用于追踪分享内容',
  `share_time` datetime NULL DEFAULT NULL COMMENT '用户分享的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '逻辑删除标识，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_share_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `fk_share_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of share
-- ----------------------------
INSERT INTO `share` VALUES (1, 21, 101, 1, 'http://example.com/share/101', '2025-01-01 10:00:00', 0);
INSERT INTO `share` VALUES (2, 21, 102, 2, 'http://example.com/share/102', '2025-01-02 11:00:00', 0);
INSERT INTO `share` VALUES (3, 21, 103, 1, 'http://example.com/share/103', '2025-01-03 12:00:00', 0);
INSERT INTO `share` VALUES (4, 21, 104, 1, 'http://example.com/share/104', '2025-01-04 13:00:00', 0);
INSERT INTO `share` VALUES (5, 21, 105, 2, 'http://example.com/share/105', '2025-01-05 14:00:00', 0);
INSERT INTO `share` VALUES (6, 21, 106, 1, 'http://example.com/share/106', '2025-01-06 15:00:00', 0);
INSERT INTO `share` VALUES (15, 2, 107, 1, 'http://example.com/share/107', '2025-01-07 16:00:00', 0);
INSERT INTO `share` VALUES (16, 2, 108, 2, 'http://example.com/share/108', '2025-01-08 17:00:00', 0);
INSERT INTO `share` VALUES (17, 3, 109, 1, 'http://example.com/share/109', '2025-01-09 18:00:00', 0);
INSERT INTO `share` VALUES (18, 3, 110, 2, 'http://example.com/share/110', '2025-01-10 19:00:00', 0);
INSERT INTO `share` VALUES (19, 4, 111, 1, 'http://example.com/share/111', '2025-01-11 20:00:00', 0);
INSERT INTO `share` VALUES (20, 4, 112, 2, 'http://example.com/share/112', '2025-01-12 21:00:00', 0);
INSERT INTO `share` VALUES (21, 5, 113, 1, 'http://example.com/share/113', '2025-01-13 22:00:00', 0);
INSERT INTO `share` VALUES (22, 5, 114, 2, 'http://example.com/share/114', '2025-01-14 23:00:00', 0);

-- ----------------------------
-- Table structure for tag
-- ----------------------------
DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个标签，自增',
  `tag_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标签的名称，用于用户识别和展示，应该是唯一的',
  `tag_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标签的详细描述，可以包含标签所代表的主题或分类的额外信息',
  `section_id` bigint NULL DEFAULT NULL COMMENT '标签所属的分区ID，关联分区表section的id',
  `creation_time` datetime NULL DEFAULT NULL COMMENT '标签创建的时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '标签信息最后一次更新的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '表示标签是否被删除，1表示是，0表示否',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_t_section_id`(`section_id` ASC) USING BTREE,
  CONSTRAINT `fk_tag_section_id` FOREIGN KEY (`section_id`) REFERENCES `section` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of tag
-- ----------------------------
INSERT INTO `tag` VALUES (1, '前沿科技', '关注最新的科技前沿动态和创新成果', 1, '2024-01-01 10:00:00', '2024-01-01 10:00:00', 0);
INSERT INTO `tag` VALUES (2, '科技创新', '探讨科技创新的理念、方法和案例', 1, '2024-01-01 10:05:00', '2024-01-01 10:05:00', 0);
INSERT INTO `tag` VALUES (3, '科技趋势', '分析科技行业的发展趋势和未来方向', 1, '2024-01-01 10:10:00', '2024-01-01 10:10:00', 0);
INSERT INTO `tag` VALUES (4, '深度学习', '研究深度学习算法和模型的应用与发展', 2, '2024-01-02 14:30:25', '2024-01-02 14:30:25', 0);
INSERT INTO `tag` VALUES (5, '机器学习框架', '介绍主流的机器学习框架和工具', 2, '2024-01-02 14:35:00', '2024-01-02 14:35:00', 0);
INSERT INTO `tag` VALUES (6, '自然语言处理', '探索自然语言处理技术在AI领域的应用', 2, '2024-01-02 14:40:00', '2024-01-02 14:40:00', 0);
INSERT INTO `tag` VALUES (7, '健康饮食', '分享健康饮食的建议和食谱', 3, '2024-01-03 18:45:10', '2024-01-03 18:45:10', 0);
INSERT INTO `tag` VALUES (8, '运动健身', '介绍各种运动健身的方法和技巧', 3, '2024-01-03 18:50:00', '2024-01-03 18:50:00', 0);
INSERT INTO `tag` VALUES (9, '心理健康', '关注心理健康问题及其解决方法', 3, '2024-01-03 18:55:00', '2024-01-03 18:55:00', 0);
INSERT INTO `tag` VALUES (10, '旅游攻略', '提供世界各地的旅游攻略和建议', 4, '2024-01-04 09:15:55', '2024-01-04 09:15:55', 0);
INSERT INTO `tag` VALUES (11, '旅行摄影', '分享旅行中的摄影技巧和作品', 4, '2024-01-04 09:20:00', '2024-01-04 09:20:00', 0);
INSERT INTO `tag` VALUES (12, '文化体验', '体验不同国家和地区的文化风情', 4, '2024-01-04 09:25:00', '2024-01-04 09:25:00', 0);
INSERT INTO `tag` VALUES (13, '美食制作', '介绍各种美食的制作方法和技巧', 5, '2024-01-05 21:50:20', '2024-01-05 21:50:20', 0);
INSERT INTO `tag` VALUES (14, '食谱推荐', '推荐各种美味的食谱和食材搭配', 5, '2024-01-05 21:55:00', '2024-01-05 21:55:00', 0);
INSERT INTO `tag` VALUES (15, '美食文化', '探讨不同地区的美食文化和历史', 5, '2024-01-05 22:00:00', '2024-01-05 22:00:00', 0);
INSERT INTO `tag` VALUES (16, '最新电影', '关注最新的电影资讯和影评', 6, '2024-01-06 11:20:33', '2024-01-06 11:20:33', 0);
INSERT INTO `tag` VALUES (17, '明星动态', '追踪明星的最新动态和活动', 6, '2024-01-06 11:25:00', '2024-01-06 11:25:00', 0);
INSERT INTO `tag` VALUES (18, '娱乐八卦', '分享娱乐圈的八卦新闻和趣事', 6, '2024-01-06 11:30:00', '2024-01-06 11:30:00', 0);
INSERT INTO `tag` VALUES (19, '智能手机', '介绍最新的智能手机产品和测评', 7, '2024-01-07 16:45:50', '2024-01-07 16:45:50', 0);
INSERT INTO `tag` VALUES (20, '电脑硬件', '探讨电脑硬件的性能和升级技巧', 7, '2024-01-07 16:50:00', '2024-01-07 16:50:00', 0);
INSERT INTO `tag` VALUES (21, '可穿戴设备', '分享可穿戴设备的使用体验和功能', 7, '2024-01-07 16:55:00', '2024-01-07 16:55:00', 0);
INSERT INTO `tag` VALUES (22, '现代艺术', '展示现代艺术作品和艺术家', 8, '2024-01-08 08:00:00', '2024-01-08 08:00:00', 0);
INSERT INTO `tag` VALUES (23, '设计趋势', '分析设计行业的最新趋势和理念', 8, '2024-01-08 08:05:00', '2024-01-08 08:05:00', 0);
INSERT INTO `tag` VALUES (24, '创意设计', '分享创意设计作品和灵感', 8, '2024-01-08 08:10:00', '2024-01-08 08:10:00', 0);
INSERT INTO `tag` VALUES (25, '运动赛事', '关注各类运动赛事的动态和结果', 9, '2024-01-09 00:25:00', '2024-01-09 00:25:00', 0);
INSERT INTO `tag` VALUES (26, '运动技巧', '分享各种运动的技巧和注意事项', 9, '2024-01-09 00:30:00', '2024-01-09 00:30:00', 0);
INSERT INTO `tag` VALUES (27, '运动营养', '探讨运动营养对运动员的影响和建议', 9, '2024-01-09 00:35:00', '2024-01-09 00:35:00', 0);
INSERT INTO `tag` VALUES (28, '在线课程', '推荐优质的在线教育课程和平台', 10, '2024-01-10 13:25:45', '2024-01-10 13:25:45', 0);
INSERT INTO `tag` VALUES (29, '学习资源', '分享各种学习资源和资料', 10, '2024-01-10 13:30:00', '2024-01-10 13:30:00', 0);
INSERT INTO `tag` VALUES (30, '教育科技', '探讨教育科技在教育领域的应用', 10, '2024-01-10 13:35:00', '2024-01-10 13:35:00', 0);
INSERT INTO `tag` VALUES (31, '营养均衡', '介绍如何实现日常饮食的营养均衡', 11, '2024-01-11 19:35:55', '2024-01-11 19:35:55', 0);
INSERT INTO `tag` VALUES (32, '健康饮食计划', '分享个性化的健康饮食计划和建议', 11, '2024-01-11 19:40:00', '2024-01-11 19:40:00', 0);
INSERT INTO `tag` VALUES (33, '营养补充', '探讨营养补充剂的使用和效果', 11, '2024-01-11 19:45:00', '2024-01-11 19:45:00', 0);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一个用户，自增',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户名，用户登录的名称',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '密码，存储时为加密后的密码',
  `salt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '盐值，用于密码加密的盐值',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱，用户的电子邮箱地址',
  `phone_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '手机号，用户的手机号码',
  `registration_time` datetime NULL DEFAULT NULL COMMENT '注册时间，用户注册的时间',
  `last_login_time` datetime NULL DEFAULT NULL COMMENT '最后登录时间，用户最后一次登录的时间',
  `last_login_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '最后登录地点，用户最后一次登录的地点',
  `last_updated_time` datetime NULL DEFAULT NULL COMMENT '最后更新时间，用户资料最后一次更新的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '区分位，表示用户账户是否被删除，1表示是，0表示否',
  `is_admin` int NULL DEFAULT NULL COMMENT '区分位，表示用户是否是管理员，1表示是，0表示否',
  `is_frozen` int NULL DEFAULT NULL COMMENT '区分位，表示用户账户是否被冻结，1表示是，0表示否',
  `permission_level` int NULL DEFAULT NULL COMMENT '权限限制等级，0：正常；1：禁止评论；2：禁止发帖等，具体等级定义根据业务需求确定',
  `gender` int NULL DEFAULT NULL COMMENT '性别，0：男，1：女，2：其他，具体定义可根据业务需求扩展',
  `birth_date` date NULL DEFAULT NULL COMMENT '出生日期，用户的出生日期',
  `bio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '个人简介，用户个人简介或自我描述',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像，用户头像的路径或URL',
  `following_count` int NULL DEFAULT NULL COMMENT '关注数，用户关注的用户数量',
  `followers_count` int NULL DEFAULT NULL COMMENT '粉丝数，用户的粉丝数量',
  `review_status` int NULL DEFAULT NULL COMMENT '审核状态，0：待审核，1：已通过，2：已拒绝',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `uniq_u_username`(`username` ASC) USING BTREE,
  INDEX `idx_u_last_login_time`(`last_login_time` ASC) USING BTREE,
  INDEX `idx_u_last_updated_time`(`last_updated_time` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'alice', 'hashed_pw_1', 'salt1', 'alice@example.com', '12345678901', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Beijing', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1995-05-21', 'Hello, I am Alice.', '/avatars/alice.png', 5, 10, 1);
INSERT INTO `user` VALUES (2, 'bob', 'hashed_pw_2', 'salt2', 'bob@example.com', '12345678902', '2024-11-06 18:20:09', '2024-12-31 18:20:09', 'Shanghai', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1990-09-10', 'I am Bob.', '/avatars/bob.png', 3, 7, 1);
INSERT INTO `user` VALUES (3, 'charlie', 'hashed_pw_3', 'salt3', 'charlie@example.com', '12345678903', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Guangzhou', '2024-12-31 18:20:09', 0, 0, 0, 1, 0, '1988-12-12', 'Charlie here!', '/avatars/charlie.png', 7, 8, 1);
INSERT INTO `user` VALUES (4, 'david', 'hashed_pw_4', 'salt4', 'david@example.com', '12345678904', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Shenzhen', '2024-12-31 18:20:09', 0, 0, 0, 2, 1, '1993-03-03', 'Hi, I am David.', '/avatars/david.png', 2, 6, 1);
INSERT INTO `user` VALUES (5, 'emma', 'hashed_pw_5', 'salt5', 'emma@example.com', '12345678905', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Chengdu', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1997-07-17', 'Emma here!', '/avatars/emma.png', 6, 9, 1);
INSERT INTO `user` VALUES (6, 'frank', 'hashed_pw_6', 'salt6', 'frank@example.com', '12345678906', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Wuhan', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1992-02-22', 'Frank speaking.', '/avatars/frank.png', 1, 4, 1);
INSERT INTO `user` VALUES (7, 'grace', 'hashed_pw_7', 'salt7', 'grace@example.com', '12345678907', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Hangzhou', '2024-12-31 18:20:09', 0, 0, 0, 1, 1, '1991-11-11', 'I am Grace.', '/avatars/grace.png', 4, 5, 1);
INSERT INTO `user` VALUES (8, 'harry', 'hashed_pw_8', 'salt8', 'harry@example.com', '12345678908', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Nanjing', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1994-04-14', 'Hi, Harry here.', '/avatars/harry.png', 5, 6, 1);
INSERT INTO `user` VALUES (9, 'isabella', 'hashed_pw_9', 'salt9', 'isabella@example.com', '12345678909', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Xi\'an', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1996-06-16', 'Isabella online!', '/avatars/isabella.png', 8, 12, 1);
INSERT INTO `user` VALUES (10, 'jack', 'hashed_pw_10', 'salt10', 'jack@example.com', '12345678910', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Chongqing', '2024-12-31 18:20:09', 0, 0, 0, 2, 0, '1989-08-08', 'Hey, Jack here!', '/avatars/jack.png', 7, 11, 1);
INSERT INTO `user` VALUES (11, 'kate', 'hashed_pw_11', 'salt11', 'kate@example.com', '12345678911', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Harbin', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1998-01-25', 'This is Kate.', '/avatars/kate.png', 9, 13, 1);
INSERT INTO `user` VALUES (12, 'leo', 'hashed_pw_12', 'salt12', 'leo@example.com', '12345678912', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Changsha', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1990-10-10', 'Leo here!', '/avatars/leo.png', 3, 8, 1);
INSERT INTO `user` VALUES (13, 'mia', 'hashed_pw_13', 'salt13', 'mia@example.com', '12345678913', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Suzhou', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1999-09-09', 'I am Mia.', '/avatars/mia.png', 6, 10, 1);
INSERT INTO `user` VALUES (14, 'nick', 'hashed_pw_14', 'salt14', 'nick@example.com', '12345678914', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Qingdao', '2024-12-31 18:20:09', 0, 0, 0, 1, 0, '1992-12-20', 'Nick here.', '/avatars/nick.png', 4, 9, 1);
INSERT INTO `user` VALUES (15, 'olivia', 'hashed_pw_15', 'salt15', 'olivia@example.com', '12345678915', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Tianjin', '2024-12-31 18:20:09', 0, 0, 0, 0, 1, '1995-11-30', 'Hi, I am Olivia.', '/avatars/olivia.png', 8, 12, 1);
INSERT INTO `user` VALUES (16, 'peter', 'hashed_pw_16', 'salt16', 'peter@example.com', '12345678916', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Fuzhou', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1991-07-21', 'Peter here!', '/avatars/peter.png', 5, 7, 1);
INSERT INTO `user` VALUES (17, 'quinn', 'hashed_pw_17', 'salt17', 'quinn@example.com', '12345678917', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Jinan', '2024-12-31 18:20:09', 0, 0, 0, 2, 1, '1993-04-13', 'Quinn speaking.', '/avatars/quinn.png', 2, 5, 1);
INSERT INTO `user` VALUES (18, 'ryan', 'hashed_pw_18', 'salt18', 'ryan@example.com', '12345678918', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Dalian', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1997-02-28', 'Ryan here!', '/avatars/ryan.png', 7, 10, 1);
INSERT INTO `user` VALUES (19, 'sophia', 'hashed_pw_19', 'salt19', 'sophia@example.com', '12345678919', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Xiamen', '2024-12-31 18:20:09', 0, 0, 0, 1, 1, '1994-03-15', 'Sophia online!', '/avatars/sophia.png', 6, 11, 1);
INSERT INTO `user` VALUES (20, 'tom', 'hashed_pw_20', 'salt20', 'tom@example.com', '12345678920', '2024-12-31 18:20:09', '2024-12-31 18:20:09', 'Zhengzhou', '2024-12-31 18:20:09', 0, 0, 0, 0, 0, '1996-06-06', 'Hi, I am Tom.', '/avatars/tom.png', 8, 12, 1);
INSERT INTO `user` VALUES (21, 'abc', '{bcrypt}$2a$10$r1Qj1wQvChiQOMsAs8.r2.VKCfyjLyAGMYLQcAuywTHspbbUwAWqG', 'd0e0cc6d88d84f8a90b1b9aaff28816c', NULL, '13013060229', '2025-01-03 16:03:10', '2024-07-16 12:37:47', '本地主机', '2025-01-05 20:36:29', 0, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 1);

-- ----------------------------
-- Table structure for view
-- ----------------------------
DROP TABLE IF EXISTS `view`;
CREATE TABLE `view`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键，唯一标识一条浏览记录',
  `user_id` bigint NULL DEFAULT NULL COMMENT '进行浏览的用户ID，外键，关联用户表的id',
  `post_id` bigint NULL DEFAULT NULL COMMENT '被浏览的帖子ID，外键，关联帖子表的id',
  `view_time` datetime NULL DEFAULT NULL COMMENT '用户浏览帖子的时间',
  `is_deleted` int NULL DEFAULT NULL COMMENT '区分位，1表示已删除，0表示未删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_v_view_time`(`view_time` ASC) USING BTREE,
  INDEX `fk_view_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_view_post_id`(`post_id` ASC) USING BTREE,
  CONSTRAINT `fk_view_post_id` FOREIGN KEY (`post_id`) REFERENCES `post` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_view_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of view
-- ----------------------------
INSERT INTO `view` VALUES (31, 21, 101, '2024-01-01 10:00:00', 0);
INSERT INTO `view` VALUES (32, 21, 102, '2024-01-02 14:30:25', 0);
INSERT INTO `view` VALUES (33, 21, 103, '2024-01-03 18:45:10', 1);
INSERT INTO `view` VALUES (34, 21, 101, '2024-01-04 08:00:00', 0);
INSERT INTO `view` VALUES (35, 21, 102, '2024-01-05 09:00:00', 1);

SET FOREIGN_KEY_CHECKS = 1;
