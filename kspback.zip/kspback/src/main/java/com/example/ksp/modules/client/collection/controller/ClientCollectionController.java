package com.example.ksp.modules.client.collection.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.proxy.CollectionProxy;
import com.example.ksp.modules.client.collection.dto.CommentRequest;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;



/**
 * 合集控制器
 */
@Tag(name = "客户端合集相关接口")
@RestController
@RequestMapping("/api/client/collections")
public class ClientCollectionController {

    @Resource
    private CollectionProxy collectionProxy;



    /**
     * 查看合集详情
     *
     * @param id 合集ID
     * @return 合集详情
     */
    @Operation(summary = "查看合集详情")
    @GetMapping("/{id}")
    public Resp<Object> getCollectionDetail(@PathVariable Long id) {
        Object collectionDetail = collectionProxy.getCollectionDetail(id);
        return Resp.success(collectionDetail);
    }

    /**
     * 点赞合集
     *
     * @param id 合集ID
     * @return 点赞结果
     */
    @Operation(summary = "点赞合集")
    @PostMapping("/{id}/like")
    public Resp<Boolean> likeCollection(@PathVariable Long id) {

        Long currentUserId = getCurrentUserId();  
        boolean result = collectionProxy.likeCollection(currentUserId, id);
        return Resp.success(result);
    }

    /**
     * 分享合集
     *
     * @param id 合集ID
     * @return 分享结果
     */
    @Operation(summary = "分享合集")
    @PostMapping("/{id}/share")
    public Resp<Boolean> shareCollection(@PathVariable Long id) {

        Long currentUserId = getCurrentUserId();
        boolean result = collectionProxy.shareCollection(currentUserId, id);
        return Resp.success(result);
    }

    /**
     * 评论合集
     *
     * @param id 合集ID
     * @param request 评论请求
     * @return 评论结果
     */
    @Operation(summary = "评论合集")
    @PostMapping("/{id}/comment")
    public Resp<Object> commentCollection(
            @PathVariable Long id,
            @RequestBody CommentRequest request
    ) {

        Long currentUserId = getCurrentUserId();
        Object result = collectionProxy.commentCollection(
            currentUserId, 
            id, 
            request.getContent(), 
            request.getParentId()
        );
        return Resp.success(result);
    }

    /**
     * 订阅合集
     *
     * @param id 合集ID
     * @return 订阅结果
     */
    @Operation(summary = "订阅合集")
    @PostMapping("/{id}/subscribe")
    public Resp<Boolean> subscribeCollection(@PathVariable Long id) {

        Long currentUserId = getCurrentUserId();
        boolean result = collectionProxy.subscribeCollection(currentUserId, id);
        return Resp.success(result);
    }

    /**
     * 获取所有合集
     *
     * @return
     */
    @Operation(summary = "获取所有合集")
    @GetMapping("/list")
    Resp<Object> getAllCollections() {
        return Resp.success(collectionProxy.getAllCollections());
    }

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
       return  loginUser.getXxuser().getId();
    }
}