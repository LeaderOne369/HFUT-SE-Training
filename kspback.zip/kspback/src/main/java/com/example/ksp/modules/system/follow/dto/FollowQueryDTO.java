package com.example.ksp.modules.system.follow.dto;

import lombok.Data;

@Data
public class FollowQueryDTO {
    private Long userId;
    private Integer type; // 1:关注列表 2:粉丝列表
    private Integer pageNum = 1;
    private Integer pageSize = 10;
} 