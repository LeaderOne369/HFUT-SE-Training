package com.example.ksp.modules.client.personal.center.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.personal.center.dto.UpdateUserInfoDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalCenterService;
import com.example.ksp.modules.client.personal.center.vo.UserInfoVO;
import com.example.ksp.modules.system.user.entity.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "客户端个人中心接口")
@RestController
@RequestMapping("/api/client/personal/center")
@RequiredArgsConstructor
@Validated
public class PersonalCenterController {

    private final PersonalCenterService personalCenterService;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    @Operation(summary = "获取用户信息")
    @GetMapping("/info")
    public Resp<UserInfoVO> getUserInfo() {
        return personalCenterService.getUserInfo(getCurrentUserId());
    }

    @Operation(summary = "上传用户头像")
    @PostMapping("/avatar")
    public Resp<String> uploadAvatar(@RequestParam("file") MultipartFile file) {
        return personalCenterService.uploadAvatar(getCurrentUserId(), file);
    }

    @Operation(summary = "更新用户信息")
    @PutMapping("/info")
    public Resp<UserInfoVO> updateUserInfo(@RequestBody @Validated UpdateUserInfoDTO updateUserInfoDTO) {
        return personalCenterService.updateUserInfo(getCurrentUserId(), updateUserInfoDTO);
    }

    @Operation(summary = "注销账号")
    @PostMapping("/deactivate")
    public Resp<String> deactivateAccount(@RequestParam String password) {
        return personalCenterService.deactivateAccount(getCurrentUserId(), password);
    }
} 