package com.example.ksp.modules.client.clientlogin.dto;

import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "客户端登录请求参数")
public class ClientLoginDTO {
    
    @Schema(description = "用户名")
    private String username;
    
    @Schema(description = "手机号")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phoneNumber;
    
    @Schema(description = "密码")
    private String password;
    
    @Schema(description = "验证码")
    private String captcha;
    
    @Schema(description = "登录方式：1-用户名密码，2-手机号密码，3-手机号验证码")
    @NotNull(message = "登录方式不能为空")
    private Integer loginType;
    
    @Schema(description = "最后登录时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastLoginTime;
    
    @Schema(description = "最后登录地点")
    private String lastLoginLocation;
    
    @Schema(description = "用户状态检查配置")
    private ClientLoginCheckConfig checkConfig;
    
    @Data
    @Schema(description = "用户状态检查配置")
    public static class ClientLoginCheckConfig {
        
        @Schema(description = "是否检查删除状态（0不检查 1检查）")
        private Integer checkDeleted = 1;
        
        @Schema(description = "是否检查冻结状态（0不检查 1检查）")
        private Integer checkFrozen = 1;
        
        @Schema(description = "是否检查管理员权限（0不检查 1检查）")
        private Integer checkAdmin = 0;
        
        @Schema(description = "是否检查审核状态（0不检查 1检查）")
        private Integer checkReview = 1;
    }
    
    public LoginDTO toLoginDTO() {
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setUsername(this.username);
        loginDTO.setPhoneNumber(this.phoneNumber);
        loginDTO.setPassword(this.password);
        loginDTO.setCaptcha(this.captcha);
        loginDTO.setLoginType(this.loginType);
        return loginDTO;
    }
}
