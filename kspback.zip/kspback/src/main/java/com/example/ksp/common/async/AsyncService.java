package com.example.ksp.common.async;

/**
 * 异步服务接口
 */
public interface AsyncService {
    
    /**
     * 执行异步任务
     *
     * @param runnable 需要异步执行的任务
     */
    void execute(Runnable runnable);
} 