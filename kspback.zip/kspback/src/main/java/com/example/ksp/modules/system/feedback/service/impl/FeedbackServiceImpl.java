package com.example.ksp.modules.system.feedback.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.mapper.FeedbackMapper;
import com.example.ksp.modules.system.feedback.service.FeedbackService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class FeedbackServiceImpl extends ServiceImpl<FeedbackMapper, Feedback> implements FeedbackService {

    @Override
    public boolean submitFeedback(Feedback feedback) {
        feedback.setFeedbackTime(LocalDateTime.now());
        feedback.setStatus(0);
        feedback.setIsDeleted(0);
        return save(feedback);
    }

    @Override
    public boolean updateStatus(Long id, Integer status) {
        Feedback feedback = getById(id);
        if (feedback == null) {
            return false;
        }

        feedback.setStatus(status);
        return updateById(feedback);
    }

    @Override
    public boolean deleteFeedback(Long id) {
        return removeById(id);
    }

    @Override
    public Page<Feedback> getUserFeedbacks(Long userId, Integer status, long current, long size) {
        Page<Feedback> page = new Page<>(current, size);
        LambdaQueryWrapper<Feedback> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Feedback::getUserId, userId)
                .eq(status != null, Feedback::getStatus, status)
                .orderByDesc(Feedback::getFeedbackTime);

        return page(page, wrapper);
    }

    @Override
    public Page<Feedback> getAllFeedbacks(Integer status, long current, long size) {
        Page<Feedback> page = new Page<>(current, size);
        LambdaQueryWrapper<Feedback> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(status != null, Feedback::getStatus, status)
                .orderByDesc(Feedback::getFeedbackTime);

        return page(page, wrapper);
    }

    @Override
    public Page<Feedback> queryFeedbacks(Long userId, String feedbackContent, Integer status,
                                         LocalDateTime startTime, LocalDateTime endTime,
                                         int page, int size) {
        LambdaQueryWrapper<Feedback> queryWrapper = new LambdaQueryWrapper<>();

        // 添加条件
        if (userId != null) {
            queryWrapper.eq(Feedback::getUserId, userId);
        }
        if (feedbackContent != null && !feedbackContent.trim().isEmpty()) {
            queryWrapper.like(Feedback::getFeedbackContent, feedbackContent);
        }
        if (status != null) {
            queryWrapper.eq(Feedback::getStatus, status);
        }
        if (startTime != null) {
            queryWrapper.ge(Feedback::getFeedbackTime, startTime);
        }
        if (endTime != null) {
            queryWrapper.le(Feedback::getFeedbackTime, endTime);
        }

        // 只查询未删除的记录
        queryWrapper.eq(Feedback::getIsDeleted, 0);

        // 创建分页对象
        Page<Feedback> feedbackPage = new Page<>(page, size);

        // 执行查询
        return this.page(feedbackPage, queryWrapper);
    }
}
