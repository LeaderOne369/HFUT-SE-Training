package com.example.ksp.modules.client.homepage.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.util.Date;

@Data
@Schema(description = "消息通知视图对象")
public class NotificationVO {
    
    @Schema(description = "通知ID", example = "1")
    private Long id;
    
    @Schema(description = "通知类型", example = "comment")
    private String type;
    
    @Schema(description = "通知内容", example = "有人评论了你的视频")
    private String content;
    
    @Schema(description = "是否已读", example = "false")
    private Boolean isRead;
    
    @Schema(description = "创建时间")
    private Date createTime;
} 