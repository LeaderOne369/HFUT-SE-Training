package com.example.ksp.modules.system.tag.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("tag")
@Schema(description = "标签实体类")
public class Tag {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "主键，唯一标识一个标签，自增")
    private Long id;

    @Schema(description = "标签的名称，用于用户识别和展示，应该是唯一的")
    private String tagName;

    @Schema(description = "标签的详细描述，可以包含标签所代表的主题或分类的额外信息")
    private String tagDescription;

    @Schema(description = "标签所属的分区ID，关联分区表section的id")
    private Long sectionId;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "标签创建的时间")
    private LocalDateTime creationTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "标签信息最后一次更新的时间")
    private LocalDateTime updateTime;

    @Schema(description = "表示标签是否被删除，1表示是，0表示否")
    private Integer isDeleted;
} 