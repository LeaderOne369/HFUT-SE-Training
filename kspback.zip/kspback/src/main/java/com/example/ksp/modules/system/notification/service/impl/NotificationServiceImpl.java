package com.example.ksp.modules.system.notification.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.mapper.NotificationMapper;
import com.example.ksp.modules.system.notification.service.NotificationService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class NotificationServiceImpl extends ServiceImpl<NotificationMapper, Notification> implements NotificationService {

    @Override
    public boolean sendNotification(Notification notification) {
        notification.setCreationTime(LocalDateTime.now());
        notification.setStatus(0);
        notification.setIsDeleted(0);
        return save(notification);
    }

    @Override
    public boolean markAsRead(Long id) {
        Notification notification = getById(id);
        if (notification == null || notification.getStatus() == 1) {
            return false;
        }
        
        notification.setStatus(1);
        notification.setReadTime(LocalDateTime.now());
        return updateById(notification);
    }

    @Override
    public boolean markAllAsRead(Long userId) {
        LambdaQueryWrapper<Notification> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Notification::getUserReceiverId, userId)
                .eq(Notification::getStatus, 0);
        
        Notification update = new Notification();
        update.setStatus(1);
        update.setReadTime(LocalDateTime.now());
        
        return update(update, wrapper);
    }

    @Override
    public boolean deleteNotification(Long id) {
        return removeById(id);
    }

    @Override
    public long getUnreadCount(Long userId) {
        LambdaQueryWrapper<Notification> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Notification::getUserReceiverId, userId)
                .eq(Notification::getStatus, 0);
        
        return count(wrapper);
    }

    @Override
    public Page<Notification> getUserNotifications(Long userId, Integer type, long current, long size) {
        Page<Notification> page = new Page<>(current, size);
        LambdaQueryWrapper<Notification> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Notification::getUserReceiverId, userId)
                .eq(type != null, Notification::getType, type)
                .orderByDesc(Notification::getCreationTime);
        
        return page(page, wrapper);
    }
} 