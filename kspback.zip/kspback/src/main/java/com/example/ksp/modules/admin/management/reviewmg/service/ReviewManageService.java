package com.example.ksp.modules.admin.management.reviewmg.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reviewmg.vo.ReviewManageVO;

import java.util.Map;

public interface ReviewManageService {
    
    /**
     * 分页查询审核列表
     */
    Resp<Page<ReviewManageVO>> queryReviewPage(Integer type, Integer status, Integer page, Integer size);
    
    /**
     * 获取审核详情
     */
    Resp<ReviewManageVO> getReviewDetail(Long id);
    
    /**
     * 处理审核
     */
    Resp<Void> handleReview(Long id, Integer status, String reason);
    
    /**
     * 获取审核统计信息
     */

} 