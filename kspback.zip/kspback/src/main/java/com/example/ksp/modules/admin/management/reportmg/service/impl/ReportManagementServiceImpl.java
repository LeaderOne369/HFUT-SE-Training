package com.example.ksp.modules.admin.management.reportmg.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportHandleDTO;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportQueryDTO;
import com.example.ksp.modules.admin.management.reportmg.service.ReportManagementService;
import com.example.ksp.modules.admin.management.reportmg.vo.ReportVO;
import com.example.ksp.modules.proxy.ReportServiceProxy;
import com.example.ksp.modules.proxy.ReportTypeServiceProxy;
import com.example.ksp.modules.proxy.ReportedTypeServiceProxy;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.report.report.entity.Report;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportManagementServiceImpl implements ReportManagementService {

    private final ReportServiceProxy reportServiceProxy;
    private final ReportTypeServiceProxy reportTypeServiceProxy;
    private final ReportedTypeServiceProxy reportedTypeServiceProxy;
    private final UserServiceProxy userServiceProxy;

    @Override
    public Resp<Page<ReportVO>> getReportList(ReportQueryDTO queryDTO) {
        try {
            // 构建查询条件
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<Report>()
                .eq(queryDTO.getReportedTypeId() != null, Report::getReportedTypeId, queryDTO.getReportedTypeId())
                .eq(queryDTO.getReportTypeId() != null, Report::getReportTypeId, queryDTO.getReportTypeId())
                .eq(queryDTO.getStatus() != null, Report::getStatus, queryDTO.getStatus())
                .ge(queryDTO.getStartTime() != null, Report::getReportTime, queryDTO.getStartTime())
                .le(queryDTO.getEndTime() != null, Report::getReportTime, queryDTO.getEndTime())
                .orderByDesc(Report::getReportTime);

            // 执行分页查询
            Page<Report> page = reportServiceProxy.page(
                new Page<>(queryDTO.getCurrent(), queryDTO.getSize()),
                wrapper
            );

            // 转换为VO
            Page<ReportVO> voPage = new Page<>();
            BeanUtils.copyProperties(page, voPage, "records");
            
            List<ReportVO> voList = new ArrayList<>();
            for (Report report : page.getRecords()) {
                ReportVO vo = new ReportVO();
                BeanUtils.copyProperties(report, vo);
                
                // 填充关联信息
                vo.setUsername(userServiceProxy.getUserById(report.getUserId()).getUsername());
                vo.setReportedTypeName(reportedTypeServiceProxy.getTypeName(report.getReportedTypeId()));
                vo.setReportTypeName(reportTypeServiceProxy.getTypeName(report.getReportTypeId()));
                vo.setReportedContent(reportServiceProxy.getReportedContent(
                    report.getReportedContentId(), 
                    report.getReportedTypeId()
                ));
                
                voList.add(vo);
            }
            voPage.setRecords(voList);
            
            return Resp.success(voPage);
        } catch (Exception e) {
            log.error("获取举报列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报列表失败");
        }
    }

    @Override
    public Resp<ReportVO> getReportDetail(Long reportId) {
        try {
            Report report = reportServiceProxy.getById(reportId);
            if (report == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报记录不存在");
            }
            
            ReportVO vo = new ReportVO();
            BeanUtils.copyProperties(report, vo);
            
            // 填充关联信息
            vo.setUsername(userServiceProxy.getUsername(report.getUserId()));
            vo.setReportedTypeName(reportedTypeServiceProxy.getTypeName(report.getReportedTypeId()));
            vo.setReportTypeName(reportTypeServiceProxy.getTypeName(report.getReportTypeId()));
            vo.setReportedContent(reportServiceProxy.getReportedContent(
                report.getReportedContentId(), 
                report.getReportedTypeId()
            ));
            
            return Resp.success(vo);
        } catch (Exception e) {
            log.error("获取举报详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报详情失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<String> handleReport(ReportHandleDTO handleDTO) {
        try {
            Report report = reportServiceProxy.getById(handleDTO.getReportId());
            if (report == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报记录不存在");
            }
            
            // 更新处理状态和结果
            report.setStatus(handleDTO.getStatus());
            report.setOutcome(handleDTO.getOutcome());
            
            // 根据处理结果执行相应操作
            switch (handleDTO.getOutcome()) {
                case 1 -> // 删除内容
                    reportServiceProxy.deleteReportedContent(
                        report.getReportedContentId(), 
                        report.getReportedTypeId()
                    );
                case 2 -> // 警告用户
                    userServiceProxy.warnUser(report.getUserId());
                case 3 -> // 禁言用户
                    userServiceProxy.muteUser(report.getUserId());
                case 4 -> // 封禁用户
                    userServiceProxy.banUser(report.getUserId());
            }
            
            reportServiceProxy.updateById(report);
            return Resp.success("处理成功");
        } catch (Exception e) {
            log.error("处理举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "处理举报失败");
        }
    }

    @Override
    public Resp<Map<String, Object>> getReportStats() {
        try {
            Map<String, Object> stats = new HashMap<>();
            
            // 获取各状态的举报数量
            stats.put("pendingCount", reportServiceProxy.countByStatus(0));
            stats.put("processingCount", reportServiceProxy.countByStatus(1));
            stats.put("processedCount", reportServiceProxy.countByStatus(2));
            stats.put("ignoredCount", reportServiceProxy.countByStatus(3));
            
            // 获取各类型的举报数量
            stats.put("typeStats", reportServiceProxy.countByReportType());
            
            // 获取各处理结果的数量
            stats.put("outcomeStats", reportServiceProxy.countByOutcome());
            
            return Resp.success(stats);
        } catch (Exception e) {
            log.error("获取举报统计信息失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报统计信息失败");
        }
    }
} 