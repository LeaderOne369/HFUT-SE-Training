package com.example.ksp.modules.client.personal.center.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderCreateDTO;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalFavoriteService;
import com.example.ksp.modules.proxy.FavoriteServiceProxy;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalFavoriteServiceImpl implements PersonalFavoriteService {

    private final FavoriteServiceProxy favoriteServiceProxy;

    @Override
    public Resp<FavoriteFolder> createFolder(Long userId, FavoriteFolderCreateDTO folderDTO) {
        try {
            FavoriteFolder folder = new FavoriteFolder();
            folder.setUserId(userId);
            folder.setFolderName(folderDTO.getFolderName());
            folder.setVisibility(folderDTO.getVisibility());
            folder.setCreationTime(LocalDateTime.now());
            folder.setUpdateTime(LocalDateTime.now());
            folder.setIsDeleted(0);
            folder.setReviewStatus(0); // 设置为待审核状态
            
            return favoriteServiceProxy.createFolder(folder);
        } catch (Exception e) {
            log.error("创建收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建收藏夹失败");
        }
    }

    @Override
    public Resp<Boolean> updateFolder(Long userId, FavoriteFolderDTO folderDTO) {
        try {
            // 验证收藏夹所有权
            FavoriteFolder existingFolder = favoriteServiceProxy.getFolderById(folderDTO.getId()).getData();
            if (existingFolder == null || !existingFolder.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权操作此收藏夹");
            }
            
            // 只更新允许修改的字段
            existingFolder.setFolderName(folderDTO.getFolderName());
            existingFolder.setVisibility(folderDTO.getVisibility());
            existingFolder.setUpdateTime(LocalDateTime.now());
            existingFolder.setReviewStatus(0); // 修改后重新进入待审核状态
            
            return favoriteServiceProxy.updateFolder(existingFolder);
        } catch (Exception e) {
            log.error("更新收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新收藏夹失败");
        }
    }

    @Override
    public Resp<Boolean> deleteFolder(Long userId, Long folderId) {
        try {
            // 验证收藏夹所有权
            FavoriteFolder folder = favoriteServiceProxy.getFolderById(folderId).getData();
            if (folder == null || !folder.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权操作此收藏夹");
            }
            
            return favoriteServiceProxy.deleteFolder(folderId);
        } catch (Exception e) {
            log.error("删除收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除收藏夹失败");
        }
    }

    @Override
    public Resp<Page<FavoriteFolder>> getFolderList(Long userId, long current, long size) {
        try {
            return favoriteServiceProxy.getUserFolders(userId, current, size);
        } catch (Exception e) {
            log.error("获取收藏夹列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏夹列表失败");
        }
    }

    @Override
    public Resp<Page<Favorite>> getFavoriteList(Long userId, Long folderId, long current, long size) {
        try {
            return favoriteServiceProxy.getUserFavorites(userId, folderId, current, size);
        } catch (Exception e) {
            log.error("获取收藏列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏列表失败");
        }
    }

    @Override
    public Resp<Boolean> deleteFavorite(Long userId, Long favoriteId) {
        try {
            // 验证收藏所有权
            Favorite favorite = favoriteServiceProxy.getFavoriteById(favoriteId).getData();
            if (favorite == null || !favorite.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权操作此收藏");
            }
            
            return favoriteServiceProxy.deleteFavorite(favoriteId);
        } catch (Exception e) {
            log.error("删除收藏失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除收藏失败");
        }
    }

    @Override
    public Resp<Boolean> moveFavorite(Long userId, Long favoriteId, Long targetFolderId) {
        try {
            // 验证收藏所有权
            Favorite favorite = favoriteServiceProxy.getFavoriteById(favoriteId).getData();
            if (favorite == null || !favorite.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权操作此收藏");
            }
            
            // 验证目标收藏夹所有权
            FavoriteFolder targetFolder = favoriteServiceProxy.getFolderById(targetFolderId).getData();
            if (targetFolder == null || !targetFolder.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权操作目标收藏夹");
            }
            
            return favoriteServiceProxy.moveFavorite(favoriteId, targetFolderId);
        } catch (Exception e) {
            log.error("移动收藏失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "移动收藏失败");
        }
    }
} 