package com.example.ksp.modules.proxy;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reportedtype.service.ReportedTypeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class ReportedTypeServiceProxy {

    private final ReportedTypeService reportedTypeService;

    /**
     * 获取所有举报对象类型
     *
     * @return 举报对象类型列表
     */
    public Resp<List<ReportedType>> getAllReportedTypes() {
        log.info("代理层：获取所有举报对象类型");
        try {
            List<ReportedType> types = reportedTypeService.list();
            return Resp.success(types);
        } catch (Exception e) {
            log.error("获取举报对象类型列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报对象类型失败");
        }
    }

    /**
     * 获取举报对象类型详情
     *
     * @param reportedTypeId 举报对象类型ID
     * @return 举报对象类型信息
     */
    public Resp<ReportedType> getReportedType(Long reportedTypeId) {
        log.info("代理层：获取举报对象类型详情，ID：{}", reportedTypeId);
        if (reportedTypeId == null || reportedTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的举报对象类型ID");
        }
        
        try {
            return reportedTypeService.getReportedType(reportedTypeId);
        } catch (Exception e) {
            log.error("获取举报对象类型详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报对象类型失败");
        }
    }

    /**
     * 获取举报对象类型名称
     */
    public String getTypeName(Long typeId) {
        try {
            ReportedType type = reportedTypeService.getById(typeId);
            return type != null ? type.getTypeName() : null;
        } catch (Exception e) {
            log.error("获取举报对象类型名称失败, typeId: {}", typeId, e);
            throw new RuntimeException("获取举报对象类型名称失败");
        }
    }
} 