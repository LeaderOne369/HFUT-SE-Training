package com.example.ksp.modules.system.citation.citationtype.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeCreateDTO;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeUpdateDTO;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;

public interface CitationTypeService extends IService<CitationType> {
    
    Resp<CitationType> createCitationType(CitationTypeCreateDTO createDTO);
    
    Resp<CitationType> updateCitationType(CitationTypeUpdateDTO updateDTO);
    
    Resp<Void> deleteCitationType(Long id);
    
    Resp<CitationType> getCitationType(Long id);
    
    Resp<Page<CitationType>> listCitationTypes(Page<CitationType> page, String typeName, Integer isActive);
} 