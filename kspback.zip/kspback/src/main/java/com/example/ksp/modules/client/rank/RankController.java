package com.example.ksp.modules.client.rank;


import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.List;
@Tag(name = "客户端排行榜相关接口")
@RestController
@RequestMapping("/api/client/rank")
public class RankController {

    @Autowired
    private PostServiceProxy postService;

    @Operation(summary = "获取日榜")
    @GetMapping("/daily")
    public Resp<List<Post>> getDailyRank() {
        List<Post> dailyRank = postService.getRankList("daily");
        return Resp.success(dailyRank);
    }

    @Operation(summary = "获取周榜")
    @GetMapping("/weekly")
    public Resp<List<Post>> getWeeklyRank() {
        List<Post> weeklyRank = postService.getRankList("weekly");
        return Resp.success(weeklyRank);
    }

    @Operation(summary = "获取月榜")
    @GetMapping("/monthly")
    public Resp<List<Post>> getMonthlyRank() {
        List<Post> monthlyRank = postService.getRankList("monthly");
        return Resp.success(monthlyRank);
    }
}
