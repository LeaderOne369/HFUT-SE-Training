package com.example.ksp.modules.admin.management.usermg;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

@Data
@Schema(description = "管理员创建用户DTO")
public class UserCreateDTO {
    
    @Schema(description = "用户名")
    @NotBlank(message = "用户名不能为空")
    @Size(min = 4, max = 20, message = "用户名长度必须在4-20之间")
    private String username;
    
    @Schema(description = "密码")
    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 20, message = "密码长度必须在6-20之间")
    private String password;
    
    @Schema(description = "邮箱")
    @Email(message = "邮箱格式不正确")
    private String email;
    
    @Schema(description = "手机号")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phoneNumber;
    
    @Schema(description = "是否管理员（0否 1是）")
    @Min(value = 0, message = "无效的管理员状态")
    @Max(value = 1, message = "无效的管理员状态")
    private Integer isAdmin;
    
    @Schema(description = "是否冻结（0否 1是）")
    @Min(value = 0, message = "无效的冻结状态")
    @Max(value = 1, message = "无效的冻结状态")
    private Integer isFrozen;
    
    @Schema(description = "权限等级（0正常 1禁止评论 2禁止发帖）")
    @Min(value = 0, message = "无效的权限等级")
    @Max(value = 2, message = "无效的权限等级")
    private Integer permissionLevel;
    
    @Schema(description = "性别（0男 1女 2其他）")
    @Min(value = 0, message = "无效的性别选项")
    @Max(value = 2, message = "无效的性别选项")
    private Integer gender;
    
    @Schema(description = "出生日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @Past(message = "出生日期必须是过去的日期")
    private LocalDate birthDate;
    
    @Schema(description = "个人简介")
    @Size(max = 255, message = "个人简介不能超过255个字符")
    private String bio;
    
    @Schema(description = "头像文件")
    private MultipartFile avatar;
    
    @Schema(description = "审核状态（0待审核 1已通过 2已拒绝）")
    @Min(value = 0, message = "无效的审核状态")
    @Max(value = 2, message = "无效的审核状态")
    private Integer reviewStatus;
}
