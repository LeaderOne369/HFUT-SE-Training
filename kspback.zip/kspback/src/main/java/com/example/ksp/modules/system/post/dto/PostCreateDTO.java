package com.example.ksp.modules.system.post.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "创建帖子请求参数")
public class PostCreateDTO {

    @NotNull(message = "用户ID不能为空")
    @Schema(description = "用户ID")
    private Long userId;

    @NotNull(message = "分区ID不能为空")
    @Schema(description = "分区ID")
    private Long sectionId;

    
    @Schema(description = "标签，多个标签用逗号分隔")
    private String tags;
    
    @Schema(description = "封面图片")
    private String cover;
    
    @Schema(description = "摘要")
    private String summary;
    
    @Schema(description = "引用信息")
    private String citation;
    
    @Schema(description = "所属合集ID")
    private Long collectionId;
    
    @NotBlank(message = "标题不能为空")
    @Schema(description = "标题")
    private String title;

    @Schema(description = "内容文件ID，由文件上传接口返回")
    private String contentFileId;

    @Schema(description = "内容文件路径，由文件上传接口返回")
    private String contentFilePath;
    
    @NotNull(message = "可见性不能为空")
    @Schema(description = "可见性(1:公开 0:私密)")
    private Integer visibility;
    
    @NotNull(message = "状态不能为空")
    @Schema(description = "状态(0:草稿 1:已发布)")
    private Integer status;
} 