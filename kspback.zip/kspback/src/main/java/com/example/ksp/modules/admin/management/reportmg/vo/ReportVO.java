package com.example.ksp.modules.admin.management.reportmg.vo;

import com.example.ksp.modules.system.report.report.entity.Report;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "举报信息VO")
public class ReportVO extends Report {
    
    @Schema(description = "举报用户名")
    private String username;
    
    @Schema(description = "举报对象类型名称")
    private String reportedTypeName;
    
    @Schema(description = "举报类型名称")
    private String reportTypeName;
    
    @Schema(description = "被举报内容")
    private String reportedContent;
} 