package com.example.ksp.modules.client.personal.statistics.service.impl;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.statistics.service.PersonalStatisticsService;
import com.example.ksp.modules.proxy.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalStatisticsServiceImpl implements PersonalStatisticsService {
    
    private final UserServiceProxy userServiceProxy;
    private final PostServiceProxy postServiceProxy;
    private final CollectionServiceProxy collectionServiceProxy;
    private final CommentServiceProxy commentServiceProxy;
    private final LikeServiceProxy likeServiceProxy;
    private final FavoriteServiceProxy favoriteServiceProxy;
    private final ShareServiceProxy shareServiceProxy;

    @Override
    public Resp<Map<String, Integer>> getSocialStats(Long userId) {
        log.info("获取用户社交统计数据, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }

        try {
            Map<String, Integer> stats = userServiceProxy.getFollowStats(userId);
            return Resp.success(stats);
        } catch (Exception e) {
            log.error("获取用户社交统计数据失败", e);
            return Resp.error(500, "获取社交统计数据失败");
        }
    }

    @Override
    public Resp<Map<String, Integer>> getContentStats(Long userId) {
        log.info("获取用户内容创作统计数据, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }

        try {
            Map<String, Integer> stats = new HashMap<>();
            
            // 获取发帖数
            Resp<Integer> postCount = postServiceProxy.getUserPostCount(userId);
            stats.put("postCount", postCount.getData());
            
            // 获取合集数
            Resp<Integer> collectionCount = collectionServiceProxy.getUserCollectionCount(userId);
            stats.put("collectionCount", collectionCount.getData());
            
            // 获取分享数
            Resp<Long> shareCount = shareServiceProxy.getUserShareCount(userId);
            stats.put("shareCount", shareCount.getData().intValue());
            
            return Resp.success(stats);
        } catch (Exception e) {
            log.error("获取用户内容统计数据失败", e);
            return Resp.error(500, "获取内容统计数据失败");
        }
    }

    @Override
    public Resp<Map<String, Integer>> getInteractionStats(Long userId) {
        log.info("获取用户互动统计数据, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }

        try {
            Map<String, Integer> stats = new HashMap<>();
            
            // 获取收到的评论数
            Resp<Integer> commentCount = commentServiceProxy.getReceivedCommentCount(userId);
            stats.put("receivedComments", commentCount.getData());
            
            // 获取收到的点赞数
            Resp<Integer> likeCount = likeServiceProxy.getReceivedLikeCount(userId);
            stats.put("receivedLikes", likeCount.getData());
            
            // 获取收到的收藏数
            Resp<Integer> favoriteCount = favoriteServiceProxy.getReceivedFavoriteCount(userId);
            stats.put("receivedFavorites", favoriteCount.getData());
            
            return Resp.success(stats);
        } catch (Exception e) {
            log.error("获取用户互动统计数据失败", e);
            return Resp.error(500, "获取互动统计数据失败");
        }
    }

    @Override
    public Resp<Map<String, Integer>> getAllStats(Long userId) {
        log.info("获取用户所有统计数据, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }

        try {
            Map<String, Integer> allStats = new HashMap<>();
            
            // 合并所有统计数据
            Resp<Map<String, Integer>> socialStats = getSocialStats(userId);
            Resp<Map<String, Integer>> contentStats = getContentStats(userId);
            Resp<Map<String, Integer>> interactionStats = getInteractionStats(userId);
            
            if (socialStats.getData() != null) {
                allStats.putAll(socialStats.getData());
            }
            if (contentStats.getData() != null) {
                allStats.putAll(contentStats.getData());
            }
            if (interactionStats.getData() != null) {
                allStats.putAll(interactionStats.getData());
            }
            
            return Resp.success(allStats);
        } catch (Exception e) {
            log.error("获取用户所有统计数据失败", e);
            return Resp.error(500, "获取统计数据失败");
        }
    }
}