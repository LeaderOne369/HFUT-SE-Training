package com.example.ksp.modules.client.personal.profile.controller;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.ReportServiceProxy;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.user.entity.UserFollowDetailVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Tag(name = "客户端个人主页接口", description = "提供用户个人主页相关的接口")
@RestController//返回json格式数据
@RequestMapping("/api/client/personal/profile")
@RequiredArgsConstructor//自动注入
public class PersonalProfileController {

    @Autowired//使用proxy下的userServiceProxy作为userService
    private UserServiceProxy userService;

    private final ReportServiceProxy reportServiceProxy;


    /**
     * 获取用户的粉丝详情列表
     * @param userId 用户ID
     * @return List<UserFollowDetailVO>
     */
    /**
     * 获取用户的粉丝详情列表
     * @param userId 用户ID
     * @return Resp<List<UserFollowDetailVO>>
     */
    @Operation(summary = "获取用户的粉丝详情列表")
    @GetMapping("/{userId}/followers")
    public Resp<List<UserFollowDetailVO>> getFollowers(@PathVariable Long userId) {
        List<UserFollowDetailVO> followers = userService.getFollowers(userId);
        return Resp.success(followers);
    }

    /**
     * 获取用户的关注详情列表
     * @param userId 用户ID
     * @return Resp<List<UserFollowDetailVO>>
     */
    @Operation(summary = "获取用户的关注详情列表")
    @GetMapping("/{userId}/following")
    public Resp<List<UserFollowDetailVO>> getFollowing(@PathVariable Long userId) {
        List<UserFollowDetailVO> following = userService.getFollowing(userId);
        return Resp.success(following);
    }

    /**
     * 获取用户的关注者和被关注者统计
     * @param userId 用户ID
     * @return Resp<Map<String, Integer>>
     */
    @Operation(summary = "获取用户的关注者和被关注者统计")
    @GetMapping("/{userId}/follow-stats")
    public Resp<Map<String, Integer>> getFollowStats(@PathVariable Long userId) {
        Map<String, Integer> stats = userService.getFollowStats(userId);
        return Resp.success(stats);
    }

    /**
     * 一次性获取用户的关注者、被关注者详情以及统计信息
     * @param userId 用户ID
     * @return Resp<List<Map<String, Object>>>
     */
    @Operation(summary = "一次性获取用户的关注者、被关注者详情以及统计信息")
    @GetMapping("/{userId}/follow-details")
    public Resp<List<Map<String, Object>>> getFollowDetails(@PathVariable Long userId) {
        List<Map<String, Object>> details = userService.getAllFollowDetails(userId);
        return Resp.success(details);
    }

    @Operation(summary = "举报用户")
    @PostMapping("/{userId}/report")
    public Resp<Report> reportUser(
            @Parameter(description = "被举报用户ID") @PathVariable Long userId,
            @Parameter(description = "举报类型ID") @RequestParam Long reportTypeId,
            @Parameter(description = "举报理由") @RequestParam(required = false) String reason,
            @RequestHeader("token") String token) throws Exception {

        ReportCreateDTO createDTO = new ReportCreateDTO();
        createDTO.setReason(reason);
        createDTO.setReportedTypeId(3L);// 固定reportedTypeId为3，表示用户类型
        createDTO.setReportTypeId(reportTypeId);
        createDTO.setReportedContentId(userId);
        Long reporterId = userService.getUserIdByUsername(JwtUtil.parseJWT(token).getSubject()).getData();
        return reportServiceProxy.createReport(createDTO,reporterId);
    }
}
