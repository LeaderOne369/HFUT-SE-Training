package com.example.ksp.modules.system.collection.collection.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "更新合集请求参数")
public class CollectionUpdateDTO {
    
    @NotNull(message = "合集ID不能为空")
    @Schema(description = "合集ID")
    private Long id;
    
    @Schema(description = "合集名称")
    private String collectionName;
    
    @Schema(description = "合集描述")
    private String collectionDescription;
    
    @Schema(description = "可见性(0:私密 1:公开)")
    private Integer visibility;
    
    @Schema(description = "审核状态(0:待审核 1:已通过 2:已拒绝)")
    private Integer reviewStatus;
} 