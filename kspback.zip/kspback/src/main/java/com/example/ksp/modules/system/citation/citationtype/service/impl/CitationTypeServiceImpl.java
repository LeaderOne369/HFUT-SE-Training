package com.example.ksp.modules.system.citation.citationtype.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeCreateDTO;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeUpdateDTO;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.citation.citationtype.mapper.CitationTypeMapper;
import com.example.ksp.modules.system.citation.citationtype.service.CitationTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class CitationTypeServiceImpl extends ServiceImpl<CitationTypeMapper, CitationType> implements CitationTypeService {

    @Override
    public Resp<CitationType> createCitationType(CitationTypeCreateDTO createDTO) {
        try {
            // 检查是否已存在相同名称的引用类型
            if (checkTypeNameExists(createDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "引用类型名称已存在");
            }
            
            CitationType citationType = new CitationType();
            BeanUtils.copyProperties(createDTO, citationType);
            
            save(citationType);
            return Resp.success(citationType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建引用类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<CitationType> updateCitationType(CitationTypeUpdateDTO updateDTO) {
        try {
            CitationType citationType = getById(updateDTO.getId());
            if (citationType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用类型不存在");
            }
            
            // 如果修改了类型名称，需要检查是否与其他记录重复
            if (StringUtils.hasText(updateDTO.getTypeName()) 
                && !updateDTO.getTypeName().equals(citationType.getTypeName())
                && checkTypeNameExists(updateDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "引用类型名称已存在");
            }
            
            BeanUtils.copyProperties(updateDTO, citationType);
            updateById(citationType);
            
            return Resp.success(citationType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新引用类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> deleteCitationType(Long id) {
        try {
            if (!removeById(id)) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用类型不存在");
            }
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除引用类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<CitationType> getCitationType(Long id) {
        try {
            CitationType citationType = getById(id);
            if (citationType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用类型不存在");
            }
            return Resp.success(citationType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取引用类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<CitationType>> listCitationTypes(Page<CitationType> page, String typeName, Integer isActive) {
        try {
            LambdaQueryWrapper<CitationType> wrapper = new LambdaQueryWrapper<>();
            
            if (StringUtils.hasText(typeName)) {
                wrapper.like(CitationType::getTypeName, typeName);
            }
            if (isActive != null) {
                wrapper.eq(CitationType::getIsActive, isActive);
            }
            
            wrapper.orderByDesc(CitationType::getId);
            
            Page<CitationType> result = page(page, wrapper);
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询引用类型列表失败: " + e.getMessage());
        }
    }

    private boolean checkTypeNameExists(String typeName) {
        LambdaQueryWrapper<CitationType> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(CitationType::getTypeName, typeName);
        return count(wrapper) > 0;
    }
} 