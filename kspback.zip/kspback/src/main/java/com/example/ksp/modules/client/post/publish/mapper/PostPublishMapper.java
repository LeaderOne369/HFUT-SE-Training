package com.example.ksp.modules.client.post.publish.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.tag.entity.Tag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PostPublishMapper extends BaseMapper<Post> {

    /**
     * 根据分区ID查询标签列表
     */
    @Select("SELECT t.* FROM tag t " +
            "INNER JOIN tag st ON t.id = st.id " +
            "WHERE st.section_id = #{sectionId} AND t.is_deleted = 0 ")
    List<Tag> getTagsBySection(@Param("sectionId") Long sectionId);

    /**
     * 根据用户ID查询其创建的合集列表
     */
    @Select("SELECT * FROM collection " +
            "WHERE creator_id = #{userId} AND is_deleted = 0 " +
            "ORDER BY creation_time DESC")
    List<Collection> getUserCollections(@Param("userId") Long userId);

    /**
     * 查询所有可用的引用类型
     */
    @Select("SELECT * FROM citation_type " +
            "WHERE is_active = 0 ")
    List<CitationType> getAllCitationTypes();

    /**
     * 查询所有可用的分区
     */
    @Select("SELECT * FROM section " +
            "WHERE is_deleted = 0 " )
    List<Section> getAllSections();
} 