package com.example.ksp.modules.system.like.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("`like`")
@Schema(name = "Like对象", description = "点赞信息")
public class Like {

    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "用户ID")
    private Long userId;

    @Schema(description = "被点赞对象ID")
    private Long likeObjectId;

    @Schema(description = "点赞对象类型(1:帖子 2:合集 3:评论)")
    private Integer likeObjectType;

    @Schema(description = "点赞时间")
    private LocalDateTime likeTime;

    @Schema(description = "是否删除")
    @TableLogic
    private Integer isDeleted;
}
