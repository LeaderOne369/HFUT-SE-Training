package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class ReportServiceProxy {

    private final ReportService reportService;

    /**
     * 创建举报
     *
     * @param createDTO 举报创建DTO
     * @param userId 用户ID
     * @return 举报信息
     */
    public Resp<Report> createReport(ReportCreateDTO createDTO, Long userId) {
        log.info("代理层：创建举报，用户ID：{}, 举报内容：{}", userId, createDTO);
        if (userId == null || userId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的用户ID");
        }
        if (createDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "举报内容不能为空");
        }
        
        try {
            return reportService.createReport(createDTO, userId);
        } catch (Exception e) {
            log.error("创建举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建举报失败");
        }
    }

    /**
     * 检查用户是否已举报过该内容
     *
     * @param userId 用户ID
     * @param contentId 内容ID
     * @param contentType 内容类型
     * @return 是否已举报
     */
    public Resp<Boolean> hasReported(Long userId, Long contentId, Integer contentType) {
        log.info("代理层：检查用户是否已举报，用户ID：{}, 内容ID：{}, 内容类型：{}", userId, contentId, contentType);
        if (userId == null || userId <= 0 || contentId == null || contentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的用户ID或内容ID");
        }
        
        try {
            // TODO: 实现检查逻辑
            return Resp.success(false);
        } catch (Exception e) {
            log.error("检查用户举报状态失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "检查举报状态失败");
        }
    }

    /**
     * 分页查询
     */
    public Page<Report> page(Page<Report> page, LambdaQueryWrapper<Report> wrapper) {
        try {
            return reportService.page(page, wrapper);
        } catch (Exception e) {
            log.error("分页查询举报记录失败", e);
            throw new RuntimeException("查询失败");
        }
    }

    /**
     * 获取单个举报记录
     */
    public Report getById(Long reportId) {
        try {
            return reportService.getById(reportId);
        } catch (Exception e) {
            log.error("获取举报记录失败, reportId: {}", reportId, e);
            throw new RuntimeException("获取失败");
        }
    }

    /**
     * 更新举报记录
     */
    public boolean updateById(Report report) {
        try {
            return reportService.updateById(report);
        } catch (Exception e) {
            log.error("更新举报记录失败, report: {}", report, e);
            throw new RuntimeException("更新失败");
        }
    }

    /**
     * 删除被举报的内容
     */
    public Object deleteReportedContent(Long contentId, Long reportedTypeId) {
        try {
            return reportService.deleteReportedContent(contentId, reportedTypeId);
        } catch (Exception e) {
            log.error("删除被举报内容失败, contentId: {}, reportedTypeId: {}", contentId, reportedTypeId, e);
            throw new RuntimeException("删除失败");
        }
    }

    /**
     * 获取被举报的内容
     */
    public String getReportedContent(Long contentId, Long reportedTypeId) {
        try {
            return reportService.getReportedContent(contentId, reportedTypeId);
        } catch (Exception e) {
            log.error("获取被举报内容失败, contentId: {}, reportedTypeId: {}", contentId, reportedTypeId, e);
            throw new RuntimeException("获取失败");
        }
    }

    /**
     * 统计各状态的举报数量
     */
    public long countByStatus(Integer status) {
        try {
            return reportService.countByStatus(status);
        } catch (Exception e) {
            log.error("统计举报状态数量失败, status: {}", status, e);
            throw new RuntimeException("统计失败");
        }
    }

    /**
     * 统计各举报类型的数量
     */
    public Map<String, Long> countByReportType() {
        try {
            return reportService.countByReportType();
        } catch (Exception e) {
            log.error("统计举报类型数量失败", e);
            throw new RuntimeException("统计失败");
        }
    }

    /**
     * 统计各处理结果的数量
     */
    public Map<String, Long> countByOutcome() {
        try {
            return reportService.countByOutcome();
        } catch (Exception e) {
            log.error("统计处理结果数量失败", e);
            throw new RuntimeException("统计失败");
        }
    }
} 