package com.example.ksp.modules.system.statistics.dto;

import com.example.ksp.modules.system.statistics.StatisticsRequest;

public interface StatisticsService {
    /**
     * 获取统计数据
     *
     * @param request 统计请求
     * @return 统计响应
     */
    StatisticsResponse getStatistics(StatisticsRequest request);
}
