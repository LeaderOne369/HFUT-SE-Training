package com.example.ksp.framework.ai;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(description = "模型列表响应")
public class ModelListResponseDTO {
    
    @Schema(description = "对象类型")
    private String object;
    
    @Schema(description = "模型列表")
    private List<Model> data;
    
    @Data
    @Schema(description = "模型信息")
    public static class Model {
        @Schema(description = "模型ID")
        private String id;
        
        @Schema(description = "对象类型")
        private String object;
        
        @Schema(description = "所有者")
        private String ownedBy;
    }
} 