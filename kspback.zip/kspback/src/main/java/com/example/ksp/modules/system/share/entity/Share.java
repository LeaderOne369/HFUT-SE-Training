package com.example.ksp.modules.system.share.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("share")
@Schema(description = "分享实体")
public class Share {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "分享ID")
    private Long id;
    
    @Schema(description = "用户ID")
    private Long userId;
    
    @Schema(description = "分享对象ID")
    private Long shareObjectId;
    
    @Schema(description = "分享对象类型(1:帖子 2:合集)")
    private Integer shareObjectType;
    
    @Schema(description = "分享链接")
    private String shareLink;
    
    @Schema(description = "分享时间")
    private LocalDateTime shareTime;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
} 