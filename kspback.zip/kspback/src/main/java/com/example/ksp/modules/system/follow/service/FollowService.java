package com.example.ksp.modules.system.follow.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.follow.dto.FollowCreateDTO;
import com.example.ksp.modules.system.follow.dto.FollowQueryDTO;
import com.example.ksp.modules.system.follow.entity.Follow;
import com.example.ksp.modules.system.user.entity.User;

public interface FollowService extends IService<Follow> {
    /**
     * 关注用户
     */
    Resp<String> follow(Long followerId, FollowCreateDTO createDTO);

    /**
     * 取消关注
     */
    Resp<String> unfollow(Long followerId, Long followeeId);

    /**
     * 检查是否已关注
     */
    Resp<Boolean> checkFollow(Long followerId, Long followeeId);

    /**
     * 分页查询关注列表或粉丝列表
     */
    Resp<Page<User>> queryFollowList(FollowQueryDTO queryDTO);
} 