package com.example.ksp.modules.system.collection.collection.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.mapper.CollectionMapper;
import com.example.ksp.modules.system.collection.collection.service.CollectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CollectionServiceImpl extends ServiceImpl<CollectionMapper, Collection> implements CollectionService {

    private static final Logger log = LoggerFactory.getLogger(CollectionServiceImpl.class);

    @Override
    public Resp<Collection> createCollection(CollectionCreateDTO createDTO) {
        try {
            Collection collection = new Collection();
            BeanUtils.copyProperties(createDTO, collection);
            
            LocalDateTime now = LocalDateTime.now();
            collection.setCreationTime(now);
            collection.setUpdateTime(now);
            collection.setIsDeleted(0);
            collection.setLikeCount(0);
            collection.setCommentCount(0);
            collection.setSubscribeCount(0);
            collection.setShareCount(0);
            collection.setReviewStatus(0); // 待审核
            
            save(collection);
            return Resp.success(collection);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建合集失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Collection> updateCollection(CollectionUpdateDTO updateDTO) {
        try {
            LambdaQueryWrapper<Collection> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Collection::getId, updateDTO.getId())
                   .eq(Collection::getIsDeleted, 0);
            
            Collection collection = getOne(wrapper);
            if (collection == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在或已被删除");
            }
            
            BeanUtils.copyProperties(updateDTO, collection);
            collection.setUpdateTime(LocalDateTime.now());
            updateById(collection);
            
            return Resp.success(collection);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新合集失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> deleteCollection(Long id) {
        try {
            LambdaQueryWrapper<Collection> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Collection::getId, id)
                   .eq(Collection::getIsDeleted, 0);
            
            Collection collection = getOne(wrapper);
            if (collection == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在或已被删除");
            }
            
            collection.setIsDeleted(1);
            collection.setUpdateTime(LocalDateTime.now());
            updateById(collection);
            
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除合集失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Collection> getCollection(Long id) {
        try {
            LambdaQueryWrapper<Collection> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Collection::getId, id)
                   .eq(Collection::getIsDeleted, 0);
            
            Collection collection = getOne(wrapper);
            if (collection == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在或已被删除");
            }
            return Resp.success(collection);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取合集失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<Collection>> queryCollections(CollectionQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<Collection> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Collection::getIsDeleted, 0);
            
            if (StringUtils.hasText(queryDTO.getCollectionName())) {
                wrapper.like(Collection::getCollectionName, queryDTO.getCollectionName());
            }
            if (queryDTO.getCreatorId() != null) {
                wrapper.eq(Collection::getCreatorId, queryDTO.getCreatorId());
            }
            if (queryDTO.getVisibility() != null) {
                wrapper.eq(Collection::getVisibility, queryDTO.getVisibility());
            }
            if (queryDTO.getReviewStatus() != null) {
                wrapper.eq(Collection::getReviewStatus, queryDTO.getReviewStatus());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(Collection::getCreationTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(Collection::getCreationTime, queryDTO.getEndTime());
            }
            
            wrapper.orderByDesc(Collection::getUpdateTime);
            
            Page<Collection> page = new Page<>(queryDTO.getCurrent(), queryDTO.getSize());
            page = page(page, wrapper);
            
            return Resp.success(page);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询合集列表失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Integer> getUserCollectionCount(Long userId) {
        try {
            LambdaQueryWrapper<Collection> lqw = Wrappers.lambdaQuery();
            lqw.eq(Collection::getCreatorId, userId)
               .eq(Collection::getIsDeleted, 0);
            
            int count = Math.toIntExact(count(lqw));
            return Resp.success(count);
        } catch (Exception e) {
            log.error("获取用户合集总数失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取合集总数失败");
        }
    }

    @Override
    public Resp<Page<Collection>> queryCollectionsByIds(List<Long> collectionIds, long current, long size) {
       log.info("queryCollectionsByIds: collectionIds: {}, current: {}, size: {}", collectionIds, current, size);
        try {
            LambdaQueryWrapper<Collection> lqw = new LambdaQueryWrapper<>();
            lqw.in(Collection::getId, collectionIds);
            lqw.eq(Collection::getIsDeleted, 0);
            lqw.orderByDesc(Collection::getUpdateTime);
            Page<Collection> page = new Page<>(current, size);
            page = page(page, lqw);
            return Resp.success(page);
        }catch (Exception e) {
            log.error("查询合集列表失败, collectionIds: {}, current: {}, size: {}", collectionIds, current, size, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询合集列表失败: " + e.getMessage());
        }
    }
} 