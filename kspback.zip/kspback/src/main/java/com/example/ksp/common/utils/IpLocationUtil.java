package com.example.ksp.common.utils;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class IpLocationUtil {
    
    private static final String IP_API_URL = "http://ip-api.com/json/";
    private static final String FALLBACK_LOCATION = "本地主机";
    
    /**
     * 根据IP地址获取地理位置
     * @param ip IP地址
     * @return 地理位置信息（格式：国家-省/州-城市）
     */
    public String getLocationByIp(String ip) {
        try {
            String response = HttpUtil.get(IP_API_URL + ip + "?lang=zh-CN");
            JSONObject json = JSON.parseObject(response);
            
            if ("success".equals(json.getString("status"))) {
                String country = json.getString("country");
                String region = json.getString("regionName");
                String city = json.getString("city");
                
                return String.format("%s-%s-%s", country, region, city);
            }
            
            return FALLBACK_LOCATION;
        } catch (Exception e) {
            log.error("获取IP地址位置信息失败: {}", e.getMessage());
            return FALLBACK_LOCATION;
        }
    }
} 