package com.example.ksp.modules.system.collection.collection.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;

import java.util.List;

public interface CollectionService extends IService<Collection> {
    
    Resp<Collection> createCollection(CollectionCreateDTO createDTO);
    
    Resp<Collection> updateCollection(CollectionUpdateDTO updateDTO);
    
    Resp<Void> deleteCollection(Long id);
    
    Resp<Collection> getCollection(Long id);
    
    Resp<Page<Collection>> queryCollections(CollectionQueryDTO queryDTO);
    
    /**
     * 获取用户创建的合集总数
     * @param userId 用户ID
     * @return 合集总数
     */
    Resp<Integer> getUserCollectionCount(Long userId);

    /**
     *  根据合集ID列表查询合集
     * @param collectionIds 合集ID列表
     * @param current 当前页码
     * @param size 每页大小
     * @return 合集列表
     */
    Resp<Page<Collection>> queryCollectionsByIds(List<Long> collectionIds, long current, long size);
}