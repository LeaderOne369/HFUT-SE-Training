package com.example.ksp.modules.system.reviewlog.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import com.example.ksp.modules.system.reviewlog.mapper.ReviewLogMapper;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;

@Service
public class ReviewLogServiceImpl extends ServiceImpl<ReviewLogMapper, ReviewLog> implements ReviewLogService {

    @Override
    public boolean createReviewLog(ReviewLog reviewLog) {
        reviewLog.setReviewTime(LocalDateTime.now());
        reviewLog.setReviewStatus(0); // 默认待审核
        return save(reviewLog);
    }

    @Override
    public boolean updateReviewStatus(Long id, Integer status, String notes) {
        ReviewLog reviewLog = getById(id);
        if (reviewLog == null) {
            return false;
        }
        
        reviewLog.setReviewStatus(status);
        reviewLog.setReviewNotes(notes);
        reviewLog.setReviewTime(LocalDateTime.now());
        return updateById(reviewLog);
    }

    @Override
    public Page<ReviewLog> getContentReviews(Long contentId, Integer contentType, long current, long size) {
        Page<ReviewLog> page = new Page<>(current, size);
        LambdaQueryWrapper<ReviewLog> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ReviewLog::getContentId, contentId)
                .eq(ReviewLog::getContentType, contentType)
                .orderByDesc(ReviewLog::getReviewTime);
        
        return page(page, wrapper);
    }

    @Override
    public Page<ReviewLog> getReviewerLogs(Long reviewerId, Integer status, long current, long size) {
        Page<ReviewLog> page = new Page<>(current, size);
        LambdaQueryWrapper<ReviewLog> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ReviewLog::getReviewerId, reviewerId)
                .eq(status != null, ReviewLog::getReviewStatus, status)
                .orderByDesc(ReviewLog::getReviewTime);
        
        return page(page, wrapper);
    }

    @Override
    public Page<ReviewLog> getPendingReviews(Integer contentType, long current, long size) {
        Page<ReviewLog> page = new Page<>(current, size);
        LambdaQueryWrapper<ReviewLog> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ReviewLog::getReviewStatus, 0)
                .eq(contentType != null, ReviewLog::getContentType, contentType)
                .orderByAsc(ReviewLog::getReviewTime);
        
        return page(page, wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean batchReview(Long[] ids, Integer status, String notes) {
        return Arrays.stream(ids).allMatch(id -> updateReviewStatus(id, status, notes));
    }
} 