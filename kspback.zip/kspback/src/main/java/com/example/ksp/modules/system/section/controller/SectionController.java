package com.example.ksp.modules.system.section.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.section.service.SectionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级分区管理接口")
@RestController
@RequestMapping("/api/system/section")
public class SectionController {

    @Autowired
    private SectionService sectionService;
    @Operation(summary = "创建分区")
    @PostMapping("/create")
    public Resp<Boolean> createSection(@RequestBody Section section) {
        boolean result = sectionService.createSection(section);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "创建分区失败");
    }

    @Operation(summary = "更新分区")
    @PutMapping("/update")
    public Resp<Boolean> updateSection(@RequestBody Section section) {
        boolean result = sectionService.updateSection(section);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新分区失败");
    }

    @Operation(summary = "删除分区")
    @DeleteMapping("/delete/{id}")
    public Resp<Boolean> deleteSection(
            @Parameter(description = "分区ID", required = true) 
            @PathVariable Long id) {
        boolean result = sectionService.deleteSection(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除分区失败");
    }

    @Operation(summary = "切换分区可见性")
    @PutMapping("/toggle-visibility/{id}")
    public Resp<Boolean> toggleVisibility(
            @Parameter(description = "分区ID", required = true) 
            @PathVariable Long id) {
        boolean result = sectionService.toggleVisibility(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "切换分区可见性失败");
    }

    @Operation(summary = "分页查询分区")
    @GetMapping("/list")
    public Resp<Page<Section>> listSections(
            @Parameter(description = "页码", required = true) 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小", required = true) 
            @RequestParam(defaultValue = "10") long size) {
        Page<Section> page = new Page<>(current, size);
        LambdaQueryWrapper<Section> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(Section::getUpdateTime);
        
        Page<Section> result = sectionService.page(page, wrapper);
        return Resp.success(result);
    }

    @Operation(summary = "获取分区详情")
    @GetMapping("/get/{id}")
    public Resp<Section> getSection(
            @Parameter(description = "分区ID", required = true) 
            @PathVariable Long id) {
        Section section = sectionService.getById(id);
        if (section != null) {
            return Resp.success(section);
        }
        return Resp.error(HttpStatus.NOT_FOUND, "分区不存在");
    }
}
