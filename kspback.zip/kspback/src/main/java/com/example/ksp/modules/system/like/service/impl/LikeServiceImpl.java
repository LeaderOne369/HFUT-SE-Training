package com.example.ksp.modules.system.like.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.mapper.CollectionMapper;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.comment.mapper.CommentMapper;
import com.example.ksp.modules.system.like.entity.Like;
import com.example.ksp.modules.system.like.mapper.LikeMapper;
import com.example.ksp.modules.system.like.service.LikeService;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.mapper.PostMapper;
import com.example.ksp.modules.system.comment.service.CommentService;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class LikeServiceImpl extends ServiceImpl<LikeMapper, Like> implements LikeService {
    
    @Resource
    private LikeMapper likeMapper;
    
    @Resource
    private PostMapper postMapper;
    
    @Resource
    private CollectionMapper collectionMapper;
    
    @Resource
    private CommentService commentService;

    @Override
    public boolean addLike(Long userId, Long objectId, Integer objectType) {
        if (checkLiked(userId, objectId, objectType)) {
            return false;
        }

        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getLikeObjectId, objectId)
                .eq(Like::getLikeObjectType, objectType);

        if(count(wrapper) > 0){
            Like like = new Like();
            like.setId( likeMapper.selectOne(wrapper).getId());
            like.setIsDeleted(0);
            return  updateById(like);
        }

        Like like = new Like();
        like.setUserId(userId);
        like.setLikeObjectId(objectId);
        like.setLikeObjectType(objectType);
        like.setLikeTime(LocalDateTime.now());
        like.setIsDeleted(0);

        return save(like);
    }

    @Override
    public boolean cancelLike(Long userId, Long objectId, Integer objectType) {
        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getLikeObjectId, objectId)
                .eq(Like::getLikeObjectType, objectType);

        return remove(wrapper);
    }

    @Override
    public boolean checkLiked(Long userId, Long objectId, Integer objectType) {
        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getLikeObjectId, objectId)
                .eq(Like::getLikeObjectType, objectType)
                .eq(Like::getIsDeleted, 0);

        return count(wrapper) > 0;
    }

    @Override
    public Resp<List<Like>> getAllLikesByUser(Long userId) {
        log.info("查询用户所有点赞记录，用户ID: {}", userId);
        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getIsDeleted, 0)
                .orderByDesc(Like::getLikeTime);
        return Resp.success(list(wrapper));
    }

    @Override
    public Resp<List<Like>> getLikesByUserAndType(Long userId, Integer objectType) {
        log.info("查询用户特定类型点赞记录，用户ID: {}, 对象类型: {}", userId, objectType);
        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getLikeObjectType, objectType)
                .eq(Like::getIsDeleted, 0)
                .orderByDesc(Like::getLikeTime);
        return Resp.success(list(wrapper));
    }

    @Override
    public Resp<Integer> getLikeCountByUser(Long userId) {
        log.info("查询用户点赞总数，用户ID: {}", userId);
        LambdaQueryWrapper<Like> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Like::getUserId, userId)
                .eq(Like::getIsDeleted, 0);
        return Resp.success(Math.toIntExact(count(wrapper)));
    }

    @Override
    public Resp<Integer> getReceivedLikeCount(Long userId) {
        try {
            // 1. 获取用户的所有帖子ID
            LambdaQueryWrapper<Post> postLqw = Wrappers.lambdaQuery();
            postLqw.select(Post::getId)
                   .eq(Post::getUserId, userId)
                   .eq(Post::getIsDeleted, 0);
            List<Long> postIds = postMapper.selectList(postLqw)
                    .stream()
                    .map(Post::getId)
                    .collect(Collectors.toList());

            // 2. 获取用户的所有合集ID
            LambdaQueryWrapper<Collection> collectionLqw = Wrappers.lambdaQuery();
            collectionLqw.select(Collection::getId)
                        .eq(Collection::getCreatorId, userId)
                        .eq(Collection::getIsDeleted, 0);
            List<Long> collectionIds = collectionMapper.selectList(collectionLqw)
                    .stream()
                    .map(Collection::getId)
                    .collect(Collectors.toList());

            // 3. 获取用户的所有评论ID
            LambdaQueryWrapper<Comment> commentLqw = Wrappers.lambdaQuery();
            commentLqw.select(Comment::getId)
                     .eq(Comment::getCommenterId, userId)
                     .eq(Comment::getIsDeleted, 0);
            List<Long> commentIds = commentService.list(commentLqw)
                    .stream()
                    .map(Comment::getId)
                    .collect(Collectors.toList());

            // 4. 统计这些内容收到的点赞数
            LambdaQueryWrapper<Like> likeLqw = Wrappers.lambdaQuery();
            likeLqw.eq(Like::getIsDeleted, 0);
            
            // 统计帖子点赞
            if (!postIds.isEmpty()) {
                likeLqw.and(wrapper -> wrapper
                    .in(Like::getLikeObjectId, postIds)
                    .eq(Like::getLikeObjectType, 1));
            }
            
            // 统计合集点赞
            if (!collectionIds.isEmpty()) {
                likeLqw.or(wrapper -> wrapper
                    .in(Like::getLikeObjectId, collectionIds)
                    .eq(Like::getLikeObjectType, 2));
            }
            
            // 统计评论点赞
            if (!commentIds.isEmpty()) {
                likeLqw.or(wrapper -> wrapper
                    .in(Like::getLikeObjectId, commentIds)
                    .eq(Like::getLikeObjectType, 3));
            }

            // 如果用户没有任何内容，直接返回0
            if (postIds.isEmpty() && collectionIds.isEmpty() && commentIds.isEmpty()) {
                return Resp.success(0);
            }

            int count = Math.toIntExact(count(likeLqw));
            return Resp.success(count);
        } catch (Exception e) {
            log.error("获取用户收到的点赞数量失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取点赞数量失败");
        }
    }
}
