package com.example.ksp.modules.client.comment;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;
import com.example.ksp.modules.proxy.CommentServiceProxy;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端评论接口")
@RestController("clientCommentController")
@RequestMapping("/api/client/comment")
@RequiredArgsConstructor
public class CommentController {


    private final CommentService commentService;

    private final CommentServiceProxy commentServiceProxy;

    @Operation(summary = "举报评论")
    @PostMapping("/{commentId}/report")
    public Resp<String> reportComment(
            @Parameter(description = "评论ID") @PathVariable Long commentId,
            @Parameter(description = "举报类型ID") @RequestParam Long reportTypeId,
            @Parameter(description = "举报理由") @RequestParam(required = false) String reason,
            @RequestHeader("token") String token) {
        return commentService.reportComment(commentId, reportTypeId, 2L, reason, token);
    }

    @Operation(summary = "回复评论")
    @PostMapping("/{commentId}/reply")
    public Resp<CommentDTO> replyComment(
            @Parameter(description = "评论ID") @PathVariable Long commentId,
            @Parameter(description = "评论内容") @RequestParam String content,
            @RequestHeader("token") String token) {
        return commentService.replyComment(commentId, content, token);
    }


    @Operation(summary = "删除评论")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteComment(
            @Parameter(description = "评论ID")
            @PathVariable Long id) {
        return commentServiceProxy.deleteComment(id);
    }
}
