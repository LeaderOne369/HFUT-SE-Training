package com.example.ksp.modules.system.citation.citation.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citation.dto.CitationCreateDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationQueryDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationUpdateDTO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;

import java.util.List;

public interface CitationService extends IService<Citation> {
    
    Resp<Citation> createCitation(CitationCreateDTO createDTO);
    
    Resp<Citation> updateCitation(CitationUpdateDTO updateDTO);
    
    Resp<String> deleteCitation(Long id);
    
    Resp<Citation> getCitation(Long id);
    
    Resp<Page<Citation>> queryCitations(CitationQueryDTO queryDTO);

    Resp<List<Citation>> getPostCitations(Long postId);
} 