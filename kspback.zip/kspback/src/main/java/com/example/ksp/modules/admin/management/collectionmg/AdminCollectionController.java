package com.example.ksp.modules.admin.management.collectionmg;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.CollectionServiceProxy;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController("adminCollectionController")
@RequestMapping("/admin/collection")
@RequiredArgsConstructor
@Tag(name = "合集管理接口")
public class AdminCollectionController {

    private final CollectionServiceProxy collectionServiceProxy;

    @PostMapping
    @Operation(summary = "创建合集")
    public Resp<Collection> createCollection(@RequestBody CollectionCreateDTO createDTO) {
        return collectionServiceProxy.createCollection(createDTO);
    }

    @PutMapping
    @Operation(summary = "更新合集")
    public Resp<Collection> updateCollection(@RequestBody CollectionUpdateDTO updateDTO) {
        return collectionServiceProxy.updateCollection(updateDTO);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "删除合集")
    public Resp<Void> deleteCollection(@PathVariable Long id) {
        return collectionServiceProxy.deleteCollection(id);
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取合集详情")
    public Resp<Collection> getCollection(@PathVariable Long id) {
        return collectionServiceProxy.getCollection(id);
    }

    @GetMapping("/page")
    @Operation(summary = "分页查询合集")
    public Resp<Page<Collection>> queryCollections(CollectionQueryDTO queryDTO) {
        return collectionServiceProxy.queryCollections(queryDTO);
    }

    @GetMapping("/count/{userId}")
    @Operation(summary = "获取用户创建的合集总数")
    public Resp<Integer> getUserCollectionCount(@PathVariable Long userId) {
        return collectionServiceProxy.getUserCollectionCount(userId);
    }

    @GetMapping("/isSubscribed")
    @Operation(summary = "判断用户是否订阅了合集")
    public Resp<Boolean> isSubscribed(@RequestParam Long collectionId, @RequestParam Long userId) {
        return collectionServiceProxy.isSubscribed(collectionId, userId);
    }
}
