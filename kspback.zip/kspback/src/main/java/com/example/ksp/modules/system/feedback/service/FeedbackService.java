package com.example.ksp.modules.system.feedback.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.modules.system.feedback.entity.Feedback;

import java.time.LocalDateTime;

public interface FeedbackService extends IService<Feedback> {

    /**
     * 提交反馈
     */
    boolean submitFeedback(Feedback feedback);

    /**
     * 更新反馈状态
     */
    boolean updateStatus(Long id, Integer status);

    /**
     * 删除反馈
     */
    boolean deleteFeedback(Long id);

    /**
     * 获取用户的反馈列表
     */
    Page<Feedback> getUserFeedbacks(Long userId, Integer status, long current, long size);

    /**
     * 获取所有反馈列表（管理员使用）
     */
    Page<Feedback> getAllFeedbacks(Integer status, long current, long size);

    /**
     * 按照各种条件查询反馈记录，并返回分页结果
     *
     * @param userId          用户ID
     * @param feedbackContent 反馈内容关键字
     * @param status          反馈状态
     * @param startTime       反馈提交的开始时间
     * @param endTime         反馈提交的结束时间
     * @param page            当前页码
     * @param size            每页记录数
     * @return 分页的反馈记录
     */
    Page<Feedback> queryFeedbacks(Long userId, String feedbackContent, Integer status,
                                  LocalDateTime startTime, LocalDateTime endTime,
                                  int page, int size);
}
