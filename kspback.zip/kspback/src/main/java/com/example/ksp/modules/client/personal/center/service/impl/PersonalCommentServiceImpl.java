package com.example.ksp.modules.client.personal.center.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.service.PersonalCommentService;
import com.example.ksp.modules.proxy.CommentServiceProxy;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalCommentServiceImpl implements PersonalCommentService {

    private final CommentServiceProxy commentServiceProxy;

    @Override
    public Resp<Page<Comment>> getUserComments(Long userId, long current, long size) {
        try {
            CommentQueryDTO queryDTO = new CommentQueryDTO();
            queryDTO.setCommenterId(userId);
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            // 只查询未删除的评论
            // 注意：这里假设CommentQueryDTO中添加了isDeleted字段
            // queryDTO.setIsDeleted(0);
            
            return commentServiceProxy.queryComments(queryDTO);
        } catch (Exception e) {
            log.error("获取用户评论列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论列表失败");
        }
    }

    @Override
    public Resp<Page<Comment>> getReceivedComments(Long userId, long current, long size) {
        try {
            CommentQueryDTO queryDTO = new CommentQueryDTO();
            // 查询对用户帖子的评论
            queryDTO.setCommentableId(userId);
            queryDTO.setCommentableType(1); // 1表示帖子
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            // 只查询公开的评论
            // 注意：这里假设CommentQueryDTO中添加了isPublic字段
            // queryDTO.setIsPublic(1);
            // 只查询未删除的评论
            // queryDTO.setIsDeleted(0);
            
            return commentServiceProxy.queryComments(queryDTO);
        } catch (Exception e) {
            log.error("获取用户收到的评论列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论列表失败");
        }
    }

    @Override
    public Resp<Comment> getCommentDetail(Long userId, Long commentId) {
        try {
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }
            
            Comment comment = commentResp.getData();
            // 检查评论是否已删除
            if (comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论已删除");
            }
            
            // 检查是否有权限查看
            // 1. 是评论的发布者
            // 2. 是被评论对象的所有者
            // 3. 如果是私密评论，必须是评论相关者才能查看
            if (!comment.getCommenterId().equals(userId) && 
                !comment.getCommentableId().equals(userId) && 
                comment.getIsPublic() == 0) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权查看此评论");
            }
            
            return Resp.success(comment);
        } catch (Exception e) {
            log.error("获取评论详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论详情失败");
        }
    }

    @Override
    public Resp<Boolean> deleteComment(Long userId, Long commentId) {
        try {
            // 验证评论所有权
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }
            
            Comment comment = commentResp.getData();
            // 检查评论是否已删除
            if (comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论已删除");
            }
            
            // 只有评论发布者可以删除评论
            if (!comment.getCommenterId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权删除此评论");
            }
            
            Resp<Void> deleteResp = commentServiceProxy.deleteComment(commentId);
            return Resp.success(deleteResp.getCode() == 200);
        } catch (Exception e) {
            log.error("删除评论失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除评论失败");
        }
    }
} 