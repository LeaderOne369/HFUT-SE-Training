package com.example.ksp.modules.system.share.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.share.entity.Share;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ShareMapper extends BaseMapper<Share> {
} 