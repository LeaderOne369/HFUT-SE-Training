package com.example.ksp.modules.system.report.report.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.ReportTypeServiceProxy;
import com.example.ksp.modules.proxy.ReportedTypeServiceProxy;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.comment.service.CommentService;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.service.PostService;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.dto.ReportQueryDTO;
import com.example.ksp.modules.system.report.report.dto.ReportUpdateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.report.mapper.ReportMapper;
import com.example.ksp.modules.system.report.report.service.ReportService;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reportedtype.service.ReportedTypeService;
import com.example.ksp.modules.system.report.reporttype.service.ReportTypeService;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportServiceImpl extends ServiceImpl<ReportMapper, Report> implements ReportService {


    private  final ReportedTypeService reportedTypeService;
    private  final ReportTypeService reportTypeService;
    private  final ReportTypeServiceProxy reportTypeServiceProxy;
    private  final ReportedTypeServiceProxy reportedTypeServiceProxy;
    private  final UserService userService;
    private  final CommentService commentService;
    private  final PostService postService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Report> createReport(ReportCreateDTO createDTO, Long userId) {
        try {
            // 检查举报对象是否已被删除
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getReportedContentId, createDTO.getReportedContentId())
                   .eq(Report::getReportedTypeId, createDTO.getReportedTypeId())
                   .eq(Report::getUserId, userId)
                   .eq(Report::getIsDeleted, 0);
            
            if (count(wrapper) > 0) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "您已经举报过该内容");
            }
            
            Report report = new Report();
            BeanUtils.copyProperties(createDTO, report);
            
            report.setUserId(userId);
            report.setReportTime(LocalDateTime.now());
            report.setStatus(0); // 待处理
            report.setOutcome(0); // 无行动
            report.setIsDeleted(0);
            
            save(report);
            return Resp.success(report);
        } catch (Exception e) {
            log.error("创建举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建举报失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Report> updateReport(ReportUpdateDTO updateDTO) {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getId, updateDTO.getId())
                   .eq(Report::getIsDeleted, 0);
            
            Report report = getOne(wrapper);
            if (report == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报不存在或已被删除");
            }
            
            if (updateDTO.getStatus() != null) {
                report.setStatus(updateDTO.getStatus());
            }
            if (updateDTO.getOutcome() != null) {
                report.setOutcome(updateDTO.getOutcome());
            }
            
            updateById(report);
            return Resp.success(report);
        } catch (Exception e) {
            log.error("更新举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新举报失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Report> getReport(Long reportId) {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getId, reportId)
                   .eq(Report::getIsDeleted, 0);
            
            Report report = getOne(wrapper);
            if (report == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报不存在或已被删除");
            }
            return Resp.success(report);
        } catch (Exception e) {
            log.error("获取举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<Report>> queryReports(ReportQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getIsDeleted, 0);
            
            if (queryDTO.getUserId() != null) {
                wrapper.eq(Report::getUserId, queryDTO.getUserId());
            }
            if (queryDTO.getReportedTypeId() != null) {
                wrapper.eq(Report::getReportedTypeId, queryDTO.getReportedTypeId());
            }
            if (queryDTO.getReportTypeId() != null) {
                wrapper.eq(Report::getReportTypeId, queryDTO.getReportTypeId());
            }
            if (queryDTO.getStatus() != null) {
                wrapper.eq(Report::getStatus, queryDTO.getStatus());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(Report::getReportTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(Report::getReportTime, queryDTO.getEndTime());
            }
            
            wrapper.orderByDesc(Report::getReportTime);
            
            Page<Report> page = page(new Page<>(queryDTO.getCurrent(), queryDTO.getSize()), wrapper);
            return Resp.success(page);
        } catch (Exception e) {
            log.error("查询举报失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询举报失败: " + e.getMessage());
        }
    }

    @Override
    public long countByStatus(Integer status) {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getStatus, status)
                   .eq(Report::getIsDeleted, 0);
            return count(wrapper);
        } catch (Exception e) {
            log.error("统计举报状态数量失败", e);
            return 0L;
        }
    }

    @Override
    public Map<String, Long> countByReportType() {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getIsDeleted, 0)
                   .groupBy(Report::getReportTypeId)
                   .select(Report::getReportTypeId);
            
            List<Report> reports = list(wrapper);
            Map<String, Long> result = new HashMap<>();
            
            for (Report report : reports) {
                LambdaQueryWrapper<Report> countWrapper = new LambdaQueryWrapper<>();
                countWrapper.eq(Report::getReportTypeId, report.getReportTypeId())
                           .eq(Report::getIsDeleted, 0);
                result.put(report.getReportTypeId().toString(), count(countWrapper));
            }
            
            return result;
        } catch (Exception e) {
            log.error("统计举报类型数量失败", e);
            return new HashMap<>();
        }
    }

    @Override
    public Map<String, Long> countByOutcome() {
        try {
            LambdaQueryWrapper<Report> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Report::getIsDeleted, 0)
                   .groupBy(Report::getOutcome)
                   .select(Report::getOutcome);
            
            List<Report> reports = list(wrapper);
            Map<String, Long> result = new HashMap<>();
            
            for (Report report : reports) {
                LambdaQueryWrapper<Report> countWrapper = new LambdaQueryWrapper<>();
                countWrapper.eq(Report::getOutcome, report.getOutcome())
                           .eq(Report::getIsDeleted, 0);
                result.put(report.getOutcome().toString(), count(countWrapper));
            }
            
            return result;
        } catch (Exception e) {
            log.error("统计处理结果数量失败", e);
            return new HashMap<>();
        }
    }

    @Override
    public String getReportedContent(Long contentId, Long reportedTypeId) {
        try {
            ReportedType reportedType = reportedTypeService.getById(reportedTypeId);
            if (reportedType == null) {
                log.error("被举报对象类型不存在, reportedTypeId: {}", reportedTypeId);
                return "未知的举报对象类型";
            }

            String result = "";
            switch (reportedType.getTypeName()) {
                case "POST" -> {
                    Post post = postService.getById(contentId);
                    result = post != null ? JSONUtil.toJsonStr(post) : "帖子不存在或已被删除";
                }
                case "COMMENT" -> {
                    Comment comment = commentService.getById(contentId);
                    result = comment != null ? comment.getContent() : "评论不存在或已被删除";
                }
                case "USER" -> {
                    User user = userService.getById(contentId);
                    result = user != null ? user.getUsername() : "用户不存在或已被删除";
                }
                default -> result = "未知的举报对象类型";
            }
            return result;
        } catch (Exception e) {
            log.error("获取被举报内容失败, contentId: {}, reportedTypeId: {}", contentId, reportedTypeId, e);
            return "获取内容失败";
        }
    }

    @Override
    public Object deleteReportedContent(Long contentId, Long reportedTypeId) {
        try {
            ReportedType reportedType = reportedTypeService.getById(reportedTypeId);
            if (reportedType == null) {
                log.error("被举报对象类型不存在, reportedTypeId: {}", reportedTypeId);
                return false;
            }

            Object result;
            switch (reportedType.getTypeName()) {
                case "POST" -> result = postService.deletePost(contentId).getData();  // 删除帖子
                case "COMMENT" -> result = commentService.deleteComment(contentId);  // 删除评论
                case "USER" -> {
                    log.warn("用户类型的举报不支持删除操作, contentId: {}", contentId);
                    result = false;
                }
                default -> {
                    log.error("未知的举报对象类型, code: {}", reportedType.getTypeName());
                    result = false;
                }
            }
            return result;
        } catch (Exception e) {
            log.error("删除被举报内容失败, contentId: {}, reportedTypeId: {}", contentId, reportedTypeId, e);
            return false;
        }
    }
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Void> deleteReport(Long id) {
        try {
            // 检查举报是否存在
            Report report = getById(id);
            if (report == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报不存在");
            }

            // 逻辑删除举报
            report.setIsDeleted(1);
            if (!updateById(report)) {
                throw new RuntimeException("删除举报失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("删除举报失败, id: {}", id, e);
            throw new RuntimeException("删除举报失败", e);
        }
    }
}