package com.example.ksp.modules.system.report.reportedtype.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeCreateDTO;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeUpdateDTO;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reportedtype.mapper.ReportedTypeMapper;
import com.example.ksp.modules.system.report.reportedtype.service.ReportedTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class ReportedTypeServiceImpl extends ServiceImpl<ReportedTypeMapper, ReportedType> implements ReportedTypeService {

    @Override
    public Resp<ReportedType> createReportedType(ReportedTypeCreateDTO createDTO) {
        try {
            // 检查是否已存在相同名称的举报对象类型
            if (checkTypeNameExists(createDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "举报对象类型名称已存在");
            }
            
            ReportedType reportedType = new ReportedType();
            BeanUtils.copyProperties(createDTO, reportedType);
            
            save(reportedType);
            return Resp.success(reportedType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建举报对象类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<ReportedType> updateReportedType(ReportedTypeUpdateDTO updateDTO) {
        try {
            ReportedType existingType = getById(updateDTO.getId());
            if (existingType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报对象类型不存在");
            }
            
            // 如果修改了类型名称，需要检查是否与其他记录重复
            if (StringUtils.hasText(updateDTO.getTypeName()) 
                && !updateDTO.getTypeName().equals(existingType.getTypeName())
                && checkTypeNameExists(updateDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "举报对象类型名称已存在");
            }
            
            BeanUtils.copyProperties(updateDTO, existingType);
            updateById(existingType);
            
            return Resp.success(existingType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新举报对象类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> deleteReportedType(Long id) {
        try {
            if (!removeById(id)) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报对象类型不存在");
            }
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除举报对象类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<ReportedType> getReportedType(Long id) {
        try {
            ReportedType reportedType = getById(id);
            if (reportedType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报对象类型不存在");
            }
            return Resp.success(reportedType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报对象类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<ReportedType>> listReportedTypes(Page<ReportedType> page, String typeName, Integer isActive) {
        try {
            LambdaQueryWrapper<ReportedType> wrapper = new LambdaQueryWrapper<>();
            
            if (StringUtils.hasText(typeName)) {
                wrapper.like(ReportedType::getTypeName, typeName);
            }
            if (isActive != null) {
                wrapper.eq(ReportedType::getIsActive, isActive);
            }
            
            Page<ReportedType> result = page(page, wrapper);
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询举报对象类型列表失败: " + e.getMessage());
        }
    }

    private boolean checkTypeNameExists(String typeName) {
        LambdaQueryWrapper<ReportedType> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ReportedType::getTypeName, typeName);
        return count(wrapper) > 0;
    }
} 