package com.example.ksp.modules.system.follow.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.follow.dto.FollowCreateDTO;
import com.example.ksp.modules.system.follow.dto.FollowQueryDTO;
import com.example.ksp.modules.system.follow.service.FollowService;
import com.example.ksp.modules.system.user.entity.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级关注管理")
@RestController
@RequestMapping("/api/system/follow")
@RequiredArgsConstructor
public class FollowController {

    private final FollowService followService;

    @Operation(summary = "关注用户")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<String> follow(
            @Parameter(description = "关注信息") 
            @RequestBody @Valid FollowCreateDTO createDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Long currentUserId = Long.parseLong(authentication.getName());
        return followService.follow(currentUserId, createDTO);
    }

    @Operation(summary = "取消关注")
    @DeleteMapping("/{followeeId}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> unfollow(
            @Parameter(description = "被关注者ID") 
            @PathVariable Long followeeId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Long currentUserId = Long.parseLong(authentication.getName());
        return followService.unfollow(currentUserId, followeeId);
    }

    @Operation(summary = "检查是否已关注")
    @GetMapping("/check/{followeeId}")
    @PreAuthorize("isAuthenticated()")
    public Resp<Boolean> checkFollow(
            @Parameter(description = "被关注者ID") 
            @PathVariable Long followeeId) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Long currentUserId = Long.parseLong(authentication.getName());
        return followService.checkFollow(currentUserId, followeeId);
    }

    @Operation(summary = "查询关注列表或粉丝列表")
    @GetMapping("/list")
    @PreAuthorize("isAuthenticated()")
    public Resp<Page<User>> queryFollowList(@Valid FollowQueryDTO queryDTO) {
        return followService.queryFollowList(queryDTO);
    }
} 