package com.example.ksp.modules.admin.management.reportmg.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "举报查询参数")
public class ReportQueryDTO {
    
    @Schema(description = "举报对象类型ID")
    private Long reportedTypeId;
    
    @Schema(description = "举报类型ID")
    private Long reportTypeId;
    
    @Schema(description = "处理状态(0:待处理 1:正在处理 2:已处理 3:无需处理)")
    private Integer status;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
    
    @Schema(description = "关键词(用户名/举报理由)")
    private String keyword;
    
    @Schema(description = "当前页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
} 