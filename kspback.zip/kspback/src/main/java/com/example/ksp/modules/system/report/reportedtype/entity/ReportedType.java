package com.example.ksp.modules.system.report.reportedtype.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@TableName("reported_type")
@Schema(description = "举报对象类型实体")
public class ReportedType {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "举报对象类型ID")
    private Long id;
    
    @Schema(description = "举报对象类型名称")
    private String typeName;
    
    @Schema(description = "举报对象类型描述")
    private String typeDescription;
    
    @Schema(description = "是否启用(1:启用 0:未启用)")
    private Integer isActive;
} 