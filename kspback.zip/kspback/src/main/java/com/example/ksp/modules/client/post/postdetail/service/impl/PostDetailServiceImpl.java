package com.example.ksp.modules.client.post.postdetail.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.async.AsyncService;
import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.utils.MinioUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;
import com.example.ksp.modules.client.post.postdetail.dto.PostDetailDTO;
import com.example.ksp.modules.client.post.postdetail.dto.PostStatsDTO;
import com.example.ksp.modules.client.post.postdetail.service.PostDetailService;
import com.example.ksp.modules.proxy.*;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import com.example.ksp.modules.system.section.service.SectionService;
import com.example.ksp.modules.system.share.entity.Share;
import com.example.ksp.modules.system.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.*;
import java.util.stream.Collectors;

import static com.example.ksp.modules.client.post.publish.service.impl.PostPublishServiceImpl.COVER_BUCKET;

@Slf4j
@Service
@RequiredArgsConstructor
public class PostDetailServiceImpl implements PostDetailService {

    private final PostServiceProxy postServiceProxy;
    private final UserServiceProxy userServiceProxy;
    private final LikeServiceProxy likeServiceProxy;
    private final ShareServiceProxy shareServiceProxy;
    private final FavoriteServiceProxy favoriteServiceProxy;
    private final CommentServiceProxy commentServiceProxy;
    private final CollectionServiceProxy collectionServiceProxy;
    private final AsyncService asyncService;
    private final MinioUtil minioUtil;
    private final ReportServiceProxy reportServiceProxy;
    private final ReportedTypeServiceProxy reportedTypeServiceProxy;
    private final ReportTypeServiceProxy reportTypeServiceProxy;
    private final SectionServiceProxy sectionServiceProxy;


    @Override
    public Resp<PostStatsDTO> getPostStats(Long postId, String token) {
        log.info("获取帖子统计信息, postId: {}", postId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        
        try {
            // 获取当前的 SecurityContext
            SecurityContext securityContext = SecurityContextHolder.getContext();
            
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 获取帖子基本信息
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            Post post = postResp.getData();
            
            // 3. 获取各种统计数据

            Resp<Integer> favoriteCountResp = favoriteServiceProxy.getFavoriteCount(postId, 1);
            
            // 4. 获取当前用户的交互状态
            Resp<Boolean> isLikedResp = likeServiceProxy.isLiked(currentUserId, postId, 1);
            Resp<Boolean> isFavoritedResp = favoriteServiceProxy.isFavorited(postId, 1, currentUserId);
            Resp<Boolean> isSharedResp = shareServiceProxy.isShared(postId, 1, currentUserId);
            
            // 5. 构建统计信息
            PostStatsDTO stats = PostStatsDTO.builder()
                    .postId(post.getId())
                    .viewCount(post.getViewCount())
                    .likeCount(post.getLikeCount())
                    .commentCount(post.getCommentCount())
                    .shareCount(post.getShareCount())
                    .favoriteCount(favoriteCountResp.getData())
                    .isLiked(isLikedResp.getCode() == 200 && Boolean.TRUE.equals(isLikedResp.getData()))
                    .isFavorited(isFavoritedResp.getCode() == 200 && Boolean.TRUE.equals(isFavoritedResp.getData()))
                    .isShared(isSharedResp.getCode() == 200 && Boolean.TRUE.equals(isSharedResp.getData()))
                    .build();
            
            // 6. 异步更新浏览量
//            asyncService.execute(() -> {
//                try {
//                    // 在新线程中设置 SecurityContext
//                    SecurityContextHolder.setContext(securityContext);
//                    postServiceProxy.incrementViewCount(postId);
//                } finally {
//                    // 清理 SecurityContext
//                    SecurityContextHolder.clearContext();
//                }
//            });
            
            return Resp.success(stats);
        } catch (Exception e) {
            log.error("获取帖子统计信息失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取统计信息失败");
        }
    }

    @Override
    public Resp<Object> getPostDetail(Long postId, String token) {
        log.info("获取帖子详细信息, postId: {}", postId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        
        try {
            // 1. 获取帖子基本信息
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            Post post = postResp.getData();
            
            // 2. 获取作者信息
            Resp<User> authorResp = userServiceProxy.getUser(post.getUserId());
            if (authorResp.getCode() != 200 || authorResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "作者信息不存在");
            }
            User author = authorResp.getData();
            
            // 3. 获取统计信息
            Resp<PostStatsDTO> statsResp = getPostStats(postId, token);
            if (statsResp.getCode() != 200) {
                return Resp.error(statsResp.getCode(), statsResp.getMsg());
            }
            
            // 4. 获取合集信息和订阅状态
            boolean isSubscribed = false;
            String collectionName = null;
            if (post.getCollectionId() != null) {
                Resp<Collection> collectionResp = collectionServiceProxy.getCollection(post.getCollectionId());
                if (collectionResp.getCode() == 200 && collectionResp.getData() != null) {
                    collectionName = collectionResp.getData().getCollectionName();
                    // 获取当前用户ID
                    String username = JwtUtil.parseJWT(token).getSubject();
                    Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
                    if (userIdResp.getCode() == 200 && userIdResp.getData() != null) {
                        Resp<Boolean> subscribeResp = collectionServiceProxy.isSubscribed(post.getCollectionId(), userIdResp.getData());
                        isSubscribed = subscribeResp.getCode() == 200 && Boolean.TRUE.equals(subscribeResp.getData());
                    }
                }
            }
            
            // 4.5 获取帖子内容文件信息并生成预签名URL
            String contentFileId = post.getContentFileId();
            String contentFilePath = post.getContentFilePath();
            String presignedUrl = null;
            
            if (StringUtils.isNotBlank(contentFilePath)) {
                try {
                    presignedUrl = minioUtil.getPermanentFileUrl(contentFilePath);

                } catch (Exception e) {
                    log.error("生成预签名URL失败, postId: {}, path: {}", postId, contentFilePath, e);
                }
            }
            String coverUrl=post.getCover();

            Citation citation = postServiceProxy.getCitation(post.getId());
            // 5. 构建返回DTO
            PostDetailDTO detailDTO = PostDetailDTO.builder()
                    .postId(post.getId())
                    .title(post.getTitle())
                    .authorId(author.getId())
                    .authorName(author.getUsername())
                    .authorAvatar(author.getAvatar())
                    .cover(coverUrl)
                    .sectionId(post.getSectionId())
                    .sectionName(sectionServiceProxy.getSectionById(post.getSectionId()).getSectionName())
                    .summary(post.getSummary())
                    .citation(citation)
                    .createTime(post.getPublishTime())
                    .updateTime(post.getUpdateTime())
                    .stats(statsResp.getData())
                    .tags(StringUtils.isBlank(post.getTags()) ? new ArrayList<>() : Arrays.asList(post.getTags().split(",")))
                    .collectionId(post.getCollectionId())
                    .collectionName(collectionName)
                    .isCollectionSubscribed(isSubscribed)
                    .contentFileId(contentFileId)
                    .contentFilePath(presignedUrl)  // 返回预签名URL而不是原始路径
                    .build();
            
            return Resp.success(detailDTO);
        } catch (Exception e) {
            log.error("获取帖子详细信息失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取帖子详细信息失败");
        }
    }

    @Override
    public Resp<Page<CommentDTO>> getPostComments(Long postId, String token, Long current, Long size) {
        log.info("获取帖子评论列表, postId: {}, current: {}, size: {}", postId, current, size);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        if (current == null || current <= 0) {
            current = 1L;
        }
        if (size == null || size <= 0) {
            size = 10L;
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 构建评论查询条件
            CommentQueryDTO queryDTO = new CommentQueryDTO();
            queryDTO.setCommentableId(postId);
            queryDTO.setCommentableType(1); // 1表示帖子
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            
            // 3. 获取评论列表
            Resp<Page<Comment>> commentsResp = commentServiceProxy.queryComments(queryDTO);
            if (commentsResp.getCode() != 200 || commentsResp.getData() == null) {
                return Resp.error(commentsResp.getCode(), commentsResp.getMsg());
            }
            
            Page<Comment> commentPage = commentsResp.getData();
            List<Comment> comments = commentPage.getRecords();
            
            // 4. 获取评论者信息
            Set<Long> userIds = comments.stream()
                    .map(Comment::getCommenterId)
                    .collect(Collectors.toSet());
            Map<Long, User> userMap = new HashMap<>();
            for (Long userId : userIds) {
                Resp<User> userResp = userServiceProxy.getUser(userId);
                if (userResp.getCode() == 200 && userResp.getData() != null) {
                    userMap.put(userId, userResp.getData());
                }
            }
            
            // 5. 获取当前用户对评论的点赞状态
            Map<Long, Boolean> likeStatusMap = new HashMap<>();
            for (Comment comment : comments) {
                Resp<Boolean> isLikedResp = likeServiceProxy.isLiked(comment.getId(),  currentUserId,3); // 3表示评论类型
                likeStatusMap.put(comment.getId(), 
                    isLikedResp.getCode() == 200 && Boolean.TRUE.equals(isLikedResp.getData()));
            }
            
            // 6. 转换为DTO
            List<CommentDTO> commentDTOs = comments.stream()
                    .map(comment -> {
                        User commenter = userMap.get(comment.getCommenterId());
                        User replyToCommenter = comment.getParentCommentId() != null ? 
                                userMap.get(getParentCommenterIdById(comment.getParentCommentId())) : null;
                        
                        return CommentDTO.builder()
                                .id(comment.getId())
                                .content(comment.getContent())
                                .commenterId(comment.getCommenterId())
                                .commenterName(commenter != null ? commenter.getUsername() : "未知用户")
                                .commenterAvatar(commenter != null ? commenter.getAvatar() : null)
                                .creationTime(comment.getCreationTime())
                                .likeCount(comment.getLikeCount())
                                .replyCount(comment.getReplyCount())
                                .isLiked(likeStatusMap.getOrDefault(comment.getId(), false))
                                .parentCommentId(comment.getParentCommentId())
                                .replyToCommenterId(replyToCommenter != null ? replyToCommenter.getId() : null)
                                .replyToCommenterName(replyToCommenter != null ? replyToCommenter.getUsername() : null)
                                .isPublic(comment.getIsPublic())
                                .reviewStatus(comment.getReviewStatus())
                                .build();
                    })
                    .collect(Collectors.toList());
            
            // 7. 构建分页结果
            Page<CommentDTO> result = new Page<>(current, size, commentPage.getTotal());
            result.setRecords(commentDTOs);
            
            return Resp.success(result);
        } catch (Exception e) {
            log.error("获取帖子评论列表失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论列表失败");
        }
    }

    @Override
    public Resp<Page<CommentDTO>> getChildComments(Long commentId, String token, Long current, Long size) {
        log.info("获取评论的子评论列表, commentId: {}, current: {}, size: {}", commentId, current, size);
        
        // 参数校验
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        if (current == null || current <= 0) {
            current = 1L;
        }
        if (size == null || size <= 0) {
            size = 10L;
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 构建子评论查询条件
            CommentQueryDTO queryDTO = new CommentQueryDTO();
            queryDTO.setParentCommentId(commentId);
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            
            // 3. 获取子评论列表
            Resp<Page<Comment>> commentsResp = commentServiceProxy.queryComments(queryDTO);
            if (commentsResp.getCode() != 200 || commentsResp.getData() == null) {
                return Resp.error(commentsResp.getCode(), commentsResp.getMsg());
            }
            
            // 4. 转换为DTO（复用现有代码）
            return convertCommentsToDTO(commentsResp.getData(), currentUserId);
        } catch (Exception e) {
            log.error("获取评论的子评论列表失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取子评论列表失败");
        }
    }

    @Override
    public Resp<String> toggleCommentLike(Long commentId, String token) {
        log.info("切换评论点赞状态, commentId: {}", commentId);
        
        // 参数校验
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查评论是否存在
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }
            
            // 3. 切换点赞状态
            Resp<Boolean> isLikedResp = likeServiceProxy.isLiked( currentUserId, commentId, 3);
            if (isLikedResp.getCode() != 200) {
                return Resp.error(isLikedResp.getCode(), isLikedResp.getMsg());
            }
            
            boolean isLiked = Boolean.TRUE.equals(isLikedResp.getData());
            if (isLiked) {
                // 取消点赞
                Resp<Boolean> cancelResp = likeServiceProxy.cancelLike(currentUserId, commentId, 3);
                if (cancelResp.getCode() != 200) {
                    return Resp.error(cancelResp.getCode(), cancelResp.getMsg());
                }
                // 减少点赞数
                commentServiceProxy.decrementLikeCount(commentId);
                return Resp.success("取消点赞成功");
            } else {
                // 添加点赞
                Resp<Boolean> addResp = likeServiceProxy.addLike(currentUserId, commentId, 3);
                if (addResp.getCode() != 200) {
                    return Resp.error(addResp.getCode(), addResp.getMsg());
                }
                // 增加点赞数
                commentServiceProxy.incrementLikeCount(commentId);
                return Resp.success("点赞成功");
            }
        } catch (Exception e) {
            log.error("切换评论点赞状态失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "操作失败");
        }
    }

    @Override
    public Resp<String> togglePostLike(Long postId, String token) {
        log.info("切换帖子点赞状态, postId: {}", postId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 切换点赞状态
            Resp<Boolean> isLikedResp = likeServiceProxy.isLiked(currentUserId, postId, 1);
            if (isLikedResp.getCode() != 200) {
                return Resp.error(isLikedResp.getCode(), isLikedResp.getMsg());
            }
            
            boolean isLiked = Boolean.TRUE.equals(isLikedResp.getData());
            if (isLiked) {
                // 取消点赞
                Resp<Boolean> cancelResp = likeServiceProxy.cancelLike(currentUserId, postId, 1);
                if (cancelResp.getCode() != 200) {
                    return Resp.error(cancelResp.getCode(), cancelResp.getMsg());
                }
                // 减少点赞数
                postServiceProxy.decrementLikeCount(postId);
                return Resp.success("取消点赞成功");
            } else {
                // 添加点赞
                Resp<Boolean> addResp = likeServiceProxy.addLike(currentUserId, postId, 1);
                if (addResp.getCode() != 200) {
                    return Resp.error(addResp.getCode(), addResp.getMsg());
                }
                // 增加点赞数
                postServiceProxy.incrementLikeCount(postId);
                return Resp.success("点赞成功");
            }
        } catch (Exception e) {
            log.error("切换帖子点赞状态失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "操作失败");
        }
    }

    @Override
    public Resp<String> sharePost(Long postId, String token) {
        log.info("分享帖子, postId: {}", postId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 添加分享记录
            Resp<Share> shareResp = shareServiceProxy.addShare(currentUserId, postId, 1);
            if (shareResp.getCode() != 200) {
                return Resp.error(shareResp.getCode(), shareResp.getMsg());
            }
            
            // 4. 增加分享数
            postServiceProxy.incrementShareCount(postId);
            
            return Resp.success("分享成功", shareResp.getData().getShareLink());
        } catch (Exception e) {
            log.error("分享帖子失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "分享失败");
        }
    }

    @Override
    public Resp<CommentDTO> replyPost(Long postId, String content, String token) {
        log.info("回复帖子, postId: {}, content: {}", postId, content);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        if (StringUtils.isBlank(content)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 创建评论
            CommentCreateDTO createDTO = new CommentCreateDTO();
            createDTO.setCommenterId(currentUserId);
            createDTO.setCommentableId(postId);
            createDTO.setCommentableType(1); // 1表示帖子
            createDTO.setContent(content);
            createDTO.setIsPublic(1); // 默认公开
            
            Resp<Comment> commentResp = commentServiceProxy.createComment(createDTO);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(commentResp.getCode(), commentResp.getMsg());
            }
            
            // 4. 增加帖子评论数
            postServiceProxy.incrementCommentCount(postId);
            
            // 5. 转换为DTO
            Comment comment = commentResp.getData();
            Resp<User> userResp = userServiceProxy.getUser(currentUserId);
            User user = userResp.getData();
            
            CommentDTO commentDTO = new CommentDTO();
            commentDTO.setId(comment.getId());
            commentDTO.setContent(comment.getContent());
            commentDTO.setCommenterId(comment.getCommenterId());
            commentDTO.setCommenterName(user != null ? user.getUsername() : "未知用户");
            commentDTO.setCommenterAvatar(user != null ? user.getAvatar() : null);
            commentDTO.setCreationTime(comment.getCreationTime());
            commentDTO.setLikeCount(0);
            commentDTO.setReplyCount(0);
            commentDTO.setIsLiked(false);
            commentDTO.setIsPublic(comment.getIsPublic());
            commentDTO.setReviewStatus(comment.getReviewStatus());
            
            return Resp.success(commentDTO);
        } catch (Exception e) {
            log.error("回复帖子失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "回复失败");
        }
    }

    /**
     * 根据评论ID获取评论者ID
     */
    private Long getParentCommenterIdById(Long commentId) {
        try {
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() == 200 && commentResp.getData() != null) {
                return commentResp.getData().getCommenterId();
            }
        } catch (Exception e) {
            log.error("获取父评论作者ID失败, commentId: {}", commentId, e);
        }
        return null;
    }

    /**
     * 将评论列表转换为DTO
     */
    private Resp<Page<CommentDTO>> convertCommentsToDTO(Page<Comment> commentPage, Long currentUserId) {
        List<Comment> comments = commentPage.getRecords();
        
        // 1. 获取评论者信息
        Set<Long> userIds = comments.stream()
                .map(Comment::getCommenterId)
                .collect(Collectors.toSet());
        Map<Long, User> userMap = new HashMap<>();
        for (Long userId : userIds) {
            Resp<User> userResp = userServiceProxy.getUser(userId);
            if (userResp.getCode() == 200 && userResp.getData() != null) {
                userMap.put(userId, userResp.getData());
            }
        }
        
        // 2. 获取点赞状态
        Map<Long, Boolean> likeStatusMap = new HashMap<>();
        for (Comment comment : comments) {
            Resp<Boolean> isLikedResp = likeServiceProxy.isLiked(comment.getId(), currentUserId, 3);
            likeStatusMap.put(comment.getId(), 
                isLikedResp.getCode() == 200 && Boolean.TRUE.equals(isLikedResp.getData()));
        }
        
        // 3. 转换为DTO
        List<CommentDTO> commentDTOs = comments.stream()
                .map(comment -> {
                    User commenter = userMap.get(comment.getCommenterId());
                    User replyToCommenter = comment.getParentCommentId() != null ? 
                            userMap.get(getParentCommenterIdById(comment.getParentCommentId())) : null;
                    
                    return CommentDTO.builder()
                            .id(comment.getId())
                            .content(comment.getContent())
                            .commenterId(comment.getCommenterId())
                            .commenterName(commenter != null ? commenter.getUsername() : "未知用户")
                            .commenterAvatar(commenter != null ? commenter.getAvatar() : null)
                            .creationTime(comment.getCreationTime())
                            .likeCount(comment.getLikeCount())
                            .replyCount(comment.getReplyCount())
                            .isLiked(likeStatusMap.getOrDefault(comment.getId(), false))
                            .parentCommentId(comment.getParentCommentId())
                            .replyToCommenterId(replyToCommenter != null ? replyToCommenter.getId() : null)
                            .replyToCommenterName(replyToCommenter != null ? replyToCommenter.getUsername() : null)
                            .isPublic(comment.getIsPublic())
                            .reviewStatus(comment.getReviewStatus())
                            .build();
                })
                .collect(Collectors.toList());
        
        // 4. 构建分页结果
        Page<CommentDTO> result = new Page<>(commentPage.getCurrent(), commentPage.getSize(), commentPage.getTotal());
        result.setRecords(commentDTOs);
        
        return Resp.success(result);
    }

    @Override
    public Resp<String> togglePostFavorite(Long postId, Long folderId, String token) {
        log.info("切换帖子收藏状态, postId: {}, folderId: {}", postId, folderId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        if (folderId == null || folderId < 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的收藏夹ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 切换收藏状态
            Resp<Boolean> isFavoritedResp = favoriteServiceProxy.isFavorited(postId, 1, currentUserId);
            if (isFavoritedResp.getCode() != 200) {
                return Resp.error(isFavoritedResp.getCode(), isFavoritedResp.getMsg());
            }
            
            boolean isFavorited = Boolean.TRUE.equals(isFavoritedResp.getData());
            if (isFavorited) {
                // 取消收藏
                Resp<Boolean> cancelResp = favoriteServiceProxy.cancelFavorite(currentUserId, postId);
                if (cancelResp.getCode() != 200) {
                    return Resp.error(cancelResp.getCode(), cancelResp.getMsg());
                }
                return Resp.success("取消收藏成功");
            } else {
                // 添加收藏
                Resp<Boolean> addResp = favoriteServiceProxy.addFavorite(currentUserId, postId, folderId);
                if (addResp.getCode() != 200) {
                    return Resp.error(addResp.getCode(), addResp.getMsg());
                }
                return Resp.success("收藏成功");
            }
        } catch (Exception e) {
            log.error("切换帖子收藏状态失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "操作失败");
        }
    }

    @Override
    public Resp<Report> reportPost(Long postId, Long reportTypeId, Long reportedTypeId, String reason, String token) {
        log.info("举报帖子, postId: {}, reportTypeId: {}, reportedTypeId: {}", postId, reportTypeId, reportedTypeId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        if (reportTypeId == null || reportTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的举报类型ID");
        }
        if (reportedTypeId == null || reportedTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的被举报对象类型ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 检查举报类型是否存在
            Resp<ReportType> reportTypeResp = reportTypeServiceProxy.getReportType(reportTypeId);
            if (reportTypeResp.getCode() != 200 || reportTypeResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报类型不存在");
            }
            
            // 4. 检查被举报对象类型是否存在
            Resp<ReportedType> reportedTypeResp = reportedTypeServiceProxy.getReportedType(reportedTypeId);
            if (reportedTypeResp.getCode() != 200 || reportedTypeResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "被举报对象类型不存在");
            }
            
            // 5. 创建举报
            ReportCreateDTO createDTO = new ReportCreateDTO();
            createDTO.setUserId(currentUserId);
            createDTO.setReportedContentId(postId);
            createDTO.setReportedTypeId(reportedTypeId);
            createDTO.setReportTypeId(reportTypeId);
            createDTO.setReason(reason);
            
            Resp<Report> reportResp = reportServiceProxy.createReport(createDTO, currentUserId);
            if (reportResp.getCode() != 200) {
                return Resp.error(reportResp.getCode(), reportResp.getMsg());
            }
            
            return Resp.success("举报成功", reportResp.getData());
        } catch (Exception e) {
            log.error("举报帖子失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "举报失败");
        }
    }

    @Override
    public Resp<List<ReportType>> getAllReportTypes() {
        log.info("获取所有举报类型");
        try {
            return reportTypeServiceProxy.getAllReportTypes();
        } catch (Exception e) {
            log.error("获取举报类型列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报类型失败");
        }
    }

    @Override
    public Resp<List<ReportedType>> getAllReportedTypes() {
        log.info("获取所有举报对象类型");
        try {
            return reportedTypeServiceProxy.getAllReportedTypes();
        } catch (Exception e) {
            log.error("获取举报对象类型列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报对象类型失败");
        }
    }

    @Override
    public Resp<String> viewPost(Long postId, String token) {
        log.info("浏览帖子, postId: {}", postId);
        
        // 参数校验
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        
        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();
            
            // 2. 检查帖子是否存在
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 3. 增加浏览记录
            Resp<Void> viewResp = postServiceProxy.incrementViewCount(postId, currentUserId);
            if (viewResp.getCode() != 200) {
                return Resp.error(viewResp.getCode(), viewResp.getMsg());
            }
            
            return Resp.success("浏览成功");
        } catch (Exception e) {
            log.error("浏览帖子失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "浏览失败");
        }
    }

    

    
} 