package com.example.ksp.framework.ai;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(description = "AI补全请求参数")
public class CompletionRequestDTO {
    
    @Schema(description = "模型名称")
    private String model;
    
    @Schema(description = "提示文本")
    private String prompt;
    
    @Schema(description = "是否回显提示文本")
    private Boolean echo;
    
    @Schema(description = "频率惩罚参数")
    @JsonProperty("frequency_penalty")
    private Double frequencyPenalty;
    
    @Schema(description = "日志概率")
    private Integer logprobs;
    
    @Schema(description = "最大token数")
    @JsonProperty("max_tokens")
    private Integer maxTokens;
    
    @Schema(description = "存在惩罚参数")
    @JsonProperty("presence_penalty")
    private Double presencePenalty;
    
    @Schema(description = "停止标记")
    private Object stop;
    
    @Schema(description = "是否流式响应")
    private Boolean stream;
    
    @Schema(description = "流式响应选项")
    @JsonProperty("stream_options")
    private Object streamOptions;
    
    @Schema(description = "后缀")
    private String suffix;
    
    @Schema(description = "温度参数")
    private Double temperature;
    
    @Schema(description = "top_p参数")
    @JsonProperty("top_p")
    private Double topP;
} 