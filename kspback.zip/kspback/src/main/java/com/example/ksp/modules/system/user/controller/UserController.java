package com.example.ksp.modules.system.user.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

/**
 * 用户控制器
 * @author loself
 * @date 2024-12-31 13:49
 */
@Tag(name = "系统级用户管理", description = "用户管理相关接口")
@RestController
@RequestMapping("/api/system/user")
@RequiredArgsConstructor
public class UserController {
    
    private final UserService userService;

    @Operation(summary = "根据ID获取用户信息")
    @GetMapping("/{id}")
    public Resp<User> getUserById(
            @Parameter(description = "用户ID") @PathVariable Long id) {
        return Resp.success(userService.getById(id));
    }

    @Operation(summary = "根据手机号获取用户信息")
    @GetMapping("/phone/{phoneNumber}")
    public Resp<User> getUserByPhone(
            @Parameter(description = "手机号") @PathVariable String phoneNumber) {
        return Resp.success(userService.selectUserByPhoneNumber(phoneNumber));
    }

    @Operation(summary = "新增用户")
    @PostMapping
    public Resp<Boolean> save(
            @Parameter(description = "用户信息") @RequestBody User user) {
        return Resp.success(userService.save(user));
    }

    @Operation(summary = "更新用户信息")
    @PutMapping
    public Resp<Boolean> update(
            @Parameter(description = "用户信息") @RequestBody User user) {
        return Resp.success(userService.updateById(user));
    }

    @Operation(summary = "删除用户")
    @DeleteMapping("/{id}")
    public Resp<Boolean> delete(
            @Parameter(description = "用户ID") @PathVariable Long id) {
        return Resp.success(userService.removeById(id));
    }

    @Operation(summary = "用户注册")
    @PostMapping("/register")
    public Resp<User> register(
            @Parameter(description = "注册信息") 
            @RequestBody @Valid RegisterDTO registerDTO) {
        return userService.register(registerDTO);
    }

    @Operation(summary = "用户登录")
    @PostMapping("/login")
    public Resp<User> login(
            @Parameter(description = "登录信息") 
            @RequestBody @Valid LoginDTO loginDTO) {
        return userService.login(loginDTO);
    }

    @Operation(summary = "更新用户登录信息")
    @PutMapping("/login-info")
    public Resp<Boolean> updateUserLoginInfo(@RequestBody User user) {
        return Resp.success(userService.updateUserLoginInfo(user));
    }
}
