package com.example.ksp.modules.system.report.report.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.dto.ReportQueryDTO;
import com.example.ksp.modules.system.report.report.dto.ReportUpdateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;

import java.util.Map;

public interface ReportService extends IService<Report> {
    
    /**
     * 创建举报
     *
     * @param createDTO 举报创建DTO
     * @param userId 用户ID
     * @return 举报信息
     */
    Resp<Report> createReport(ReportCreateDTO createDTO, Long userId);

    /**
     * 更新举报
     *
     * @param updateDTO 举报更新DTO
     * @return 举报信息
     */
    Resp<Report> updateReport(ReportUpdateDTO updateDTO);

    /**
     * 获取举报详情
     *
     * @param reportId 举报ID
     * @return 举报信息
     */
    Resp<Report> getReport(Long reportId);

    /**
     * 分页查询举报列表
     *
     * @param queryDTO 查询条件
     * @return 举报列表
     */
    Resp<Page<Report>> queryReports(ReportQueryDTO queryDTO);

    /**
     * 统计各状态的举报数量
     *
     * @param status 状态
     * @return 数量
     */
    long countByStatus(Integer status);

    /**
     * 统计各举报类型的数量
     *
     * @return 类型-数量映射
     */
    Map<String, Long> countByReportType();

    /**
     * 统计各处理结果的数量
     *
     * @return 结果-数量映射
     */
    Map<String, Long> countByOutcome();

    String getReportedContent(Long contentId, Long reportedTypeId);

    Object deleteReportedContent(Long contentId, Long reportedTypeId);

    /**
     * 删除举报（逻辑删除）
     *
     * @param id 举报ID
     * @return 操作结果
     */
    Resp<Void> deleteReport(Long id);
} 