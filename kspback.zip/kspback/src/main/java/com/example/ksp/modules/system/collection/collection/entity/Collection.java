package com.example.ksp.modules.system.collection.collection.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("collection")
@Schema(description = "合集实体")
public class Collection {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "合集ID")
    private Long id;
    
    @Schema(description = "合集名称")
    private String collectionName;
    
    @Schema(description = "合集描述")
    private String collectionDescription;
    
    @Schema(description = "创建者ID")
    private Long creatorId;
    
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private LocalDateTime creationTime;
    
    @Schema(description = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private LocalDateTime updateTime;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
    
    @Schema(description = "点赞数")
    private Integer likeCount;
    
    @Schema(description = "评论数")
    private Integer commentCount;
    
    @Schema(description = "订阅数")
    private Integer subscribeCount;
    
    @Schema(description = "分享数")
    private Integer shareCount;
    
    @Schema(description = "可见性(0:私密 1:公开)")
    private Integer visibility;
    
    @Schema(description = "审核状态(0:待审核 1:已通过 2:已拒绝)")
    private Integer reviewStatus;
} 