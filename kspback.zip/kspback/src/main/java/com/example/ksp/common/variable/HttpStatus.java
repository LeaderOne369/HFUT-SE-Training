package com.example.ksp.common.variable;

/**
 * HTTP状态码
 * 继承自 hutool 的 HttpStatus，添加中文说明
 * @author loself
 * @date 2024-12-31 15:58
 */
public class HttpStatus extends cn.hutool.http.HttpStatus {
    private final Integer code;
    private final String msg;

    // 1xx Informational
    public static final HttpStatus CONTINUE = new HttpStatus(HTTP_CONTINUE, "继续请求");
    public static final HttpStatus SWITCHING_PROTOCOLS = new HttpStatus(HTTP_SWITCHING_PROTOCOLS, "切换协议");
    public static final HttpStatus PROCESSING = new HttpStatus(HTTP_PROCESSING, "正在处理");
    public static final HttpStatus CHECKPOINT = new HttpStatus(HTTP_CHECKPOINT, "检查点");

    // 2xx Success
    public static final HttpStatus OK = new HttpStatus(HTTP_OK, "请求成功");
    public static final HttpStatus CREATED = new HttpStatus(HTTP_CREATED, "已创建");
    public static final HttpStatus ACCEPTED = new HttpStatus(HTTP_ACCEPTED, "已接受");
    public static final HttpStatus NOT_AUTHORITATIVE = new HttpStatus(HTTP_NOT_AUTHORITATIVE, "非授权信息");
    public static final HttpStatus NO_CONTENT = new HttpStatus(HTTP_NO_CONTENT, "无内容");
    public static final HttpStatus RESET = new HttpStatus(HTTP_RESET, "重置内容");
    public static final HttpStatus PARTIAL = new HttpStatus(HTTP_PARTIAL, "部分内容");
    public static final HttpStatus MULTI_STATUS = new HttpStatus(HTTP_MULTI_STATUS, "多状态");
    public static final HttpStatus ALREADY_REPORTED = new HttpStatus(HTTP_ALREADY_REPORTED, "已经报告");
    public static final HttpStatus IM_USED = new HttpStatus(HTTP_IM_USED, "使用IM");

    // 3xx Redirection
    public static final HttpStatus MULT_CHOICE = new HttpStatus(HTTP_MULT_CHOICE, "多种选择");
    public static final HttpStatus MOVED_PERM = new HttpStatus(HTTP_MOVED_PERM, "永久移动");
    public static final HttpStatus MOVED_TEMP = new HttpStatus(HTTP_MOVED_TEMP, "临时移动");
    public static final HttpStatus SEE_OTHER = new HttpStatus(HTTP_SEE_OTHER, "查看其它");
    public static final HttpStatus NOT_MODIFIED = new HttpStatus(HTTP_NOT_MODIFIED, "未修改");
    public static final HttpStatus USE_PROXY = new HttpStatus(HTTP_USE_PROXY, "使用代理");
    public static final HttpStatus TEMP_REDIRECT = new HttpStatus(HTTP_TEMP_REDIRECT, "临时重定向");
    public static final HttpStatus PERMANENT_REDIRECT = new HttpStatus(HTTP_PERMANENT_REDIRECT, "永久重定向");

    // 4xx Client Error
    public static final HttpStatus BAD_REQUEST = new HttpStatus(HTTP_BAD_REQUEST, "错误请求");
    public static final HttpStatus UNAUTHORIZED = new HttpStatus(HTTP_UNAUTHORIZED, "未授权");
    public static final HttpStatus PAYMENT_REQUIRED = new HttpStatus(HTTP_PAYMENT_REQUIRED, "需要付款");
    public static final HttpStatus FORBIDDEN = new HttpStatus(HTTP_FORBIDDEN, "禁止访问");
    public static final HttpStatus NOT_FOUND = new HttpStatus(HTTP_NOT_FOUND, "未找到");
    public static final HttpStatus BAD_METHOD = new HttpStatus(HTTP_BAD_METHOD, "方法不允许");
    public static final HttpStatus NOT_ACCEPTABLE = new HttpStatus(HTTP_NOT_ACCEPTABLE, "不可接受");
    public static final HttpStatus PROXY_AUTH = new HttpStatus(HTTP_PROXY_AUTH, "需要代理认证");
    public static final HttpStatus CLIENT_TIMEOUT = new HttpStatus(HTTP_CLIENT_TIMEOUT, "客户端超时");
    public static final HttpStatus CONFLICT = new HttpStatus(HTTP_CONFLICT, "冲突");
    public static final HttpStatus GONE = new HttpStatus(HTTP_GONE, "已经不存在");
    public static final HttpStatus LENGTH_REQUIRED = new HttpStatus(HTTP_LENGTH_REQUIRED, "需要内容长度");
    public static final HttpStatus PRECON_FAILED = new HttpStatus(HTTP_PRECON_FAILED, "先决条件失败");
    public static final HttpStatus ENTITY_TOO_LARGE = new HttpStatus(HTTP_ENTITY_TOO_LARGE, "实体过大");
    public static final HttpStatus REQ_TOO_LONG = new HttpStatus(HTTP_REQ_TOO_LONG, "请求URI过长");
    public static final HttpStatus UNSUPPORTED_TYPE = new HttpStatus(HTTP_UNSUPPORTED_TYPE, "不支持的媒体类型");
    public static final HttpStatus REQUESTED_RANGE_NOT_SATISFIABLE = new HttpStatus(HTTP_REQUESTED_RANGE_NOT_SATISFIABLE, "请求范围不满足");
    public static final HttpStatus EXPECTATION_FAILED = new HttpStatus(HTTP_EXPECTATION_FAILED, "预期失败");
    public static final HttpStatus I_AM_A_TEAPOT = new HttpStatus(HTTP_I_AM_A_TEAPOT, "我是一个茶壶");
    public static final HttpStatus UNPROCESSABLE_ENTITY = new HttpStatus(HTTP_UNPROCESSABLE_ENTITY, "无法处理的实体");
    public static final HttpStatus LOCKED = new HttpStatus(HTTP_LOCKED, "已锁定");
    public static final HttpStatus FAILED_DEPENDENCY = new HttpStatus(HTTP_FAILED_DEPENDENCY, "失败的依赖");
    public static final HttpStatus TOO_EARLY = new HttpStatus(HTTP_TOO_EARLY, "太早");
    public static final HttpStatus UPGRADE_REQUIRED = new HttpStatus(HTTP_UPGRADE_REQUIRED, "需要升级");
    public static final HttpStatus PRECONDITION_REQUIRED = new HttpStatus(HTTP_PRECONDITION_REQUIRED, "需要先决条件");
    public static final HttpStatus TOO_MANY_REQUESTS = new HttpStatus(HTTP_TOO_MANY_REQUESTS, "请求过多");
    public static final HttpStatus REQUEST_HEADER_FIELDS_TOO_LARGE = new HttpStatus(HTTP_REQUEST_HEADER_FIELDS_TOO_LARGE, "请求头字段过大");
    public static final HttpStatus UNAVAILABLE_FOR_LEGAL_REASONS = new HttpStatus(HTTP_UNAVAILABLE_FOR_LEGAL_REASONS, "因法律原因不可用");

    // 5xx Server Error
    public static final HttpStatus INTERNAL_ERROR = new HttpStatus(HTTP_INTERNAL_ERROR, "服务器内部错误");
    public static final HttpStatus NOT_IMPLEMENTED = new HttpStatus(HTTP_NOT_IMPLEMENTED, "未实现");
    public static final HttpStatus BAD_GATEWAY = new HttpStatus(HTTP_BAD_GATEWAY, "错误网关");
    public static final HttpStatus UNAVAILABLE = new HttpStatus(HTTP_UNAVAILABLE, "服务不可用");
    public static final HttpStatus GATEWAY_TIMEOUT = new HttpStatus(HTTP_GATEWAY_TIMEOUT, "网关超时");
    public static final HttpStatus VERSION = new HttpStatus(HTTP_VERSION, "HTTP版本不支持");
    public static final HttpStatus VARIANT_ALSO_NEGOTIATES = new HttpStatus(HTTP_VARIANT_ALSO_NEGOTIATES, "变体也可以协商");
    public static final HttpStatus INSUFFICIENT_STORAGE = new HttpStatus(HTTP_INSUFFICIENT_STORAGE, "存储空间不足");
    public static final HttpStatus LOOP_DETECTED = new HttpStatus(HTTP_LOOP_DETECTED, "检测到循环");
    public static final HttpStatus BANDWIDTH_LIMIT_EXCEEDED = new HttpStatus(HTTP_BANDWIDTH_LIMIT_EXCEEDED, "带宽限制超出");
    public static final HttpStatus NOT_EXTENDED = new HttpStatus(HTTP_NOT_EXTENDED, "未扩展");
    public static final HttpStatus NETWORK_AUTHENTICATION_REQUIRED = new HttpStatus(HTTP_NETWORK_AUTHENTICATION_REQUIRED, "需要网络认证");

    HttpStatus(int code, String msg) {
        super();
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
