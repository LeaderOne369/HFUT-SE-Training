package com.example.ksp.common.config;

import io.minio.MinioClient;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.SetBucketPolicyArgs;

@Slf4j
@Data
@Configuration
@ConfigurationProperties(prefix = "minio")
public class MinioConfig {

    /**
     * 服务地址
     */
    private String endpoint;

    /**
     * 访问密钥
     */
    private String accessKey;

    /**
     * 密码
     */
    private String secretKey;

    /**
     * 默认存储桶
     */
    private String defaultBucketName;

    @Bean
    public MinioClient minioClient() {
        MinioClient client = MinioClient.builder()
                .endpoint(endpoint)
                .credentials(accessKey, secretKey)
                .build();
                
        try {
            // 检查默认存储桶是否存在
            boolean bucketExists = client.bucketExists(BucketExistsArgs.builder()
                    .bucket(defaultBucketName)
                    .build());
            
            if (!bucketExists) {
                // 创建存储桶
                client.makeBucket(MakeBucketArgs.builder()
                        .bucket(defaultBucketName)
                        .build());
                
                // 设置存储桶策略为公开读
                String policy = String.format(
                    "{\"Version\":\"2012-10-17\"," +
                    "\"Statement\":[{" +
                    "\"Effect\":\"Allow\"," +
                    "\"Principal\":{\"AWS\":[\"*\"]}," +
                    "\"Action\":[\"s3:GetObject\"]," +
                    "\"Resource\":[\"arn:aws:s3:::%s/*\"]" +
                    "}]}", defaultBucketName);
                
                client.setBucketPolicy(SetBucketPolicyArgs.builder()
                        .bucket(defaultBucketName)
                        .config(policy)
                        .build());
                
                log.info("已创建默认存储桶: {}", defaultBucketName);
            }
        } catch (Exception e) {
            log.error("初始化MinIO存储桶失败", e);
            throw new RuntimeException("初始化MinIO存储桶失败", e);
        }
        
        return client;
    }
} 