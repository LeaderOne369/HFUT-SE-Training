package com.example.ksp.modules.client.ai.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.ai.ChatResponseDTO;
import com.example.ksp.framework.ai.CompletionResponseDTO;
import com.example.ksp.modules.client.ai.dto.AiWritingRequest;

import java.util.List;

public interface AiWriteService {
    
    /**
     * 生成用户活动总结
     * @param token 用户token
     * @return 活动总结内容
     */
    Resp<String> generateUserActivitySummary(String token);
    
    /**
     * 生成文章内容
     * @param request AI写作请求参数
     * @return 生成的文章内容
     */
    Resp<String> generateArticleContent(AiWritingRequest request);
    
    /**
     * 获取可用的AI模型列表
     */
    Resp<List<String>> getAvailableModels();
    
    /**
     * 使用AI补全文本
     */
    Resp<CompletionResponseDTO> completeText(String prompt);
    
    /**
     * 使用AI对话生成内容
     */
    Resp<ChatResponseDTO> generateWithChat(String prompt);
} 