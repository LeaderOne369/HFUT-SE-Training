package com.example.ksp.modules.system.post.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.post.entity.Post;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.UpdateProvider;

import java.util.List;
import java.util.Map;

@Mapper
public interface PostMapper extends BaseMapper<Post> {
    /**
     * 按照分区ID和关键字搜索帖子，支持排序
     */
    @Select("<script>" +
            "SELECT * FROM post p " +
            "LEFT JOIN section s ON p.section_id = s.id " +
            "WHERE p.section_id = #{sectionId} " +
            "AND p.is_deleted = 0 " +
            "<if test='keyword != null and keyword != \"\"'> " +
            "AND ( " +
            "s.section_name LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.tags LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.summary LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.title LIKE CONCAT('%', #{keyword}, '%') " +
            ") " +
            "</if>" +
            "ORDER BY " +
            "<choose>" +
            "<when test='sortBy != null and sortBy != \"\"'> ${sortBy} DESC </when>" +
            "<otherwise> publish_time DESC </otherwise>" +
            "</choose>" +
            "</script>")
    Page<Post> searchPostsBySection(Page<Post> page,
                                    @Param("sectionId") Long sectionId,
                                    @Param("keyword") String keyword,
                                    @Param("sortBy") String sortBy);



    /**
     * 根据标签ID获取包含该标签的帖子列表，并支持分页
     *
     * @param page 分页对象
     * @param tagId 标签ID
     * @return 帖子分页结果
     */
    @Select("SELECT p.* FROM post p " +
            "INNER JOIN tag t ON FIND_IN_SET(t.tag_name, p.tags) > 0 " +
            "WHERE t.id = #{tagId} AND p.is_deleted = 0 " +
            "ORDER BY p.publish_time DESC")
    Page<Post> selectPostsByTag(Page<Post> page, @Param("tagId") Long tagId);

    @Select("SELECT p.* FROM post p " +
            "INNER JOIN tag t ON FIND_IN_SET(t.tag_name, p.tags) > 0 " +
            "LEFT JOIN section s ON p.section_id = s.id " +
            "WHERE t.id = #{tagId} " +
            "AND p.is_deleted = 0 " +
            "AND (#{keyword} IS NULL OR " +
            "s.section_name LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.tags LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.summary LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.title LIKE CONCAT('%', #{keyword}, '%')) " +
            "ORDER BY p.publish_time DESC")
    Page<Post> selectPostsByTagAndKey(Page<Post> page, @Param("tagId") Long tagId, @Param("keyword") String keyword);


    @Select("SELECT p.* FROM post p " +
            "LEFT JOIN section s ON p.section_id = s.id " +
            "WHERE p.is_deleted = 0 " +
            "AND (#{keyword} IS NULL OR " +
            "s.section_name LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.tags LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.summary LIKE CONCAT('%', #{keyword}, '%') OR " +
            "p.title LIKE CONCAT('%', #{keyword}, '%')) " +
            "ORDER BY p.publish_time DESC")
    Page<Post> selectPostsByKeyword(Page<Post> page, @Param("keyword") String keyword);


    // 获取日榜（按点赞数排序，限额）
    @Select("SELECT * FROM post WHERE publish_time >= CURDATE() ORDER BY like_count DESC ")
    List<Post> getDailyRank();

    // 获取周榜（按点赞数排序，限额）
    @Select("SELECT * FROM post WHERE publish_time >= CURDATE() - INTERVAL 1 WEEK ORDER BY like_count DESC ")
    List<Post> getWeeklyRank();

    // 获取月榜（按点赞数排序，限额）
    @Select("SELECT * FROM post WHERE publish_time >= CURDATE() - INTERVAL 1 MONTH ORDER BY like_count DESC ")
    List<Post> getMonthlyRank();

    // 动态更新 post 表中的字段
    @UpdateProvider(type = PostSqlProvider.class, method = "updatePost")
    int updatePost(@Param("postId") Long postId, @Param("updates") Map<String, Object> updates);
}
