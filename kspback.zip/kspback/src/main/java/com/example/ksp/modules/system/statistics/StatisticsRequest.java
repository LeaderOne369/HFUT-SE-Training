package com.example.ksp.modules.system.statistics;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class StatisticsRequest {

    /**
     * 字段名称，例如：user, view, comment 等
     */
    @NotBlank(message = "field不能为空")
    private String field;

    /**
     * 时间尺度，例如：WEEK, MONTH, YEAR 等
     */
    @NotBlank(message = "timeScale不能为空")
    private String timeScale;
}
