package com.example.ksp.modules.system.comment.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("comment")
@Schema(description = "评论实体")
public class Comment {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "评论ID")
    private Long id;
    
    @Schema(description = "评论者ID")
    private Long commenterId;
    
    @Schema(description = "被评论对象ID")
    private Long commentableId;
    
    @Schema(description = "被评论对象类型(1:帖子 2:合集 3:评论)")
    private Integer commentableType;
    
    @Schema(description = "评论内容")
    private String content;
    
    @Schema(description = "创建时间")
    private LocalDateTime creationTime;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
    
    @Schema(description = "父评论ID")
    private Long parentCommentId;
    
    @Schema(description = "点赞数")
    private Integer likeCount;
    
    @Schema(description = "回复数")
    private Integer replyCount;
    
    @Schema(description = "是否公开(0:私密 1:公开)")
    private Integer isPublic;
    
    @Schema(description = "审核状态(0:待审核 1:已通过 2:已拒绝)")
    private Integer reviewStatus;
} 