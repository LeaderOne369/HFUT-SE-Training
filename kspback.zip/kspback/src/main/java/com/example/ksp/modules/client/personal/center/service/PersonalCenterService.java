package com.example.ksp.modules.client.personal.center.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.UpdateUserInfoDTO;
import com.example.ksp.modules.client.personal.center.vo.UserInfoVO;
import com.example.ksp.modules.system.user.entity.User;
import org.springframework.web.multipart.MultipartFile;

public interface PersonalCenterService {
    
    /**
     * 获取用户信息
     */
    Resp<UserInfoVO> getUserInfo(Long userId);
    
    /**
     * 上传用户头像
     */
    Resp<String> uploadAvatar(Long userId, MultipartFile file);
    
    /**
     * 更新用户信息
     */
    Resp<UserInfoVO> updateUserInfo(Long userId, UpdateUserInfoDTO updateUserInfoDTO);
    
    /**
     * 注销账号
     */
    Resp<String> deactivateAccount(Long userId, String password);
} 