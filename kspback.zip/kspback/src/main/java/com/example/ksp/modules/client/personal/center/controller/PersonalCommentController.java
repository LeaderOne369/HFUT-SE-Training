package com.example.ksp.modules.client.personal.center.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.personal.center.service.PersonalCommentService;
import com.example.ksp.modules.system.comment.entity.Comment;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端个人中心个人评论管理")
@RestController
@RequestMapping("/api/client/personal/comment")
@RequiredArgsConstructor
public class PersonalCommentController {

    private final PersonalCommentService personalCommentService;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }


    @Operation(summary = "获取我发布的评论列表")
    @GetMapping("/published")
    public Resp<Page<Comment>> getMyComments(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalCommentService.getUserComments(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取我收到的评论列表")
    @GetMapping("/received")
    public Resp<Page<Comment>> getReceivedComments(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalCommentService.getReceivedComments(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取评论详情")
    @GetMapping("/{commentId}")
    public Resp<Comment> getCommentDetail(@PathVariable Long commentId) {
        return personalCommentService.getCommentDetail(getCurrentUserId(), commentId);
    }

    @Operation(summary = "删除评论")
    @DeleteMapping("/{commentId}")
    public Resp<Boolean> deleteComment(@PathVariable Long commentId) {
        return personalCommentService.deleteComment(getCurrentUserId(), commentId);
    }
} 