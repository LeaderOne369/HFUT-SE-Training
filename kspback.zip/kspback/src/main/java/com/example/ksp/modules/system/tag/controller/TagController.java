package com.example.ksp.modules.system.tag.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.tag.dto.TagCreateDTO;
import com.example.ksp.modules.system.tag.dto.TagQueryDTO;
import com.example.ksp.modules.system.tag.dto.TagUpdateDTO;
import com.example.ksp.modules.system.tag.entity.Tag;
import com.example.ksp.modules.system.tag.service.TagService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@io.swagger.v3.oas.annotations.tags.Tag(name = "系统级标签管理")
@RestController
@RequestMapping("/api/system/tag")
@RequiredArgsConstructor
public class TagController {

    private final TagService tagService;

    @Operation(summary = "创建标签")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Tag> createTag(
            @Parameter(description = "创建标签信息") 
            @RequestBody @Valid TagCreateDTO createDTO) {
        return tagService.createTag(createDTO);
    }

    @Operation(summary = "更新标签")
    @PutMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Tag> updateTag(
            @Parameter(description = "更新标签信息") 
            @RequestBody @Valid TagUpdateDTO updateDTO) {
        return tagService.updateTag(updateDTO);
    }

    @Operation(summary = "删除标签")
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> deleteTag(
            @Parameter(description = "标签ID") 
            @PathVariable Long id) {
        return tagService.deleteTag(id);
    }

    @Operation(summary = "获取标签详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<Tag> getTag(
            @Parameter(description = "标签ID") 
            @PathVariable Long id) {
        return tagService.getTag(id);
    }

    @Operation(summary = "分页查询标签")
    @GetMapping("/list")
    @PreAuthorize("isAuthenticated()")
    public Resp<Page<Tag>> queryTags(@Valid TagQueryDTO queryDTO) {
        return tagService.queryTags(queryDTO);
    }

    @Operation(summary = "获取分区下的所有标签")
    @GetMapping("/section/{sectionId}")
    @PreAuthorize("isAuthenticated()")
    public Resp<List<Tag>> getTagsBySection(
            @Parameter(description = "分区ID") 
            @PathVariable Long sectionId) {
        return tagService.getTagsBySection(sectionId);
    }

} 