package com.example.ksp.modules.client.ai.service;

import com.example.ksp.common.variable.Resp;

import java.util.concurrent.ConcurrentHashMap;

public interface AiChatService {
    
    ConcurrentHashMap<Object, Object> createChatConnection();
    
    Resp<Void> chat(String clientId, String question);
    
    void closeChatConnection(String clientId);
    
    Resp<String> chatSync(String clientId, String question);
} 