package com.example.ksp.modules.system.report.report.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "更新举报请求参数")
public class ReportUpdateDTO {
    
    @NotNull(message = "举报ID不能为空")
    @Schema(description = "举报ID")
    private Long id;
    
    @Schema(description = "处理状态(0:待处理 1:正在处理 2:已处理 3:无需处理)")
    private Integer status;
    
    @Schema(description = "处理结果(0:无行动 1:内容已删除 2:警告用户 3:用户禁言 4:用户封禁)")
    private Integer outcome;
} 