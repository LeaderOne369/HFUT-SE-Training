package com.example.ksp.modules.client.personal.center.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * @author loself
 * @date 2025-01-08 16:50
 */

@Data
@Schema(description = "收藏夹创建")
public class FavoriteFolderCreateDTO {

    @Schema(description = "收藏夹名称")
    @NotBlank(message = "收藏夹名称不能为空")
    @Size(max = 50, message = "收藏夹名称不能超过50个字符")
    private String folderName;


    @Schema(description = "可见性(0:自己可见 1:公开可见)")
    private Integer visibility;

}
