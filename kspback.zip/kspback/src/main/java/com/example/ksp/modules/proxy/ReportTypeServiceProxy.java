package com.example.ksp.modules.proxy;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import com.example.ksp.modules.system.report.reporttype.service.ReportTypeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class ReportTypeServiceProxy {

    private final ReportTypeService reportTypeService;

    /**
     * 获取所有举报类型
     *
     * @return 举报类型列表
     */
    public Resp<List<ReportType>> getAllReportTypes() {
        log.info("代理层：获取所有举报类型");
        try {
            List<ReportType> types = reportTypeService.list();
            return Resp.success(types);
        } catch (Exception e) {
            log.error("获取举报类型列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报类型失败");
        }
    }

    /**
     * 获取举报类型详情
     *
     * @param reportTypeId 举报类型ID
     * @return 举报类型信息
     */
    public Resp<ReportType> getReportType(Long reportTypeId) {
        log.info("代理层：获取举报类型详情，ID：{}", reportTypeId);
        if (reportTypeId == null || reportTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的举报类型ID");
        }
        
        try {
            return reportTypeService.getReportType(reportTypeId);
        } catch (Exception e) {
            log.error("获取举报类型详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报类型失败");
        }
    }

    /**
     * 获取举报类型名称
     */
    public String getTypeName(Long typeId) {
        try {
            ReportType type = reportTypeService.getById(typeId);
            return type != null ? type.getTypeName() : null;
        } catch (Exception e) {
            log.error("获取举报类型名称失败, typeId: {}", typeId, e);
            throw new RuntimeException("获取举报类型名称失败");
        }
    }
} 