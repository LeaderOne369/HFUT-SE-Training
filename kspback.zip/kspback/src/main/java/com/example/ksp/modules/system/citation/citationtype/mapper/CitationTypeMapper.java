package com.example.ksp.modules.system.citation.citationtype.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CitationTypeMapper extends BaseMapper<CitationType> {
} 