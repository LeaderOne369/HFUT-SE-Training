package com.example.ksp.modules.client.ai.service.impl;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.ai.ChatResponseDTO;
import com.example.ksp.framework.ai.CompletionResponseDTO;
import com.example.ksp.framework.ai.DSAiClient;
import com.example.ksp.modules.client.ai.dto.AiWritingRequest;
import com.example.ksp.modules.client.ai.service.AiWriteService;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.post.entity.Post;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class AiWriteServiceImpl implements AiWriteService {

    private final UserServiceProxy userServiceProxy;
    private final PostServiceProxy postServiceProxy;
    private final DSAiClient dsAiClient;



    @Override
    public Resp<String> generateUserActivitySummary(String token) {
        try {
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (!Objects.equals(userIdResp.getCode(), HttpStatus.OK.getCode())) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户不存在");
            }
            Long userId = userIdResp.getData();

            // 获取用户最近的帖子
            List<Post> recentPosts = postServiceProxy.getUserRecentPosts(userId, 10);

            // 获取用户浏览历史
            List<Post> viewHistory = postServiceProxy.getUserViewHistory(userId, 10);

            // 构建提示信息
            String prompt = buildActivitySummaryPrompt(recentPosts, viewHistory);

            // 调用AI服务生成总结
            Resp<ChatResponseDTO> response = dsAiClient.chat(prompt);
            if (!(Objects.equals(response.getCode(), HttpStatus.OK.getCode()))) {
                return Resp.error(response.getCode(), String.valueOf(response.getData()));
            }

            String summary = response.getData().getChoices().get(0).getMessage().getContent();
            return Resp.success(summary);
        } catch (Exception e) {
            log.error("生成用户活动总结失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "生成总结失败：" + e.getMessage());
        }
    }

    @Override
    public Resp<String> generateArticleContent(AiWritingRequest request) {
        try {
            // 验证请求参数
            if (!isValidOutputFormat(request.getOutputFormat())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "不支持的输出格式");
            }

            // 构建AI提示信息
            String prompt = buildArticlePrompt(request);

            // 根据是否有现有内容选择补全或对话模式
            Resp<?> response = dsAiClient.chat(prompt);

            if (!(Objects.equals(response.getCode(), HttpStatus.OK.getCode()))) {
                return Resp.error(response.getCode(), String.valueOf(response.getData()));
            }

            // 提取生成的内容
            String content;
            if (response.getData() instanceof CompletionResponseDTO completionResponse) {
                content = completionResponse.getChoices().get(0).getText();
            } else if (response.getData() instanceof ChatResponseDTO chatResponse) {
                content = chatResponse.getChoices().get(0).getMessage().getContent();
            } else {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "未知的响应类型");
            }

            // 根据指定格式处理输出
            String formattedContent = formatContent(content, request.getOutputFormat());
            return Resp.success(formattedContent);
        } catch (Exception e) {
            log.error("生成文章内容失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "生成内容失败：" + e.getMessage());
        }
    }

    @Override
    public Resp<List<String>> getAvailableModels() {
        return dsAiClient.listModels();
    }

    @Override
    public Resp<CompletionResponseDTO> completeText(String prompt ) {
        return dsAiClient.complete(prompt);
    }

    @Override
    public Resp<ChatResponseDTO> generateWithChat(String prompt) {
        return dsAiClient.chat(prompt);
    }

    /**
     * 构建活动总结的提示信息
     */
    private String buildActivitySummaryPrompt(List<Post> recentPosts, List<Post> viewHistory) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("请根据以下用户活动信息生成一份简洁的总结：\n\n");
        
        prompt.append("最近发布的帖子：\n");
        recentPosts.forEach(post -> 
            prompt.append("- ").append(post.getTitle()).append("\n")
        );
        
        prompt.append("\n浏览历史：\n");
        viewHistory.forEach(post -> 
            prompt.append("- ").append(post.getTitle()).append("\n")
        );
        
        return prompt.toString();
    }

    /**
     * 构建文章生成的提示信息
     */
    private String buildArticlePrompt(AiWritingRequest request) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("请根据以下要求生成文章内容：\n\n");
        
        prompt.append("标题：").append(request.getTitle()).append("\n");
        if (request.getDescription() != null) {
            prompt.append("简述：").append(request.getDescription()).append("\n");
        }
        if (request.getExistingContent() != null) {
            prompt.append("已有内容：\n").append(request.getExistingContent()).append("\n");
        }
        if (request.getWritingStyle() != null) {
            prompt.append("写作风格：").append(request.getWritingStyle()).append("\n");
        }
        if (request.getTargetWordCount() != null) {
            prompt.append("目标字数：").append(request.getTargetWordCount()).append("\n");
        }
        
        return prompt.toString();
    }

    /**
     * 验证输出格式是否支持
     */
    private boolean isValidOutputFormat(String format) {
        return "md".equalsIgnoreCase(format) || "txt".equalsIgnoreCase(format);
    }

    /**
     * 格式化输出内容
     */
    private String formatContent(String content, String format) {
        if ("md".equalsIgnoreCase(format)) {
            return formatAsMarkdown(content);
        }
        return content;
    }

    /**
     * 将内容格式化为Markdown
     */
    private String formatAsMarkdown(String content) {
        // 这里可以添加Markdown格式化逻辑
        return content;
    }
} 