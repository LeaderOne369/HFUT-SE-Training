package com.example.ksp.modules.system.report.report.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.dto.ReportQueryDTO;
import com.example.ksp.modules.system.report.report.dto.ReportUpdateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.report.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级举报管理")
@RestController
@RequestMapping("/api/system/report")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @Operation(summary = "创建举报")
    @PostMapping
    public Resp<Report> createReport(
            @RequestHeader("token") String token,
            @RequestBody @Valid ReportCreateDTO createDTO) {
        return reportService.createReport(createDTO, createDTO.getUserId());
    }

    @Operation(summary = "更新举报")
    @PutMapping
    public Resp<Report> updateReport(
            @RequestHeader("token") String token,
            @RequestBody @Valid ReportUpdateDTO updateDTO) {
        return reportService.updateReport(updateDTO);
    }

    @Operation(summary = "删除举报")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteReport(
            @RequestHeader("token") String token,
            @Parameter(description = "举报ID") 
            @PathVariable Long id) {
        return reportService.deleteReport(id);
    }

    @Operation(summary = "获取举报详情")
    @GetMapping("/{id}")
    public Resp<Report> getReport(
            @RequestHeader("token") String token,
            @Parameter(description = "举报ID") 
            @PathVariable Long id) {
        return reportService.getReport(id);
    }

    @Operation(summary = "查询举报列表")
    @PostMapping("/list")
    public Resp<Page<Report>> queryReports(
            @RequestHeader("token") String token,
            @RequestBody ReportQueryDTO queryDTO) {
        return reportService.queryReports(queryDTO);
    }
} 