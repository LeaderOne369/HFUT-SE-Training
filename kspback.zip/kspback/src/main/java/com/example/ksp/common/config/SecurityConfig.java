package com.example.ksp.common.config;

import com.example.ksp.common.utils.ServletUtil;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.filter.JwtAuthenticationTokenFilter;
import com.example.ksp.framework.security.provider.CaptchaAuthenticationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.ksp.common.variable.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.security.authentication.BadCredentialsException;
import java.security.InvalidParameterException;


import java.util.Arrays;

/**
 * @author loself
 * @date 2024-12-31 15:56
 */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter;

    @Autowired
    private CaptchaAuthenticationProvider captchaAuthenticationProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // CsrfFilter 禁用CSRF
        http.csrf(AbstractHttpConfigurer::disable);

        // 异常处理
        http.exceptionHandling(config -> config
                // 未登录或token过期
                .authenticationEntryPoint((request, response, exception) -> {
                    String message = "未登录或登录已过期";
                    if (exception instanceof BadCredentialsException) {
                        message = "用户名或密码错误";
                    }
                    ServletUtil.print(response, Resp.error(HttpStatus.UNAUTHORIZED.getCode(), message));
                })
                // 权限不足
                .accessDeniedHandler((request, response, exception) -> {
                    String message = "权限不足";
                    if (exception != null) {
                        message = "请求方式不允许";
                    } else if (null instanceof MissingServletRequestParameterException) {
                        message = "缺少必要的请求参数";
                    } else if (null instanceof InvalidParameterException) {
                        message = "请求参数格式错误";
                    }
                    ServletUtil.print(response, Resp.error(HttpStatus.FORBIDDEN.getCode(), message));
                })
        );

        // AuthorizationFilter 授权，除匿名接口外都需要认证
        http.authorizeHttpRequests(authorize -> authorize
                // Swagger UI v3 (OpenAPI)
                .requestMatchers("/v3/api-docs/**").permitAll()
                .requestMatchers("/swagger-ui/**").permitAll()
                .requestMatchers("/swagger-ui.html").permitAll()
                .requestMatchers("/swagger-resources/**").permitAll()
                .requestMatchers("/webjars/**").permitAll()
                // 开放的接口
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/system/user/register").permitAll()
                .requestMatchers("/sendcaptcha").permitAll()
                .requestMatchers("/avatars/**").permitAll()
                .requestMatchers("/api/client/**").permitAll()
                .requestMatchers("api/client/ai/chat/**").permitAll()
                .requestMatchers("/api/client/login/**").permitAll()
                .requestMatchers("/test/**").permitAll()
                .requestMatchers("/api/admin/login/**").permitAll()
                // 其他所有请求需要认证
                .anyRequest().authenticated()
        );



        // headers 处理
        http.headers(header -> {
            header.cacheControl(HeadersConfigurer.CacheControlConfig::disable);
            header.frameOptions(HeadersConfigurer.FrameOptionsConfig::disable);
        });

        // TokenFilter 通过 Token 实现认证
        http.addFilterBefore(jwtAuthenticationTokenFilter, UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }

    /**
     * 配置认证管理器
     *
     * @return 认证管理器
     */
    @Bean
    public AuthenticationManager authenticationManager(UserDetailsService userDetailsService) {
        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService);
        authenticationProvider.setPasswordEncoder(passwordEncoder);
        return new ProviderManager(Arrays.asList(authenticationProvider, captchaAuthenticationProvider));
    }
}
