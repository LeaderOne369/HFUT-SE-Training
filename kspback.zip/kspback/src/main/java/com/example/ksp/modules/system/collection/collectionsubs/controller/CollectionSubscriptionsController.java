package com.example.ksp.modules.system.collection.collectionsubs.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsCreateDTO;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsQueryDTO;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;
import com.example.ksp.modules.system.collection.collectionsubs.service.CollectionSubscriptionsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级合集订阅管理")
@RestController
@RequestMapping("/api/system/collection-subscriptions")
@RequiredArgsConstructor
public class CollectionSubscriptionsController {

    private final CollectionSubscriptionsService subscriptionsService;

    @Operation(summary = "创建订阅")
    @PostMapping
    public Resp<CollectionSubscriptions> createSubscription(
            @RequestHeader("token") String token,
            @RequestBody @Valid CollectionSubscriptionsCreateDTO createDTO) {
        return subscriptionsService.createSubscription(createDTO);
    }

    @Operation(summary = "取消订阅")
    @DeleteMapping("/{id}")
    public Resp<Void> cancelSubscription(
            @RequestHeader("token") String token,
            @Parameter(description = "订阅ID") 
            @PathVariable Long id) {
        return subscriptionsService.cancelSubscription(id);
    }

    @Operation(summary = "获取订阅详情")
    @GetMapping("/{id}")
    public Resp<CollectionSubscriptions> getSubscription(
            @RequestHeader("token") String token,
            @Parameter(description = "订阅ID") 
            @PathVariable Long id) {
        return subscriptionsService.getSubscription(id);
    }

    @Operation(summary = "查询订阅列表")
    @PostMapping("/list")
    public Resp<Page<CollectionSubscriptions>> querySubscriptions(
            @RequestHeader("token") String token,
            @RequestBody CollectionSubscriptionsQueryDTO queryDTO) {
        return subscriptionsService.querySubscriptions(queryDTO);
    }
} 