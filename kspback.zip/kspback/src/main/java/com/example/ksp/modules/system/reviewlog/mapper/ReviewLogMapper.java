package com.example.ksp.modules.system.reviewlog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReviewLogMapper extends BaseMapper<ReviewLog> {
}