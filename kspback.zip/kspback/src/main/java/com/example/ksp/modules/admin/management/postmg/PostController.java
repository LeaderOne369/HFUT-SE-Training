package com.example.ksp.modules.admin.management.postmg;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.CollectionServiceProxy;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.proxy.SectionServiceProxy;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.tag.entity.Tag;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@io.swagger.v3.oas.annotations.tags.Tag(name = "管理端帖子管理接口")
@RestController("adminPostController")
@RequestMapping("/api/admin/management/post")
public class PostController {


    @Autowired
    private SectionServiceProxy sectionServiceProxy;
    @Autowired
    private PostServiceProxy postServiceProxy;
    @Autowired
    private CollectionServiceProxy collectionServiceProxy;


    /**
     * 获取所有分区
     */
    @Operation(summary = "获取所有分区")
    @GetMapping("/all")
    public Resp<List<Section>> getAllSections() {
        return sectionServiceProxy.getAllSections();
    }

    /**
     * 获取分区下的所有标签
     */
    @Operation(summary = "获取分区下的所有标签")
    @GetMapping("/{sectionId}/tags")
    public Resp<List<Tag>> getTagsBySectionId(@PathVariable Long sectionId) {
        return sectionServiceProxy.getTagsBySection(sectionId);
    }

    /**
     * 获取分区或标签下的所有帖子
     */
    @Operation(summary = "获取分区或标签下的所有帖子")
    @GetMapping("/{sectionId}/posts")
    public Resp<Page<Post>> getPostsBySectionOrTag(
            @PathVariable Long sectionId,
            @RequestParam(required = false) Long tagId,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {
        if(tagId != null) {
            return Resp.success(sectionServiceProxy.getPostsBySectionOrTag(sectionId, tagId, current, size).getData());
        }
        Page<Post> posts = postServiceProxy.getPostsBySection(sectionId, current, size);
        return Resp.success(posts);
    }


//    /**
//     * 获取指定分区下的所有帖子
//     *
//     * @param sectionId 分区ID
//     * @param current 当前页
//     * @param size 每页显示的帖子数量
//     * @return 分区下的帖子列表
//     */
//    @GetMapping("/{sectionId}/posts")
//    public Resp<Page<Post>> getPostsBySection(@PathVariable("sectionId") Long sectionId,
//                                              @RequestParam("current") long current,
//                                              @RequestParam("size") long size) {
//        return postService.getPostsBySection(sectionId, current, size);
//    }

    /**
     * 按分区和关键字搜索帖子，支持分页和排序
     */
    @Operation(summary = "按分区和关键字搜索帖子")
    @GetMapping("/{sectionId}/posts/search")
    public Resp<Page<Post>> searchPostsBySection(
            @PathVariable Long sectionId,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size,
            @RequestParam(defaultValue = "creation_time") String sortBy) {
        Page<Post> posts = sectionServiceProxy.searchPostsBySection(sectionId, keyword, current, size, sortBy).getData();
        return Resp.success(posts);
    }


    //根据postService.getById(postId)写接口
    @Operation(summary = "根据ID获取帖子")
    @GetMapping("/{postId}")
    public Resp<Post> getPostById(@PathVariable Long postId) {
        return Resp.success(postServiceProxy.getPostById(postId));
    }

    ////根据Collection getById(Long id)写接口
    @Operation(summary = "根据ID获取收藏夹")
    @GetMapping("/collection/{id}")
    public Resp<Collection> getCollectionById(@PathVariable Long id) {

        return collectionServiceProxy.getCollectionById(id);
    }

    //updatePost@Override
    //    public int updatePost(Long posId, Map<String, Object> updates) {
    //        return postMapper.updatePost(posId, updates);  // 调用 Mapper 的动态更新方法
    //    }
    //模仿public Resp<String> updateUser(@RequestBody long userId, @RequestParam Map<String, Object> updates)
    @Operation(summary = "更新帖子")
    @PutMapping("/update/{postId}")
    public Resp<String> updatePost(@PathVariable Long postId,  @RequestParam Map<String, Object> updates) {
        if (updates.isEmpty()) {
            return Resp.error(400, "没有提供需要更新的字段");
        }
        if (postServiceProxy.updatePost(postId, updates) == 0) {
            return Resp.error(500, "帖子更新失败");
        }
        return Resp.success("帖子更新成功");
    }

    ///**
    //     * 删除帖子
    //     */
    //    public Resp<String> deletePost(Long id) {
    //        log.info("代理层：删除帖子，ID：{}", id);
    //        return postService.deletePost(id);
    //    }
    //模仿public Resp<String> deleteUser(@PathVariable Long id)
    @Operation(summary = "删除帖子")
    @DeleteMapping("/{postId}")
    public Resp<String> deletePost(@PathVariable Long postId) {
        if (postServiceProxy.deletePost(postId).getCode() == 0) {
            return Resp.error(500, "帖子删除失败");
        }
        return Resp.success("帖子删除成功");
    }
}
