package com.example.ksp.common.filter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

public class PublicIpRequestWrapper extends HttpServletRequestWrapper {
    
    private final String publicIp;
    
    public PublicIpRequestWrapper(HttpServletRequest request, String publicIp) {
        super(request);
        this.publicIp = publicIp;
    }
    
    @Override
    public String getRemoteAddr() {
        return publicIp != null ? publicIp : super.getRemoteAddr();
    }
} 