package com.example.ksp.modules.client.ai.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "AI写作辅助请求参数")
public class AiWritingRequest {
    
    @Schema(description = "文章标题")
    @NotBlank(message = "标题不能为空")
    private String title;
    
    @Schema(description = "文章简述")
    private String description;
    
    @Schema(description = "已有的部分内容")
    private String existingContent;
    
    @Schema(description = "期望输出格式(md/txt)")
    @NotNull(message = "输出格式不能为空")
    private String outputFormat;
    
    @Schema(description = "写作风格(正式/轻松/专业等)")
    private String writingStyle;
    
    @Schema(description = "期望字数")
    private Integer targetWordCount;
} 