package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.usermg.UserCreateDTO;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.entity.UserFollowDetailVO;
import com.example.ksp.modules.system.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class UserServiceProxy {

    private static final Logger log = LoggerFactory.getLogger(UserServiceProxy.class);

    private final UserService userService;

    /**
     * 用户登录
     */
    public Resp<User> login(LoginDTO loginDTO) {
        return userService.login(loginDTO);
    }

    /**
     * 更新用户登录信息
     */
    public boolean updateUserLoginInfo(User user) {
        return userService.updateUserLoginInfo(user);
    }

    /**
     * 注册用户
     */
    public Resp<User> register(RegisterDTO registerDTO) {
        return userService.register(registerDTO);
    }

    /**
     * 检查用户名是否存在
     */
    public boolean checkUsernameExists(String username) {
        return userService.selectUserByUsername(username) != null;
    }

    /**
     * 检查手机号是否存在
     */
    public boolean checkPhoneExists(String phoneNumber) {
        return userService.selectUserByPhoneNumber(phoneNumber) != null;
    }

    /**
     * 重置密码
     */
    public Resp<String> resetPassword(String phoneNumber, String newPassword) {
        return userService.resetPassword(phoneNumber, newPassword);
    }

    /**
     * 验证密码
     */
    public boolean verifyPassword(Long userId, String password) {
        return userService.verifyPassword(userId, password);
    }

    /**
     * 更新密码
     */
    public Resp<String> updatePassword(Long userId, String newPassword) {
        return userService.updatePassword(userId, newPassword);
    }

    /**
     * 注销账号
     */
    public Resp<String> deactivateAccount(Long userId) {
        return userService.deactivateAccount(userId);
    }

    public List<UserFollowDetailVO> getFollowers(Long userId) {
        return userService.getFollowers(userId);
    }

    public List<UserFollowDetailVO> getFollowing(Long userId) {
        return userService.getFollowing(userId);
    }

    public Map<String, Integer> getFollowStats(Long userId) {
        return userService.getFollowStats(userId);
    }

    public List<Map<String, Object>> getAllFollowDetails(Long userId) {
        return userService.getAllFollowDetails(userId);
    }

    /**
     * 根据用户名获取用户ID
     */
    public Resp<Long> getUserIdByUsername(String username) {
        log.info("代理层：根据用户名获取用户ID，username: {}", username);
        if (username == null || username.trim().isEmpty()) {
            return Resp.error(400, "用户名不能为空");
        }
        try {
            Long userId = userService.getUserIdByUsername(username);
            return userId != null ? Resp.success(userId) : Resp.error(404, "用户不存在");
        } catch (Exception e) {
            log.error("获取用户ID失败", e);
            return Resp.error(500, "获取用户ID失败");
        }
    }

    /**
     * 获取用户信息
     *
     * @param userId 用户ID
     * @return 用户信息
     */
    public Resp<User> getUser(Long userId) {
        log.info("代理层：获取用户信息，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的用户ID");
        }

        try {
            User user = userService.getById(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }

            // 清除敏感信息
            user.setPassword(null);
            user.setSalt(null);

            return Resp.success(user);
        } catch (Exception e) {
            log.error("获取用户信息失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取用户信息失败");
        }
    }


    /**
     * 创建新用户
     *
     * @param user 用户对象，包含用户信息
     * @return 影响的行数，通常为1表示成功
     */
    public Resp<Object> createUser(User user) {
        return userService.createUser(user);
    }

    /**
     * 删除用户
     *
     * @param id 用户ID
     * @return 影响的行数，通常为1表示成功
     */
    public int deleteUser(Long id) {
        return userService.deleteUser(id);
    }

    /**
     * 更新用户信息
     *
     * @param userId 用户对象，包含更新后的用户信息
     * @return 影响的行数，通常为1表示成功
     */
    public int updateUser(long userId,Map<String, Object> updates) {
        return userService.updateUser(userId, updates);
    }


    public boolean updateUser(User user) {
        return userService.updateById(user);
    }
    /**
     * 根据用户ID获取用户信息
     *
     * @param id 用户ID
     * @return 用户对象，如果用户不存在则返回null
     */
    public User getUserById(Long id) {
        return userService.getUserById(id);
    }

    /**
     * 根据用户名获取用户信息
     *
     * @param username 用户名
     * @return 用户对象，如果用户不存在则返回null
     */
    public User getUserByUsername(String username) {
        return userService.getUserByUsername(username);
    }

    /**
     * 获取所有用户列表
     *
     * @return 用户列表
     */
    public Page<User> getAllUsers(int page, int size) {
        return userService.getAllUsers(page,size);
    }

    //分页查询方法
    public Page<User> getUsersByPage(int pageNum, int pageSize, String orderByColumn, String sort, String username, String email) {
        return userService.getUsersByPage(pageNum, pageSize, orderByColumn, sort, username, email);
    }

    public boolean updateFrozenStatus(Long id, Integer isFrozen) {

        return userService.updateFrozenStatus(id, isFrozen);
    }

    public boolean updatePermissionLevel(Long id, Integer permissionLevel) {

        return userService.updatePermissionLevel(id, permissionLevel);
    }

    /**
     * 获取用户名
     */
    public String getUsername(Long userId) {
        try {
            User user = userService.getById(userId);
            return user != null ? user.getUsername() : null;
        } catch (Exception e) {
            log.error("获取用户名失败, userId: {}", userId, e);
            throw new RuntimeException("获取用户名失败");
        }
    }

    /**
     * 警告用户
     */
    public Resp<Boolean> warnUser(Long userId) {
        try {
            return userService.warnUser(userId);
        } catch (Exception e) {
            log.error("警告用户失败, userId: {}", userId, e);
            throw new RuntimeException("警告用户失败");
        }
    }

    /**
     * 禁言用户
     */
    public Resp<Boolean> muteUser(Long userId) {
        try {
            return userService.muteUser(userId);
        } catch (Exception e) {
            log.error("禁言用户失败, userId: {}", userId, e);
            throw new RuntimeException("禁言用户失败");
        }
    }

    /**
     * 封禁用户
     */
    public Resp<Boolean> banUser(Long userId) {
        try {
            return userService.banUser(userId);
        } catch (Exception e) {
            log.error("封禁用户失败, userId: {}", userId, e);
            throw new RuntimeException("封禁用户失败");
        }
    }

    public boolean addUser(UserCreateDTO user) {
        return userService.addUser(user);
    }
}
