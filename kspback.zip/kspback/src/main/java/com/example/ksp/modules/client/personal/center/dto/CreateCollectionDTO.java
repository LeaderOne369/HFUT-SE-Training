package com.example.ksp.modules.client.personal.center.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * @author loself
 * @date 2025-01-08 16:06
 */


@Data
@Schema(description = "创建合集")
public class CreateCollectionDTO {


    @NotBlank(message = "合集名称不能为空")
    @Schema(description = "合集名称")
    private String collectionName;

    @Schema(description = "合集描述")
    private String collectionDescription;


    @NotNull(message = "可见性不能为空")
    @Schema(description = "可见性(0:私密 1:公开)")
    private Integer visibility;
}
