package com.example.ksp.test;

import com.example.ksp.common.utils.MinioUtil;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Objects;
import java.util.UUID;
@Tag(name = "系统级MinIO测试接口")
@RestController
@RequestMapping("/api/test/minio")
@RequiredArgsConstructor
public class MinioTestController {
    
    private final MinioUtil minioUtil;
    
    @PostMapping("/test")
    public String test() {
        try {
            // 测试上传一段文本
            String content = "Hello MinIO!";
            String path = "test/hello.txt";
            
            // 上传内容
            String url = minioUtil.uploadString(path, content);
            
            // 读取内容
            String savedContent = minioUtil.getFileContent(path);
            
            return "上传成功！\n访问URL: " + url + "\n读取内容: " + savedContent;
        } catch (Exception e) {
            return "测试失败：" + e.getMessage();
        }
    }
    
    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file) {
        try {
            // 生成文件名
            String fileName = UUID.randomUUID().toString() + 
                Objects.requireNonNull(file.getOriginalFilename()).substring(file.getOriginalFilename().lastIndexOf("."));
            
            // 上传文件
            String url = minioUtil.uploadFile("uploads/" + fileName, file);
            
            return "文件上传成功！\n访问URL: " + url;
        } catch (Exception e) {
            return "上传失败：" + e.getMessage();
        }
    }
} 