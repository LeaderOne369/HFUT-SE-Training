package com.example.ksp.modules.system.comment.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import java.util.List;

public interface CommentService extends IService<Comment> {

    Resp<Comment> createComment(CommentCreateDTO createDTO);

    Resp<Comment> replyComment(CommentCreateDTO createDTO);

    Resp<Void> deleteComment(Long id);

    Resp<Comment> getComment(Long id);

    Resp<Page<Comment>> queryComments(CommentQueryDTO queryDTO);

    Resp<String> updateReviewStatus(Long id, Integer reviewStatus);

    /**
     * 获取用户所有评论记录
     *
     * @param userId 用户ID
     * @return 用户评论列表
     */
    Resp<List<Comment>> getAllCommentsByUser(Long userId);

    /**
     * 获取用户对特定类型对象的评论记录
     *
     * @param userId       用户ID
     * @param objectType   评论对象类型 (1:帖子, 2:合集, 3:评论)
     * @return 用户特定类型评论列表
     */
    Resp<List<Comment>> getCommentsByUserAndType(Long userId, Integer objectType);

    /**
     * 获取用户评论总数
     *
     * @param userId 用户ID
     * @return 用户评论总数
     */
    Resp<Integer> getCommentCountByUser(Long userId);


    /**
     * 清空用户所有评论记录 (逻辑删除)
     *
     * @param userId 用户ID
     * @return 是否清空成功
     */
    Resp<Void> clearAllCommentsByUser(Long userId);

    Resp<Integer> getReceivedCommentCount(Long userId);

    Resp<Void> decrementLikeCount(Long commentId);

    Resp<Void> incrementLikeCount(Long commentId);
}
