package com.example.ksp.modules.client.comment;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.postdetail.dto.PostStatsDTO;
import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;

import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;

import java.util.List;

/**
 * 帖子详情服务接口
 */
public interface CommentService {

    Resp<String> reportComment(Long commentId, Long reportTypeId, Long reportedTypeId, String reason, String token);

    Resp<CommentDTO> replyComment(Long commentId, String content, String token);


}
