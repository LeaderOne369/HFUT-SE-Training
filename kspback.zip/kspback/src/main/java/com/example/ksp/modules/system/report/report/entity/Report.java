package com.example.ksp.modules.system.report.report.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("report")
@Schema(description = "举报实体")
public class Report {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "举报ID")
    private Long id;
    
    @Schema(description = "举报用户ID")
    private Long userId;
    
    @Schema(description = "被举报内容ID")
    private Long reportedContentId;
    
    @Schema(description = "举报对象类型ID")
    private Long reportedTypeId;
    
    @Schema(description = "举报类型ID")
    private Long reportTypeId;
    
    @Schema(description = "举报理由")
    private String reason;
    
    @Schema(description = "举报时间")
    private LocalDateTime reportTime;
    
    @Schema(description = "处理状态(0:待处理 1:正在处理 2:已处理 3:无需处理)")
    private Integer status;
    
    @Schema(description = "处理结果(0:无行动 1:内容已删除 2:警告用户 3:用户禁言 4:用户封禁)")
    private Integer outcome;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
} 