package com.example.ksp.modules.client.search.vo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PostByEsVO {
    private Long id;
    private Long userId;
    private Long sectionId;
    private String sectionName;
    private String tags;
    private String cover;
    private String summary;
    private String citation;
    private Long collectionId;
    private String collectionName;
    private String title;
    private String contentFileId;
    private String contentFilePath;
    private LocalDateTime publishTime;
    private LocalDateTime updateTime;
    private Integer viewCount;
    private Integer commentCount;
    private Integer likeCount;
    private Integer shareCount;
    private Integer status;
    private Integer isPinned;
    private Integer isEssence;
    private Integer visibility;
    private Integer reviewStatus;
    private Integer isDeleted;
    private String authorName;
    private String authorAvatar;
} 