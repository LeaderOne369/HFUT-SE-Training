package com.example.ksp.common.filter;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

@Component
@WebFilter(urlPatterns = "/*")
@Order(1)
@Slf4j
public class PublicIpFilter implements Filter {
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        
        try {
            // 获取客户端真实IP
            String clientIp = request.getRemoteAddr();
            
            // 如果是本地测试环境
            if ("127.0.0.1".equals(clientIp) || "0:0:0:0:0:0:0:1".equals(clientIp)) {
                try {
                    clientIp = InetAddress.getLocalHost().getHostAddress();
                } catch (UnknownHostException e) {
                    log.error("获取本地IP失败", e);
                }
            }
            
            // 包装请求
            PublicIpRequestWrapper requestWrapper = new PublicIpRequestWrapper(req, clientIp);
            chain.doFilter(requestWrapper, response);
            
        } catch (Exception e) {
            log.error("获取客户端IP失败", e);
            chain.doFilter(request, response);
        }
    }
} 