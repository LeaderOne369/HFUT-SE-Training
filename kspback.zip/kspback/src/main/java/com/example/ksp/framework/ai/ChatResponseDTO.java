package com.example.ksp.framework.ai;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(description = "AI聊天响应")
public class ChatResponseDTO {
    
    @Schema(description = "响应ID")
    private String id;
    
    @Schema(description = "对象类型")
    private String object;
    
    @Schema(description = "创建时间戳")
    private Long created;
    
    @Schema(description = "使用的模型")
    private String model;
    
    @Schema(description = "响应选项列表")
    private List<Choice> choices;
    
    @Schema(description = "使用统计")
    private Usage usage;
    
    @Schema(description = "系统指纹")
    @JsonProperty("system_fingerprint")
    private String systemFingerprint;
    
    @Data
    @Schema(description = "响应选项")
    public static class Choice {
        @Schema(description = "选项索引")
        private Integer index;
        
        @Schema(description = "消息内容")
        private Message message;
        
        @Schema(description = "日志概率")
        private Object logprobs;
        
        @Schema(description = "结束原因")
        @JsonProperty("finish_reason")
        private String finishReason;
    }
    
    @Data
    @Schema(description = "消息内容")
    public static class Message {
        @Schema(description = "角色")
        private String role;
        
        @Schema(description = "内容")
        private String content;
    }
    
    @Data
    @Schema(description = "使用统计")
    public static class Usage {
        @Schema(description = "提示token数")
        @JsonProperty("prompt_tokens")
        private Integer promptTokens;
        
        @Schema(description = "完成token数")
        @JsonProperty("completion_tokens")
        private Integer completionTokens;
        
        @Schema(description = "总token数")
        @JsonProperty("total_tokens")
        private Integer totalTokens;
        
        @Schema(description = "提示缓存命中token数")
        @JsonProperty("prompt_cache_hit_tokens")
        private Integer promptCacheHitTokens;
        
        @Schema(description = "提示缓存未命中token数")
        @JsonProperty("prompt_cache_miss_tokens")
        private Integer promptCacheMissTokens;
    }
}