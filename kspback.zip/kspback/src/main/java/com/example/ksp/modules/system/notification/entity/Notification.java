package com.example.ksp.modules.system.notification.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("notification")
@Schema(name = "Notification对象", description = "通知信息")
public class Notification {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "发送者ID")
    private Long userSenderId;

    @Schema(description = "接收者ID")
    private Long userReceiverId;

    @Schema(description = "通知标题")
    private String title;

    @Schema(description = "通知内容")
    private String content;

    @Schema(description = "通知类型(1:评论回复 2:点赞 3:系统通知)")
    private Integer type;

    @Schema(description = "通知状态(0:未读 1:已读)")
    private Integer status;

    @Schema(description = "创建时间")
    private LocalDateTime creationTime;

    @Schema(description = "阅读时间")
    private LocalDateTime readTime;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;
} 