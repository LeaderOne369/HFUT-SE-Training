package com.example.ksp.modules.admin.management.reviewmg.service.impl;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reviewmg.service.ReviewManageService;
import com.example.ksp.modules.admin.management.reviewmg.vo.ReviewManageVO;
import com.example.ksp.modules.proxy.ReviewLogProxy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReviewManageServiceImpl implements ReviewManageService {
    
    private final ReviewLogProxy reviewLogProxy;
    
    @Override
    public Resp<Page<ReviewManageVO>> queryReviewPage(Integer type, Integer status, Integer page, Integer size) {
        return reviewLogProxy.queryReviewPage(type, status, page, size);
    }
    
    @Override
    public Resp<ReviewManageVO> getReviewDetail(Long id) {
        return reviewLogProxy.getReviewDetail(id);
    }
    
    @Override
    public Resp<Void> handleReview(Long id, Integer status, String reason) {
        return reviewLogProxy.handleReview(id, status, reason);
    }


}