package com.example.ksp.modules.system.collection.collection.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "合集查询参数")
public class CollectionQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "合集名称")
    private String collectionName;
    
    @Schema(description = "创建者ID")
    private Long creatorId;
    
    @Schema(description = "可见性")
    private Integer visibility;
    
    @Schema(description = "审核状态")
    private Integer reviewStatus;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 