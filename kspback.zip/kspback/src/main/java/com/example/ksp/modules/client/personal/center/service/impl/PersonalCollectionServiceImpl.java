package com.example.ksp.modules.client.personal.center.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.CreateCollectionDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalCollectionService;
import com.example.ksp.modules.proxy.CollectionServiceProxy;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;

import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsQueryDTO;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalCollectionServiceImpl implements PersonalCollectionService {

    private final CollectionServiceProxy collectionServiceProxy;

    @Override
    public Resp<Page<Collection>> getUserCollections(Long userId, long current, long size) {
        try {
            CollectionQueryDTO queryDTO = new CollectionQueryDTO();
            queryDTO.setCreatorId(userId);
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            
            return collectionServiceProxy.queryCollections(queryDTO);
        } catch (Exception e) {
            log.error("获取用户合集列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取合集列表失败");
        }
    }

    @Override
    public Resp<Page<Collection>> getSubscribedCollections(Long userId, long current, long size) {
        try {
            return collectionServiceProxy.getSubscribedCollections(userId, current, size);
        } catch (Exception e) {
            log.error("获取用户订阅的合集列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取合集列表失败");
        }
    }

    @Override
    public Resp<Collection> getCollectionDetail(Long userId, Long collectionId) {
        try {
            Resp<Collection> collectionResp = collectionServiceProxy.getCollection(collectionId);
            if (collectionResp.getCode() != 200 || collectionResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在");
            }
            
            Collection collection = collectionResp.getData();
            // 检查合集是否已删除
            if (collection.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集已删除");
            }
            
            // 检查权限
            // 1. 是合集的创建者
            // 2. 合集是公开的且已通过审核
            if (!collection.getCreatorId().equals(userId) && 
                (collection.getVisibility() == 0 || collection.getReviewStatus() != 1)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权查看此合集");
            }
            
            return Resp.success(collection);
        } catch (Exception e) {
            log.error("获取合集详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取合集详情失败");
        }
    }

    @Override
    public Resp<Collection> updateCollection(Long userId, CollectionUpdateDTO updateDTO) {
        try {
            // 验证合集所有权
            Resp<Collection> collectionResp = collectionServiceProxy.getCollection(updateDTO.getId());
            if (collectionResp.getCode() != 200 || collectionResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在");
            }
            
            Collection collection = collectionResp.getData();
            // 检查合集是否已删除
            if (collection.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集已删除");
            }
            
            if (!collection.getCreatorId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权修改此合集");
            }
            
            // 修改后需要重新审核
            updateDTO.setReviewStatus(0);
            
            return collectionServiceProxy.updateCollection(updateDTO);
        } catch (Exception e) {
            log.error("更新合集失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新合集失败");
        }
    }

    @Override
    public Resp<Boolean> deleteCollection(Long userId, Long collectionId) {
        try {
            // 验证合集所有权
            Resp<Collection> collectionResp = collectionServiceProxy.getCollection(collectionId);
            if (collectionResp.getCode() != 200 || collectionResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在");
            }
            
            Collection collection = collectionResp.getData();
            if (!collection.getCreatorId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权删除此合集");
            }
            
            Resp<Void> deleteResp = collectionServiceProxy.deleteCollection(collectionId);
            return Resp.success(deleteResp.getCode() == 200);
        } catch (Exception e) {
            log.error("删除合集失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除合集失败");
        }
    }

    @Override
    public Resp<Boolean> unsubscribeCollection(Long userId, Long collectionId) {
        try {
            // 检查合集是否存在
            Resp<Collection> collectionResp = collectionServiceProxy.getCollection(collectionId);
            if (collectionResp.getCode() != 200 || collectionResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "合集不存在");
            }
            
            // 检查是否已订阅
            Resp<Boolean> subResp = collectionServiceProxy.isSubscribed(collectionId, userId);
            if (subResp.getCode() != 200 || !subResp.getData()) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "未订阅此合集");
            }
            
            // 取消订阅
            Resp<Void> unsubResp = collectionServiceProxy.unsubscribeCollection(collectionId, userId);
            if (unsubResp.getCode() != 200) {
                return Resp.error(unsubResp.getCode(), unsubResp.getMsg());
            }
            
            return Resp.success(true);
        } catch (Exception e) {
            log.error("取消订阅合集失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "取消订阅失败");
        }
    }

    @Override
    public Resp<Collection> createCollection(Long currentUserId, CreateCollectionDTO createDTO) {
        try {
            CollectionCreateDTO dto = new CollectionCreateDTO();
            BeanUtils.copyProperties(createDTO, dto);
            dto.setCreatorId(currentUserId);
            return collectionServiceProxy.createCollection(dto);
        } catch (Exception e) {
            return  Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建合集失败");
        }
    }
} 