package com.example.ksp.modules.system.favorite.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favorite.mapper.FavoriteMapper;
import com.example.ksp.modules.system.favorite.service.FavoriteService;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.mapper.PostMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service


//TODO 逻辑删除字段未检验
public class FavoriteServiceImpl extends ServiceImpl<FavoriteMapper, Favorite> implements FavoriteService {


    @Autowired
    PostMapper postMapper;
    @Override
    public boolean addFavorite(Long userId, Long postId, Long folderId) {
        // 检查是否已收藏
        if (checkFavorite(userId, postId)) {
            return false;
        }

        Favorite favorite = new Favorite();
        favorite.setUserId(userId);
        favorite.setPostId(postId);
        favorite.setFolderId(folderId);
        favorite.setFavoriteTime(LocalDateTime.now());
        favorite.setIsDeleted(0);
        return save(favorite);
    }

    @Override
    public boolean cancelFavorite(Long userId, Long postId) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId)
                .eq(Favorite::getPostId, postId);
        return remove(wrapper);
    }

    @Override
    public boolean moveFavorite(Long id, Long newFolderId) {
        Favorite favorite = getById(id);
        if (favorite == null) {
            return false;
        }
        
        favorite.setFolderId(newFolderId);
        return updateById(favorite);
    }

    @Override
    public Page<Favorite> getUserFavorites(Long userId, Long folderId, long current, long size) {
        Page<Favorite> page = new Page<>(current, size);
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId)
                .eq(folderId != null, Favorite::getFolderId, folderId)
                .orderByDesc(Favorite::getFavoriteTime);
        
        return page(page, wrapper);
    }

    @Override
    public long getPostFavoriteCount(Long postId) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getPostId, postId);
        return count(wrapper);
    }

    @Override
    public boolean checkFavorite(Long userId, Long postId) {
        LambdaQueryWrapper<Favorite> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Favorite::getUserId, userId)
                .eq(Favorite::getPostId, postId);
        return count(wrapper) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean batchMoveFavorites(Long[] ids, Long newFolderId) {
        return Arrays.stream(ids).allMatch(id -> moveFavorite(id, newFolderId));
    }

    @Override
    public Resp<Integer> getReceivedFavoriteCount(Long userId) {
        try {
            // 1. 获取用户的所有帖子ID
            LambdaQueryWrapper<Post> postLqw = Wrappers.lambdaQuery();
            postLqw.select(Post::getId)
                   .eq(Post::getUserId, userId)
                   .eq(Post::getIsDeleted, 0);
            List<Long> userPostIds = postMapper.selectList(postLqw)
                    .stream()
                    .map(Post::getId)
                    .collect(Collectors.toList());
            
            if (userPostIds.isEmpty()) {
                return Resp.success(0);
            }
            
            // 2. 统计这些帖子被收藏的次数
            LambdaQueryWrapper<Favorite> favoriteLqw = Wrappers.lambdaQuery();
            favoriteLqw.in(Favorite::getPostId, userPostIds)
                      .eq(Favorite::getIsDeleted, 0);
            
            int count = Math.toIntExact(count(favoriteLqw));
            return Resp.success(count);
        } catch (Exception e) {
            log.error("获取用户收到的收藏数量失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏数量失败");
        }
    }
} 