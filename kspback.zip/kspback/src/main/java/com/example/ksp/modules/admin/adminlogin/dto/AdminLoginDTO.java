package com.example.ksp.modules.admin.adminlogin.dto;

import com.example.ksp.modules.system.user.dto.LoginDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "管理员登录请求参数")
public class AdminLoginDTO {
    
    @NotBlank(message = "用户名不能为空")
    @Schema(description = "用户名")
    private String username;
    
    @NotBlank(message = "密码不能为空")
    @Schema(description = "密码")
    private String password;
    
    @Schema(description = "最后登录时间")
    private LocalDateTime lastLoginTime;
    
    @Schema(description = "最后登录地点")
    private String lastLoginLocation;
    
    public LoginDTO toLoginDTO() {
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setUsername(username);
        loginDTO.setPassword(password);
        loginDTO.setLoginType(1); // 用户名密码登录
        return loginDTO;
    }
} 