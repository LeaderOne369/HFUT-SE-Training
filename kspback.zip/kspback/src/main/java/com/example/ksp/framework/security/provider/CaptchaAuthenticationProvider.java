package com.example.ksp.framework.security.provider;

import com.example.ksp.common.utils.CaptchaUtil;
import com.example.ksp.framework.security.service.CaptchaUserDetailsService;
import com.example.ksp.framework.security.token.CaptchaAuthenticationToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

/**
 * @author loself
 * @date 2024-12-31 15:54
 */
@Component
public class CaptchaAuthenticationProvider implements AuthenticationProvider {

    private final CaptchaUserDetailsService userDetailsService;
    private final CaptchaUtil captchaService;

    @Autowired
    public CaptchaAuthenticationProvider(CaptchaUserDetailsService userDetailsService, 
                                       CaptchaUtil captchaService) {
        this.userDetailsService = userDetailsService;
        this.captchaService = captchaService;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        if (!supports(authentication.getClass())) {
            return null;
        }

        CaptchaAuthenticationToken authToken = (CaptchaAuthenticationToken) authentication;
        String principal = (String) authToken.getPrincipal();
        String captcha = (String) authToken.getCredentials();

        if (!captchaService.checkCaptcha(principal, captcha)) {
            throw new BadCredentialsException("验证码错误");
        }

        UserDetails userDetails = userDetailsService.loadUserByUsername(principal);

        CaptchaAuthenticationToken authenticatedToken = new CaptchaAuthenticationToken(
                userDetails, userDetails.getAuthorities());
        authenticatedToken.setDetails(authentication.getDetails());

        return authenticatedToken;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return (CaptchaAuthenticationToken.class.isAssignableFrom(authentication));
    }
}
