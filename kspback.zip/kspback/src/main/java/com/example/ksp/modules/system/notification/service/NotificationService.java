package com.example.ksp.modules.system.notification.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.modules.system.notification.entity.Notification;

public interface NotificationService extends IService<Notification> {
    
    /**
     * 发送通知
     */
    boolean sendNotification(Notification notification);

    /**
     * 标记通知为已读
     */
    boolean markAsRead(Long id);

    /**
     * 批量标记通知为已读
     */
    boolean markAllAsRead(Long userId);

    /**
     * 删除通知
     */
    boolean deleteNotification(Long id);

    /**
     * 获取用户的未读通知数量
     */
    long getUnreadCount(Long userId);

    /**
     * 获取用户的通知列表
     */
    Page<Notification> getUserNotifications(Long userId, Integer type, long current, long size);
} 