package com.example.ksp.modules.system.like.controller;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.like.service.LikeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级点赞管理接口")
@RestController
@RequestMapping("/api/system/like")
public class LikeController {

    @Autowired
    private LikeService likeService;

    @Operation(summary = "添加点赞", description = "为指定对象添加点赞")
    @PostMapping("/add")
    public Resp<Boolean> addLike(
            @Parameter(description = "用户ID", required = true) @RequestParam Long userId,
            @Parameter(description = "对象ID", required = true) @RequestParam Long objectId,
            @Parameter(description = "对象类型(1:帖子 2:合集 3:评论)", required = true) @RequestParam Integer objectType) {
        
        boolean result = likeService.addLike(userId, objectId, objectType);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "已经点赞过了");
    }

    @Operation(summary = "取消点赞", description = "取消指定对象的点赞")
    @DeleteMapping("/cancel")
    public Resp<Boolean> cancelLike(
            @Parameter(description = "用户ID", required = true) @RequestParam Long userId,
            @Parameter(description = "对象ID", required = true) @RequestParam Long objectId,
            @Parameter(description = "对象类型(1:帖子 2:合集 3:评论)", required = true) @RequestParam Integer objectType) {
        
        boolean result = likeService.cancelLike(userId, objectId, objectType);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "取消点赞失败");
    }

    @Operation(summary = "检查点赞状态", description = "检查用户是否已对指定对象点赞")
    @GetMapping("/check")
    public Resp<Boolean> checkLiked(
            @Parameter(description = "用户ID", required = true) @RequestParam Long userId,
            @Parameter(description = "对象ID", required = true) @RequestParam Long objectId,
            @Parameter(description = "对象类型(1:帖子 2:合集 3:评论)", required = true) @RequestParam Integer objectType) {
        
        boolean result = likeService.checkLiked(userId, objectId, objectType);
        return Resp.success(result);
    }
} 