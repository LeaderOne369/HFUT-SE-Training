package com.example.ksp.modules.client.notification.controller;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.NotificationServiceProxy;
import com.example.ksp.modules.system.notification.entity.Notification;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Tag(name = "客户端通知接口")
@RestController("clientNotificationController") // 修改 Bean 名称
@RequestMapping("/api/client/notification")
@RequiredArgsConstructor
public class NotificationController {
    @Autowired
    private final NotificationServiceProxy notificationServiceProxy;

    /**
     * 获取用户的所有通知
     */
    @Operation(summary = "获取用户的所有通知")
    @GetMapping("/user/{userId}/all")
    public Resp<List<Notification>> getAllNotifications(
            @PathVariable Long userId,
            @RequestParam(value = "type", required = false) Integer type,
            @RequestParam(value = "current", defaultValue = "1") long current,
            @RequestParam(value = "size", defaultValue = "10") long size) {
        return notificationServiceProxy.receiveMessages(userId, type, current, size);
    }

    /**
     * 查看单条通知的详情
     */
    @Operation(summary = "查看单条通知的详情")
    @GetMapping("/{id}")
    public Resp<Notification> getNotificationDetails(@PathVariable Long id) {
        return notificationServiceProxy.getMessageDetails(id);
    }

    /**
     * 标记指定通知为已读
     */
    @Operation(summary = "标记指定通知为已读")
    @PutMapping("/{id}/read")
    public Resp<Boolean> markAsRead(@PathVariable Long id) {
        return notificationServiceProxy.markAsRead(id);
    }

    /**
     * 标记用户所有通知为已读
     */
    @Operation(summary = "标记用户所有通知为已读")
    @PutMapping("/user/{userId}/markAllRead")
    public Resp<Boolean> markAllAsRead(@PathVariable Long userId) {
        return notificationServiceProxy.markAllAsRead(userId);
    }

    /**
     * 删除指定通知
     */
    @Operation(summary = "删除指定通知")
    @DeleteMapping("/{id}")
    public Resp<Boolean> deleteNotification(@PathVariable Long id) {
        return notificationServiceProxy.deleteMessage(id);
    }

    /**
     * 获取用户未读通知的数量
     */
    @Operation(summary = "获取用户未读通知的数量")
    @GetMapping("/user/{userId}/unreadCount")
    public Resp<Long> getUnreadCount(@PathVariable Long userId) {
        return notificationServiceProxy.getUnreadCount(userId);
    }
}
