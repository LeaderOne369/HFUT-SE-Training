package com.example.ksp.modules.system.view.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.modules.system.view.entity.View;

public interface ViewService extends IService<View> {
    
    /**
     * 记录浏览
     */
    boolean recordView(Long userId, Long postId);

    /**
     * 删除浏览记录
     */
    boolean deleteView(Long id);

    /**
     * 批量删除用户的浏览记录
     */
    boolean deleteUserViews(Long userId);

    /**
     * 获取用户的浏览记录
     */
    Page<View> getUserViews(Long userId, long current, long size);

    /**
     * 获取帖子的浏览记录
     */
    Page<View> getPostViews(Long postId, long current, long size);

    /**
     * 获取帖子的浏览次数
     */
    long getPostViewCount(Long postId);
} 