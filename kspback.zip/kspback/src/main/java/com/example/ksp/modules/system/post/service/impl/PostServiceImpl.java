package com.example.ksp.modules.system.post.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.ksp.common.utils.MinioUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.dto.PostCreateDTO;
import com.example.ksp.modules.system.post.dto.PostQueryDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.mapper.PostMapper;
import com.example.ksp.modules.system.post.service.PostService;
import jakarta.annotation.Resource;
import com.example.ksp.modules.system.view.service.ViewService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.multipart.MultipartFile;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PostServiceImpl extends ServiceImpl<PostMapper, Post> implements PostService {

    private static final Logger log = LoggerFactory.getLogger(PostServiceImpl.class);
    @Resource
    private PostMapper postMapper;
    private final MinioUtil minioUtil;
    private final ViewService viewService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Post> createPost(PostCreateDTO createDTO) {
        try {
            Post post = new Post();
            BeanUtils.copyProperties(createDTO, post);

            // 生成内容文件路径
            post.setContentFileId(createDTO.getContentFileId());
            post.setContentFilePath(createDTO.getContentFilePath());
            // 设置其他字段
            post.setPublishTime(LocalDateTime.now());
            post.setViewCount(0);
            post.setCommentCount(0);
            post.setLikeCount(0);
            post.setShareCount(0);
            post.setIsEssence(0);
            post.setIsPinned(0);
            post.setReviewStatus(1);
            post.setUpdateTime(LocalDateTime.now());
            post.setIsDeleted(0);

            save(post);
            return Resp.success(post);
        } catch (Exception e) {
            log.error("创建帖子失败", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建帖子失败: " + e.getMessage());
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Post> updatePost(PostUpdateDTO updateDTO) {
        try {
            Post post = getById(updateDTO.getId());
            if (post == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }

            // 更新基本信息
            if (updateDTO.getSectionId() != null) post.setSectionId(updateDTO.getSectionId());
            if (updateDTO.getTags() != null) post.setTags(updateDTO.getTags());
            if (updateDTO.getCover() != null) post.setCover(updateDTO.getCover());
            if (updateDTO.getSummary() != null) post.setSummary(updateDTO.getSummary());
            if (updateDTO.getCitation() != null) post.setCitation(updateDTO.getCitation());
            if (updateDTO.getCollectionId() != null) post.setCollectionId(updateDTO.getCollectionId());
            if (updateDTO.getTitle() != null) post.setTitle(updateDTO.getTitle());

            // 如果内容有更新，则更新MinIO中的文件
           if(updateDTO.getContentFileId() != null && !updateDTO.getContentFileId().equals(post.getContentFileId())) {
                // 删除旧文件
                minioUtil.deleteFile(post.getContentFilePath());
                // 更新文件
                post.setContentFileId(updateDTO.getContentFileId());
                post.setContentFilePath(updateDTO.getContentFilePath());
           }

            // 更新其他字段
            post.setUpdateTime(LocalDateTime.now());
            if (updateDTO.getVisibility() != null) post.setVisibility(updateDTO.getVisibility());
            if (updateDTO.getStatus() != null) post.setStatus(updateDTO.getStatus());

            updateById(post);
            return Resp.success(post);
        } catch (Exception e) {
            log.error("更新帖子失败", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新帖子失败: " + e.getMessage());
        }
    }

    /**
     * 生成内容文件路径
     */
    private String generateContentFilePath() {
        return "post/content/" + UUID.randomUUID() + ".html";
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<String> deletePost(Long id) {
        try {
            Post post = getById(id);
            if (post == null) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
            }

            // 逻辑删除帖子
            post.setIsDeleted(1);
            post.setUpdateTime(LocalDateTime.now());
            updateById(post);

            return Resp.success("删除成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除帖子失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Post> getPost(Long id) {
        Post post = getById(id);
        if (post == null || post.getIsDeleted() == 1) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
        }
        return Resp.success(post);
    }

    @Override
    public Resp<Page<Post>> queryPosts(PostQueryDTO queryDTO) {
        try {
            Page<Post> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());

            LambdaQueryWrapper<Post> wrapper = new LambdaQueryWrapper<Post>()
                .eq(Post::getIsDeleted, 0)
                .eq(queryDTO.getUserId() != null, Post::getUserId, queryDTO.getUserId())
                .eq(queryDTO.getSectionId() != null, Post::getSectionId, queryDTO.getSectionId())
                .eq(queryDTO.getCollectionId() != null, Post::getCollectionId, queryDTO.getCollectionId())
                .eq(queryDTO.getStatus() != null, Post::getStatus, queryDTO.getStatus())
                .eq(queryDTO.getVisibility() != null, Post::getVisibility, queryDTO.getVisibility())
                .eq(queryDTO.getReviewStatus() != null, Post::getReviewStatus, queryDTO.getReviewStatus())
                .like(StringUtils.isNotBlank(queryDTO.getTags()), Post::getTags, queryDTO.getTags())
                .and(StringUtils.isNotBlank(queryDTO.getKeyword()), w -> w
                    .like(Post::getTitle, queryDTO.getKeyword())
                    .or()
                    .like(Post::getSummary, queryDTO.getKeyword())
                );

            // 添加时间范围查询
            if (StringUtils.isNotBlank(queryDTO.getStartTime())) {
                wrapper.ge(Post::getPublishTime, LocalDateTime.parse(queryDTO.getStartTime(),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            }
            if (StringUtils.isNotBlank(queryDTO.getEndTime())) {
                wrapper.le(Post::getPublishTime, LocalDateTime.parse(queryDTO.getEndTime(),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            }

            // 按更新时间倒序排序
            wrapper.orderByDesc(Post::getUpdateTime);

            return Resp.success(page(page, wrapper));
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询帖子失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updateStatus(Long id, Integer status) {
        try {
            Post post = getById(id);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
            }

            post.setStatus(status);
            post.setUpdateTime(LocalDateTime.now());
            updateById(post);

            return Resp.success("更新状态成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新状态失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updateReviewStatus(Long id, Integer reviewStatus) {
        try {
            Post post = getById(id);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
            }

            post.setReviewStatus(reviewStatus);
            post.setUpdateTime(LocalDateTime.now());
            updateById(post);

            return Resp.success("更新审核状态成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新审核状态失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updatePinned(Long id, Integer isPinned) {
        try {
            Post post = getById(id);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
            }

            post.setIsPinned(isPinned);
            post.setUpdateTime(LocalDateTime.now());
            updateById(post);

            return Resp.success(isPinned == 1 ? "置顶成功" : "取消置顶成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新置顶状态失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updateEssence(Long id, Integer isEssence) {
        try {
            Post post = getById(id);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "帖子不存在");
            }

            post.setIsEssence(isEssence);
            post.setUpdateTime(LocalDateTime.now());
            updateById(post);

            return Resp.success(isEssence == 1 ? "设为精华成功" : "取消精华成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新精华状态失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Integer> getUserPostCount(Long userId) {
        try {
            LambdaQueryWrapper<Post> lqw = Wrappers.lambdaQuery();
            lqw.eq(Post::getUserId, userId)
               .eq(Post::getIsDeleted, 0);

            int count = Math.toIntExact(count(lqw));
            return Resp.success(count);
        } catch (Exception e) {
            log.error("获取用户发帖总数失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取发帖总数失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Void> incrementViewCount(Long postId, Long userId) {
        try {
            // 1. 记录浏览记录
            boolean recorded = viewService.recordView(userId, postId);
            if (!recorded) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "记录浏览记录失败");
            }

            // 2. 使用SQL直接更新浏览量，避免并发问题
            LambdaUpdateWrapper<Post> updateWrapper = new LambdaUpdateWrapper<>();
            updateWrapper.eq(Post::getId, postId)
                        .setSql("view_count = view_count + 1");
            boolean success = update(updateWrapper);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新浏览量失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("增加帖子浏览量失败, postId: {}, userId: {}", postId, userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加浏览量失败");
        }
    }
    @Override
    public Page<Post> searchPostsBySection(Long sectionId, String keyword, long current, long size, String sortBy) {
        // 创建分页对象
        Page<Post> page = new Page<>(current, size);
        // 调用PostMapper中的自定义查询方法
        return postMapper.searchPostsBySection(page, sectionId, keyword, sortBy);
    }
    /**
     * 根据标签ID获取所有包含该标签的帖子
     *
     * @param tagId 标签ID
     * @param current 当前页
     * @param size 每页数量
     * @return 标签下的帖子分页列表
     */
    @Override
    public Page<Post> searchPostsByTag(Long tagId, long current, long size) {
        Page<Post> page = new Page<>(current, size);
        return postMapper.selectPostsByTag(page, tagId);
    }

    @Override
    public Page<Post> searchPostsByTagAndKey(Long tagId, long current, long size, String keyword) {
        Page<Post> page = new Page<>(current, size);
        return postMapper.selectPostsByTagAndKey(page, tagId,keyword);
    }
    /**
     * 根据关键词进行全表搜索，支持分页
     *
     * @param page 分页对象
     * @param keyword 搜索关键字
     * @return 分页后的搜索结果
     */
    @Override
    @Transactional(readOnly = true)
    public Page<Post> selectPostsByKeyword(Page<Post> page, String keyword) {
        // 调用Mapper的查询方法进行数据库查询并返回分页结果
        return postMapper.selectPostsByKeyword(page, keyword);
    }

    @Override
    public List<Post> getRankList(String period) {
        return switch (period) {
            case "daily" -> postMapper.getDailyRank().stream()
                    .filter(post -> post.getIsDeleted() == 0)
                    .limit(10)
                    .collect(Collectors.toList());
            case "weekly" -> postMapper.getWeeklyRank().stream()
                    .filter(post -> post.getIsDeleted() == 0)
                    .limit(10)
                    .collect(Collectors.toList());
            case "monthly" -> postMapper.getMonthlyRank().stream()
                    .filter(post -> post.getIsDeleted() == 0)
                    .limit(10)
                    .collect(Collectors.toList());
            default -> throw new IllegalArgumentException("Invalid period: " + period);
        };
    }



    @Override
    public Resp<Void> incrementLikeCount(Long postId) {
        log.info("增加帖子点赞数, postId: {}", postId);
        try {
            // 1. 检查帖子是否存在
            Post post = getById(postId);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在或已删除");
            }

            // 2. 更新点赞数
            post.setLikeCount(post.getLikeCount() + 1);
            boolean success = updateById(post);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新点赞数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("增加帖子点赞数失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加点赞数失败");
        }
    }

    @Override
    public Resp<Void> decrementLikeCount(Long postId) {
        log.info("减少帖子点赞数, postId: {}", postId);
        try {
            // 1. 检查帖子是否存在
            Post post = getById(postId);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在或已删除");
            }

            // 2. 更新点赞数（确保不会小于0）
            post.setLikeCount(Math.max(post.getLikeCount() - 1, 0));
            boolean success = updateById(post);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新点赞数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("减少帖子点赞数失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "减少点赞数失败");
        }
    }

    @Override
    public Resp<Void> incrementCommentCount(Long postId) {
        log.info("增加帖子评论数, postId: {}", postId);
        try {
            // 1. 检查帖子是否存在
            Post post = getById(postId);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在或已删除");
            }

            // 2. 更新评论数
            post.setCommentCount(post.getCommentCount() + 1);
            boolean success = updateById(post);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新评论数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("增加帖子评论数失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加评论数失败");
        }
    }

    @Override
    public int updatePost(Long posId, Map<String, Object> updates) {
        return postMapper.updatePost(posId, updates);  // 调用 Mapper 的动态更新方法
    }

    @Override
    public Resp<Void> incrementShareCount(Long postId) {
        log.info("增加帖子分享数, postId: {}", postId);
        try {
            // 1. 检查帖子是否存在
            Post post = getById(postId);
            if (post == null || post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在或已删除");
            }

            // 2. 更新点赞数
            post.setShareCount(post.getShareCount() + 1);
            boolean success = updateById(post);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新分享数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("增加帖子点赞数失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加分享数失败");
        }
    }
}
