package com.example.ksp.modules.proxy;

import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.service.CollectionService;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.like.service.LikeService;
import com.example.ksp.modules.system.comment.service.CommentService;
import com.example.ksp.modules.system.collection.collectionsubs.service.CollectionSubscriptionsService;
import com.example.ksp.modules.system.share.dto.ShareCreateDTO;
import com.example.ksp.modules.system.share.service.ShareService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;


/**
 * 合集功能代理类
 */
@Component
public class CollectionProxy {

    @Resource
    private CollectionService collectionService;

    @Resource
    private LikeService likeService;

    @Resource
    private CommentService commentService;

    @Resource
    private CollectionSubscriptionsService collectionSubscriptionsService;

    @Resource
    private ShareService shareService;

    /**
     * 查看合集详情
     *
     * @param collectionId 合集ID
     * @return 合集详情
     */
    public Object getCollectionDetail(Long collectionId) {
        return collectionService.getCollection(collectionId);
    }

    /**
     * 点赞合集
     *
     * @param userId 用户ID
     * @param collectionId 合集ID
     * @return 点赞结果
     */
    public boolean likeCollection(Long userId, Long collectionId) {
        final Integer COLLECTION_TYPE = 1;
        return likeService.addLike(userId, collectionId, COLLECTION_TYPE);
    }

    /**
     * 评论合集
     *
     * @param userId 用户ID
     * @param collectionId 合集ID
     * @param content 评论内容
     * @param parentId 父评论ID
     * @return 评论结果
     */
    public Object commentCollection(Long userId, Long collectionId, String content, Long parentId) {
        final Integer COLLECTION_TYPE = 2;
        CommentCreateDTO commentCreateDTO = new CommentCreateDTO();
        commentCreateDTO.setCommenterId(userId);
        commentCreateDTO.setCommentableId(collectionId);
        commentCreateDTO.setCommentableType(COLLECTION_TYPE);
        commentCreateDTO.setContent(content);
        commentCreateDTO.setParentCommentId(parentId);
        commentCreateDTO.setIsPublic(1);
        return commentService.createComment(commentCreateDTO);
    }

    /**
     * 订阅合集
     *
     * @param userId 用户ID
     * @param collectionId 合集ID
     * @return 订阅结果
     */
    public boolean subscribeCollection(Long userId, Long collectionId) {

        CollectionSubscriptionsCreateDTO collectionSubscriptionsCreateDTO = new CollectionSubscriptionsCreateDTO();
        collectionSubscriptionsCreateDTO.setUsersId(userId);
        collectionSubscriptionsCreateDTO.setCollectionsId(collectionId);
        return collectionSubscriptionsService.createSubscription(collectionSubscriptionsCreateDTO)!=null;
    }

    /**
     * 分享合集
     *
     * @param userId 用户ID
     * @param collectionId 合集ID
     * @return 分享结果
     */
    public boolean shareCollection(Long userId, Long collectionId) {
        final Integer COLLECTION_TYPE = 2;
        ShareCreateDTO shareCreateDTO = new ShareCreateDTO();
        shareCreateDTO.setUserId(userId);
        shareCreateDTO.setShareObjectId(collectionId);
        shareCreateDTO.setShareObjectType(COLLECTION_TYPE);
        return shareService.createShare(shareCreateDTO).getData()!=null;
    }

    public List<Collection> getAllCollections() {

        return collectionService.list()
                .stream()
                .filter(collection -> collection.getReviewStatus() == 1)
                .filter(collection -> collection.getVisibility() == 1)
                .collect(Collectors.toList());
    }
}