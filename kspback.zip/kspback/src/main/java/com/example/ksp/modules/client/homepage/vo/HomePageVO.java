package com.example.ksp.modules.client.homepage.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.util.List;

@Data
@Schema(description = "首页视图对象")
public class HomePageVO {
    
    @Schema(description = "用户信息")
    private UserBriefVO userInfo;
    
    @Schema(description = "推荐内容列表")
    private List<RecommendContentVO> recommendContents;
    
    @Schema(description = "分区列表")
    private List<SectionVO> sections;
    
    @Schema(description = "消息通知列表")
    private List<NotificationVO> notifications;
    
    @Schema(description = "未读通知数量", example = "0")
    private Integer unreadNotificationCount;
} 