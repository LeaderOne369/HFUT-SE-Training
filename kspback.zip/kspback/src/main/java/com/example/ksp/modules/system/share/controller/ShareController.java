package com.example.ksp.modules.system.share.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.share.dto.ShareCreateDTO;
import com.example.ksp.modules.system.share.dto.ShareQueryDTO;
import com.example.ksp.modules.system.share.entity.Share;
import com.example.ksp.modules.system.share.service.ShareService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级分享管理")
@RestController
@RequestMapping("/api/system/share")
@RequiredArgsConstructor
public class ShareController {

    private final ShareService shareService;

    @Operation(summary = "创建分享")
    @PostMapping
    public Resp<Share> createShare(
            @RequestHeader("token") String token,
            @RequestBody @Valid ShareCreateDTO createDTO) {
        return shareService.createShare(createDTO);
    }

    @Operation(summary = "删除分享")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteShare(
            @RequestHeader("token") String token,
            @Parameter(description = "分享ID") 
            @PathVariable Long id) {
        return shareService.deleteShare(id);
    }

    @Operation(summary = "获取分享详情")
    @GetMapping("/{id}")
    public Resp<Share> getShare(
            @RequestHeader("token") String token,
            @Parameter(description = "分享ID") 
            @PathVariable Long id) {
        return shareService.getShare(id);
    }

    @Operation(summary = "查询分享列表")
    @PostMapping("/list")
    public Resp<Page<Share>> queryShares(
            @RequestHeader("token") String token,
            @RequestBody ShareQueryDTO queryDTO) {
        return shareService.queryShares(queryDTO);
    }
} 