package com.example.ksp.modules.system.feedback.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.service.FeedbackService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级反馈管理接口")
@RequiredArgsConstructor
@RequestMapping("/api/system/feedback")
public class FeedbackController {

    private final FeedbackService feedbackService;

    @Operation(summary = "提交反馈")
    @PostMapping("/submit")
    public Resp<Boolean> submitFeedback(@RequestBody Feedback feedback) {
        boolean result = feedbackService.submitFeedback(feedback);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "提交反馈失败");
    }

    @Operation(summary = "更新反馈状态")
    @PutMapping("/status/{id}")
    public Resp<Boolean> updateStatus(
            @Parameter(description = "反馈ID", required = true)
            @PathVariable Long id,
            @Parameter(description = "状态(0:未处理 1:已处理 2:已回复)", required = true)
            @RequestParam Integer status) {
        boolean result = feedbackService.updateStatus(id, status);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新状态失败");
    }

    @Operation(summary = "删除反馈")
    @DeleteMapping("/delete/{id}")
    public Resp<Boolean> deleteFeedback(
            @Parameter(description = "反馈ID", required = true)
            @PathVariable Long id) {
        boolean result = feedbackService.deleteFeedback(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除反馈失败");
    }

    @Operation(summary = "获取用户反馈列表")
    @GetMapping("/user/list")
    public Resp<Page<Feedback>> getUserFeedbacks(
            @Parameter(description = "用户ID", required = true)
            @RequestParam Long userId,
            @Parameter(description = "状态(0:未处理 1:已处理 2:已回复)", required = false)
            @RequestParam(required = false) Integer status,
            @Parameter(description = "页码")
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小")
            @RequestParam(defaultValue = "10") long size) {
        Page<Feedback> result = feedbackService.getUserFeedbacks(userId, status, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取所有反馈列表")
    @GetMapping("/admin/list")
    public Resp<Page<Feedback>> getAllFeedbacks(
            @Parameter(description = "状态(0:未处理 1:已处理 2:已回复)", required = false)
            @RequestParam(required = false) Integer status,
            @Parameter(description = "页码")
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小")
            @RequestParam(defaultValue = "10") long size) {
        Page<Feedback> result = feedbackService.getAllFeedbacks(status, current, size);
        return Resp.success(result);
    }
}
