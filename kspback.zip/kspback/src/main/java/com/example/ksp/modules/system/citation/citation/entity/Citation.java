package com.example.ksp.modules.system.citation.citation.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("citation")
@Schema(description = "引用实体")
public class Citation {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "引用ID")
    private Long id;
    
    @Schema(description = "帖子ID")
    private Long postId;
    
    @Schema(description = "引用类型ID")
    private Long citationTypeId;
    
    @Schema(description = "引用内容")
    private String citationContent;
    
    @Schema(description = "引用来源")
    private String source;
    
    @Schema(description = "引用时间")
    private LocalDateTime citationTime;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
} 