package com.example.ksp.modules.system.share.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.share.dto.ShareCreateDTO;
import com.example.ksp.modules.system.share.dto.ShareQueryDTO;
import com.example.ksp.modules.system.share.entity.Share;

import java.util.List;

public interface ShareService extends IService<Share> {

    Resp<Share> createShare(ShareCreateDTO createDTO);

    Resp<Void> deleteShare(Long id);

    Resp<Share> getShare(Long id);

    Resp<Page<Share>> queryShares(ShareQueryDTO queryDTO);



    /**
     * 获取用户的所有分享记录
     *
     * @param userId 用户ID
     * @param current   当前页码
     * @param size   每页条数
     * @return Resp<Page<Share>> 用户的分享记录分页列表
     */
    Resp<Page<Share>> getUserShares(Long userId, long current, long size);

    /**
     * 获取特定对象的分享记录
     *
     * @param objectId   被分享对象的ID
     * @param objectType 被分享对象的类型（帖子、合集等）
     * @param current       当前页码
     * @param size       每页条数
     * @return Resp<Page<Share>> 被分享对象的分享记录分页列表
     */
    Resp<Page<Share>> getObjectShares(Long objectId, Integer objectType, long current, long size);


    /**
     * 获取用户分享的总数
     *
     * @param userId 用户ID
     * @return Resp<Long> 用户分享记录的总数
     */
    Resp<Long> getUserShareCount(Long userId);
}
