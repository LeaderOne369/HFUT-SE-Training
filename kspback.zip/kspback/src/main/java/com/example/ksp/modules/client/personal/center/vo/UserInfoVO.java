package com.example.ksp.modules.client.personal.center.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @author loself
 * @date 2025-01-08 15:17
 */

@Schema(description = "用户信息")
@Data
public class UserInfoVO {
    @Schema(description = "用户ID")
    private Long id;

    @Schema(description = "用户名")
    private String username;

    @Schema(description = "邮箱")
    private String email;

    @Schema(description = "手机号")
    private String phoneNumber;

    @Schema(description = "注册时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime registrationTime;

    @Schema(description = "最后登录时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastLoginTime;

    @Schema(description = "最后登录地点")
    private String lastLoginLocation;

    @Schema(description = "最后更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastUpdatedTime;


    @Schema(description = "是否冻结（0否 1是）")
    private Integer isFrozen;

    @Schema(description = "权限等级（0正常 1禁止评论 2禁止发帖）")
    private Integer permissionLevel;

    @Schema(description = "性别（0男 1女 2其他）")
    private Integer gender;

    @Schema(description = "出生日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private LocalDate birthDate;

    @Schema(description = "个人简介")
    @Size(max = 255, message = "个人简介不能超过255个字符")
    private String bio;

    @Schema(description = "头像URL")
    private String avatar;

    @Schema(description = "关注数")
    private Integer followingCount;

    @Schema(description = "粉丝数")
    private Integer followersCount;

    @Schema(description = "审核状态（0待审核 1已通过 2已拒绝）")
    private Integer reviewStatus;
}
