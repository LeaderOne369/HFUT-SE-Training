package com.example.ksp.modules.client.collection.dto;

import lombok.Data;

@Data
public class CommentRequest {
    /**
     * 评论内容
     */
    private String content;
    
    /**
     * 父评论ID（回复评论时使用）
     */
    private Long parentId;
} 