package com.example.ksp.modules.system.tag.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.tag.dto.TagCreateDTO;
import com.example.ksp.modules.system.tag.dto.TagQueryDTO;
import com.example.ksp.modules.system.tag.dto.TagUpdateDTO;
import com.example.ksp.modules.system.tag.entity.Tag;
import com.example.ksp.modules.system.tag.mapper.TagMapper;
import com.example.ksp.modules.system.tag.service.TagService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

    @Override
    public Resp<Tag> createTag(TagCreateDTO createDTO) {
        // 检查标签名是否已存在（包括已逻辑删除的标签）
        LambdaQueryWrapper<Tag> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Tag::getTagName, createDTO.getTagName());
        Tag existingTag = getOne(wrapper);
        
        if (existingTag != null) {
            if (existingTag.getIsDeleted() == 1) {
                // 如果标签已被逻辑删除，则恢复该标签
                existingTag.setTagDescription(createDTO.getTagDescription());
                existingTag.setSectionId(createDTO.getSectionId());
                existingTag.setUpdateTime(LocalDateTime.now());
                existingTag.setIsDeleted(0);
                updateById(existingTag);
                return Resp.success(existingTag);
            } else {
                // 如果标签存在且未删除，则返回错误
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签名已存在");
            }
        }

        // 创建新标签
        Tag tag = new Tag();
        tag.setTagName(createDTO.getTagName());
        tag.setTagDescription(createDTO.getTagDescription());
        tag.setSectionId(createDTO.getSectionId());
        tag.setCreationTime(LocalDateTime.now());
        tag.setUpdateTime(LocalDateTime.now());
        tag.setIsDeleted(0);

        save(tag);
        return Resp.success(tag);
    }

    @Override
    public Resp<Tag> updateTag(TagUpdateDTO updateDTO) {
        Tag tag = getById(updateDTO.getId());
        if (tag == null || tag.getIsDeleted() == 1) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签不存在");
        }

        // 如果修改了标签名，检查新标签名是否已存在
        if (StringUtils.isNotBlank(updateDTO.getTagName()) 
                && !updateDTO.getTagName().equals(tag.getTagName())) {
            LambdaQueryWrapper<Tag> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Tag::getTagName, updateDTO.getTagName())
                    .eq(Tag::getIsDeleted, 0);
            if (count(wrapper) > 0) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签名已存在");
            }
            tag.setTagName(updateDTO.getTagName());
        }

        if (StringUtils.isNotBlank(updateDTO.getTagDescription())) {
            tag.setTagDescription(updateDTO.getTagDescription());
        }
        if (updateDTO.getSectionId() != null) {
            tag.setSectionId(updateDTO.getSectionId());
        }
        tag.setUpdateTime(LocalDateTime.now());

        updateById(tag);
        return Resp.success(tag);
    }

    @Override
    public Resp<String> deleteTag(Long id) {
        // 先检查标签是否存在且未被删除
        Tag tag = getById(id);
        if (tag == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签不存在");
        }
        
        if (tag.getIsDeleted() == 1) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签已被删除");
        }

        // 执行逻辑删除
        tag.setIsDeleted(1);
        tag.setUpdateTime(LocalDateTime.now());
        updateById(tag);
        return Resp.success("删除成功");
    }

    @Override
    public Resp<Tag> getTag(Long id) {
        Tag tag = getById(id);
        if (tag == null || tag.getIsDeleted() == 1) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "标签不存在");
        }
        return Resp.success(tag);
    }

    @Override
    public Resp<Page<Tag>> queryTags(TagQueryDTO queryDTO) {
        LambdaQueryWrapper<Tag> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Tag::getIsDeleted, 0)
                .eq(queryDTO.getSectionId() != null, Tag::getSectionId, queryDTO.getSectionId())
                .and(StringUtils.isNotBlank(queryDTO.getKeyword()), w -> w
                        .like(Tag::getTagName, queryDTO.getKeyword())
                        .or()
                        .like(Tag::getTagDescription, queryDTO.getKeyword()))
                .orderByDesc(Tag::getUpdateTime);

        Page<Tag> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        page(page, wrapper);
        return Resp.success(page);
    }

    @Override
    public Resp<List<Tag>> getTagsBySection(Long sectionId) {
        LambdaQueryWrapper<Tag> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Tag::getSectionId, sectionId)
                .eq(Tag::getIsDeleted, 0)
                .orderByDesc(Tag::getUpdateTime);

        return Resp.success(list(wrapper));
    }
} 