package com.example.ksp.modules.system.statistics.impl;

import com.example.ksp.modules.system.statistics.StatisticsRequest;
import com.example.ksp.modules.system.statistics.dto.StatisticsResponse;
import com.example.ksp.modules.system.statistics.dto.StatisticsService;
import com.example.ksp.modules.system.statistics.mapper.StatisticsMapper;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import lombok.RequiredArgsConstructor;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class StatisticsServiceImpl implements StatisticsService {

    private final StatisticsMapper statisticsMapper;

    /**
     * 字段映射到对应的表名和时间字段
     */
    private static final Map<String, TableTimeField> FIELD_MAP = new HashMap<>();

    static {
        FIELD_MAP.put("user", new TableTimeField("user", "registration_time"));
        FIELD_MAP.put("view", new TableTimeField("view", "view_time"));
        FIELD_MAP.put("comment", new TableTimeField("comment", "creation_time"));
        FIELD_MAP.put("collection", new TableTimeField("collection", "creation_time"));
        FIELD_MAP.put("section", new TableTimeField("section", "creation_time"));
        FIELD_MAP.put("tag", new TableTimeField("tag", "creation_time"));
        FIELD_MAP.put("like", new TableTimeField("like", "like_time"));
        FIELD_MAP.put("share", new TableTimeField("share", "share_time"));
        FIELD_MAP.put("favorite", new TableTimeField("favorite", "favorite_time"));
        FIELD_MAP.put("citation", new TableTimeField("citation", "citation_time"));
    }

    @Override
    public StatisticsResponse getStatistics(StatisticsRequest request) {
        String field = request.getField().toLowerCase();
        String timeScale = request.getTimeScale().toUpperCase();

        // 获取对应的表名和时间字段
        TableTimeField tableTimeField = FIELD_MAP.get(field);
        if (tableTimeField == null) {
            throw new IllegalArgumentException("无效的字段: " + field);
        }

        String tableName = tableTimeField.getTableName();
        String timeField = tableTimeField.getTimeField();

        // 计算时间范围
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startTime;
        switch (timeScale) {
            case "DAY":
                startTime = now.minusDays(1);
                break;
            case "WEEK":
                startTime = now.minusWeeks(1);
                break;
            case "MONTH":
                startTime = now.minusMonths(1);
                break;
            case "YEAR":
                startTime = now.minusYears(1);
                break;
            default:
                throw new IllegalArgumentException("无效的时间尺度: " + timeScale);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String startTimeStr = startTime.format(formatter);

        // 查询总数量
        Long totalCount = statisticsMapper.countTotal(tableName);

        // 查询增量数量
        Long incrementalCount = statisticsMapper.countIncrement(tableName, timeField, startTimeStr);

        return new StatisticsResponse(totalCount, incrementalCount);
    }

    /**
     * 内部类用于映射表名和时间字段
     */
    private static class TableTimeField {
        private final String tableName;
        private final String timeField;

        public TableTimeField(String tableName, String timeField) {
            this.tableName = tableName;
            this.timeField = timeField;
        }

        public String getTableName() {
            return tableName;
        }

        public String getTimeField() {
            return timeField;
        }
    }
}
