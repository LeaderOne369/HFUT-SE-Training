package com.example.ksp.modules.client.section;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.proxy.SectionServiceProxy;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.post.entity.Post;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@Tag(name = "客户端分区接口")
@RestController("clientSectionController")
@RequestMapping("/api/client/section")
public class SectionController {

    @Autowired
    private SectionServiceProxy sectionServiceProxy;

    @Resource
    private PostServiceProxy postServiceProxy;

    /**
     * 获取所有分区
     */
    @Operation(summary = "获取所有分区")
    @GetMapping("/all")
    public Resp<List<Section>> getAllSections() {
        return sectionServiceProxy.getAllSections();
    }

    /**
     * 获取分区下的所有标签
     */
    @Operation(summary = "获取分区下的所有标签")
    @GetMapping("/{sectionId}/tags")
    public Resp<List<com.example.ksp.modules.system.tag.entity.Tag>> getTagsBySectionId(@PathVariable Long sectionId) {
        return sectionServiceProxy.getTagsBySection(sectionId);
    }

    /**
     * 获取分区或标签下的所有帖子
     */
    @Operation(summary = "获取分区或标签下的所有帖子")
    @GetMapping("/{sectionId}/posts")
    public Resp<Page<Post>> getPostsBySectionOrTag(
            @PathVariable Long sectionId,
            @RequestParam(required = false) Long tagId,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {

        if(tagId != null) {
            return Resp.success(sectionServiceProxy.getPostsBySectionOrTag(sectionId, tagId, current, size).getData());
        }
        Page<Post> posts = postServiceProxy.getPostsBySection(sectionId, current, size);
        return Resp.success(posts);
    }


//    /**
//     * 获取指定分区下的所有帖子
//     *
//     * @param sectionId 分区ID
//     * @param current 当前页
//     * @param size 每页显示的帖子数量
//     * @return 分区下的帖子列表
//     */
//    @GetMapping("/{sectionId}/posts")
//    public Resp<Page<Post>> getPostsBySection(@PathVariable("sectionId") Long sectionId,
//                                              @RequestParam("current") long current,
//                                              @RequestParam("size") long size) {
//        return postService.getPostsBySection(sectionId, current, size);
//    }

    /**
     * 按分区和关键字搜索帖子，支持分页和排序
     */
    @Operation(summary = "按分区和关键字搜索帖子")
    @GetMapping("/{sectionId}/posts/search")
    public Resp<Page<Post>> searchPostsBySection(
            @PathVariable Long sectionId,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size,
            @RequestParam(defaultValue = "creation_time") String sortBy) {
        Page<Post> posts = sectionServiceProxy.searchPostsBySection(sectionId, keyword, current, size, sortBy).getData();
        return Resp.success(posts);
    }
}
