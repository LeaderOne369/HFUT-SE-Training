package com.example.ksp.modules.system.collection.collection.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建合集请求参数")
public class CollectionCreateDTO {
    
    @NotBlank(message = "合集名称不能为空")
    @Schema(description = "合集名称")
    private String collectionName;
    
    @Schema(description = "合集描述")
    private String collectionDescription;
    
    @NotNull(message = "创建者ID不能为空")
    @Schema(description = "创建者ID")
    private Long creatorId;
    
    @NotNull(message = "可见性不能为空")
    @Schema(description = "可见性(0:私密 1:公开)")
    private Integer visibility;
} 