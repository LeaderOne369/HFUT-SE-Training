package com.example.ksp.modules.admin.management.commentmg.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.commentmg.dto.AdminCommentDTO;
import com.example.ksp.modules.admin.management.commentmg.service.CommentManagementService;
import com.example.ksp.modules.proxy.CommentServiceProxy;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.proxy.CollectionServiceProxy;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CommentManagementServiceImpl implements CommentManagementService {

    private final CommentServiceProxy commentServiceProxy;
    private final UserServiceProxy userServiceProxy;
    private final PostServiceProxy postServiceProxy;
    private final CollectionServiceProxy collectionServiceProxy;

    @Override
    public Resp<Page<AdminCommentDTO>> getCommentList(long current, long size, String keyword,
            Integer commentableType, String startTime, String endTime, Integer status) {
        try {
            // 参数校验
            if (current < 1 || size < 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的分页参数");
            }

            // 构建查询条件
            CommentQueryDTO queryDTO = new CommentQueryDTO();
            queryDTO.setCurrent(current);
            queryDTO.setSize(size);
            queryDTO.setCommentableType(commentableType);
            queryDTO.setReviewStatus(status);
            queryDTO.setKeyword(keyword);

            // 设置时间范围
            if (StringUtils.hasText(startTime)) {
                queryDTO.setStartTime(LocalDateTime.parse(startTime, DateTimeFormatter.ISO_DATE_TIME));
            }
            if (StringUtils.hasText(endTime)) {
                queryDTO.setEndTime(LocalDateTime.parse(endTime, DateTimeFormatter.ISO_DATE_TIME));
            }

            // 查询评论列表
            Resp<Page<Comment>> commentsResp = commentServiceProxy.queryComments(queryDTO);
            if (!Objects.equals(commentsResp.getCode(), HttpStatus.OK.getCode()) || commentsResp.getData() == null) {
                return Resp.error(commentsResp.getCode(), commentsResp.getMsg());
            }

            // 获取评论列表
            Page<Comment> commentPage = commentsResp.getData();
            
            // 如果没有数据，直接返回空页
            if (commentPage.getRecords().isEmpty()) {
                return Resp.success(new Page<>(current, size, 0));
            }

            // 收集用户ID
            Set<Long> userIds = commentPage.getRecords().stream()
                    .map(Comment::getCommenterId)
                    .collect(Collectors.toSet());

            // 批量获取用户信息
            Map<Long, User> userMap = userIds.stream()
                    .map(userServiceProxy::getUser)
                    .filter(userResp -> Objects.equals(userResp.getCode(), HttpStatus.OK.getCode()) && userResp.getData() != null)
                    .collect(Collectors.toMap(
                            userResp -> userResp.getData().getId(),
                            Resp::getData
                    ));

            // 转换为DTO
            Page<AdminCommentDTO> resultPage = new Page<>(current, size, commentPage.getTotal());
            resultPage.setRecords(commentPage.getRecords().stream()
                    .map(comment -> convertToDTO(comment, userMap))
                    .collect(Collectors.toList()));

            return Resp.success(resultPage);
        } catch (Exception e) {
            log.error("获取评论列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论列表失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<AdminCommentDTO> getCommentDetail(Long id) {
        if (id == null || id <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }

        try {
            // 获取评论信息
            Resp<Comment> commentResp = commentServiceProxy.getComment(id);
            if (!Objects.equals(commentResp.getCode(), HttpStatus.OK.getCode()) || commentResp.getData() == null) {
                return Resp.error(commentResp.getCode(), commentResp.getMsg());
            }

            Comment comment = commentResp.getData();

            // 获取评论者信息
            Resp<User> userResp = userServiceProxy.getUser(comment.getCommenterId());
            Map<Long, User> userMap = Map.of(
                comment.getCommenterId(),
                    Objects.equals(userResp.getCode(), HttpStatus.OK.getCode()) ? userResp.getData() : null
            );

            return Resp.success(convertToDTO(comment, userMap));
        } catch (Exception e) {
            log.error("获取评论详情失败, commentId: {}", id, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论详情失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updateCommentStatus(Long id, Integer status) {
        // 参数校验
        if (id == null || id <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        if (status == null || (status != 0 && status != 1)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的状态值");
        }

        try {
            // 先查询评论是否存在
            Resp<Comment> commentResp = commentServiceProxy.getComment(id);
            if (!Objects.equals(commentResp.getCode(), HttpStatus.OK.getCode()) || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }

            // 更新状态
            return commentServiceProxy.updateCommentStatus(id, status);
        } catch (Exception e) {
            log.error("更新评论状态失败, commentId: {}, status: {}", id, status, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新评论状态失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> deleteComment(Long id) {
        if (id == null || id <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }

        try {
            Resp<Void> deleteResp = commentServiceProxy.deleteComment(id);
            if (!Objects.equals(deleteResp.getCode(), HttpStatus.OK.getCode())) {
                return Resp.error(deleteResp.getCode(), deleteResp.getMsg());
            }
            return Resp.success("删除成功");
        } catch (Exception e) {
            log.error("删除评论失败, commentId: {}", id, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除评论失败: " + e.getMessage());
        }
    }

    /**
     * 将Comment实体转换为AdminCommentDTO
     */
    private AdminCommentDTO convertToDTO(Comment comment, Map<Long, User> userMap) {
        AdminCommentDTO dto = new AdminCommentDTO();
        BeanUtils.copyProperties(comment, dto);

        // 设置评论者信息
        User commenter = userMap.get(comment.getCommenterId());
        if (commenter != null) {
            dto.setCommenterName(commenter.getUsername());
            dto.setCommenterAvatar(commenter.getAvatar());
        }

        // 设置被评论对象信息
        setCommentableInfo(dto, comment);

        return dto;
    }

    /**
     * 设置被评论对象的信息
     */
    private void setCommentableInfo(AdminCommentDTO dto, Comment comment) {
        if (comment == null || dto == null) {
            return;
        }

        try {
            switch (comment.getCommentableType()) {
                case 1: // 帖子
                    Resp<Post> postResp = postServiceProxy.getPost(comment.getCommentableId());
                    if (Objects.equals(postResp.getCode(), HttpStatus.OK.getCode()) && postResp.getData() != null) {
                        dto.setCommentableTitle(postResp.getData().getTitle());
                    }
                    break;
                case 2: // 合集
                    Resp<?> collectionResp = collectionServiceProxy.getCollection(comment.getCommentableId());
                    if (Objects.equals(collectionResp.getCode(), HttpStatus.OK.getCode()) && collectionResp.getData() != null) {
                        dto.setCommentableTitle(collectionResp.getData().toString());
                    }
                    break;
                case 3: // 评论
                    Resp<Comment> parentCommentResp = commentServiceProxy.getComment(comment.getCommentableId());
                    if (Objects.equals(parentCommentResp.getCode(), HttpStatus.OK.getCode()) && parentCommentResp.getData() != null) {
                        dto.setCommentableTitle(parentCommentResp.getData().getContent());
                    }
                    break;
                default:
                    log.warn("未知的评论类型: {}", comment.getCommentableType());
                    break;
            }
        } catch (Exception e) {
            log.error("设置评论对象信息失败", e);
        }
    }
} 