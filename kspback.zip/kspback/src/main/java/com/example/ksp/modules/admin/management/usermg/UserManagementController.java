package com.example.ksp.modules.admin.management.usermg;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.user.entity.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "管理端用户管理接口")
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/management/usermg")
public class UserManagementController {
    private final UserServiceProxy userService;

    @PostMapping("/create")
    @Operation(summary = "创建用户", description = "根据用户信息创建新用户")
    public Resp<Object> createUser(@RequestBody User user) {
        return userService.createUser(user);
    }

    @DeleteMapping("/delete/{id}")
    @Operation(summary = "删除用户", description = "根据用户ID删除用户")
    public Resp<String> deleteUser(@PathVariable Long id) {

        if(userService.deleteUser(id) == 0) {
            return Resp.error(500, "用户删除失败");
        }
        return Resp.success("用户删除成功");
    }

    @PutMapping("/update")
    @Operation(summary = "更新用户", description = "根据用户信息更新用户")
    public Resp<String> updateUser(@RequestBody long userId, @RequestParam Map<String, Object> updates) {
        // 检查 updates 中至少包含一个字段进行更新
        if (updates.isEmpty()) {
            return Resp.error(400, "没有提供需要更新的字段");
        }

        // 调用 Service 层进行更新
        int result = userService.updateUser(userId, updates);

        if (result == 0) {
            return Resp.error(500, "用户更新失败");
        }

        return Resp.success("用户更新成功");
    }

    @GetMapping("/get/{id}")
    @Operation(summary = "获取用户信息", description = "根据用户ID获取用户信息")
    public Resp<User> getUserById(@PathVariable Long id) {
        User user = userService.getUserById(id);
        if (user == null) {
            return Resp.error(500, "用户不存在");
        }
        return Resp.success(user);
    }

    @GetMapping("/getByUsername/{username}")
    @Operation(summary = "根据用户名获取用户信息", description = "根据用户名获取用户信息")
    public Resp<User> getUserByUsername(@PathVariable String username) {
        User user = userService.getUserByUsername(username);
        if (user == null) {
            return Resp.error(500, "用户不存在");
        }
        return Resp.success(user);
    }

    @GetMapping("/getAll")
    @Operation(summary = "获取所有用户信息", description = "获取所有用户信息")
    public Resp<Page<User>> getAllUsers(@RequestParam(defaultValue = "1") int page,
                                        @RequestParam(defaultValue = "10") int size) {
        Page<User> userPage = userService.getAllUsers(page, size);
        return Resp.success(userPage);
    }

    @GetMapping("/getSortedPage")
    @Operation(summary = "分页获取用户信息，排序字段，模糊查询", description = "根据分页参数获取用户信息")
    public Resp<Page<User>> getSortedUsers(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "id") String orderByColumn,
            @Parameter(description = "asc/desc") @RequestParam(defaultValue = "asc") String sort,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String email) {
        Page<User> page = userService.getUsersByPage(pageNum, pageSize, orderByColumn, sort, username, email);
        return Resp.success(page);
    }


    @Operation(summary = "修改用户冻结状态", description = "根据用户ID修改用户的冻结状态")
    @PutMapping("/{id}/frozen-status")
    public Resp<String> updateFrozenStatus(@PathVariable Long id, @RequestParam Integer isFrozen) {
        boolean result = userService.updateFrozenStatus(id, isFrozen);
        if (result) {
            return Resp.success("用户冻结状态修改成功");
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR,"用户冻结状态修改失败");
        }
    }

    @Operation(summary = "调整用户权限", description = "根据用户ID调整用户的权限等级")
    @PutMapping("/{id}/permission-level")
    public Resp<String> updatePermissionLevel(@PathVariable Long id, @RequestParam Integer permissionLevel) {
        boolean result = userService.updatePermissionLevel(id, permissionLevel);
        if (result) {
            return Resp.success("用户权限调整成功");
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR,"用户权限调整失败");
        }
    }
}
