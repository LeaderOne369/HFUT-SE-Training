package com.example.ksp.modules.system.post.mapper;

import jakarta.annotation.Resource;
import org.apache.ibatis.jdbc.SQL;

import java.util.Map;

@Resource
public class PostSqlProvider {

    // 动态构建更新 SQL 语句
    public String updatePost(Map<String, Object> parameters) {
        Long postId = (Long) parameters.get("postId");
        Map<String, Object> updates = (Map<String, Object>) parameters.get("updates");

        // 开始构建 SQL 语句
        SQL sql = new SQL().UPDATE("`post`");

        // 动态添加更新的字段
        for (Map.Entry<String, Object> entry : updates.entrySet()) {
            sql.SET(entry.getKey() + " = #{updates." + entry.getKey() + "}");
        }

        // 添加 WHERE 条件
        sql.WHERE("id = #{postId}");

        // 返回动态生成的 SQL
        return sql.toString();
    }
}
