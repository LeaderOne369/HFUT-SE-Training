package com.example.ksp.modules.client.homepage.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "用户简要信息视图对象")
public class UserBriefVO {
    
    @Schema(description = "用户ID", example = "1")
    private Long id;
    
    @Schema(description = "用户名", example = "张三")
    private String username;
    
    @Schema(description = "头像URL", example = "http://example.com/avatar.jpg")
    private String avatarUrl;
} 