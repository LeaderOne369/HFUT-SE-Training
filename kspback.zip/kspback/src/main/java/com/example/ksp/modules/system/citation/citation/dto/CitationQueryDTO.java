package com.example.ksp.modules.system.citation.citation.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "引用查询参数")
public class CitationQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "帖子ID")
    private Long postId;
    
    @Schema(description = "引用类型ID")
    private Long citationTypeId;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 