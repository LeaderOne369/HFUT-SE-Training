package com.example.ksp.framework.ai;

import cn.hutool.json.JSONUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class  DSAiClient {

    @Value("sk-c01251a93f994341ae2d4d86237905c9")
    private String apiKey;

    @Value("https://api.deepseek.com")
    private String apiUrl;

    private final OkHttpClient client;
    private static final MediaType JSON = MediaType.parse("application/json");
    private static final String DEFAULT_MODEL = "deepseek-chat";
    private static final int DEFAULT_MAX_TOKENS = 2048;

    public DSAiClient() {
        this.client = new OkHttpClient().newBuilder().build();
    }

    /**
     * 简单对话生成
     */
    public Resp<ChatResponseDTO> chat(String message) {
        List<ChatMessage> messages = new ArrayList<>();
        messages.add(ChatMessage.userMessage(message));
        return chatCompletion(messages, DEFAULT_MODEL);
    }

    /**
     * 携带上下文的对话生成
     */
    public Resp<ChatResponseDTO> chatWithContext(List<ChatMessage> history, String message) {
        List<ChatMessage> messages = new ArrayList<>(history);
        messages.add(ChatMessage.userMessage(message));
        return chatCompletion(messages, DEFAULT_MODEL);
    }

    /**
     * 携带系统提示和上下文的对话生成
     */
    public Resp<ChatResponseDTO> chatWithPrompt(String systemPrompt, List<ChatMessage> history, String message) {
        List<ChatMessage> messages = new ArrayList<>();
        messages.add(ChatMessage.systemMessage(systemPrompt));
        messages.addAll(history);
        messages.add(ChatMessage.userMessage(message));
        return chatCompletion(messages, DEFAULT_MODEL);
    }

    /**
     * 获取可用模型列表
     */
    public Resp<List<String>> listModels() {
        try {
            Request request = new Request.Builder()
                    .url(apiUrl + "/models")
                    .get()
                    .addHeader("Accept", "application/json")
                    .addHeader("Authorization", "Bearer " + apiKey)
                    .build();

            Response response = client.newCall(request).execute();
            if (!response.isSuccessful() || response.body() == null) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取模型列表失败");
            }

            String responseBody = response.body().string();
            ModelListResponseDTO modelList = JSONUtil.toBean(responseBody, ModelListResponseDTO.class);
            
            List<String> modelIds = modelList.getData().stream()
                    .map(ModelListResponseDTO.Model::getId)
                    .toList();
                    
            return Resp.success(modelIds);
        } catch (Exception e) {
            log.error("获取模型列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取模型列表失败: " + e.getMessage());
        }
    }

    /**
     * 核心对话完成方法
     */
    private Resp<ChatResponseDTO> chatCompletion(List<ChatMessage> messages, String model) {
        try {
            ChatRequestDTO request = buildChatRequest(messages, model);
            RequestBody body = RequestBody.create(JSON, JSONUtil.toJsonStr(request));

            Request httpRequest = new Request.Builder()
                    .url(apiUrl + "/chat/completions")
                    .post(body)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json")
                    .addHeader("Authorization", "Bearer " + apiKey)
                    .build();

            Response response = client.newCall(httpRequest).execute();
            if (!response.isSuccessful() || response.body() == null) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI服务调用失败");
            }

            String responseBody = response.body().string();
            ChatResponseDTO chatResponse = JSONUtil.toBean(responseBody, ChatResponseDTO.class);
            return Resp.success(chatResponse);

        } catch (IOException e) {
            log.error("AI对话生成失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI对话生成失败: " + e.getMessage());
        }
    }

    /**
     * 构建对话请求
     */
    private ChatRequestDTO buildChatRequest(List<ChatMessage> messages, String model) {
        List<ChatRequestDTO.Message> requestMessages = messages.stream()
                .map(msg -> ChatRequestDTO.Message.builder()
                        .role(msg.getRole().toString())
                        .content(msg.getContent())
                        .build())
                .toList();

        return ChatRequestDTO.builder()
                .messages(requestMessages)
                .model(model)
                .maxTokens(DEFAULT_MAX_TOKENS)
                .frequencyPenalty(0.0)
                .presencePenalty(0.0)
                .responseFormat(ChatRequestDTO.ResponseFormat.builder()
                        .type("text")
                        .build())
                .stream(false)
                .temperature(1.0)
                .topP(1.0)
                .toolChoice("none")
                .build();
    }

    /**
     * 文本自动补全
     * @param prompt 提示文本
     * @return 补全结果
     */
    public Resp<CompletionResponseDTO> complete(String prompt) {
        return complete(prompt, DEFAULT_MODEL, DEFAULT_MAX_TOKENS);
    }

    /**
     * 文本自动补全（自定义参数）
     * @param prompt 提示文本
     * @param model 模型名称
     * @param maxTokens 最大token数
     * @return 补全结果
     */
    public Resp<CompletionResponseDTO> complete(String prompt, String model, int maxTokens) {
        try {
            CompletionRequestDTO request = CompletionRequestDTO.builder()
                    .model(model)
                    .prompt(prompt)
                    .echo(false)
                    .frequencyPenalty(0.0)
                    .logprobs(0)
                    .maxTokens(maxTokens)
                    .presencePenalty(0.0)
                    .stop(null)
                    .stream(false)
                    .streamOptions(null)
                    .suffix(null)
                    .temperature(1.0)
                    .topP(1.0)
                    .build();

            RequestBody body = RequestBody.create(JSON, JSONUtil.toJsonStr(request));
            Request httpRequest = new Request.Builder()
                    .url(apiUrl + "/beta/completions")
                    .post(body)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Accept", "application/json")
                    .addHeader("Authorization", "Bearer " + apiKey)
                    .build();

            Response response = client.newCall(httpRequest).execute();
            if (!response.isSuccessful() || response.body() == null) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI补全服务调用失败");
            }

            String responseBody = response.body().string();
            CompletionResponseDTO completionResponse = JSONUtil.toBean(responseBody, CompletionResponseDTO.class);
            return Resp.success(completionResponse);

        } catch (Exception e) {
            log.error("AI补全生成失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI补全生成失败: " + e.getMessage());
        }
    }
}
