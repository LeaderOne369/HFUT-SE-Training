package com.example.ksp.modules.client.post.publish.controller;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.publish.dto.PostPublishDTO;
import com.example.ksp.modules.client.post.publish.service.PostPublishService;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.section.entity.Section;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@Tag(name = "客户端帖子发布")
@RestController
@RequestMapping("/api/client/post/publish")
@RequiredArgsConstructor
public class PostPublishController {

    private final PostPublishService postPublishService;
    private final UserServiceProxy userServiceProxy;




    @Operation(summary = "获取所有分区")
    @GetMapping("/sections")
    @PreAuthorize("isAuthenticated()")
    public Resp<List<Section>> getAllSections() {
        return postPublishService.getAllSections();
    }

    @Operation(summary = "获取分区下的标签")
    @GetMapping("/sections/{sectionId}/tags")
    @PreAuthorize("isAuthenticated()")
    public Resp<Object> getTagsBySection(
            @Parameter(description = "分区ID") 
            @PathVariable Long sectionId) {
        return postPublishService.getTagsBySection(sectionId);
    }

    @Operation(summary = "获取用户的合集列表")
    @GetMapping("/collections")
    @PreAuthorize("isAuthenticated()")
    public Resp<Object> getUserCollections(@RequestHeader("token") String token) {
        try {
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(401, "用户不存在");
            }
            return postPublishService.getUserCollections(userIdResp.getData());
        } catch (Exception e) {
            log.error("获取用户合集列表失败", e);
            return Resp.error(401, "无效的token");
        }
    }

    @Operation(summary = "获取所有引用类型")
    @GetMapping("/citation-types")
    @PreAuthorize("isAuthenticated()")
    public Resp<List<CitationType>> getAllCitationTypes() {
        return postPublishService.getAllCitationTypes();
    }



    @Operation(summary = "保存帖子")
    @PostMapping("/save")
    @PreAuthorize("isAuthenticated()")
    public Resp<Long> savePost(
            @RequestBody @Valid PostPublishDTO publishDTO,
            @RequestHeader("token") String token) {
        try {
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(401, "用户不存在");
            }
            return postPublishService.addPost(publishDTO, userIdResp.getData(),0);
        } catch (Exception e) {
            log.error("保存帖子失败", e);
            return Resp.error(401, "无效的token");
        }
    }

    @Operation(summary = "发布帖子")
    @PostMapping("/publish")
    @PreAuthorize("isAuthenticated()")
    public Resp<Long> publishPost(
            @RequestBody @Valid PostPublishDTO publishDTO,
            @RequestHeader("token") String token) {
        try {
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(401, "用户不存在");
            }
            return postPublishService.addPost(publishDTO, userIdResp.getData(),1);
        } catch (Exception e) {
            log.error("保存帖子失败", e);
            return Resp.error(401, "无效的token");
        }
    }



} 