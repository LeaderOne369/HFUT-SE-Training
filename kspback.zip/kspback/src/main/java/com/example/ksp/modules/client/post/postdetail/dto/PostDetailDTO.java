package com.example.ksp.modules.client.post.postdetail.dto;

import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "帖子详细信息")
public class PostDetailDTO {
    
    @Schema(description = "帖子ID")
    private Long postId;
    
    @Schema(description = "标题")
    private String title;
    
    @Schema(description = "作者ID")
    private Long authorId;
    
    @Schema(description = "作者名称")
    private String authorName;
    
    @Schema(description = "作者头像")
    private String authorAvatar;

    @Schema(description = "帖子封面图片的路径或URL")
    private String cover;

    @Schema(description = "帖子内容的简短描述，用于快速预览")
    private String summary;

    @Schema(description = "帖子中引用的其他内容或来源的详细信息")
    private Citation citation;
    
    @Schema(description = "创建时间")
   @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime createTime;
    
    @Schema(description = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime updateTime;
    
    @Schema(description = "统计信息")
    private PostStatsDTO stats;

    @Schema(description = "分区id")
    private Long sectionId;

    @Schema(description = "分区名称")
    private String sectionName;

    @Schema(description = "标签列表")
    private List<String> tags;
    
    @Schema(description = "所属合集ID")
    private Long collectionId;
    
    @Schema(description = "所属合集名称")
    private String collectionName;
    
    @Schema(description = "是否已订阅合集")
    private Boolean isCollectionSubscribed;
    
    @Schema(description = "富文本内容文件")
    private MultipartFile content;

    @Schema(description = "帖子内容文件ID")
    private String contentFileId;
    
    @Schema(description = "帖子内容文件路径")
    private String contentFilePath;
} 