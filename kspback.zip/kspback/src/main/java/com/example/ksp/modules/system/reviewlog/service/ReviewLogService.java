package com.example.ksp.modules.system.reviewlog.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;

public interface ReviewLogService extends IService<ReviewLog> {
    
    /**
     * 创建审核记录
     */
    boolean createReviewLog(ReviewLog reviewLog);

    /**
     * 更新审核状态
     */
    boolean updateReviewStatus(Long id, Integer status, String notes);

    /**
     * 获取内容的审核记录
     */
    Page<ReviewLog> getContentReviews(Long contentId, Integer contentType, long current, long size);

    /**
     * 获取审核人的审核记录
     */
    Page<ReviewLog> getReviewerLogs(Long reviewerId, Integer status, long current, long size);

    /**
     * 获取待审核列表
     */
    Page<ReviewLog> getPendingReviews(Integer contentType, long current, long size);

    /**
     * 批量审核
     */
    boolean batchReview(Long[] ids, Integer status, String notes);
} 