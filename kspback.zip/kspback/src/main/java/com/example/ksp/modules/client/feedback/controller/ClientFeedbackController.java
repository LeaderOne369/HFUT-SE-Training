package com.example.ksp.modules.client.feedback.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.feedback.dto.FeedbackDTO;
import com.example.ksp.modules.client.feedback.service.ClientFeedbackService;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "客户端反馈接口")
@RestController
@RequestMapping("/api/client/feedback")
@RequiredArgsConstructor
public class ClientFeedbackController {

    private final ClientFeedbackService clientFeedbackService;

    @Operation(summary = "提交反馈")
    @PostMapping("/submit")
    public Resp<Boolean> submitFeedback(@RequestHeader("token") String token,
                                        @RequestBody @Valid FeedbackDTO feedbackDTO) {
        return clientFeedbackService.submitFeedback(token,feedbackDTO);
    }

    @Operation(summary = "获取用户反馈列表")
    @GetMapping("/user/{userId}")
    public Resp<List<Feedback>> getUserFeedbacks(
            @Parameter(description = "用户ID", required = true)
            @PathVariable Long userId) {
        return clientFeedbackService.getUserFeedbacks(userId);
    }

    @Operation(summary = "删除反馈")
    @DeleteMapping("/{id}")
    public Resp<Boolean> deleteFeedback(
            @Parameter(description = "反馈ID", required = true)
            @PathVariable Long id) {
        return clientFeedbackService.deleteFeedback(id);
    }
} 