package com.example.ksp.modules.client.post.postdetail.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "帖子统计信息")
public class PostStatsDTO {
    
    @Schema(description = "帖子ID")
    private Long postId;
    
    @Schema(description = "浏览数")
    private Integer viewCount;
    
    @Schema(description = "点赞数")
    private Integer likeCount;
    
    @Schema(description = "评论数")
    private Integer commentCount;
    
    @Schema(description = "分享数")
    private Integer shareCount;
    
    @Schema(description = "收藏数")
    private Integer favoriteCount;
    
    @Schema(description = "当前用户是否点赞")
    private Boolean isLiked;
    
    @Schema(description = "当前用户是否收藏")
    private Boolean isFavorited;
    
    @Schema(description = "当前用户是否分享")
    private Boolean isShared;
} 