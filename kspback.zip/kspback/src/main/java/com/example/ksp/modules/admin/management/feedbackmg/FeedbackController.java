package com.example.ksp.modules.admin.management.feedbackmg;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.FeedbackServiceProxy;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Feedback 控制器
 */
@Tag(name = "管理端反馈管理接口")
@RestController("AdminFeedbackController")
@RequestMapping("/api/admin/management/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackServiceProxy feedbackService;




    /**
     * 更新反馈状态
     */
    @Operation(summary = "更新反馈状态")
    @PutMapping("/updateStatus")
    public Resp<Boolean> updateStatus(@RequestParam Long id, @RequestParam Integer status) {
        boolean result = feedbackService.updateStatus(id, status);
        return result ? Resp.success(true) : Resp.error(500, "更新反馈状态失败");
    }

    /**
     * 删除反馈
     */
    @Operation(summary = "删除反馈")
    @DeleteMapping("/delete")
    public Resp<Boolean> deleteFeedback(@RequestParam Long id) {
        boolean result = feedbackService.deleteFeedback(id);
        return result ? Resp.success(true) : Resp.error(500, "删除反馈失败");
    }

    /**
     * 获取用户的反馈列表
     */
    @Operation(summary = "获取用户的反馈列表")
    @GetMapping("/userFeedbacks")
    public Resp<Page<Feedback>> getUserFeedbacks(
            @RequestParam Long userId,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {
        Page<Feedback> feedbackPage = feedbackService.getUserFeedbacks(userId, status, current, size);
        return Resp.success(feedbackPage);
    }

    /**
     * 获取所有反馈列表（管理员使用）
     */
    @Operation(summary = "获取所有反馈列表")
    @GetMapping("/allFeedbacks")
    public Resp<Page<Feedback>> getAllFeedbacks(
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {
        Page<Feedback> feedbackPage = feedbackService.getAllFeedbacks(status, current, size);
        return Resp.success(feedbackPage);
    }

    /**
     * 按条件分页查询反馈记录
     *
     * @param userId          用户ID（可选）
     * @param feedbackContent 反馈内容关键字（可选）
     * @param status          反馈状态（可选）
     * @param startTime       反馈提交的开始时间（格式：yyyy-MM-dd'T'HH:mm:ss，可选）
     * @param endTime         反馈提交的结束时间（格式：yyyy-MM-dd'T'HH:mm:ss，可选）
     * @param page            当前页码（默认1）
     * @param size            每页记录数（默认10）
     * @return 分页的反馈记录
     */
    @Operation(summary = "按条件分页查询反馈记录")
    @GetMapping("/query")
    public Resp<Page<Feedback>> queryFeedbacks(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) String feedbackContent,
            @RequestParam(required = false) Integer status,
            @RequestParam(required = false) String startTime, // ISO_LOCAL_DATE_TIME 格式
            @RequestParam(required = false) String endTime,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        // 解析时间参数
        LocalDateTime start = null;
        LocalDateTime end = null;
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
        try {
            if (startTime != null && !startTime.trim().isEmpty()) {
                start = LocalDateTime.parse(startTime, formatter);
            }
            if (endTime != null && !endTime.trim().isEmpty()) {
                end = LocalDateTime.parse(endTime, formatter);
            }
        } catch (Exception e) {
            return Resp.error(400, "时间格式错误，请使用 yyyy-MM-dd'T'HH:mm:ss 格式");
        }

        // 调用服务层查询
        Page<Feedback> feedbackPage = feedbackService.queryFeedbacks(userId, feedbackContent, status, start, end, page, size);

        // 返回响应
        return Resp.success(feedbackPage);
    }
}
