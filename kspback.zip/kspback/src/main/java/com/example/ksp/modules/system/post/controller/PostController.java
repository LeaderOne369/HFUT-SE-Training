package com.example.ksp.modules.system.post.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.dto.PostCreateDTO;
import com.example.ksp.modules.system.post.dto.PostQueryDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.service.PostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级帖子管理接口")
@RestController
@RequestMapping("/api/system/post")
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    @Operation(summary = "创建帖子")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Post> createPost(@RequestBody @Valid PostCreateDTO createDTO) {
        return postService.createPost(createDTO);
    }

    @Operation(summary = "更新帖子")
    @PutMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Post> updatePost(@RequestBody @Valid PostUpdateDTO updateDTO) {
        return postService.updatePost(updateDTO);
    }

    @Operation(summary = "删除帖子")
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> deletePost(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id) {
        return postService.deletePost(id);
    }

    @Operation(summary = "获取帖子详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<Post> getPost(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id) {
        return postService.getPost(id);
    }

    @Operation(summary = "分页查询帖子")
    @GetMapping("/list")
    @PreAuthorize("isAuthenticated()")
    public Resp<Page<Post>> queryPosts(@Valid PostQueryDTO queryDTO) {
        return postService.queryPosts(queryDTO);
    }

    @Operation(summary = "更新帖子状态")
    @PutMapping("/{id}/status/{status}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> updateStatus(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id,
            @Parameter(description = "状态(1:已发布,0:草稿)") 
            @PathVariable Integer status) {
        return postService.updateStatus(id, status);
    }

    @Operation(summary = "更新帖子审核状态")
    @PutMapping("/{id}/review/{reviewStatus}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> updateReviewStatus(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id,
            @Parameter(description = "审核状态(0:待审核,1:已通过,2:已拒绝)") 
            @PathVariable Integer reviewStatus) {
        return postService.updateReviewStatus(id, reviewStatus);
    }

    @Operation(summary = "设置/取消置顶")
    @PutMapping("/{id}/pinned/{isPinned}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> updatePinned(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id,
            @Parameter(description = "是否置顶(1:是,0:否)") 
            @PathVariable Integer isPinned) {
        return postService.updatePinned(id, isPinned);
    }

    @Operation(summary = "设置/取消精华")
    @PutMapping("/{id}/essence/{isEssence}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> updateEssence(
            @Parameter(description = "帖子ID") 
            @PathVariable Long id,
            @Parameter(description = "是否精华(1:是,0:否)") 
            @PathVariable Integer isEssence) {
        return postService.updateEssence(id, isEssence);
    }
} 