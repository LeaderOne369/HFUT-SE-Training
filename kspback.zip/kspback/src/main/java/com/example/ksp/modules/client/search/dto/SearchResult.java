package com.example.ksp.modules.client.search.dto;

import lombok.Data;

import java.util.List;

@Data
public class SearchResult<T> {
    private long total;                      // 总记录数
    private List<SearchHit<T>> hits;        // 搜索结果列表
} 