package com.example.ksp.modules.system.report.reporttype.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeCreateDTO;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeUpdateDTO;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import com.example.ksp.modules.system.report.reporttype.service.ReportTypeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级举报类型管理")
@RestController
@RequestMapping("/api/system/report-type")
@RequiredArgsConstructor
public class ReportTypeController {

    private final ReportTypeService reportTypeService;

    @Operation(summary = "创建举报类型")
    @PostMapping
    @PreAuthorize("hasAuthority('admin')")
    public Resp<ReportType> createReportType(
            @RequestBody @Valid ReportTypeCreateDTO createDTO) {
        return reportTypeService.createReportType(createDTO);
    }

    @Operation(summary = "更新举报类型")
    @PutMapping
    @PreAuthorize("hasAuthority('admin')")
    public Resp<ReportType> updateReportType(
            @RequestBody @Valid ReportTypeUpdateDTO updateDTO) {
        return reportTypeService.updateReportType(updateDTO);
    }

    @Operation(summary = "删除举报类型")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('admin')")
    public Resp<Void> deleteReportType(
            @Parameter(description = "举报类型ID") 
            @PathVariable Long id) {
        return reportTypeService.deleteReportType(id);
    }

    @Operation(summary = "获取举报类型详情")
    @GetMapping("/{id}")
    public Resp<ReportType> getReportType(
            @Parameter(description = "举报类型ID") 
            @PathVariable Long id) {
        return reportTypeService.getReportType(id);
    }

    @Operation(summary = "获取举报类型列表")
    @GetMapping("/list")
    public Resp<Page<ReportType>> listReportTypes(
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size,
            @Parameter(description = "举报类型名称") 
            @RequestParam(required = false) String typeName,
            @Parameter(description = "是否启用") 
            @RequestParam(required = false) Integer isActive) {
        return reportTypeService.listReportTypes(new Page<>(current, size), typeName, isActive);
    }
} 