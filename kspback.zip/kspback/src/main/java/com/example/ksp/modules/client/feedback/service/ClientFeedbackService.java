package com.example.ksp.modules.client.feedback.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.feedback.dto.FeedbackDTO;
import com.example.ksp.modules.system.feedback.entity.Feedback;

import java.util.List;

public interface ClientFeedbackService {
    /**
     * 提交反馈
     */
    Resp<Boolean> submitFeedback(String token, FeedbackDTO feedbackDTO);
    
    /**
     * 获取用户反馈列表
     */
    Resp<List<Feedback>> getUserFeedbacks(Long userId);
    
    /**
     * 删除反馈
     */
    Resp<Boolean> deleteFeedback(Long id);
} 