package com.example.ksp.modules.system.report.reportedtype.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建举报对象类型请求参数")
public class ReportedTypeCreateDTO {
    
    @NotBlank(message = "举报对象类型名称不能为空")
    @Schema(description = "举报对象类型名称")
    private String typeName;
    
    @NotBlank(message = "举报对象类型描述不能为空")
    @Schema(description = "举报对象类型描述")
    private String typeDescription;
    
    @NotNull(message = "是否启用不能为空")
    @Schema(description = "是否启用(1:启用 0:未启用)")
    private Integer isActive;
} 