package com.example.ksp.modules.system.post.dto;

import lombok.Data;

@Data
public class PostQueryDTO {
    private Long userId;
    private Long sectionId;
    private String tags;
    private Long collectionId;
    private String keyword;
    private Integer status;
    private Integer visibility;
    private Integer reviewStatus;
    private String startTime;
    private String endTime;
    private Integer pageNum = 1;
    private Integer pageSize = 10;
} 