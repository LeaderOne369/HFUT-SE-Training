package com.example.ksp.modules.system.feedback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FeedbackMapper extends BaseMapper<Feedback> {
} 