package com.example.ksp.common.handler.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContentFileDTO {
    @Schema(description = "文件ID")
    private String fileId;
    
    @Schema(description = "文件URL")
    private String fileUrl;
    
    @Schema(description = "文件路径")
    private String filePath;
} 