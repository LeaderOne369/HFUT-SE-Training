package com.example.ksp.modules.client.homepage.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "分区视图对象")
public class SectionVO {

    @Schema(description = "主键ID")
    private Long id;

    @Schema(description = "分区名称")
    private String sectionName;

    @Schema(description = "分区描述")
    private String sectionDescription;
} 