package com.example.ksp.modules.client.homepage.dto;

import lombok.Data;

@Data
public class HomePageQueryDTO {
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 每页显示数量
     */
    private Integer pageSize = 10;
    
    /**
     * 当前页码
     */
    private Integer page = 1;
    
    /**
     * 推荐内容类型（可选）
     * 1: 最新内容
     * 2: 热门内容
     * 3: 关注内容
     */
    private Integer recommendType;
} 