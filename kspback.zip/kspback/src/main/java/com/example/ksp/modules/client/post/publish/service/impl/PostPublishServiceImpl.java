package com.example.ksp.modules.client.post.publish.service.impl;

import cn.hutool.json.JSONUtil;
import com.example.ksp.common.utils.MinioUtil;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.publish.dto.PostPublishDTO;
import com.example.ksp.modules.client.post.publish.mapper.PostPublishMapper;
import com.example.ksp.modules.client.post.publish.service.PostPublishService;

import com.example.ksp.modules.proxy.CitationServiceProxy;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.system.citation.citation.dto.CitationCreateDTO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.post.dto.PostCreateDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.tag.entity.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PostPublishServiceImpl implements PostPublishService {

    private final PostServiceProxy postServiceProxy;
    private final CitationServiceProxy citationServiceProxy;
    private final PostPublishMapper postPublishMapper;
    public static final String COVER_BUCKET = "post-covers";
    private  final MinioUtil minioUtil;

    @Override
    public Resp<List<Section>> getAllSections() {
        log.info("获取所有分区");
        try {
            List<Section> sections = postPublishMapper.getAllSections();
            return Resp.success(sections);
        } catch (Exception e) {
            log.error("获取分区列表失败", e);
            return Resp.error(500, "获取分区列表失败");
        }
    }

    @Override
    public Resp<Object> getTagsBySection(Long sectionId) {
        log.info("获取分区下的标签, sectionId: {}", sectionId);
        if (sectionId == null || sectionId <= 0) {
            return Resp.error(400, "无效的分区ID");
        }
        try {
            List<Tag> tags = postPublishMapper.getTagsBySection(sectionId);
            return Resp.success(tags);
        } catch (Exception e) {
            log.error("获取标签列表失败", e);
            return Resp.error(500, "获取标签列表失败");
        }
    }

    @Override
    public Resp<Object> getUserCollections(Long userId) {
        log.info("获取用户的合集列表, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            List<Collection> collections = postPublishMapper.getUserCollections(userId);
            return Resp.success(collections);
        } catch (Exception e) {
            log.error("获取用户合集列表失败", e);
            return Resp.error(500, "获取合集列表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Long> addPost(PostPublishDTO publishDTO, Long userId,Integer status) {
        log.info("保存帖子, userId: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        
        // 参数校验
        if (StringUtils.isBlank(publishDTO.getTitle())) {
            return Resp.error(400, "标题不能为空");
        }
        if (publishDTO.getContentFileId() == null) {
            return Resp.error(400, "内容不能为空");
        }
        if (publishDTO.getSectionId() == null || publishDTO.getSectionId() <= 0) {
            return Resp.error(400, "请选择分区");
        }
        if (StringUtils.isBlank(publishDTO.getTags())) {
            return Resp.error(400, "请选择标签");
        }

        try {
            // 构建PostCreateDTO
            PostCreateDTO createDTO = new PostCreateDTO();
            createDTO.setTitle(publishDTO.getTitle());
            createDTO.setContentFileId(publishDTO.getContentFileId());
            createDTO.setContentFilePath(publishDTO.getContentFilePath());
            createDTO.setSectionId(publishDTO.getSectionId());
            createDTO.setTags(publishDTO.getTags());
            createDTO.setCollectionId(publishDTO.getCollectionId());
            createDTO.setUserId(userId);
            createDTO.setCover(publishDTO.getCover());
            createDTO.setContentFileId(publishDTO.getContentFileId());
            createDTO.setContentFilePath(publishDTO.getContentFilePath());
            createDTO.setSummary(publishDTO.getSummary());
            createDTO.setVisibility(publishDTO.getVisibility());
            createDTO.setStatus(status);
            
            // 保存帖子
            Resp<Post> postResp = postServiceProxy.createPost(createDTO);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                // 如果保存失败且已上传封面，删除封面文件
                if (createDTO.getCover() != null) {
                    try {
                        String coverFileName = extractObjectNameFromUrl(createDTO.getCover());
                        minioUtil.deleteFile(COVER_BUCKET, coverFileName);
                    } catch (Exception e) {
                        log.warn("删除失败的封面文件失败", e);
                    }
                }
                return Resp.error(postResp.getCode(), postResp.getMsg());
            }
            // 处理引用信息
            if( publishDTO.getCitation() != null) {
                CitationCreateDTO citationDTO = new CitationCreateDTO();
                citationDTO.setCitationContent(publishDTO.getCitation().getCitationContent());
                citationDTO.setCitationTypeId(publishDTO.getCitation().getCitationTypeId());
                citationDTO.setPostId(postResp.getData().getId());
                citationDTO.setSource(publishDTO.getCitation().getSource());
                Resp<Citation> citationResp = citationServiceProxy.createCitation(citationDTO);
                if (citationResp.getCode() != 200 || citationResp.getData() == null) {
                    // 如果保存失败且已上传封面，删除封面文件
                    if (createDTO.getCover() != null) {
                        try {
                            String coverFileName = extractObjectNameFromUrl(createDTO.getCover());
                            minioUtil.deleteFile(COVER_BUCKET, coverFileName);
                        } catch (Exception e){
                            log.warn("删除失败的封面文件失败", e);
                        }
                    }
                    return Resp.error(citationResp.getCode(), citationResp.getMsg());
                }
                postResp.getData().setCitation(JSONUtil.toJsonStr(citationResp.getData()));
                postServiceProxy.updatePost(postResp.getData());
            }


            return Resp.success("帖子保存成功",postResp.getData().getId());
        } catch (Exception e) {
            log.error("保存帖子失败", e);
            return Resp.error(500, "保存帖子失败：" + e.getMessage());
        }
    }

    /**
     * 从文件名中获取扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null) return ".jpg";
        int lastDotIndex = filename.lastIndexOf(".");
        return lastDotIndex == -1 ? ".jpg" : filename.substring(lastDotIndex);
    }

    /**
     * 从URL中提取对象名称
     */
    private String extractObjectNameFromUrl(String url) {
        if (url == null || url.isEmpty()) {
            return null;
        }
        String[] parts = url.split("/");
        if (parts.length < 2) {
            return null;
        }
        return parts[parts.length - 1];
    }

    @Override
    public Resp<List<CitationType>> getAllCitationTypes() {
        log.info("获取所有引用类型");
        try {
            List<CitationType> types = postPublishMapper.getAllCitationTypes();
            return Resp.success(types);
        } catch (Exception e) {
            log.error("获取引用类型列表失败", e);
            return Resp.error(500, "获取引用类型列表失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Post> updatePost(Long postId, PostPublishDTO updateDTO, Long currentUserId, int status) {
        log.info("更新帖子,用户id:{}", currentUserId);
        // 参数校验
        if (StringUtils.isBlank(updateDTO.getTitle())) {
            return Resp.error(400, "标题不能为空");
        }
        if (updateDTO.getContentFileId() == null) {
            return Resp.error(400, "内容不能为空");
        }
        if (updateDTO.getSectionId() == null || updateDTO.getSectionId() <= 0) {
            return Resp.error(400, "请选择分区");
        }
        if (StringUtils.isBlank(updateDTO.getTags())) {
            return Resp.error(400, "请选择标签");
        }

        try {
            // 构建PostCreateDTO
            PostUpdateDTO createDTO = new PostUpdateDTO();
            createDTO.setId(postId);
            createDTO.setTitle(updateDTO.getTitle());
            createDTO.setContentFileId(updateDTO.getContentFileId());
            createDTO.setContentFilePath(updateDTO.getContentFilePath());
            createDTO.setSectionId(updateDTO.getSectionId());
            createDTO.setTags(updateDTO.getTags());
            createDTO.setCollectionId(updateDTO.getCollectionId());
            createDTO.setCover(updateDTO.getCover());
            createDTO.setContentFileId(updateDTO.getContentFileId());
            createDTO.setContentFilePath(updateDTO.getContentFilePath());
            createDTO.setStatus(status);
            createDTO.setSummary(updateDTO.getSummary());
            createDTO.setVisibility(updateDTO.getVisibility());

            Resp<Post> postResp = postServiceProxy.updatePost(createDTO);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                // 如果保存失败且已上传封面，删除封面文件
                if (createDTO.getCover() != null) {
                    try {
                        String coverFileName = extractObjectNameFromUrl(createDTO.getCover());
                        minioUtil.deleteFile(COVER_BUCKET, coverFileName);
                    } catch (Exception e) {
                        log.warn("删除失败的封面文件失败", e);
                    }
                }
                return Resp.error(postResp.getCode(), postResp.getMsg());
            }


            // 处理引用信息
            if( updateDTO.getCitation() != null) {
                CitationCreateDTO citationDTO = new CitationCreateDTO();
                citationDTO.setCitationContent(updateDTO.getCitation().getCitationContent());
                citationDTO.setCitationTypeId(updateDTO.getCitation().getCitationTypeId());
                citationDTO.setPostId(postResp.getData().getId());
                citationDTO.setSource(updateDTO.getCitation().getSource());
                Resp<Citation> citationResp = citationServiceProxy.createCitation(citationDTO);
                if (citationResp.getCode() != 200 || citationResp.getData() == null) {
                    // 如果保存失败且已上传封面，删除封面文件
                    if (createDTO.getCover() != null) {
                        try {
                            String coverFileName = extractObjectNameFromUrl(createDTO.getCover());
                            minioUtil.deleteFile(COVER_BUCKET, coverFileName);
                        } catch (Exception e){
                            log.warn("删除失败的封面文件失败", e);
                        }
                    }
                    return Resp.error(citationResp.getCode(), citationResp.getMsg());
                }
                postResp.getData().setCitation(JSONUtil.toJsonStr(citationResp.getData()));
                postServiceProxy.updatePost(postResp.getData());
            }
            return Resp.success("帖子更新成功",postResp.getData());
        } catch (Exception e) {
            log.error("保存帖子失败", e);
            return Resp.error(500, "保存帖子失败：" + e.getMessage());
        }

    }

} 