package com.example.ksp.modules.system.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.admin.management.usermg.UserSqlProvider;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.entity.UserFollowDetailVO;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 用户Mapper接口
 * @author loself
 * @date 2024-12-31 13:47
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /**
     * 更新用户登录信息
     */
    @Update("UPDATE user SET last_login_time = #{loginTime}, last_login_location = #{location} WHERE id = #{userId}")
    int updateLoginInfo(@Param("userId") Long userId,
                       @Param("loginTime") LocalDateTime loginTime,
                       @Param("location") String location);

    /**
     * 获取用户关注的人列表
     */
    @Select("SELECT u.* FROM user u " +
            "INNER JOIN follow f ON u.id = f.followee_id " +
            "WHERE f.follower_id = #{userId} " +
            "AND f.is_deleted = '0' " +
            "AND u.is_deleted = 0")
    IPage<User> getFolloweeList(@Param("userId") Long userId, Page<User> page);

    /**
     * 获取用户的粉丝列表
     */
    @Select("SELECT u.* FROM user u " +
            "INNER JOIN follow f ON u.id = f.follower_id " +
            "WHERE f.followee_id = #{userId} " +
            "AND f.is_deleted = '0' " +
            "AND u.is_deleted = 0")
    IPage<User> getFollowerList(@Param("userId") Long userId, Page<User> page);


    /**
     * 查询用户的关注者详情（粉丝列表）
     * @param userId 用户ID
     * @return List<UserFollowDetailVO> 关注者详情列表
     */
    @Select("""
        SELECT u.id AS userId, u.username, u.avatar
        FROM follow f
        JOIN user u ON f.follower_id = u.id
        WHERE f.followee_id = #{userId} AND f.is_deleted = '0'
    """)
    List<UserFollowDetailVO> getFollowersDetails(@Param("userId") Long userId);

    /**
     * 查询用户的关注详情（关注列表）
     * @param userId 用户ID
     * @return List<UserFollowDetailVO> 关注详情列表
     */
    @Select("""
        SELECT u.id AS userId, u.username, u.avatar
        FROM follow f
        JOIN user u ON f.followee_id = u.id
        WHERE f.follower_id = #{userId} AND f.is_deleted = '0'
    """)
    List<UserFollowDetailVO> getFollowingDetails(@Param("userId") Long userId);

    /**
     * 获取用户的关注者和被关注者统计
     * @param userId 用户ID
     * @return Map<String, Integer> key 为 followersCount 和 followingCount
     */
    @Select("""
        SELECT 
            (SELECT COUNT(*) FROM follow WHERE followee_id = #{userId} AND is_deleted = '0') AS followersCount,
            (SELECT COUNT(*) FROM follow WHERE follower_id = #{userId} AND is_deleted = '0') AS followingCount
    """)
    Map<String, Integer> getFollowStatistics(@Param("userId") Long userId);

    /**
     * 一次性查询用户的关注者和被关注者详情以及统计信息
     * 减少数据库访问次数
     * @param userId 用户ID
     * @return Map<String, Object>
     */
    @Select("""
        SELECT 
            f1.followee_id AS followeeId,
            f2.follower_id AS followerId,
            u1.id AS followingUserId,
            u1.username AS followingUsername,
            u1.avatar AS followingAvatar,
            u2.id AS followerUserId,
            u2.username AS followerUsername,
            u2.avatar AS followerAvatar,
            (SELECT COUNT(*) FROM follow WHERE followee_id = #{userId} AND is_deleted = '0') AS followersCount,
            (SELECT COUNT(*) FROM follow WHERE follower_id = #{userId} AND is_deleted = '0') AS followingCount
        FROM user u
        LEFT JOIN follow f1 ON f1.follower_id = #{userId} AND f1.is_deleted = '0'
        LEFT JOIN user u1 ON f1.followee_id = u1.id
        LEFT JOIN follow f2 ON f2.followee_id = #{userId} AND f2.is_deleted = '0'
        LEFT JOIN user u2 ON f2.follower_id = u2.id
        WHERE u.id = #{userId}
    """)
    List<Map<String, Object>> getFollowDetailsAndStats(@Param("userId") Long userId);

    /**
     * 插入新用户
     *
     * @param user 用户对象，包含需要插入的用户信息
     * @return 插入的行数
     */
    @Insert("INSERT INTO `user` (username, password, salt, email, phone_number, registration_time, last_login_time, " +
            "last_login_location, last_updated_time, is_deleted, is_admin, is_frozen, permission_level, gender, birth_date, bio, avatar, " +
            "following_count, followers_count, review_status) VALUES (#{username}, #{password}, #{salt}, #{email}, #{phoneNumber}, " +
            "#{registrationTime}, #{lastLoginTime}, #{lastLoginLocation}, #{lastUpdatedTime}, #{isDeleted}, #{isAdmin}, #{isFrozen}, " +
            "#{permissionLevel}, #{gender}, #{birthDate}, #{bio}, #{avatar}, #{followingCount}, #{followersCount}, #{reviewStatus})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);

    /**
     * 根据用户ID删除用户，将is_deleted字段置为1
     *
     * @param id 用户ID
     * @return 删除的行数
     */
    @Update("UPDATE `user` SET is_deleted = 1 WHERE id = #{id}")
    int delete(Long id);

    /**
     * 更新用户信息
     *
     * @param user 用户对象，包含需要更新的用户信息
     * @return 更新的行数
     */
    @Update("UPDATE `user` SET username = #{username}, salt = #{salt}, email = #{email}, " +
            "phone_number = #{phoneNumber}, is_deleted = #{isDeleted}, is_admin = #{isAdmin}, is_frozen = #{isFrozen}, " +
            "permission_level = #{permissionLevel}, gender = #{gender}, birth_date = #{birthDate}, bio = #{bio}, avatar = #{avatar}, " +
            "review_status = #{reviewStatus} WHERE id = #{id}")
    int update(User user);

    // 动态更新用户字段
    @UpdateProvider(type = UserSqlProvider.class, method = "updateUser")
    int updateUser(@Param("userId") Long userId, @Param("updates") Map<String, Object> updates);

    /**
     * 根据用户ID查找用户
     *
     * @param id 用户ID
     * @return 用户对象，如果用户不存在则返回null
     */
    @Select("SELECT * FROM `user` WHERE id = #{id} AND is_deleted = 0")
    User findById(Long id);

    /**
     * 根据用户名查找用户
     *
     * @param username 用户名
     * @return 用户对象，如果用户不存在则返回null
     */
    @Select("SELECT * FROM `user` WHERE username = #{username} AND is_deleted = 0")
    User findByUsername(String username);

    /**
     * 查找所有未删除的用户
     *
     * @return 用户列表
     */
    @Select("SELECT * FROM `user` WHERE is_deleted = 0")
    Page<User> allUser(Page<User> page);

    // 分页查询用户，支持条件
    // 自定义分页查询方法
    @Select("SELECT * FROM `user` WHERE is_deleted = 0 ORDER BY ${orderByColumn} ${sort}")
    List<User> findByPage(Page<User> page, String orderByColumn, String sort);


    // 修改用户冻结状态
    void updateFrozenStatus(@Param("id") Long id, @Param("isFrozen") Integer isFrozen);

    // 调整用户权限
    void updatePermissionLevel(@Param("id") Long id, @Param("permissionLevel") Integer permissionLevel);

}
