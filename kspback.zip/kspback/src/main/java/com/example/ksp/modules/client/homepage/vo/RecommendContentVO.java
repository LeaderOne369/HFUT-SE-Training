package com.example.ksp.modules.client.homepage.vo;

import com.example.ksp.modules.system.post.entity.Post;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "推荐内容视图对象")
public class RecommendContentVO {
    
    @Schema(description = "帖子")
    private Post post;

    @Schema(description = "作者信息")
    private UserBriefVO author;

} 