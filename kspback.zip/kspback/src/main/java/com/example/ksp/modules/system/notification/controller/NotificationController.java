package com.example.ksp.modules.system.notification.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级通知管理接口")
@RestController
@RequestMapping("/system/notification")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Operation(summary = "发送通知")
    @PostMapping("/send")
    public Resp<Boolean> sendNotification(@RequestBody Notification notification) {
        boolean result = notificationService.sendNotification(notification);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "发送通知失败");
    }

    @Operation(summary = "标记通知为已读")
    @PutMapping("/read/{id}")
    public Resp<Boolean> markAsRead(
            @Parameter(description = "通知ID", required = true) 
            @PathVariable Long id) {
        boolean result = notificationService.markAsRead(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "标记已读失败");
    }

    @Operation(summary = "标记所有通知为已读")
    @PutMapping("/read-all")
    public Resp<Boolean> markAllAsRead(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId) {
        boolean result = notificationService.markAllAsRead(userId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "标记全部已读失败");
    }

    @Operation(summary = "删除通知")
    @DeleteMapping("/delete/{id}")
    public Resp<Boolean> deleteNotification(
            @Parameter(description = "通知ID", required = true) 
            @PathVariable Long id) {
        boolean result = notificationService.deleteNotification(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除通知失败");
    }

    @Operation(summary = "获取未读通知数量")
    @GetMapping("/unread-count")
    public Resp<Long> getUnreadCount(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId) {
        long count = notificationService.getUnreadCount(userId);
        return Resp.success(count);
    }

    @Operation(summary = "获取用户通知列表")
    @GetMapping("/list")
    public Resp<Page<Notification>> getUserNotifications(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "通知类型(1:评论回复 2:点赞 3:系统通知)", required = false) 
            @RequestParam(required = false) Integer type,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<Notification> result = notificationService.getUserNotifications(userId, type, current, size);
        return Resp.success(result);
    }
}
