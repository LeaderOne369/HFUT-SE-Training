package com.example.ksp.common.handler;

import com.example.ksp.common.handler.dto.ContentFileDTO;
import com.example.ksp.common.utils.MinioUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Component
@RequiredArgsConstructor
public class FileUploadHandler {

    private final MinioUtil minioUtil;
    
    private static final String AVATAR_BUCKET = "avatar";
    private static final String CONTENT_BUCKET = "content";
    private static final String COVER_BUCKET = "cover";
    private static final String IMAGE_BUCKET = "images";

    public enum FileType {
        AVATAR, CONTENT, COVER, IMAGE
    }

    /**
     * 通用文件上传方法
     * @param file 文件
     * @param type 文件类型 （ AVATAR, CONTENT, COVER）
     * @param userId 用户ID
     * @return 文件访问URL
     */
    public Resp<?> uploadFile(MultipartFile file, FileType type, Long userId) {
        if (file == null || file.isEmpty()) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "文件不能为空");
        }

        // 根据类型检查文件格式
        String contentType = file.getContentType();
        if (!validateFileType(contentType, type)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "不支持的文件类型");
        }

        try {
            if (type == FileType.CONTENT) {
                // 生成内容文件路径


                return uploadContent(file,file.getContentType(), userId);
            } else {
                // 其他类型文件的处理保持不变
                String fileName = generateFileName(type, userId, getFileExtension(file.getOriginalFilename()));
                String bucketName = getBucketName(type);
                minioUtil.uploadFile(bucketName, fileName, file);
                String fileUrl = minioUtil.getPermanentFileUrl(bucketName, fileName);
                return Resp.success(fileUrl);
            }
        } catch (Exception e) {
            log.error("文件上传失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "文件上传失败：" + e.getMessage());
        }
    }

    /**
     * 验证文件类型
     */
    private boolean validateFileType(String contentType, FileType type) {
        if (contentType == null) {
            return false;
        }
        
        return switch (type) {
            case AVATAR, COVER -> contentType.startsWith("image/");
            case CONTENT -> contentType.startsWith("text/") || 
                          contentType.startsWith("application/json") ||
                          contentType.equals("application/octet-stream") ||
                          contentType.equals("text/html") ||
                          contentType.equals("application/xml") ||
                          contentType.equals("text/xml") ||
                          contentType.equals("text/plain") ||
                          contentType.equals("text/markdown") ||
                          contentType.equals("application/x-www-form-urlencoded");
            case IMAGE -> false;
        };
    }

    /**
     * 上传富文本或Markdown内容
     */
    public Resp<?> uploadContent(MultipartFile file, String contentType, Long userId) {
        if (file == null || file.isEmpty()) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "内容不能为空");
        }

        try {
            // 根据内容类型确定文件扩展名
            String extension = getFileExtensionByContentType(contentType);
            
            // 生成内容文件路径
            String contentFilePath = "post/content/" + UUID.randomUUID() + extension;
            // 生成文件ID
            String fileId = "content-" + userId + "-" + UUID.randomUUID();
            
            // 读取文件内容并设置正确的字符编码
            String content = new String(file.getBytes(), StandardCharsets.UTF_8);
            
            // 添加 UTF-8 BOM 标记，确保某些编辑器能正确识别编码
            byte[] contentBytes;
            if (extension.equals(".html")) {
                // 为HTML添加编码声明
                if (!content.contains("<meta charset=\"UTF-8\"")) {
                    content = "<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"UTF-8\">\n</head>\n<body>\n" 
                            + content + "\n</body>\n</html>";
                }
                contentBytes = content.getBytes(StandardCharsets.UTF_8);
            } else if (extension.equals(".md")) {
                // Markdown文件添加UTF-8 BOM
                byte[] bom = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
                byte[] contentBom = content.getBytes(StandardCharsets.UTF_8);
                contentBytes = new byte[bom.length + contentBom.length];
                System.arraycopy(bom, 0, contentBytes, 0, bom.length);
                System.arraycopy(contentBom, 0, contentBytes, bom.length, contentBom.length);
            } else {
                contentBytes = content.getBytes(StandardCharsets.UTF_8);
            }
            
            // 设置正确的Content-Type，包含字符编码信息
            String fullContentType = contentType + "; charset=UTF-8";
            
            // 上传内容
            minioUtil.uploadBytes(CONTENT_BUCKET, contentFilePath, contentBytes, fullContentType);
            
            // 获取文件访问URL
            String fileUrl = minioUtil.getPermanentFileUrl(CONTENT_BUCKET, contentFilePath);
            
            return Resp.success(ContentFileDTO.builder()
                    .fileId(fileId)
                    .fileUrl(fileUrl)
                    .filePath(contentFilePath)
                    .build());
        } catch (Exception e) {
            log.error("内容上传失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "内容上传失败：" + e.getMessage());
        }
    }




    /**
     * 根据内容类型获取文件扩展名
     */
    private String getFileExtensionByContentType(String contentType) {
        return switch (contentType) {
            case "text/html" -> ".html";
            case "text/markdown" -> ".md";
            case "application/json" -> ".json";
            case "text/xml", "application/xml" -> ".xml";
            default -> ".txt";
        };
    }

    /**
     * 删除文件
     */
    public void deleteFile(String fileUrl, FileType type) {
        try {
            String bucketName = getBucketName(type);
            String objectName = extractObjectNameFromUrl(fileUrl);
            minioUtil.deleteFile(bucketName, objectName);
        } catch (Exception e) {
            log.warn("删除文件失败: {}", e.getMessage());
        }
    }

    /**
     * 生成文件名
     */
    private String generateFileName(FileType type, Long userId, String extension) {
        String prefix = switch (type) {
            case AVATAR -> "avatar_";
            case CONTENT -> "content_";
            case COVER -> "cover_";
            default -> "";
        };
        
        return prefix + userId + "_" + System.currentTimeMillis() + "_" + 
               UUID.randomUUID().toString().substring(0, 8) + extension;
    }

    /**
     * 获取文件扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null || filename.lastIndexOf(".") == -1) {
            return "";
        }
        return filename.substring(filename.lastIndexOf("."));
    }

    /**
     * 获取存储桶名称
     */
    private String getBucketName(FileType type) {
        return switch (type) {
            case AVATAR -> AVATAR_BUCKET;
            case CONTENT -> CONTENT_BUCKET;
            case COVER -> COVER_BUCKET;
            case IMAGE -> IMAGE_BUCKET;
        };
    }

    /**
     * 从URL中提取对象名称
     */
    private String extractObjectNameFromUrl(String url) {
        if (url == null || url.isEmpty()) {
            return "";
        }
        return url.substring(url.lastIndexOf("/") + 1);
    }

    /**
     * 上传图片
     */
    public Resp<?> uploadImage(MultipartFile file, Long userId) {
        if (file == null || file.isEmpty()) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "图片不能为空");
        }

        // 检查文件类型
        String contentType = file.getContentType();
        if (!validateImageType(contentType)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "不支持的图片类型");
        }

        try {
            // 生成文件名
            String fileName = generateImageFileName(userId, getFileExtension(file.getOriginalFilename()));
            
            // 上传图片
            minioUtil.uploadFile(IMAGE_BUCKET, fileName, file);
            
            // 获取访问URL
            String fileUrl = minioUtil.getPermanentFileUrl(IMAGE_BUCKET, fileName);
            
            return Resp.success(fileUrl);
        } catch (Exception e) {
            log.error("图片上传失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "图片上传失败：" + e.getMessage());
        }
    }

    /**
     * 验证图片类型
     */
    private boolean validateImageType(String contentType) {
        if (contentType == null) {
            return false;
        }
        return contentType.startsWith("image/");
    }

    /**
     * 生成图片文件名
     */
    private String generateImageFileName(Long userId, String extension) {
        LocalDateTime now = LocalDateTime.now();
        String datePath = now.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        return String.format("user_%d/%s/%s%s", 
                userId, 
                datePath, 
                UUID.randomUUID().toString().replace("-", ""), 
                extension);
    }
} 