package com.example.ksp.common.utils;

import com.example.ksp.common.config.MinioConfig;
import com.example.ksp.framework.minio.CustomMultipartFile;
import io.minio.*;
import io.minio.http.Method;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class MinioUtil {

    private final MinioClient minioClient;
    private final MinioConfig minioConfig;

    /**
     * 创建存储桶
     */
    public void createBucket(String bucketName) {
        try {
            boolean exists = minioClient.bucketExists(BucketExistsArgs.builder()
                    .bucket(bucketName)
                    .build());
            if (!exists) {
                minioClient.makeBucket(MakeBucketArgs.builder()
                        .bucket(bucketName)
                        .build());
            }
        } catch (Exception e) {
            log.error("创建存储桶失败: {}", e.getMessage());
            throw new RuntimeException("创建存储桶失败", e);
        }
    }

    /**
     * 上传文件
     */
    public String uploadFile(String bucketName, String objectName, MultipartFile file) {
        try {
            createBucket(bucketName);
            
            minioClient.putObject(PutObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .stream(file.getInputStream(), file.getSize(), -1)
                    .contentType(file.getContentType())
                    .build());
            
            return getFileUrl(bucketName, objectName);
        } catch (Exception e) {
            log.error("上传文件失败: {}", e.getMessage());
            throw new RuntimeException("上传文件失败", e);
        }
    }

    /**
     * 上传字符串内容
     */
    public String uploadString(String bucketName, String objectName, String content) {
        try {
            createBucket(bucketName);
            
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
            
            minioClient.putObject(PutObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .stream(bais, bytes.length, -1)
                    .contentType("text/html")
                    .build());
            
            return getFileUrl(bucketName, objectName);
        } catch (Exception e) {
            log.error("上传内容失败: {}", e.getMessage());
            throw new RuntimeException("上传内容失败", e);
        }
    }

    /**
     * 下载文件
     */
    public InputStream downloadFile(String bucketName, String objectName) {
        try {
            return minioClient.getObject(GetObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .build());
        } catch (Exception e) {
            log.error("下载文件失败: {}", e.getMessage());
            throw new RuntimeException("下载文件失败", e);
        }
    }

    /**
     * 获取文件内容
     */
    public String getFileContent(String bucketName, String objectName) {
        try {
            InputStream stream = downloadFile(bucketName, objectName);
            byte[] bytes = stream.readAllBytes();
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("获取文件内容失败: {}", e.getMessage());
            throw new RuntimeException("获取文件内容失败", e);
        }
    }

    /**
     * 删除文件
     */
    public void deleteFile(String bucketName, String objectName) {
        try {
            minioClient.removeObject(RemoveObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .build());
        } catch (Exception e) {
            log.error("删除文件失败: {}", e.getMessage());
            throw new RuntimeException("删除文件失败", e);
        }
    }

    /**
     * 获取文件访问URL
     */
    public String getFileUrl(String bucketName, String objectName) {
        try {
            return minioClient.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .method(Method.GET)
                    .expiry(7, TimeUnit.DAYS)  // URL有效期7天
                    .build());
        } catch (Exception e) {
            log.error("获取文件URL失败: {}", e.getMessage());
            throw new RuntimeException("获取文件URL失败", e);
        }
    }

    /**
     * 使用默认存储桶上传文件
     */
    public String uploadFile(String objectName, MultipartFile file) {
        return uploadFile(minioConfig.getDefaultBucketName(), objectName, file);
    }

    /**
     * 使用默认存储桶上传字符串内容
     */
    public String uploadString(String objectName, String content) {
        return uploadString(minioConfig.getDefaultBucketName(), objectName, content);
    }

    /**
     * 使用默认存储桶下载文件
     */
    public InputStream downloadFile(String objectName) {
        return downloadFile(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 使用默认存储桶获取文件内容
     */
    public String getFileContent(String objectName) {
        return getFileContent(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 使用默认存储桶删除文件
     */
    public void deleteFile(String objectName) {
        deleteFile(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 使用默认存储桶获取文件URL
     */
    public String getFileUrl(String objectName) {
        return getFileUrl(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 获取文件的永久访问URL
     */
    public String getPermanentFileUrl(String bucketName, String objectName) {
        try {
            return String.format("%s/%s/%s", minioConfig.getEndpoint(), bucketName, objectName);
        } catch (Exception e) {
            log.error("获取文件URL失败: {}", e.getMessage());
            throw new RuntimeException("获取文件URL失败", e);
        }
    }

    /**
     * 使用默认存储桶获取文件的永久访问URL
     */
    public String getPermanentFileUrl(String objectName) {
        return getPermanentFileUrl(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 获取文件并转换为MultipartFile
     */
    public MultipartFile getFileAsMultipartFile(String bucketName, String objectName) {
        try {
            // 从MinIO获取文件
            GetObjectResponse response = minioClient.getObject(
                GetObjectArgs.builder()
                    .bucket(bucketName)
                    .object(objectName)
                    .build()
            );

            // 读取文件内容
            byte[] content = response.readAllBytes();
            
            // 获取文件的Content-Type
            String contentType = response.headers().get("Content-Type");
            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            // 创建MultipartFile
            return new CustomMultipartFile(
                content,                   // 文件内容
                objectName,                // 文件名
                objectName,                // 原始文件名
                contentType                // Content Type
            );
        } catch (Exception e) {
            log.error("获取文件失败: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 使用默认存储桶获取文件并转换为MultipartFile
     */
    public MultipartFile getFileAsMultipartFile(String objectName) {
        return getFileAsMultipartFile(minioConfig.getDefaultBucketName(), objectName);
    }

    /**
     * 上传字节数组
     * @param bucketName 存储桶名称
     * @param objectName 对象名称
     * @param bytes 字节数组
     * @param contentType 内容类型
     * @throws Exception 上传异常
     */
    public void uploadBytes(String bucketName, String objectName, byte[] bytes, String contentType) throws Exception {
        try {
            // 确保存储桶存在
            createBucket(bucketName);
            
            // 使用 ByteArrayInputStream 上传字节数组
            try (ByteArrayInputStream bais = new ByteArrayInputStream(bytes)) {
                minioClient.putObject(PutObjectArgs.builder()
                        .bucket(bucketName)
                        .object(objectName)
                        .stream(bais, bytes.length, -1)
                        .contentType(contentType)
                        .build());
                
                log.info("文件上传成功 - bucket: {}, object: {}, size: {} bytes", 
                        bucketName, objectName, bytes.length);
            }
        } catch (Exception e) {
            log.error("上传字节数组失败 - bucket: {}, object: {}", bucketName, objectName, e);
            throw new RuntimeException("上传字节数组失败: " + e.getMessage());
        }
    }



    
    /**
     * 上传HTML内容
     * @param bucketName 存储桶名称
     * @param objectName 对象名称
     * @param htmlContent HTML内容
     * @return 文件访问URL
     * @throws Exception 上传异常
     */
    public String uploadHtml(String bucketName, String objectName, String htmlContent) throws Exception {
        byte[] bytes = htmlContent.getBytes(StandardCharsets.UTF_8);
        uploadBytes(bucketName, objectName, bytes, "text/html");
        return getPermanentFileUrl(bucketName, objectName);
    }
} 