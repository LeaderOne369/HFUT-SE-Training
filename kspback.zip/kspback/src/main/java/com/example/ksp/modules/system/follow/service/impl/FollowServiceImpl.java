package com.example.ksp.modules.system.follow.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.follow.dto.FollowCreateDTO;
import com.example.ksp.modules.system.follow.dto.FollowQueryDTO;
import com.example.ksp.modules.system.follow.entity.Follow;
import com.example.ksp.modules.system.follow.mapper.FollowMapper;
import com.example.ksp.modules.system.follow.service.FollowService;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class FollowServiceImpl extends ServiceImpl<FollowMapper, Follow> implements FollowService {

    private final UserService userService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<String> follow(Long followerId, FollowCreateDTO createDTO) {
        // 检查被关注者是否存在
        if (!userService.checkUserExists(createDTO.getFolloweeId())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被关注用户不存在");
        }

        // 不能关注自己
        if (followerId.equals(createDTO.getFolloweeId())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "不能关注自己");
        }

        // 检查是否已经关注
        LambdaQueryWrapper<Follow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Follow::getFollowerId, followerId)
                .eq(Follow::getFolloweeId, createDTO.getFolloweeId());
        Follow existingFollow = getOne(wrapper);

        if (existingFollow != null) {
            if ("0".equals(existingFollow.getIsDeleted())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "已经关注该用户");
            } else {
                // 恢复已删除的关注记录
                existingFollow.setIsDeleted("0");
                existingFollow.setFollowTime(LocalDateTime.now());
                updateById(existingFollow);
                
                // 更新关注数和粉丝数
                userService.incrementFollowCount(followerId);
                userService.incrementFansCount(createDTO.getFolloweeId());
                
                return Resp.success("关注成功");
            }
        }

        // 创建新的关注记录
        Follow follow = new Follow();
        follow.setFollowerId(followerId);
        follow.setFolloweeId(createDTO.getFolloweeId());
        follow.setFollowTime(LocalDateTime.now());
        follow.setIsDeleted("0");
        save(follow);

        // 更新关注数和粉丝数
        userService.incrementFollowCount(followerId);
        userService.incrementFansCount(createDTO.getFolloweeId());

        return Resp.success("关注成功");
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<String> unfollow(Long followerId, Long followeeId) {
        LambdaQueryWrapper<Follow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Follow::getFollowerId, followerId)
                .eq(Follow::getFolloweeId, followeeId)
                .eq(Follow::getIsDeleted, "0");

        Follow follow = getOne(wrapper);
        if (follow == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "未关注该用户");
        }

        // 逻辑删除
        follow.setIsDeleted("1");
        updateById(follow);

        // 更新关注数和粉丝数
        userService.decrementFollowCount(followerId);
        userService.decrementFansCount(followeeId);

        return Resp.success("取消关注成功");
    }

    @Override
    public Resp<Boolean> checkFollow(Long followerId, Long followeeId) {
        LambdaQueryWrapper<Follow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Follow::getFollowerId, followerId)
                .eq(Follow::getFolloweeId, followeeId)
                .eq(Follow::getIsDeleted, "0");

        return Resp.success(count(wrapper) > 0);
    }

    @Override
    public Resp<Page<User>> queryFollowList(FollowQueryDTO queryDTO) {
        if (queryDTO.getUserId() == null || queryDTO.getType() == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "参数错误");
        }

        // 创建分页对象
        Page<User> userPage = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());

        // 根据类型查询关注列表或粉丝列表
        if (queryDTO.getType() == 1) {
            // 查询关注列表
            return userService.getFolloweeList(queryDTO.getUserId(), userPage);
        } else if (queryDTO.getType() == 2) {
            // 查询粉丝列表
            return userService.getFollowerList(queryDTO.getUserId(), userPage);
        } else {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "类型参数错误");
        }
    }
} 