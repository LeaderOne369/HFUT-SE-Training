package com.example.ksp.modules.proxy;

import com.example.ksp.modules.system.statistics.StatisticsRequest;
import com.example.ksp.modules.system.statistics.dto.StatisticsResponse;
import com.example.ksp.modules.system.statistics.dto.StatisticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class StatisticsServiceProxy {
    private final StatisticsService statisticsService;
    public StatisticsResponse getStatistics(StatisticsRequest request) {
        return statisticsService.getStatistics(request);
    }
}
