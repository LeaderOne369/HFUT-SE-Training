package com.example.ksp.modules.client.ai.service.impl;

import com.coze.openapi.client.chat.CreateChatReq;
import com.coze.openapi.client.chat.model.*;
import com.coze.openapi.client.connversations.message.model.Message;
import com.coze.openapi.service.auth.TokenAuth;
import com.coze.openapi.service.config.Consts;
import com.coze.openapi.service.service.CozeAPI;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.ai.model.ChatMessage;
import com.example.ksp.modules.client.ai.service.AiChatService;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
public class AiChatServiceImpl implements AiChatService {

    private static final Map<String, SseEmitter> sseEmitterMap = new ConcurrentHashMap<>();
    private static final Map<String, List<ChatMessage>> chatHistoryMap = new ConcurrentHashMap<>();
    private static final int MAX_HISTORY_SIZE = 50;
    
    @Value("${coze.bot.token}")
    private String token;
    
    @Value("${coze.bot.id}")
    private String botId;

    @Override
    public ConcurrentHashMap<Object, Object> createChatConnection() {
        SseEmitter sseEmitter = new SseEmitter(0L);
        String clientId = UUID.randomUUID().toString();
        sseEmitterMap.put(clientId, sseEmitter);
        chatHistoryMap.put(clientId, new ArrayList<>());
        
        try {
            sseEmitter.send(SseEmitter.event()
                    .name("connect")
                    .data(clientId));
        } catch (IOException e) {
            log.error("建立连接失败", e);
        }
        
        sseEmitter.onCompletion(() -> {
            log.info("连接结束: {}", clientId);
            cleanup(clientId);
        });
        
        sseEmitter.onTimeout(() -> {
            log.info("连接超时: {}", clientId);
            cleanup(clientId);
        });

        ConcurrentHashMap<Object, Object> map = new ConcurrentHashMap<>();
        map.put("clientId", clientId);
        map.put("sseEmitter",sseEmitter);
        return map;
    }

    @Override
    public Resp<Void> chat(String clientId, String question) {
        try {
            SseEmitter sseEmitter = sseEmitterMap.get(clientId);
            if (sseEmitter == null) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "连接已断开，请重新建立连接");
            }

            List<ChatMessage> history = chatHistoryMap.get(clientId);
            history.add(ChatMessage.userMessage(question));

            List<Message> messages = new ArrayList<>();
            history.forEach(msg -> {
                if ("user".equals(msg.getRole())) {
                    messages.add(Message.buildUserQuestionText(msg.getContent()));
                } else if ("assistant".equals(msg.getRole())) {
                    messages.add(Message.buildAssistantAnswer(msg.getContent()));
                }
            });

            TokenAuth authCli = new TokenAuth(token);
            CozeAPI coze = new CozeAPI.Builder()
                    .baseURL(Consts.COZE_CN_BASE_URL)
                    .auth(authCli)
                    .readTimeout(10000)
                    .build();

            CreateChatReq req = CreateChatReq.builder()
                    .botID(botId)
                    .userID(clientId)
                    .messages(messages)
                    .build();

            StringBuilder answer = new StringBuilder();
            Flowable<ChatEvent> resp = coze.chat().stream(req);
            
            resp.blockingForEach(event -> {
                if (ChatEventType.CONVERSATION_MESSAGE_DELTA.equals(event.getEvent())) {
                    String content = event.getMessage().getContent();
                    answer.append(content);
                    sseEmitter.send(SseEmitter.event()
                            .name("message")
                            .data(content));
                }
                
                if (ChatEventType.CONVERSATION_CHAT_COMPLETED.equals(event.getEvent())) {
                    history.add(ChatMessage.assistantMessage(answer.toString()));
                    // 保持历史记录在50条以内
                    while (history.size() > MAX_HISTORY_SIZE) {
                        history.remove(0);
                    }
                    
                    sseEmitter.send(SseEmitter.event()
                            .name("complete")
                            .data(event.getChat().getUsage().getTokenCount()));
                }
            });
            
            coze.shutdownExecutor();
            return Resp.success(null);
        } catch (Exception e) {
            log.error("AI对话异常", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI对话异常: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> chatSync(String clientId, String question) {
        try {
            List<ChatMessage> history = chatHistoryMap.computeIfAbsent(clientId, k -> new ArrayList<>());
            history.add(ChatMessage.userMessage(question));

            List<Message> messages = new ArrayList<>();
            history.forEach(msg -> {
                if ("user".equals(msg.getRole())) {
                    messages.add(Message.buildUserQuestionText(msg.getContent()));
                } else if ("assistant".equals(msg.getRole())) {
                    messages.add(Message.buildAssistantAnswer(msg.getContent()));
                }
            });

            TokenAuth authCli = new TokenAuth(token);
            CozeAPI coze = new CozeAPI.Builder()
                    .baseURL(Consts.COZE_CN_BASE_URL)
                    .auth(authCli)
                    .readTimeout(10000)
                    .build();

            CreateChatReq req = CreateChatReq.builder()
                    .botID(botId)
                    .userID(clientId)
                    .messages(messages)
                    .build();

            // 使用非流式API创建对话并轮询结果,设置10秒超时
            ChatPoll chatPoll = coze.chat().createAndPoll(req, 10L);
            
            if (chatPoll != null) {
                String answer = chatPoll.getMessages().get(chatPoll.getMessages().size() - 5).getContent();
                Message message = Message.buildAssistantAnswer(answer);
                history.add(ChatMessage.assistantMessage(message.getContent()));
                
                // 保持历史记录在50条以内
                while (history.size() > MAX_HISTORY_SIZE) {
                    history.remove(0);
                }
                return Resp.success(answer);
            }
            
            coze.shutdownExecutor();
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI回答超时或未完成");
        } catch (Exception e) {
            log.error("AI对话异常", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "AI对话异常: " + e.getMessage());
        }
    }

    @Override
    public void closeChatConnection(String clientId) {
        cleanup(clientId);
    }
    
    private void cleanup(String clientId) {
        sseEmitterMap.remove(clientId);
        chatHistoryMap.remove(clientId);
    }
} 