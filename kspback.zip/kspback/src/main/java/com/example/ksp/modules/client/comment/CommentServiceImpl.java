package com.example.ksp.modules.client.comment;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;

import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;
import com.example.ksp.modules.proxy.*;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.entity.Comment;

import com.example.ksp.modules.system.report.report.dto.ReportCreateDTO;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import com.example.ksp.modules.system.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Component("clientCommentServiceImpl")
@RequiredArgsConstructor
public class CommentServiceImpl implements CommentService {

    private final UserServiceProxy userServiceProxy;
    private final CommentServiceProxy commentServiceProxy;
    private final ReportServiceProxy reportServiceProxy;
    private final ReportedTypeServiceProxy reportedTypeServiceProxy;
    private final ReportTypeServiceProxy reportTypeServiceProxy;
    @Override
    public Resp<String> reportComment(Long commentId, Long reportTypeId, Long reportedTypeId, String reason, String token) {
        log.info("举报评论, commentId: {}, reportTypeId: {}, reportedTypeId: {}", commentId, reportTypeId, reportedTypeId);

        // 参数校验
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        if (reportTypeId == null || reportTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的举报类型ID");
        }
        if (reportedTypeId == null || reportedTypeId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的被举报对象类型ID");
        }

        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();

            // 2. 检查评论是否存在
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }

            // 3. 检查举报类型是否存在
            Resp<ReportType> reportTypeResp = reportTypeServiceProxy.getReportType(reportTypeId);
            if (reportTypeResp.getCode() != 200 || reportTypeResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报类型不存在");
            }

            // 4. 检查被举报对象类型是否存在
            Resp<ReportedType> reportedTypeResp = reportedTypeServiceProxy.getReportedType(reportedTypeId);
            if (reportedTypeResp.getCode() != 200 || reportedTypeResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "被举报对象类型不存在");
            }

            // 5. 创建举报
            ReportCreateDTO createDTO = new ReportCreateDTO();
            createDTO.setUserId(currentUserId);
            createDTO.setReportedContentId(commentId);
            createDTO.setReportedTypeId(reportedTypeId);
            createDTO.setReportTypeId(reportTypeId);
            createDTO.setReason(reason);

            Resp<Report> reportResp = reportServiceProxy.createReport(createDTO, currentUserId);
            if (reportResp.getCode() != 200) {
                return Resp.error(reportResp.getCode(), reportResp.getMsg());
            }

            return Resp.success("举报成功");
        } catch (Exception e) {
            log.error("举报评论失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "举报失败");
        }
    }

    @Override
    public Resp<CommentDTO> replyComment(Long commentId, String content, String token) {
        log.info("回复评论, commentId: {}, content: {}", commentId, content);

        // 参数校验
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        if (StringUtils.isBlank(content)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }

        try {
            // 1. 获取当前用户ID
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> userIdResp = userServiceProxy.getUserIdByUsername(username);
            if (userIdResp.getCode() != 200 || userIdResp.getData() == null) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户未登录");
            }
            Long currentUserId = userIdResp.getData();

            // 2. 检查评论是否存在
            Resp<Comment> commentResp = commentServiceProxy.getComment(commentId);
            if (commentResp.getCode() != 200 || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }

            // 3. 创建子评论
            CommentCreateDTO createDTO = new CommentCreateDTO();
            createDTO.setCommenterId(currentUserId);
            createDTO.setCommentableId(commentId);
            createDTO.setCommentableType(3);// 3表示评论
            createDTO.setParentCommentId(commentId);
            createDTO.setContent(content);
            createDTO.setIsPublic(1); // 默认公开

            Resp<Comment> newCommentResp = commentServiceProxy.replyComment(createDTO);
            if (newCommentResp.getCode() != 200 || newCommentResp.getData() == null) {
                return Resp.error(newCommentResp.getCode(), newCommentResp.getMsg());
            }

            // 4. 转换为DTO
            Comment newComment = newCommentResp.getData();
            Resp<User> userResp = userServiceProxy.getUser(currentUserId);
            User user = userResp.getData();

            CommentDTO commentDTO = new CommentDTO();
            commentDTO.setId(newComment.getId());
            commentDTO.setContent(newComment.getContent());
            commentDTO.setCommenterId(newComment.getCommenterId());
            commentDTO.setCommenterName(user != null ? user.getUsername() : "未知用户");
            commentDTO.setCommenterAvatar(user != null ? user.getAvatar() : null);
            commentDTO.setCreationTime(newComment.getCreationTime());
            commentDTO.setParentCommentId(newComment.getParentCommentId());
            commentDTO.setLikeCount(0);
            commentDTO.setReplyCount(0);
            commentDTO.setIsLiked(false);
            commentDTO.setIsPublic(newComment.getIsPublic());
            commentDTO.setReviewStatus(newComment.getReviewStatus());
            Resp<Comment> commentResp1 = commentServiceProxy.getComment(newComment.getParentCommentId());
            Resp<User> userResp1 = userServiceProxy.getUser(commentResp1.getData().getCommenterId());

            commentDTO.setReplyToCommenterId(userResp1.getData()==null?null:userResp1.getData().getId());
            commentDTO.setReplyToCommenterName(userResp1.getData()==null?null:userResp1.getData().getUsername());

            return Resp.success(commentDTO);
        } catch (Exception e) {
            log.error("回复评论失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "回复失败");
        }
    }
}
