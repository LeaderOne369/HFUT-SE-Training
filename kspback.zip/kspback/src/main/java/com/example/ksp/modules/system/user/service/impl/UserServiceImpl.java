package com.example.ksp.modules.system.user.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.usermg.UserCreateDTO;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import com.example.ksp.modules.system.favoritefolder.service.FavoriteFolderService;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.service.NotificationService;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.entity.UserFollowDetailVO;
import com.example.ksp.modules.system.user.mapper.UserMapper;
import com.example.ksp.modules.system.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 用户服务实现类
 * @author loself
 * @date 2024-12-31 14:21
 */

@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    private final PasswordEncoder passwordEncoder;
    private final RedisCache redisCache;
    private final UserMapper userMapper;
    private final NotificationService notificationService;
    private final FavoriteFolderService favoriteFolderService;

    @Autowired
    public UserServiceImpl(PasswordEncoder passwordEncoder,
                         RedisCache redisCache,
                         UserMapper userMapper,
                         NotificationService notificationService,
                         FavoriteFolderService favoriteFolderService) {
        this.passwordEncoder = passwordEncoder;
        this.redisCache = redisCache;
        this.userMapper = userMapper;
        this.notificationService = notificationService;
        this.favoriteFolderService = favoriteFolderService;
    }

    @Override
    public User selectUserByPhoneNumber(String phone) {
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getPhoneNumber, phone)
              .eq(User::getIsDeleted, 0);
        return getOne(wrapper);
    }

    @Override
    public User selectUserByUsername(String username) {
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getUsername, username)
              .eq(User::getIsDeleted, 0);
        return getOne(wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateUserLoginInfo(User user) {
        if (user == null || user.getId() == null) {
            return false;
        }

        // 只更新登录相关字段
        User updateUser = new User();
        updateUser.setId(user.getId());
        updateUser.setLastLoginTime(user.getLastLoginTime());
        updateUser.setLastLoginLocation(user.getLastLoginLocation());
        updateUser.setLastUpdatedTime(user.getLastUpdatedTime());

        return userMapper.updateById(updateUser) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<User> register(RegisterDTO registerDTO) {
        // 验证验证码
//        String cacheKey = "captcha of " + registerDTO.getPhoneNumber();
//        String cacheCaptcha = redisCache.getCacheObject(cacheKey);
//        if (cacheCaptcha == null || !cacheCaptcha.equals(registerDTO.getCaptcha())) {
//            return Resp.error(HttpStatus.BAD_REQUEST, "验证码错误或已过期");
//        }
//        // 验证成功后删除验证码
//        redisCache.deleteObject(cacheKey);

        // 检查用户名是否已存在
        if (selectUserByUsername(registerDTO.getUsername()) != null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "用户名已存在");
        }

        // 检查手机号是否已存在
        if (selectUserByPhoneNumber(registerDTO.getPhoneNumber()) != null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "手机号已被注册");
        }

        // 生成盐值
        String salt = UUID.randomUUID().toString().replace("-", "");

        // 创建新用户
        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setPhoneNumber(registerDTO.getPhoneNumber());
        // 将密码和盐值组合后进行加密
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword() + salt));
        user.setSalt(salt);
        user.setRegistrationTime(LocalDateTime.now());
        user.setLastUpdatedTime(LocalDateTime.now());
        user.setIsDeleted(0);
        user.setIsAdmin(0);
        user.setIsFrozen(0);
        user.setPermissionLevel(0);
        //默认审核通过
        user.setReviewStatus(1);
        user.setFollowersCount(0);
        user.setFollowingCount(0);



        // 保存用户
        if (save(user)) {
            try {
                // 创建默认收藏夹
                FavoriteFolder defaultFavorite = new FavoriteFolder();
                defaultFavorite.setUserId(user.getId());
                defaultFavorite.setFolderName("默认收藏夹");
                defaultFavorite.setVisibility(1);
                defaultFavorite.setCreationTime(LocalDateTime.now());
                defaultFavorite.setIsDeleted(0);
                favoriteFolderService.save(defaultFavorite);

                // 创建欢迎通知
                Notification welcomeNotification = new Notification();
                welcomeNotification.setUserReceiverId(user.getId());
                welcomeNotification.setType(3);  // 系统通知
                welcomeNotification.setTitle("欢迎加入");
                welcomeNotification.setContent("欢迎加入我们的平台！我们已为您创建了默认收藏夹，开始您的收藏之旅吧。");
                welcomeNotification.setCreationTime(LocalDateTime.now());
                welcomeNotification.setStatus(0);  // 未读
                welcomeNotification.setIsDeleted(0);
                notificationService.save(welcomeNotification);

                return Resp.success(user);
            } catch (Exception e) {
                log.error("创建默认收藏夹或欢迎通知失败", e);
                throw new RuntimeException("注册过程中发生错误", e);
            }
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "注册失败");
        }
    }

    @Override
    public Resp<User> login(LoginDTO loginDTO) {
        User user;
        switch (loginDTO.getLoginType()) {
            case 1 -> { // 用户名密码登录
                user = selectUserByUsername(loginDTO.getUsername());
                if (user == null) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "用户名不存在或账号已注销");
                }
                if (!passwordEncoder.matches(loginDTO.getPassword() + user.getSalt(),
                        user.getPassword())) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "密码错误");
                }
            }
            case 2 -> { // 手机号密码登录
                user = selectUserByPhoneNumber(loginDTO.getPhoneNumber());
                if (user == null) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "手机号未注册或账号已注销");
                }
                if (!passwordEncoder.matches(loginDTO.getPassword() + user.getSalt(),
                        user.getPassword())) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "密码错误");
                }
            }
            case 3 -> { // 手机号验证码登录
                user = selectUserByPhoneNumber(loginDTO.getPhoneNumber());
                if (user == null) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "手机号未注册或账号已注销");
                }
                String cacheKey = "captcha of " + loginDTO.getPhoneNumber();
                String cacheCaptcha = redisCache.getCacheObject(cacheKey);
                if (cacheCaptcha == null || !cacheCaptcha.equals(loginDTO.getCaptcha())) {
                    return Resp.error(HttpStatus.BAD_REQUEST, "验证码错误或已过期");
                }
                // 验证成功后删除验证码
                redisCache.deleteObject(cacheKey);
            }
            default -> {
                return Resp.error(HttpStatus.BAD_REQUEST, "不支持的登录方式");
            }
        }

        // 更新登录信息
        updateUserLoginInfo(user);

        return Resp.success(user);
    }

    @Override
    public Resp<String> resetPassword(String phoneNumber, String newPassword) {
        // 根据手机号查询用户
        User user = selectUserByPhoneNumber(phoneNumber);
        if (user == null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "用户不存在");
        }

        // 生成新的盐值
        String salt = UUID.randomUUID().toString().replace("-", "");

        // 更新密码和盐值
        User updateUser = new User();
        updateUser.setId(user.getId());
        updateUser.setPassword(passwordEncoder.encode(newPassword + salt));
        updateUser.setSalt(salt);
        updateUser.setLastUpdatedTime(LocalDateTime.now());

        if (updateById(updateUser)) {
            return Resp.success("密码重置成功");
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR, "密码重置失败");
        }
    }

    @Override
    public boolean verifyPassword(Long userId, String password) {
        User user = getById(userId);
        if (user == null) {
            return false;
        }
        return passwordEncoder.matches(password + user.getSalt(), user.getPassword());
    }

    @Override
    public Resp<String> updatePassword(Long userId, String newPassword) {
        User user = getById(userId);
        if (user == null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "用户不存在");
        }

        // 生成新的盐值
        String salt = UUID.randomUUID().toString().replace("-", "");

        // 更新密码和盐值
        User updateUser = new User();
        updateUser.setId(userId);
        updateUser.setPassword(passwordEncoder.encode(newPassword + salt));
        updateUser.setSalt(salt);
        updateUser.setLastUpdatedTime(LocalDateTime.now());

        if (updateById(updateUser)) {
            return Resp.success("密码修改成功");
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR, "密码修改失败");
        }
    }

    @Override
    public Resp<String> deactivateAccount(Long userId) {
        User user = getById(userId);
        if (user == null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "用户不存在");
        }

        // 更新用户状态为已删除
        User updateUser = new User();
        updateUser.setId(userId);
        updateUser.setUsername(user.getUsername()+"is_deleted-"+UUID.randomUUID());
        updateUser.setIsDeleted(1);
        updateUser.setLastUpdatedTime(LocalDateTime.now());

        if (updateById(updateUser)) {
            return Resp.success("账号注销成功");
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR, "账号注销失败");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void incrementFollowCount(Long userId) {
        // 使用SQL直接更新以避免并发问题
        LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(User::getId, userId)
                .setSql("follow_count = follow_count + 1");
        update(updateWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decrementFollowCount(Long userId) {
        LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(User::getId, userId)
                .setSql("follow_count = GREATEST(follow_count - 1, 0)"); // 确保不会小于0
        update(updateWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void incrementFansCount(Long userId) {
        LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(User::getId, userId)
                .setSql("fans_count = fans_count + 1");
        update(updateWrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decrementFansCount(Long userId) {
        LambdaUpdateWrapper<User> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(User::getId, userId)
                .setSql("fans_count = GREATEST(fans_count - 1, 0)"); // 确保不会小于0
        update(updateWrapper);
    }

    @Override
    public boolean checkUserExists(Long userId) {
        if (userId == null) {
            return false;
        }
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getId, userId)
                .eq(User::getIsDeleted, 0); // 只检查未删除的用户
        return count(queryWrapper) > 0;
    }

    @Override
    public Resp<Page<User>> getFolloweeList(Long userId, Page<User> page) {
        return (Resp<Page<User>>) baseMapper.getFolloweeList(userId, page);
    }

    @Override
    public Resp<Page<User>> getFollowerList(Long userId, Page<User> page) {
        return (Resp<Page<User>>) baseMapper.getFollowerList(userId, page);
    }

    /**
     * 获取用户的粉丝详情列表
     * @param userId 用户ID
     * @return List<UserFollowDetailVO>
     */
    @Override
    public List<UserFollowDetailVO> getFollowers(Long userId) {
        return userMapper.getFollowersDetails(userId);
    }

    /**
     * 获取用户的关注详情列表
     * @param userId 用户ID
     * @return List<UserFollowDetailVO>
     */
    @Override
    public List<UserFollowDetailVO> getFollowing(Long userId) {
        return userMapper.getFollowingDetails(userId);
    }

    /**
     * 获取用户的关注者和被关注者统计
     * @param userId 用户ID
     * @return Map<String, Integer>
     */
    @Override
    public Map<String, Integer> getFollowStats(Long userId) {
        return userMapper.getFollowStatistics(userId);
    }

    /**
     * 一次性获取用户的关注者、被关注者详情以及统计信息
     * @param userId 用户ID
     * @return List<Map<String, Object>>
     */
    @Override
    public List<Map<String, Object>> getAllFollowDetails(Long userId) {
        return userMapper.getFollowDetailsAndStats(userId);
    }

    @Override
    public Long getUserIdByUsername(String username) {
        log.info("根据用户名获取用户ID, username: {}", username);
        try {
            // 构建查询条件
            LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(User::getUsername, username)
                  .eq(User::getIsDeleted, 0)
                  .select(User::getId);

            // 查询用户
            User user = getOne(wrapper);
            return user != null ? user.getId() : null;
        } catch (Exception e) {
            log.error("查询用户ID失败", e);
            return null;
        }
    }


    @Override
    public Resp<Object> createUser(User user1) {
        if (selectUserByUsername(user1.getUsername()) != null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "用户名已存在");
        }

        // 检查手机号是否已存在
        if (selectUserByPhoneNumber(user1.getPhoneNumber()) != null) {
            return Resp.error(HttpStatus.BAD_REQUEST, "手机号已被注册");
        }

        // 生成盐值
        String salt = UUID.randomUUID().toString().replace("-", "");

        // 创建新用户
        User user = new User();
        user.setUsername(user1.getUsername());
        user.setPhoneNumber(user1.getPhoneNumber());
        // 将密码和盐值组合后进行加密
        user.setPassword(passwordEncoder.encode(user1.getPassword() + salt));
        user.setSalt(salt);
        user.setRegistrationTime(LocalDateTime.now());
        user.setLastUpdatedTime(LocalDateTime.now());
        user.setIsDeleted(0);
        user.setIsAdmin(0);
        user.setIsFrozen(0);
        user.setPermissionLevel(0);
        //默认审核通过
        user.setReviewStatus(1);
        user.setFollowersCount(0);
        user.setFollowingCount(0);



        // 保存用户
        if (save(user)) {
            try {
                // 创建默认收藏夹
                FavoriteFolder defaultFavorite = new FavoriteFolder();
                defaultFavorite.setUserId(user.getId());
                defaultFavorite.setFolderName("默认收藏夹");
                defaultFavorite.setVisibility(1);
                defaultFavorite.setCreationTime(LocalDateTime.now());
                defaultFavorite.setIsDeleted(0);
                favoriteFolderService.save(defaultFavorite);

                // 创建欢迎通知
                Notification welcomeNotification = new Notification();
                welcomeNotification.setUserReceiverId(user.getId());
                welcomeNotification.setType(3);  // 系统通知
                welcomeNotification.setTitle("欢迎加入");
                welcomeNotification.setContent("欢迎加入我们的平台！我们已为您创建了默认收藏夹，开始您的收藏之旅吧。");
                welcomeNotification.setCreationTime(LocalDateTime.now());
                welcomeNotification.setStatus(0);  // 未读
                welcomeNotification.setIsDeleted(0);
                notificationService.save(welcomeNotification);

                return Resp.success(user);
            } catch (Exception e) {
                log.error("创建默认收藏夹或欢迎通知失败", e);
                throw new RuntimeException("注册过程中发生错误", e);
            }
        } else {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "注册失败");
        }
    }

    @Override
    public int deleteUser(Long id) {
        User user = new User();
        user.setId(id);
        user.setIsDeleted(1);
        return userMapper.updateById(user);

    }

    @Override
    public int updateUser(Long userId, Map<String, Object> updates) {
        return userMapper.updateUser(userId, updates);  // 调用 Mapper 的动态更新方法
    }

    @Override
    public User getUserById(Long id) {
        return userMapper.findById(id);
    }

    @Override
    public User getUserByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    public Page<User> getAllUsers(int page, int size){
        Page<User> userPage = new Page<>(page, size);
        return userMapper.allUser(userPage);
    }

    @Override
    public Page<User> getUsersByPage(int pageNum, int pageSize, String orderByColumn, String sort, String username, String email) {
        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<>();

        // 使用 Lambda 查询条件
        if (StringUtils.isNotBlank(username)) {
            lambdaQueryWrapper.like(User::getUsername, username);
        }

        if (StringUtils.isNotBlank(email)) {
            lambdaQueryWrapper.like(User::getEmail, email);
        }

        // 排序
        if ("desc".equalsIgnoreCase(sort)) {
            if ("username".equalsIgnoreCase(orderByColumn)) {
                lambdaQueryWrapper.orderByDesc(User::getUsername);
            } else if ("email".equalsIgnoreCase(orderByColumn)) {
                lambdaQueryWrapper.orderByDesc(User::getEmail);
            } else {
                lambdaQueryWrapper.orderByDesc(User::getId);
            }
        } else {
            if ("username".equalsIgnoreCase(orderByColumn)) {
                lambdaQueryWrapper.orderByAsc(User::getUsername);
            } else if ("email".equalsIgnoreCase(orderByColumn)) {
                lambdaQueryWrapper.orderByAsc(User::getEmail);
            } else {
                lambdaQueryWrapper.orderByAsc(User::getId);
            }
        }


        // 创建分页对象
        Page<User> page = new Page<>(pageNum, pageSize);


        // 执行分页查询
        return userMapper.selectPage(page, lambdaQueryWrapper);
    }

//    @Override
//    public Page<User> getUsersByPage(int pageNum, int pageSize, String orderByColumn, String sort) {
//        Page<User> page = new Page<>(pageNum, pageSize);
//        return page.setRecords(userMapper.findByPage(page, orderByColumn, sort));
//    }
    // 分页查询方法-新

//    public Page<User> getUsersByPage(int pageNum, int pageSize, String orderByColumn, String sort, String username, String email) {
//        LambdaQueryWrapper<User> lambdaQueryWrapper = new LambdaQueryWrapper<>();
//
//        // 使用 Lambda 查询条件
//        if (username != null) {
//            lambdaQueryWrapper.like(User::getUsername, username);
//        }
//
//        if (email != null) {
//            lambdaQueryWrapper.like(User::getEmail, email);
//        }
//
//        // 排序
//        if ("desc".equalsIgnoreCase(sort)) {
//            if ("username".equalsIgnoreCase(orderByColumn)) {
//                lambdaQueryWrapper.orderByDesc(User::getUsername);
//            } else if ("email".equalsIgnoreCase(orderByColumn)) {
//                lambdaQueryWrapper.orderByDesc(User::getEmail);
//            } else {
//                lambdaQueryWrapper.orderByDesc(User::getId);
//            }
//        } else {
//            if ("username".equalsIgnoreCase(orderByColumn)) {
//                lambdaQueryWrapper.orderByAsc(User::getUsername);
//            } else if ("email".equalsIgnoreCase(orderByColumn)) {
//                lambdaQueryWrapper.orderByAsc(User::getEmail);
//            } else {
//                lambdaQueryWrapper.orderByAsc(User::getId);
//            }
//        }
//
//        // 创建分页对象
//        Page<User> page = new Page<>(pageNum, pageSize);
//
//        // 执行分页查询
//        return userMapper.selectPage(page, lambdaQueryWrapper);
//    }


    @Override
    public boolean updateFrozenStatus(Long id, Integer isFrozen) {
        User user = new User();
        user.setId(id);
        user.setIsFrozen(isFrozen);
        return updateById(user);
    }

    @Override
    public boolean updatePermissionLevel(Long id, Integer permissionLevel) {
        User user = new User();
        user.setId(id);
        user.setPermissionLevel(permissionLevel);
        return updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Boolean> warnUser(Long userId) {
        try {
            User user = getById(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }

            // 创建警告通知
            Notification notification = new Notification();
            notification.setUserReceiverId(userId);
            notification.setType(3); // 系统通知
            notification.setTitle("系统警告");
            notification.setContent("您的账号因违规行为收到一次警告，请遵守社区规范。");
            notification.setCreationTime(LocalDateTime.now());
            notification.setStatus(0); // 未读
            notification.setIsDeleted(0);

            notificationService.save(notification);
            return Resp.success(true);
        } catch (Exception e) {
            log.error("警告用户失败, userId: {}", userId, e);
            throw new RuntimeException("警告用户失败", e);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Boolean> muteUser(Long userId) {
        try {
            User user = getById(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }

            // 更新用户权限等级为禁止评论
            User updateUser = new User();
            updateUser.setId(userId);
            updateUser.setPermissionLevel(1); // 1: 禁止评论
            updateUser.setLastUpdatedTime(LocalDateTime.now());

            if (!updateById(updateUser)) {
                throw new RuntimeException("更新用户权限失败");
            }

            // 创建禁言通知
            Notification notification = new Notification();
            notification.setUserReceiverId(userId);
            notification.setType(3); // 系统通知
            notification.setTitle("账号禁言");
            notification.setContent("您的账号因违规行为被禁言，禁言期间将无法发表评论。");
            notification.setCreationTime(LocalDateTime.now());
            notification.setStatus(0); // 未读
            notification.setIsDeleted(0);

            notificationService.save(notification);
            return Resp.success(true);
        } catch (Exception e) {
            log.error("禁言用户失败, userId: {}", userId, e);
            throw new RuntimeException("禁言用户失败", e);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Boolean> banUser(Long userId) {
        try {
            User user = getById(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }

            // 更新用户为冻结状态
            User updateUser = new User();
            updateUser.setId(userId);
            updateUser.setIsFrozen(1); // 1: 已冻结
            updateUser.setLastUpdatedTime(LocalDateTime.now());

            if (!updateById(updateUser)) {
                throw new RuntimeException("更新用户状态失败");
            }

            // 创建封禁通知
            Notification notification = new Notification();
            notification.setUserReceiverId(userId);
            notification.setType(3); // 系统通知
            notification.setTitle("账号封禁");
            notification.setContent("您的账号因严重违规行为被封禁，封禁期间将无法使用账号。");
            notification.setCreationTime(LocalDateTime.now());
            notification.setStatus(0); // 未读
            notification.setIsDeleted(0);

            notificationService.save(notification);
            return Resp.success(true);
        } catch (Exception e) {
            log.error("封禁用户失败, userId: {}", userId, e);
            throw new RuntimeException("封禁用户失败", e);
        }
    }

    @Override
    public Resp<User> getUser(Long userId) {
        try {
            User user = getById(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }
            return Resp.success(user);
        } catch (Exception e) {
            log.error("获取用户信息失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取用户信息失败");
        }
    }

    @Override
    public boolean addUser(UserCreateDTO user) {
        try {
            User newUser = new User();
            BeanUtils.copyProperties(user, newUser);
            return save(newUser);
        }catch (Exception e) {
            log.error("添加用户失败, user: {}", user, e);
            return false; // 添加失败
        }
    }
}
