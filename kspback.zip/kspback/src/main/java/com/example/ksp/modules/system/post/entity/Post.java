package com.example.ksp.modules.system.post.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
//@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@TableName("post")
@Schema(description = "帖子实体类")
public class Post {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "主键，唯一标识一个帖子，自增")
    private Long id;

    @Schema(description = "关联用户表的id，发布帖子的用户ID")
    private Long userId;

    @Schema(description = "关联分区表的id，帖子所属的分区ID")
    private Long sectionId;

    @Schema(description = "帖子的标签，用于分类和搜索，可以是多个标签的字符串，例如 \"标签1, 标签2\"")
    private String tags;

    @Schema(description = "帖子封面图片的路径或URL")
    private String cover;

    @Schema(description = "帖子内容的简短描述，用于快速预览")
    private String summary;



    @Schema(description = "帖子中引用的其他内容或来源的详细信息")
    @JsonRawValue  // 在序列化时直接输出原始JSON字符串
    @JsonDeserialize()
    private String citation;

    @Schema(description = "关联合集表的id，帖子所属的合集ID")
    private Long collectionId;

    @Schema(description = "帖子的标题")
    private String title;

    @Schema(description = "minio的文件id，用于标识富文本内容的文件")
    private String contentFileId;

    @Schema(description = "minio文件的路径，指向富文本内容的文件")
    private String contentFilePath;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "帖子发布的时间")
    private LocalDateTime publishTime;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "帖子最后一次更新的时间")
    private LocalDateTime updateTime;

    @Schema(description = "帖子被浏览的次数")
    private Integer viewCount;

    @Schema(description = "帖子下的评论数量")
    private Integer commentCount;

    @Schema(description = "帖子获得的点赞数量")
    private Integer likeCount;

    @Schema(description = "帖子被分享的次数")
    private Integer shareCount;

    @Schema(description = "帖子的状态，1表示已发布，0表示草稿")
    private Integer status;

    @Schema(description = "区分位，表示帖子是否被置顶显示，1表示是，0表示否")
    private Integer isPinned;

    @Schema(description = "区分位，表示帖子是否被标记为精华，1表示是，0表示否")
    private Integer isEssence;

    @Schema(description = "定义谁可以查看帖子，0：自己；1：公开")
    private Integer visibility;

    @Schema(description = "审核状态，0-待审核，1-已通过，2-已拒绝")
    private Integer reviewStatus;

    @Schema(description = "逻辑删除字段，1表示已删除，0表示未删除")
    private Integer isDeleted;
}