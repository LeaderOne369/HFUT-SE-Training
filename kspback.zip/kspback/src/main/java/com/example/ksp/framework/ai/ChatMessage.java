package com.example.ksp.framework.ai;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "AI对话消息")
public class ChatMessage {

    @Schema(description = "消息角色(system/user/assistant)")
    private Role role;

    @Schema(description = "消息内容")
    private String content;

    public enum Role {
        SYSTEM,
        USER,
        ASSISTANT;

        @Override
        public String toString() {
            return name().toLowerCase();
        }
    }

    /**
     * 创建系统消息
     */
    public static ChatMessage systemMessage(String content) {
        return ChatMessage.builder()
                .role(Role.SYSTEM)
                .content(content)
                .build();
    }

    /**
     * 创建用户消息
     */
    public static ChatMessage userMessage(String content) {
        return ChatMessage.builder()
                .role(Role.USER)
                .content(content)
                .build();
    }

    /**
     * 创建助手消息
     */
    public static ChatMessage assistantMessage(String content) {
        return ChatMessage.builder()
                .role(Role.ASSISTANT)
                .content(content)
                .build();
    }

    /**
     * 构建对话历史
     */
    @Builder
    public static class ChatHistory {
        @Builder.Default
        private List<ChatMessage> messages = new ArrayList<>();

        /**
         * 添加系统消息
         */
        public ChatHistory addSystemMessage(String content) {
            messages.add(systemMessage(content));
            return this;
        }

        /**
         * 添加用户消息
         */
        public ChatHistory addUserMessage(String content) {
            messages.add(userMessage(content));
            return this;
        }

        /**
         * 添加助手消息
         */
        public ChatHistory addAssistantMessage(String content) {
            messages.add(assistantMessage(content));
            return this;
        }

        /**
         * 获取消息列表
         */
        public List<ChatMessage> getMessages() {
            return messages;
        }

        /**
         * 清空消息历史
         */
        public void clear() {
            messages.clear();
        }
    }
} 