package com.example.ksp.modules.client.clientlogin.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.clientlogin.dto.ClientLoginDTO;
import com.example.ksp.modules.client.clientlogin.dto.ClientRegisterDTO;
import com.example.ksp.modules.client.clientlogin.dto.ForgetPasswordDTO;
import com.example.ksp.modules.client.clientlogin.dto.ChangePasswordDTO;
import com.example.ksp.modules.client.clientlogin.dto.DeactivateAccountDTO;
import java.util.Map;

public interface ClientLoginService {
    /**
     * 客户端用户登录
     * @param clientLoginDTO 登录信息
     * @return 登录结果（包含token和用户信息）
     */
    Resp<Map<String, Object>> login(ClientLoginDTO clientLoginDTO);

    /**
     * 获取当前登录用户信息
     */
    Resp<Map<String, Object>> getLoginInfo();

    /**
     * 退出登录
     */
    Resp<Void> logout();

    /**
     * 刷新Token
     */
    Resp<Map<String, String>> refreshToken();

    /**
     * 检查Token有效性
     */
    Resp<Boolean> checkToken(String token);

    /**
     * 获取IP地址信息
     * @param ip IP地址，如果为空则获取当前请求的IP地址
     */
    Resp<Map<String, String>> getIpInfo(String ip);

    /**
     * 用户注册
     */
    Resp<String> register(ClientRegisterDTO registerDTO);

    /**
     * 忘记密码
     */
    Resp<String> forgetPassword(ForgetPasswordDTO forgetPasswordDTO);

    /**
     * 修改密码
     */
    Resp<String> changePassword(ChangePasswordDTO changePasswordDTO);

    /**
     * 账号注销
     */
    Resp<String> deactivateAccount(DeactivateAccountDTO deactivateDTO);

    /**
     * 发送验证码
     * @param phoneNumber 手机号码
     * @return 发送结果
     */
    Resp<String> sendCaptcha(String phoneNumber);
} 