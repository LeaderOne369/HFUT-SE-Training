package com.example.ksp.modules.proxy;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.admin.management.reviewmg.vo.ReviewManageVO;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class ReviewLogProxy {

    private final ReviewLogService reviewLogService;

    private final UserServiceProxy userServiceProxy;

    /**
     * 分页查询审核记录
     */
    public Resp<Page<ReviewManageVO>> queryReviewPage(Integer type, Integer status, Integer page, Integer size) {
        try {
            Page<ReviewLog> pageParam = new Page<>(page, size);
            LambdaQueryWrapper<ReviewLog> wrapper = new LambdaQueryWrapper<ReviewLog>()
                .eq(type != null, ReviewLog::getContentType, type)
                .eq(status != null, ReviewLog::getReviewStatus, status)
                .orderByDesc(ReviewLog::getReviewTime);
                
            Page<ReviewLog> pageResult = reviewLogService.page(pageParam, wrapper);
            
            // 转换结果
            Page<ReviewManageVO> voPage = new Page<>(page, size, pageResult.getTotal());
            List<ReviewManageVO> voList = pageResult.getRecords().stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());
            voPage.setRecords(voList);
            
            return Resp.success(voPage);
        } catch (Exception e) {
            log.error("查询审核记录失败: ", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "查询审核记录失败");
        }
    }

    /**
     * 获取审核详情
     */
    public Resp<ReviewManageVO> getReviewDetail(Long id) {
        try {
            ReviewLog reviewLog = reviewLogService.getById(id);
            if (reviewLog == null) {
                return Resp.error(HttpStatus.NOT_FOUND, "审核记录不存在");
            }
            return Resp.success(convertToVO(reviewLog));
        } catch (Exception e) {
            log.error("获取审核详情失败: ", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取审核详情失败");
        }
    }

    /**
     * 处理审核
     */
    @Transactional(rollbackFor = Exception.class)
    public Resp<Void> handleReview(Long id, Integer status, String reason) {
        try {
            ReviewLog reviewLog = reviewLogService.getById(id);
            if (reviewLog == null) {
                return Resp.error(HttpStatus.NOT_FOUND, "审核记录不存在");
            }
            
            ReviewLog update = new ReviewLog();
            update.setId(id);
            update.setReviewStatus(status);
            update.setReviewNotes(reason);
            update.setReviewTime(LocalDateTime.now());
            update.setReviewerId(getUserId());
            boolean success = reviewLogService.updateById(update);
            if (!success) {
                return Resp.error(HttpStatus.BAD_REQUEST, "处理审核失败");
            }
            return Resp.success(null);
        } catch (Exception e) {
            log.error("处理审核失败: ", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "处理审核失败");
        }
    }

    private Long getUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    /**
     * 将 ReviewLog 转换为 ReviewManageVO
     */
    private ReviewManageVO convertToVO(ReviewLog reviewLog) {
        if (reviewLog == null) {
            return null;
        }
        ReviewManageVO vo = new ReviewManageVO();
        BeanUtils.copyProperties(reviewLog, vo);
        Long reviewerId = reviewLog.getReviewerId();
        String username = userServiceProxy.getUser(reviewerId).getData().getUsername();
        vo.setReviewerName(username);
        return vo;
    }
} 