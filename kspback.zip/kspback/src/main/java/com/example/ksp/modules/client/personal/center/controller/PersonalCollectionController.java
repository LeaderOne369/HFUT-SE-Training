package com.example.ksp.modules.client.personal.center.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.personal.center.dto.CreateCollectionDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalCollectionService;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端个人中心个人合集管理")
@RestController
@RequestMapping("/api/client/personal/collection")
@RequiredArgsConstructor
public class PersonalCollectionController {

    private final PersonalCollectionService personalCollectionService;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    @Operation(summary = "获取我创建的合集列表")
    @GetMapping("/created")
    public Resp<Page<Collection>> getMyCollections(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalCollectionService.getUserCollections(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取我订阅的合集列表")
    @GetMapping("/subscribed")
    public Resp<Page<Collection>> getSubscribedCollections(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalCollectionService.getSubscribedCollections(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取合集详情")
    @GetMapping("/{collectionId}")
    public Resp<Collection> getCollectionDetail(@PathVariable Long collectionId) {
        return personalCollectionService.getCollectionDetail(getCurrentUserId(), collectionId);
    }

    @Operation(summary = "更新合集")
    @PutMapping
    public Resp<Collection> updateCollection(@RequestBody CollectionUpdateDTO updateDTO) {
        return personalCollectionService.updateCollection(getCurrentUserId(), updateDTO);
    }


    @Operation(summary = "增加合集")
    @PutMapping("/add")
    public Resp<Collection> createCollection(@RequestBody CreateCollectionDTO createDTO) {
        return personalCollectionService.createCollection(getCurrentUserId(), createDTO);
    }
    @Operation(summary = "删除合集")
    @DeleteMapping("/{collectionId}")
    public Resp<Boolean> deleteCollection(@PathVariable Long collectionId) {
        return personalCollectionService.deleteCollection(getCurrentUserId(), collectionId);
    }

    @Operation(summary = "取消订阅合集")
    @DeleteMapping("/subscription/{collectionId}")
    public Resp<Boolean> unsubscribeCollection(@PathVariable Long collectionId) {
        return personalCollectionService.unsubscribeCollection(getCurrentUserId(), collectionId);
    }
} 