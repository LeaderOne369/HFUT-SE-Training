package com.example.ksp.modules.system.share.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建分享请求参数")
public class ShareCreateDTO {
    
    @NotNull(message = "用户ID不能为空")
    @Schema(description = "用户ID")
    private Long userId;
    
    @NotNull(message = "分享对象ID不能为空")
    @Schema(description = "分享对象ID")
    private Long shareObjectId;
    
    @NotNull(message = "分享对象类型不能为空")
    @Schema(description = "分享对象类型(1:帖子 2:合集)")
    private Integer shareObjectType;
} 