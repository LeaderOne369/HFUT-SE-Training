package com.example.ksp.common.variable;

import lombok.Data;

/**
 * @author loself
 * @date 2024-12-31 15:59
 */
@Data
public class Resp<T> {
    /**
     * 响应码 如：200-成功，500-未知异常
     */
    private Integer code;

    /**
     * 异常描述信息
     */
    private String msg;

    /**
     * 返回的数据
     */
    private T data;

    /**
     * 成功
     *
     * @param data 响应数据
     * @return 响应对象
     */
    public static <T> Resp<T> success(T data) {
        Resp<T> result = new Resp<>();
        result.setCode(200);
        result.setData(data);
        return result;
    }

    /**
     * 成功
     * @param msg 提示信息
     * @param data 响应数据
     * @return 响应对象
     */
    public static <T> Resp<T> success(String msg, T data) {
        Resp<T> result = new Resp<>();
        result.setCode(200);
        result.setMsg(msg);
        result.setData(data);
        return result;
    }

    /**
     * 失败
     *
     * @param status HTTP 响应状态
     * @return 响应对象
     */
    public static <T> Resp<T> error(HttpStatus status) {
        Resp<T> result = new Resp<>();
        result.setCode(status.getCode());
        result.setMsg(status.getMsg());
        return result;
    }

    /**
     * 失败
     *
     * @param status HTTP 响应状态
     * @param msg 异常描述信息
     * @return 响应对象
     */
    public static <T> Resp<T> error(HttpStatus status, String msg) {
        Resp<T> result = new Resp<>();
        result.setCode(status.getCode());
        result.setMsg(msg);
        return result;
    }

    public static <T> Resp<T> error(int httpCode, String  msg) {
        Resp<T> result = new Resp<>();
        result.setCode(httpCode);
        result.setMsg(msg);
        return result;
    }
}

