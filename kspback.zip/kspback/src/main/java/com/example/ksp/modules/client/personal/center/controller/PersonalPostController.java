package com.example.ksp.modules.client.personal.center.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.personal.center.service.PersonalPostService;
import com.example.ksp.modules.client.post.postdetail.service.PostDetailService;
import com.example.ksp.modules.client.post.publish.dto.PostPublishDTO;
import com.example.ksp.modules.client.post.publish.service.PostPublishService;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端个人中心个人帖子管理")
@RestController
@RequestMapping("/api/client/personal/post")
@RequiredArgsConstructor
public class PersonalPostController {

    private final PersonalPostService personalPostService;

    private final PostDetailService postDetailService;

    private final PostPublishService postPublishService;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    @Operation(summary = "获取我的帖子列表")
    @GetMapping("/list")
    public Resp<Page<Post>> getMyPosts(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalPostService.getUserPosts(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取帖子详情")
    @GetMapping("/{postId}")
    public Resp<Object> getPostDetail(@PathVariable Long postId, @RequestHeader("token") String token)  {
        return postDetailService.getPostDetail(postId,token);
    }

    @Operation(summary = "更新帖子")
    @PutMapping
    public Resp<Post> updatePost(@RequestBody PostPublishDTO updateDTO,@RequestParam Long postId) {
        return postPublishService.updatePost(postId,updateDTO, getCurrentUserId(),0);
    }

    @Operation(summary = "删除帖子")
    @DeleteMapping("/{postId}")
    public Resp<Boolean> deletePost(@PathVariable Long postId) {
        return personalPostService.deletePost(getCurrentUserId(), postId);
    }
} 