package com.example.ksp.modules.system.user.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.usermg.UserCreateDTO;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.entity.UserFollowDetailVO;

import java.util.List;
import java.util.Map;

/**
 * 用户服务接口
 * @author loself
 * @date 2024-12-31 14:20
 */
public interface UserService extends IService<User> {
    /**
     * 根据手机号查询用户
     * @param phone 手机号
     * @return 用户信息
     */
    User selectUserByPhoneNumber(String phone);

    /**
     * 根据用户名查询用户
     * @param username 用户名
     * @return 用户信息
     */
    User selectUserByUsername(String username);

    /**
     * 更新用户最后登录信息
     * @param user 用户信息
     * @return 是否成功
     */
    boolean updateUserLoginInfo(User user);

    Resp<User> register(RegisterDTO registerDTO);

    /**
     * 用户登录
     * @param loginDTO 登录信息
     * @return 登录结果
     */
    Resp<User> login(LoginDTO loginDTO);

    /**
     * 重置密码
     *
     * @param phoneNumber 手机号
     * @param newPassword 新密码
     * @return 操作结果
     */
    Resp<String> resetPassword(String phoneNumber, String newPassword);

    /**
     * 验证密码
     * @param userId 用户ID
     * @param password 密码
     * @return 是否正确
     */
    boolean verifyPassword(Long userId, String password);

    /**
     * 更新密码
     *
     * @param userId      用户ID
     * @param newPassword 新密码
     * @return 操作结果
     */
    Resp<String> updatePassword(Long userId, String newPassword);

    /**
     * 注销账号
     *
     * @param userId 用户ID
     * @return 操作结果
     */
    Resp<String> deactivateAccount(Long userId);

    // 增加关注数
    void incrementFollowCount(Long userId);

    // 减少关注数
    void decrementFollowCount(Long userId);

    // 增加粉丝数
    void incrementFansCount(Long userId);

    // 减少粉丝数
    void decrementFansCount(Long userId);

    // 检查用户是否存在
    boolean checkUserExists(Long userId);

    Resp<Page<User>> getFolloweeList(Long userId, Page<User> page);

    Resp<Page<User>> getFollowerList(Long userId, Page<User> page);

    /**
     * 获取用户的关注者详情列表（粉丝列表）
     * @param userId 用户ID
     * @return List<UserFollowDetailVO>
     */
    List<UserFollowDetailVO> getFollowers(Long userId);

    /**
     * 获取用户的关注详情列表
     * @param userId 用户ID
     * @return List<UserFollowDetailVO>
     */
    List<UserFollowDetailVO> getFollowing(Long userId);

    /**
     * 获取用户的关注者和被关注者统计
     * @param userId 用户ID
     * @return Map<String, Integer>
     */
    Map<String, Integer> getFollowStats(Long userId);

    /**
     * 一次性获取用户的关注者、被关注者详情以及统计信息
     * @param userId 用户ID
     * @return List<Map<String, Object>>
     */
    List<Map<String, Object>> getAllFollowDetails(Long userId);

    /**
     * 根据用户名获取用户ID
     */
    Long getUserIdByUsername(String username);



    /**
     * 创建新用户
     *
     * @param user 用户对象，包含用户信息
     * @return 影响的行数，通常为1表示成功
     */
    Resp<Object> createUser(User user);

    /**
     * 删除用户
     *
     * @param id 用户ID
     * @return 影响的行数，通常为1表示成功
     */
    int deleteUser(Long id);

    /**
     * 更新用户信息
     *
     * @param userId 用户对象，包含更新后的用户信息
     * @return 影响的行数，通常为1表示成功
     */

    int updateUser(Long userId, Map<String, Object> updates);

    /**
     * 根据用户ID获取用户信息
     *
     * @param id 用户ID
     * @return 用户对象，如果用户不存在则返回null
     */
    User getUserById(Long id);

    /**
     * 根据用户名获取用户信息
     *
     * @param username 用户名
     * @return 用户对象，如果用户不存在则返回null
     */
    User getUserByUsername(String username);

    /**
     * 获取所有用户列表
     *
     * @return 用户列表
     */
    Page<User> getAllUsers(int page, int size);

    // 分页查询方法
    Page<User> getUsersByPage(int pageNum, int pageSize, String orderByColumn, String sort, String username, String email);

    // 修改用户冻结状态
    boolean updateFrozenStatus(Long id, Integer isFrozen);

    // 调整用户权限
    boolean updatePermissionLevel(Long id, Integer permissionLevel);

    /**
     * 警告用户
     */
    Resp<Boolean> warnUser(Long userId);

    /**
     * 禁言用户
     */
    Resp<Boolean> muteUser(Long userId);

    /**
     * 封禁用户
     */
    Resp<Boolean> banUser(Long userId);

    /**
     * 获取用户信息
     */
    Resp<User> getUser(Long userId);


    /**
     * 管理员新建用户
     *
     * @param user 用户信息
     * @return 操作结果
     */
    boolean addUser(UserCreateDTO user);
}
