package com.example.ksp.modules.client.homepage.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.homepage.vo.*;
import java.util.List;

public interface ClientHomePageService {
    
    /**
     * 获取首页数据
     *
     * @param userId 用户ID
     * @return 首页数据视图对象
     */
    Resp<HomePageVO> getHomePageData(Long userId);
    
    /**
     * 获取用户简要信息
     *
     * @param userId 用户ID
     * @return 用户简要信息视图对象
     */
    Resp<UserBriefVO> getUserBrief(Long userId);
    
    /**
     * 获取推荐内容列表
     *
     * @param limit 获取数量限制
     * @return 推荐内容列表
     */
    Resp<List<RecommendContentVO>> getRecommendContents(Integer limit);
    
    /**
     * 获取分区列表
     *
     * @return 分区列表
     */
    Resp<List<SectionVO>> getSections();
    
    /**
     * 获取用户通知列表
     *
     * @param userId 用户ID
     * @param limit 获取数量限制
     * @return 通知列表
     */
    Resp<List<NotificationVO>> getNotifications(Long userId, Integer limit);
} 