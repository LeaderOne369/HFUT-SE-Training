package com.example.ksp.modules.client.homepage.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.homepage.service.ClientHomePageService;
import com.example.ksp.modules.client.homepage.vo.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Tag(name = "客户端首页管理")
@RequestMapping("/api/client/homepage")
@RequiredArgsConstructor
@Validated
public class ClientHomePageController {

    private final ClientHomePageService homePageService;

    private Long getCurrentUserId() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof LoginUser) {
            LoginUser loginUser = (LoginUser) principal;
            return loginUser.getXxuser().getId();
        }
        return null;
    }

    @Operation(summary = "获取首页数据", description = "获取首页所需的所有数据，包括用户信息、推荐内容、分区和通知")
    @GetMapping
    public Resp<HomePageVO> getHomePageData() {
        Long userId = getCurrentUserId();
        return homePageService.getHomePageData(userId);
    }

    @Operation(summary = "获取用户简要信息", description = "获取当前登录用户的简要信息")
    @GetMapping("/user-brief")
    public Resp<UserBriefVO> getUserBrief() {
        Long userId = getCurrentUserId();
        return homePageService.getUserBrief(userId);
    }

    @Operation(summary = "获取推荐内容", description = "获取首页推荐内容列表")
    @GetMapping("/recommend")
    @Parameter(name = "limit", description = "获取数量限制", example = "10")
    public Resp<List<RecommendContentVO>> getRecommendContents(@RequestParam(defaultValue = "10") Integer limit) {
        return homePageService.getRecommendContents(limit);
    }

    @Operation(summary = "获取分区列表", description = "获取所有可用分区信息")
    @GetMapping("/sections")
    public Resp<List<SectionVO>> getSections() {
        return homePageService.getSections();
    }

    @Operation(summary = "获取通知列表", description = "获取当前用户的通知消息")
    @GetMapping("/notifications")
    @Parameter(name = "limit", description = "获取数量限制", example = "20")
    public Resp<List<NotificationVO>> getNotifications(@RequestParam(defaultValue = "20") Integer limit) {
        Long userId = getCurrentUserId();
        return homePageService.getNotifications(userId, limit);
    }
} 