package com.example.ksp.modules.system.favoritefolder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FavoriteFolderMapper extends BaseMapper<FavoriteFolder> {
} 