package com.example.ksp.modules.system.collection.collectionsubs.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "合集订阅查询参数")
public class CollectionSubscriptionsQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "用户ID")
    private Long usersId;
    
    @Schema(description = "合集ID")
    private Long collectionsId;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 