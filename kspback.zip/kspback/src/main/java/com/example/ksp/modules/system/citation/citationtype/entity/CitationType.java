package com.example.ksp.modules.system.citation.citationtype.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@TableName("citation_type")
@Schema(description = "引用类型实体")
public class CitationType {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "引用类型ID")
    private Long id;
    
    @Schema(description = "引用类型名称")
    private String typeName;
    
    @Schema(description = "引用类型描述")
    private String typeDescription;
    
    @Schema(description = "是否启用(1:启用 0:未启用)")
    private Integer isActive;
} 