package com.example.ksp.framework.ai;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@Schema(description = "AI聊天请求参数")
public class ChatRequestDTO  {
    
    @Schema(description = "对话消息列表")
    private List<Message> messages;
    
    @Schema(description = "模型名称")
    private String model;
    
    @Schema(description = "频率惩罚参数")
    @JsonProperty("frequency_penalty")
    private Double frequencyPenalty;
    
    @Schema(description = "最大token数")
    @JsonProperty("max_tokens")
    private Integer maxTokens;
    
    @Schema(description = "存在惩罚参数")
    @JsonProperty("presence_penalty")
    private Double presencePenalty;
    
    @Schema(description = "响应格式配置")
    @JsonProperty("response_format")
    private ResponseFormat responseFormat;
    
    @Schema(description = "停止标记")
    private Object stop;
    
    @Schema(description = "是否流式响应")
    private Boolean stream;
    
    @Schema(description = "流式响应选项")
    @JsonProperty("stream_options")
    private Object streamOptions;
    
    @Schema(description = "温度参数")
    private Double temperature;
    
    @Schema(description = "top_p参数")
    @JsonProperty("top_p")
    private Double topP;
    
    @Schema(description = "可用工具列表")
    private Object tools;
    
    @Schema(description = "工具选择")
    @JsonProperty("tool_choice")
    private String toolChoice;
    
    @Schema(description = "是否返回日志概率")
    private Boolean logprobs;
    
    @Schema(description = "top日志概率")
    @JsonProperty("top_logprobs")
    private Object topLogprobs;
    
    @Data
    @Builder
    public static class Message {
        @Schema(description = "消息内容")
        private String content;
        
        @Schema(description = "角色(system/user/assistant)")
        private String role;
    }
    
    @Data
    @Builder
    public static class ResponseFormat {
        @Schema(description = "响应类型")
        private String type;
    }
}
