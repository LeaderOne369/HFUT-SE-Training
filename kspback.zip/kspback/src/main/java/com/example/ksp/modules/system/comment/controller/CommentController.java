package com.example.ksp.modules.system.comment.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.comment.service.CommentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级评论管理")
@RestController
@RequestMapping("/api/system/comment")
@RequiredArgsConstructor
public class CommentController {

    private final CommentService commentService;

    @Operation(summary = "创建评论")
    @PostMapping
    public Resp<Comment> createComment(
            @RequestHeader("token") String token,
            @RequestBody @Valid CommentCreateDTO createDTO) {
        return commentService.createComment(createDTO);
    }

    @Operation(summary = "删除评论")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteComment(
            @RequestHeader("token") String token,
            @Parameter(description = "评论ID") 
            @PathVariable Long id) {
        return commentService.deleteComment(id);
    }

    @Operation(summary = "获取评论详情")
    @GetMapping("/{id}")
    public Resp<Comment> getComment(
            @RequestHeader("token") String token,
            @Parameter(description = "评论ID") 
            @PathVariable Long id) {
        return commentService.getComment(id);
    }

    @Operation(summary = "查询评论列表")
    @PostMapping("/list")
    public Resp<Page<Comment>> queryComments(
            @RequestHeader("token") String token,
            @RequestBody CommentQueryDTO queryDTO) {
        return commentService.queryComments(queryDTO);
    }

    @Operation(summary = "更新评论审核状态")
    @PutMapping("/{id}/review-status/{status}")
    public Resp<String> updateReviewStatus(
            @RequestHeader("token") String token,
            @Parameter(description = "评论ID") 
            @PathVariable Long id,
            @Parameter(description = "审核状态(0:待审核 1:已通过 2:已拒绝)") 
            @PathVariable Integer status) {
        return commentService.updateReviewStatus(id, status);
    }
} 