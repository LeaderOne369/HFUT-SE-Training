package com.example.ksp.modules.admin.management.reviewmg.controller;
import java.util.*;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.admin.management.reviewmg.service.ReviewManageService;
import com.example.ksp.modules.admin.management.reviewmg.vo.ReviewManageVO;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reviewmg.dto.ReviewManageDTO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.security.access.prepost.PreAuthorize;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "管理端审核管理接口")
@RestController
@RequestMapping("/api/admin/management/review")
@RequiredArgsConstructor
public class ReviewManageController {
    
    private final ReviewManageService reviewManageService;
    
    @Operation(summary = "获取审核列表")
    @GetMapping("/list")
    public Resp<Page<ReviewManageVO>> getReviewList(
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer size) {
        return reviewManageService.queryReviewPage(type, status, page, size);
    }
    
    @Operation(summary = "获取审核详情")
    @GetMapping("/{reviewId}")
    public Resp<ReviewManageVO> getReviewDetail(
            @Parameter(description = "审核ID")
            @PathVariable Long reviewId) {
        return reviewManageService.getReviewDetail(reviewId);
    }



    @Operation(summary = "处理审核")
    @PostMapping("/handle")
    public Resp<Void> handleReview(@RequestBody @Valid ReviewManageDTO dto) {
        return reviewManageService.handleReview(dto.getId(), dto.getStatus(), dto.getReason());
    }
    

} 