package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favorite.service.FavoriteService;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import com.example.ksp.modules.system.favoritefolder.service.FavoriteFolderService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Component;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.CharacterData;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class FavoriteServiceProxy {

    private final FavoriteService favoriteService;
    private final FavoriteFolderService favoriteFolderService;

    /**
     * 添加收藏
     */
    public Resp<Boolean> addFavorite(Long userId, Long postId, Long folderId) {
        boolean result = favoriteService.addFavorite(userId, postId, folderId);
        return Resp.success(result);
    }

    /**
     * 取消收藏
     */
    public Resp<Boolean> cancelFavorite(Long userId, Long postId) {
        boolean result = favoriteService.cancelFavorite(userId, postId);
        return Resp.success(result);
    }

    /**
     * 移动收藏到其他收藏夹
     */
    public Resp<Boolean> moveFavorite(Long id, Long newFolderId) {
        boolean result = favoriteService.moveFavorite(id, newFolderId);
        return Resp.success(result);
    }

    /**
     * 获取用户的收藏列表
     */
    public Resp<Page<Favorite>> getUserFavorites(Long userId, Long folderId, long current, long size) {
        Page<Favorite> favorites = favoriteService.getUserFavorites(userId, folderId, current, size);
        return Resp.success(favorites);
    }

    /**
     * 获取帖子的收藏数量
     */
    public Resp<Long> getPostFavoriteCount(Long postId) {
        long count = favoriteService.getPostFavoriteCount(postId);
        return Resp.success(count);
    }

    /**
     * 检查用户是否已收藏帖子
     */
    public Resp<Boolean> checkFavorite(Long userId, Long postId) {
        boolean result = favoriteService.checkFavorite(userId, postId);
        return Resp.success(result);
    }

    /**
     * 批量移动收藏
     */
    public Resp<Boolean> batchMoveFavorites(Long[] ids, Long newFolderId) {
        boolean result = favoriteService.batchMoveFavorites(ids, newFolderId);
        return Resp.success(result);
    }

    /**
     * 获取用户收到的收藏数量
     */
    public Resp<Integer> getReceivedFavoriteCount(Long userId) {
        log.info("代理层：获取用户收到的收藏数量，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return favoriteService.getReceivedFavoriteCount(userId);
        } catch (Exception e) {
            log.error("获取用户收到的收藏数量失败", e);
            return Resp.error(500, "获取收藏数量失败");
        }
    }

    /**
     * 判断用户是否收藏帖子
     *
     * @param postId 帖子ID
     * @param objectType 对象类型（固定为1）
     * @param userId 用户ID
     * @return 是否已收藏
     */
    public Resp<Boolean> isFavorited(Long postId, Integer objectType, Long userId) {
        log.info("代理层：判断用户是否收藏帖子，用户ID: {}, 帖子ID: {}", userId, postId);
        if (userId == null || userId <= 0 || postId == null || postId <= 0) {
            return Resp.error(400, "用户ID或帖子ID无效");
        }

        try {
            boolean isFavorited = favoriteService.checkFavorite(userId, postId);
            return Resp.success(isFavorited);
        } catch (Exception e) {
            log.error("检查帖子收藏状态失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "检查收藏状态失败");
        }
    }

    /**
     * 获取帖子的收藏数量
     *
     * @param postId 帖子ID
     * @param objectType 对象类型（固定为1）
     * @return 收藏数量
     */
    public Resp<Integer> getFavoriteCount(Long postId, Integer objectType) {
        log.info("代理层：获取帖子收藏数量，帖子ID: {}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(400, "帖子ID无效");
        }

        try {
            long count = favoriteService.getPostFavoriteCount(postId);
            return Resp.success((int) count);
        } catch (Exception e) {
            log.error("获取帖子收藏数量失败, postId: {}", postId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏数量失败");
        }
    }

    /**
     * 创建收藏夹
     */
    public Resp<FavoriteFolder> createFolder(FavoriteFolder folder) {
        try {
            boolean result = favoriteFolderService.createFolder(folder);
            if (result) {
                return Resp.success(folder);
            } else {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建收藏夹失败");
            }
        } catch (Exception e) {
            log.error("创建收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建收藏夹失败");
        }
    }

    /**
     * 根据ID获取收藏夹
     */
    public Resp<FavoriteFolder> getFolderById(Long id) {
        try {
            FavoriteFolder folder = favoriteFolderService.getById(id);
            if (folder != null) {
                return Resp.success(folder);
            } else {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "收藏夹不存在");
            }
        } catch (Exception e) {
            log.error("获取收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏夹失败");
        }
    }

    /**
     * 更新收藏夹
     */
    public Resp<Boolean> updateFolder(FavoriteFolder folder) {
        try {
            boolean result = favoriteFolderService.updateFolder(folder);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("更新收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新收藏夹失败");
        }
    }

    /**
     * 删除收藏夹
     */
    public Resp<Boolean> deleteFolder(Long folderId) {
        try {
            boolean result = favoriteFolderService.deleteFolder(folderId);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("删除收藏夹失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除收藏夹失败");
        }
    }

    /**
     * 获取用户的收藏夹列表
     */
    public Resp<Page<FavoriteFolder>> getUserFolders(Long userId, long current, long size) {
        try {
            Page<FavoriteFolder> folders = favoriteFolderService.getUserFolders(userId, current, size);
            return Resp.success(folders);
        } catch (Exception e) {
            log.error("获取用户收藏夹列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏夹列表失败");
        }
    }

    /**
     * 根据ID获取收藏
     */
    public Resp<Favorite> getFavoriteById(Long favoriteId) {
        try {
            Favorite favorite = favoriteService.getById(favoriteId);
            if (favorite != null) {
                return Resp.success(favorite);
            } else {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "收藏不存在");
            }
        } catch (Exception e) {
            log.error("获取收藏失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取收藏失败");
        }
    }

    /**
     * 删除收藏
     */
    public Resp<Boolean> deleteFavorite(Long favoriteId) {
        try {
            boolean result = favoriteService.removeById(favoriteId);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("删除收藏失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除收藏失败");
        }
    }

    /**
     * 更新收藏夹可见性
     */
    public Resp<Boolean> updateFolderVisibility(Long folderId, Integer visibility) {
        try {
            boolean result = favoriteFolderService.updateVisibility(folderId, visibility);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("更新收藏夹可见性失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新收藏夹可见性失败");
        }
    }

    /**
     * 更新收藏夹审核状态
     */
    public Resp<Boolean> updateFolderReviewStatus(Long folderId, Integer status) {
        try {
            boolean result = favoriteFolderService.updateReviewStatus(folderId, status);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("更新收藏夹审核状态失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新收藏夹审核状态失败");
        }
    }
}
