package com.example.ksp.modules.client.post.postdetail.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;
import com.example.ksp.modules.client.post.postdetail.dto.PostStatsDTO;
import com.example.ksp.modules.client.post.postdetail.service.PostDetailService;
import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "客户端帖子详情接口")
@RestController
@RequestMapping("/api/client/post-detail")
@RequiredArgsConstructor
public class PostDetailController {

    private final PostDetailService postDetailService;

    @Operation(summary = "获取帖子统计信息")
    @GetMapping("/{postId}/stats")
    public Resp<PostStatsDTO> getPostStats(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token) {
        return postDetailService.getPostStats(postId, token);
    }

    @Operation(summary = "获取帖子详细信息")
    @GetMapping("/{postId}")
    public Resp<Object> getPostDetail(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token) {
        return postDetailService.getPostDetail(postId, token);
    }

    @Operation(summary = "获取帖子评论列表")
    @GetMapping("/{postId}/comments")
    public Resp<Page<CommentDTO>> getPostComments(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token,
            @Parameter(description = "当前页码") @RequestParam(defaultValue = "1") Long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") Long size) {
        return postDetailService.getPostComments(postId, token, current, size);
    }

    @Operation(summary = "获取评论的子评论")
    @GetMapping("/comments/{commentId}/children")
    public Resp<Page<CommentDTO>> getChildComments(
            @Parameter(description = "评论ID") @PathVariable Long commentId,
            @RequestHeader("token") String token,
            @Parameter(description = "当前页码") @RequestParam(defaultValue = "1") Long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") Long size) {
        return postDetailService.getChildComments(commentId, token, current, size);
    }

    @Operation(summary = "点赞/取消点赞评论")
    @PostMapping("/comments/{commentId}/like")
    public Resp<String> toggleCommentLike(
            @Parameter(description = "评论ID") @PathVariable Long commentId,
            @RequestHeader("token") String token) {
        return postDetailService.toggleCommentLike(commentId, token);
    }

    @Operation(summary = "点赞/取消点赞帖子")
    @PostMapping("/{postId}/like")
    public Resp<String> togglePostLike(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token) {
        return postDetailService.togglePostLike(postId, token);
    }

    @Operation(summary = "分享帖子")
    @PostMapping("/{postId}/share")
    public Resp<String> sharePost(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token) {
        return postDetailService.sharePost(postId, token);
    }

    @Operation(summary = "回复帖子")
    @PostMapping("/{postId}/reply")
    public Resp<CommentDTO> replyPost(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @Parameter(description = "评论内容") @RequestParam String content,
            @RequestHeader("token") String token) {
        return postDetailService.replyPost(postId, content, token);
    }

    @Operation(summary = "收藏/取消收藏帖子")
    @PostMapping("/{postId}/favorite")
    public Resp<String> togglePostFavorite(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @Parameter(description = "收藏夹ID") @RequestParam Long folderId,
            @RequestHeader("token") String token) {
        return postDetailService.togglePostFavorite(postId, folderId, token);
    }

    @Operation(summary = "举报帖子")
    @PostMapping("/{postId}/report")
    public Resp<Report> reportPost(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @Parameter(description = "举报类型ID") @RequestParam Long reportTypeId,
            @Parameter(description = "举报理由") @RequestParam(required = false) String reason,
            @RequestHeader("token") String token) {
        return postDetailService.reportPost(postId, reportTypeId, 1L, reason, token);
    }

    @Operation(summary = "获取所有举报类型")
    @GetMapping("/report-types")
    public Resp<List<ReportType>> getAllReportTypes() {
        return postDetailService.getAllReportTypes();
    }

    @Operation(summary = "获取所有举报对象类型")
    @GetMapping("/reported-types")
    public Resp<List<ReportedType>> getAllReportedTypes() {
        return postDetailService.getAllReportedTypes();
    }

    @Operation(summary = "浏览帖子")
    @PostMapping("/{postId}/view")
    public Resp<String> viewPost(
            @Parameter(description = "帖子ID") @PathVariable Long postId,
            @RequestHeader("token") String token) {
        return postDetailService.viewPost(postId, token);
    }
}