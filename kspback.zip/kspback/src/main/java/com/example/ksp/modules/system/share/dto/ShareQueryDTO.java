package com.example.ksp.modules.system.share.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "分享查询参数")
public class ShareQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "用户ID")
    private Long userId;
    
    @Schema(description = "分享对象ID")
    private Long shareObjectId;
    
    @Schema(description = "分享对象类型")
    private Integer shareObjectType;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 