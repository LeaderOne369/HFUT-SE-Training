package com.example.ksp.modules.system.share.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.share.dto.ShareCreateDTO;
import com.example.ksp.modules.system.share.dto.ShareQueryDTO;
import com.example.ksp.modules.system.share.entity.Share;
import com.example.ksp.modules.system.share.mapper.ShareMapper;
import com.example.ksp.modules.system.share.service.ShareService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ShareServiceImpl extends ServiceImpl<ShareMapper, Share> implements ShareService {

    @Override
    public Resp<Share> createShare(ShareCreateDTO createDTO) {
        try {
            Share share = new Share();
            BeanUtils.copyProperties(createDTO, share);

            share.setShareTime(LocalDateTime.now());
            share.setIsDeleted(0);
            // 生成分享链接
            share.setShareLink("/share/" + UUID.randomUUID().toString());

            save(share);
            return Resp.success(share);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建分享失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> deleteShare(Long id) {
        try {
            LambdaQueryWrapper<Share> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Share::getId, id)
                   .eq(Share::getIsDeleted, 0);

            Share share = getOne(wrapper);
            if (share == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "分享记录不存在或已删除");
            }

            share.setIsDeleted(1);
            updateById(share);

            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除分享失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Share> getShare(Long id) {
        try {
            LambdaQueryWrapper<Share> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Share::getId, id)
                   .eq(Share::getIsDeleted, 0);

            Share share = getOne(wrapper);
            if (share == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "分享记录不存在或已删除");
            }
            return Resp.success(share);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取分享记录失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<Share>> queryShares(ShareQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<Share> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Share::getIsDeleted, 0);

            if (queryDTO.getUserId() != null) {
                wrapper.eq(Share::getUserId, queryDTO.getUserId());
            }
            if (queryDTO.getShareObjectId() != null) {
                wrapper.eq(Share::getShareObjectId, queryDTO.getShareObjectId());
            }
            if (queryDTO.getShareObjectType() != null) {
                wrapper.eq(Share::getShareObjectType, queryDTO.getShareObjectType());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(Share::getShareTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(Share::getShareTime, queryDTO.getEndTime());
            }

            wrapper.orderByDesc(Share::getShareTime);

            Page<Share> page = new Page<>(queryDTO.getCurrent(), queryDTO.getSize());
            page = page(page, wrapper);

            return Resp.success(page);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询分享列表失败: " + e.getMessage());
        }
    }


    @Override
    public Resp<Page<Share>> getUserShares(Long userId, long current, long size) {
        Page<Share> page = new Page<>(current, size);
        Page<Share> userShares = page(page, new com.baomidou.mybatisplus.core.conditions.query.QueryWrapper<Share>()
                .eq("user_id", userId)
                .eq("is_deleted", 0)
                .orderByDesc("share_time"));
        return Resp.success(userShares);
    }

    @Override
    public Resp<Page<Share>> getObjectShares(Long objectId, Integer objectType, long current, long size) {
        Page<Share> page = new Page<>(current, size);
        Page<Share> objectShares = page(page, new com.baomidou.mybatisplus.core.conditions.query.QueryWrapper<Share>()
                .eq("share_object_id", objectId)
                .eq("share_object_type", objectType)
                .eq("is_deleted", 0)
                .orderByDesc("share_time"));
        return Resp.success(objectShares);
    }


    @Override
    public Resp<Long> getUserShareCount(Long userId) {
        long count = count(new com.baomidou.mybatisplus.core.conditions.query.QueryWrapper<Share>()
                .eq("user_id", userId)
                .eq("is_deleted", 0));
        return Resp.success(count);
    }
}
