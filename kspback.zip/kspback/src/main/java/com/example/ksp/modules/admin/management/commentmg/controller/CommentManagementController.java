package com.example.ksp.modules.admin.management.commentmg.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.commentmg.dto.AdminCommentDTO;
import com.example.ksp.modules.admin.management.commentmg.service.CommentManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "管理端评论管理")
@RestController
@RequestMapping("/api/admin/management/comment")
@RequiredArgsConstructor
public class CommentManagementController {

    private final CommentManagementService commentManagementService;

    @Operation(summary = "获取评论列表")
    @GetMapping("/list")
    public Resp<Page<AdminCommentDTO>> getCommentList(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size,
            @Parameter(description = "评论内容关键词") @RequestParam(required = false) String keyword,
            @Parameter(description = "评论类型(1:帖子 2:合集 3:评论)") @RequestParam(required = false) Integer commentableType,
            @Parameter(description = "开始时间") @RequestParam(required = false) String startTime,
            @Parameter(description = "结束时间") @RequestParam(required = false) String endTime,
            @Parameter(description = "评论状态(0:不可见 1:可见)") @RequestParam(required = false) Integer status) {
        return commentManagementService.getCommentList(current, size, keyword, commentableType, startTime, endTime, status);
    }

    @Operation(summary = "获取评论详情")
    @GetMapping("/{id}")
    public Resp<AdminCommentDTO> getCommentDetail(@PathVariable Long id) {
        return commentManagementService.getCommentDetail(id);
    }

    @Operation(summary = "更新评论状态")
    @PutMapping("/{id}/status/{status}")
    public Resp<String> updateCommentStatus(
            @Parameter(description = "评论ID") @PathVariable Long id,
            @Parameter(description = "状态(0:不可见 1:可见)") @PathVariable Integer status) {
        return commentManagementService.updateCommentStatus(id, status);
    }

    @Operation(summary = "删除评论")
    @DeleteMapping("/{id}")
    public Resp<String> deleteComment(@PathVariable Long id) {
        return commentManagementService.deleteComment(id);
    }
} 