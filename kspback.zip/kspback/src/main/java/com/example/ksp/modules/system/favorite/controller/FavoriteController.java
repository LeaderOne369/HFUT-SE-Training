package com.example.ksp.modules.system.favorite.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favorite.service.FavoriteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级收藏管理接口")
@RestController
@RequestMapping("/api/system/favorite")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    @Operation(summary = "添加收藏")
    @PostMapping("/add")
    public Resp<Boolean> addFavorite(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId,
            @Parameter(description = "收藏夹ID", required = true) 
            @RequestParam Long folderId) {
        boolean result = favoriteService.addFavorite(userId, postId, folderId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "添加收藏失败");
    }

    @Operation(summary = "取消收藏")
    @DeleteMapping("/cancel")
    public Resp<Boolean> cancelFavorite(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId) {
        boolean result = favoriteService.cancelFavorite(userId, postId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "取消收藏失败");
    }

    @Operation(summary = "移动收藏到其他收藏夹")
    @PutMapping("/move/{id}")
    public Resp<Boolean> moveFavorite(
            @Parameter(description = "收藏ID", required = true) 
            @PathVariable Long id,
            @Parameter(description = "新收藏夹ID", required = true) 
            @RequestParam Long newFolderId) {
        boolean result = favoriteService.moveFavorite(id, newFolderId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "移动收藏失败");
    }

    @Operation(summary = "获取用户的收藏列表")
    @GetMapping("/user/list")
    public Resp<Page<Favorite>> getUserFavorites(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "收藏夹ID") 
            @RequestParam(required = false) Long folderId,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<Favorite> result = favoriteService.getUserFavorites(userId, folderId, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取帖子的收藏数量")
    @GetMapping("/post/count")
    public Resp<Long> getPostFavoriteCount(
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId) {
        long count = favoriteService.getPostFavoriteCount(postId);
        return Resp.success(count);
    }

    @Operation(summary = "检查用户是否已收藏帖子")
    @GetMapping("/check")
    public Resp<Boolean> checkFavorite(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId) {
        boolean result = favoriteService.checkFavorite(userId, postId);
        return Resp.success(result);
    }

    @Operation(summary = "批量移动收藏")
    @PutMapping("/batch/move")
    public Resp<Boolean> batchMoveFavorites(
            @Parameter(description = "收藏ID数组", required = true) 
            @RequestParam Long[] ids,
            @Parameter(description = "新收藏夹ID", required = true) 
            @RequestParam Long newFolderId) {
        boolean result = favoriteService.batchMoveFavorites(ids, newFolderId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "批量移动收藏失败");
    }
} 