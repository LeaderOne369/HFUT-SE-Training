package com.example.ksp.modules.system.post.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.dto.PostCreateDTO;
import com.example.ksp.modules.system.post.dto.PostQueryDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;

import java.util.List;
import java.util.Map;

public interface PostService extends IService<Post> {
    /**
     * 创建帖子
     */
    Resp<Post> createPost(PostCreateDTO createDTO);

    /**
     * 更新帖子
     */
    Resp<Post> updatePost(PostUpdateDTO updateDTO);

    /**
     * 删除帖子
     */
    Resp<String> deletePost(Long id);

    /**
     * 获取帖子详情
     */
    Resp<Post> getPost(Long id);

    /**
     * 分页查询帖子
     */
    Resp<Page<Post>> queryPosts(PostQueryDTO queryDTO);

    /**
     * 更新帖子状态
     */
    Resp<String> updateStatus(Long id, Integer status);

    /**
     * 更新帖子审核状态
     */
    Resp<String> updateReviewStatus(Long id, Integer reviewStatus);

    /**
     * 设置/取消置顶
     */
    Resp<String> updatePinned(Long id, Integer isPinned);

    /**
     * 设置/取消精华
     */
    Resp<String> updateEssence(Long id, Integer isEssence);
    /**
     * 获取分区下的帖子，支持分页、排序和关键字搜索
     */
    Page<Post> searchPostsBySection(Long sectionId, String keyword, long current, long size, String sortBy);

    Page<Post> searchPostsByTag(Long tagId, long current, long size);

    Page<Post> searchPostsByTagAndKey(Long tagId, long current, long size, String keyword);

    Page<Post> selectPostsByKeyword(Page<Post> page, String keyword);

    List<Post> getRankList(String period);

    /**
     * 获取用户发帖总数
     * @param userId 用户ID
     * @return 发帖总数
     */
    Resp<Integer> getUserPostCount(Long userId);

    /**
     * 增加帖子浏览量并记录浏览记录
     * @param postId 帖子ID
     * @param userId 用户ID
     * @return 操作结果
     */
    Resp<Void> incrementViewCount(Long postId, Long userId);

    Resp<Void> incrementLikeCount(Long postId);

    Resp<Void> decrementLikeCount(Long postId);

    Resp<Void> incrementCommentCount(Long postId);

    int updatePost(Long posId, Map<String, Object> updates);

    Resp<Void> incrementShareCount(Long postId);
}


