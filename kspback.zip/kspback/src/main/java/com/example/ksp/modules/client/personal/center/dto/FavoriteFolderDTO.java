package com.example.ksp.modules.client.personal.center.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "收藏夹DTO")
public class FavoriteFolderDTO {



    @Schema(description = "收藏夹ID")
    private Long Id;

    @Schema(description = "收藏夹名称")
    @NotBlank(message = "收藏夹名称不能为空")
    @Size(max = 50, message = "收藏夹名称不能超过50个字符")
    private String folderName;




    @Schema(description = "可见性(0:自己可见 1:公开可见)")
    private Integer visibility;
} 