package com.example.ksp.modules.system.citation.citation.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建引用请求参数")
public class CitationCreateDTO {
    
    @NotNull(message = "帖子ID不能为空")
    @Schema(description = "帖子ID")
    private Long postId;
    
    @NotNull(message = "引用类型ID不能为空")
    @Schema(description = "引用类型ID")
    private Long citationTypeId;
    
    @NotBlank(message = "引用内容不能为空")
    @Schema(description = "引用内容")
    private String citationContent;
    
    @NotBlank(message = "引用来源不能为空")
    @Schema(description = "引用来源")
    private String source;
} 