package com.example.ksp.modules.proxy;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.view.entity.View;
import com.example.ksp.modules.system.view.service.ViewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ViewServiceProxy {

    private final ViewService viewService;

    public boolean recordView(Long userId, Long postId) {
        return viewService.recordView(userId, postId);
    }

    public boolean deleteView(Long id) {
        return viewService.deleteView(id);
    }

    public boolean deleteUserViews(Long userId) {
        return viewService.deleteUserViews(userId);
    }

    public Page<View> getUserViews(Long userId, long current, long size) {
        return viewService.getUserViews(userId, current, size);
    }

    public Page<View> getPostViews(Long postId, long current, long size) {
        return viewService.getPostViews(postId, current, size);
    }

    public long getPostViewCount(Long postId) {
        return viewService.getPostViewCount(postId);
    }
}
