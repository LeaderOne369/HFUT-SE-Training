package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.service.CollectionService;

import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsQueryDTO;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;
import com.example.ksp.modules.system.collection.collectionsubs.service.CollectionSubscriptionsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Component
@RequiredArgsConstructor
public class CollectionServiceProxy {

    private final CollectionService collectionService;
    private final CollectionSubscriptionsService subscriptionsService;

    /**
     * 创建合集
     */
    public Resp<Collection> createCollection(CollectionCreateDTO createDTO) {
        log.info("代理层：创建合集，参数：{}", createDTO);
        return collectionService.createCollection(createDTO);
    }

    /**
     * 更新合集
     */
    public Resp<Collection> updateCollection(CollectionUpdateDTO updateDTO) {
        log.info("代理层：更新合集，参数：{}", updateDTO);
        return collectionService.updateCollection(updateDTO);
    }

    /**
     * 删除合集
     */
    public Resp<Void> deleteCollection(Long id) {
        log.info("代理层：删除合集，ID：{}", id);
        return collectionService.deleteCollection(id);
    }

    /**
     * 获取合集详情
     */
    public Resp<Collection> getCollection(Long id) {
        log.info("代理层：获取合集详情，ID：{}", id);
        return collectionService.getCollection(id);
    }

    /**
     * 分页查询合集
     */
    public Resp<Page<Collection>> queryCollections(CollectionQueryDTO queryDTO) {
        log.info("代理层：分页查询合集，参数：{}", queryDTO);
        return collectionService.queryCollections(queryDTO);
    }

    /**
     * 获取用户创建的合集总数
     */
    public Resp<Integer> getUserCollectionCount(Long userId) {
        log.info("代理层：获取用户创建的合集总数，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return collectionService.getUserCollectionCount(userId);
        } catch (Exception e) {
            log.error("获取用户合集总数失败", e);
            return Resp.error(500, "获取合集总数失败");
        }
    }

    /**
     * 判断用户是否订阅了合集
     *
     * @param collectionId 合集ID
     * @param userId 用户ID
     * @return 是否已订阅
     */
    public Resp<Boolean> isSubscribed(Long collectionId, Long userId) {
        log.info("代理层：判断用户是否订阅合集，用户ID: {}, 合集ID: {}", userId, collectionId);
        if (userId == null || userId <= 0 || collectionId == null || collectionId <= 0) {
            return Resp.error(400, "用户ID或合集ID无效");
        }

        try {
            // 构建查询条件
            CollectionSubscriptionsQueryDTO queryDTO = new CollectionSubscriptionsQueryDTO();
            queryDTO.setUsersId(userId);
            queryDTO.setCollectionsId(collectionId);
            queryDTO.setCurrent(1L);
            queryDTO.setSize(1L);

            // 查询订阅记录
            Resp<Page<CollectionSubscriptions>> resp = subscriptionsService.querySubscriptions(queryDTO);
            if (resp.getCode() != 200 || resp.getData() == null) {
                return Resp.error(500, "查询订阅状态失败");
            }

            boolean isSubscribed = resp.getData().getTotal() > 0;
            return Resp.success(isSubscribed);
        } catch (Exception e) {
            log.error("检查合集订阅状态失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "检查订阅状态失败");
        }
    }

    /**
     * 根据ID获取合集
     */
    public Collection getById(Long id) {
        Resp<Collection> resp = collectionService.getCollection(id);
        return resp.getCode() == 200 ? resp.getData() : null;
    }

    /**
     * 根据ID获取合集
     */
    public Resp<Collection> getCollectionById(Long id) {
        return collectionService.getCollection(id);
    }




    /**
     * 取消订阅合集
     */
    public Resp<Void> unsubscribeCollection(Long collectionId, Long userId) {
        log.info("代理层：取消订阅合集，用户ID: {}, 合集ID: {}", userId, collectionId);
        try {
            // 查询订阅记录
            CollectionSubscriptionsQueryDTO queryDTO = new CollectionSubscriptionsQueryDTO();
            queryDTO.setUsersId(userId);
            queryDTO.setCollectionsId(collectionId);
            queryDTO.setCurrent(1L);
            queryDTO.setSize(1L);

            Resp<Page<CollectionSubscriptions>> resp = subscriptionsService.querySubscriptions(queryDTO);
            if (resp.getCode() != 200 || resp.getData() == null || resp.getData().getRecords().isEmpty()) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "未找到订阅记录");
            }

            // 取消订阅
            CollectionSubscriptions subscription = resp.getData().getRecords().get(0);
            return subscriptionsService.cancelSubscription(subscription.getId());
        } catch (Exception e) {
            log.error("取消订阅合集失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "取消订阅失败");
        }
    }


    /**
     *  获取用户订阅的合集
     * @param userId 用户ID
     * @param current 当前页
     * @param size 每页大小
     * @return Resp<Page<Collection>>
     */
    public Resp<Page<Collection>> getSubscribedCollections(Long userId, long current, long size) {
        log.info("获取用户订阅的合集，用户ID: {}, 当前页: {}, 每页大小: {}", userId, current, size);
        try {

            LambdaQueryWrapper <CollectionSubscriptions> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CollectionSubscriptions::getUsersId, userId);
            wrapper.eq(CollectionSubscriptions::getIsDeleted,0);
            List<CollectionSubscriptions> subscriptions = subscriptionsService.list(wrapper);
           List<Long> collectionIds = subscriptions.stream().map(CollectionSubscriptions::getCollectionsId).toList();
           if(collectionIds.isEmpty()) {
               log.info("用户没有订阅的合集");
               return Resp.success("用户没有订阅的合集",new Page<>());
           }
           return collectionService.queryCollectionsByIds(collectionIds, current, size);

        }catch (Exception e) {
            log.error("获取用户订阅的合集失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取用户订阅的合集失败");
        }
    }
}
