package com.example.ksp.modules.system.follow.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FollowCreateDTO {
    @NotNull(message = "被关注者ID不能为空")
    private Long followeeId;
} 