package com.example.ksp.framework.security.service;

import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author loself
 * @date 2024-12-31 15:51
 */
@Service
public class CaptchaUserDetailsService implements UserDetailsService {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public CaptchaUserDetailsService(UserService userService, 
                                   PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String phone) throws UsernameNotFoundException {
        User user = userService.selectUserByPhoneNumber(phone);
        if (user == null) {
            throw new UsernameNotFoundException("用户名或密码错误");
        }
        
        // 将原始密码与盐值组合，用于后续验证
        String rawPassword = user.getPassword();
        user.setPassword(rawPassword + user.getSalt());
        
        ArrayList<String> list = new ArrayList<>(Arrays.asList("user", "admin"));
        return new LoginUser(user, list);
    }
}
