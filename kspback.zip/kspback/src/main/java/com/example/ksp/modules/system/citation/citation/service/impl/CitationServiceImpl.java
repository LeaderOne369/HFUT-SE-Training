package com.example.ksp.modules.system.citation.citation.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citation.dto.CitationCreateDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationQueryDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationUpdateDTO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.citation.citation.mapper.CitationMapper;
import com.example.ksp.modules.system.citation.citation.service.CitationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;


@Slf4j
@Service
@RequiredArgsConstructor
public class CitationServiceImpl extends ServiceImpl<CitationMapper, Citation> implements CitationService {

    @Override
    public Resp<Citation> createCitation(CitationCreateDTO createDTO) {
        try {
            Citation citation = new Citation();
            BeanUtils.copyProperties(createDTO, citation);
            
            citation.setCitationTime(LocalDateTime.now());
            citation.setIsDeleted(0);
            
            save(citation);
            return Resp.success(citation);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建引用失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Citation> updateCitation(CitationUpdateDTO updateDTO) {
        try {
            LambdaQueryWrapper<Citation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Citation::getId, updateDTO.getId())
                   .eq(Citation::getIsDeleted, 0);
            
            Citation citation = getOne(wrapper);
            if (citation == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用不存在或已被删除");
            }
            
            BeanUtils.copyProperties(updateDTO, citation);
            updateById(citation);
            
            return Resp.success(citation);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新引用失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> deleteCitation(Long id) {
        try {
            LambdaQueryWrapper<Citation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Citation::getId, id)
                   .eq(Citation::getIsDeleted, 0);
            
            Citation citation = getOne(wrapper);
            if (citation == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用不存在或已被删除");
            }
            
            citation.setIsDeleted(1);
            updateById(citation);
            
            return Resp.success("删除引用成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除引用失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Citation> getCitation(Long id) {
        try {
            LambdaQueryWrapper<Citation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Citation::getId, id)
                   .eq(Citation::getIsDeleted, 0);
            
            Citation citation = getOne(wrapper);
            if (citation == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "引用不存在或已被删除");
            }
            return Resp.success(citation);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取引用失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<Citation>> queryCitations(CitationQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<Citation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Citation::getIsDeleted, 0);
            
            if (queryDTO.getPostId() != null) {
                wrapper.eq(Citation::getPostId, queryDTO.getPostId());
            }
            if (queryDTO.getCitationTypeId() != null) {
                wrapper.eq(Citation::getCitationTypeId, queryDTO.getCitationTypeId());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(Citation::getCitationTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(Citation::getCitationTime, queryDTO.getEndTime());
            }
            
            wrapper.orderByDesc(Citation::getCitationTime);
            
            Page<Citation> page = new Page<>(queryDTO.getCurrent(), queryDTO.getSize());
            page = page(page, wrapper);
            
            return Resp.success(page);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询引用列表失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<List<Citation>> getPostCitations(Long postId) {
        log.info("获取帖子引用列表, postId: {}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(400, "无效的帖子ID");
        }
        
        try {
            // 构建查询条件
            LambdaQueryWrapper<Citation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Citation::getPostId, postId)
                  .eq(Citation::getIsDeleted, 0)
                  .orderByDesc(Citation::getCitationTime);
            
            // 查询引用列表
            List<Citation> citations = list(wrapper);
            return Resp.success(citations);
        } catch (Exception e) {
            log.error("获取帖子引用列表失败", e);
            return Resp.error(500, "获取引用列表失败");
        }
    }
} 