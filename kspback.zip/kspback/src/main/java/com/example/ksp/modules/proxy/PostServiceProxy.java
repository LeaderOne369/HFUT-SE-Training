package com.example.ksp.modules.proxy;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.Operator;
import co.elastic.clients.elasticsearch._types.query_dsl.TextQueryType;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.elasticsearch.indices.AnalyzeResponse;
import co.elastic.clients.elasticsearch.indices.analyze.AnalyzeToken;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.search.dto.SearchHit;
import com.example.ksp.modules.client.search.dto.SearchResult;

import com.example.ksp.modules.client.search.vo.PostByEsVO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.citation.citation.service.CitationService;
import com.example.ksp.modules.system.post.dto.PostCreateDTO;
import com.example.ksp.modules.system.post.dto.PostQueryDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.service.PostService;
import com.example.ksp.modules.system.view.entity.View;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;


@Slf4j
@Component
@RequiredArgsConstructor
public class PostServiceProxy {

    private final PostService postService;

    private final ElasticsearchClient esClient;

    private final CitationService citationService;

    private final ViewServiceProxy viewServiceProxy;


    /**
     * 根据id更新帖子
     */
    public int updatePost(Post post) {
        return postService.updateById(post) ? 1 : 0;
    }



    /**
     * 根据关键词搜索帖子
     */
    public List<Post> searchPosts(String keyword, int limit) {
        return postService.list(new LambdaQueryWrapper<Post>()
                .like(Post::getTitle, keyword)
                .eq(Post::getStatus, 1)
                .eq(Post::getReviewStatus, 1)
                .eq(Post::getIsDeleted, 0)
                .last("LIMIT " + limit));
    }

    /**
     * 获取随机推荐帖子
     */
    public List<Post> getRandomPosts(int limit) {
        return postService.list(new LambdaQueryWrapper<Post>()
                .eq(Post::getStatus, 1)
                .eq(Post::getReviewStatus, 1)
                .eq(Post::getIsDeleted, 0)
                .last("LIMIT " + limit));
    }

    /**
     * 获取相关帖子
     */
    public List<Post> getRelatedPosts(Long postId, int limit) {
        return postService.list(new LambdaQueryWrapper<Post>()
                .eq(Post::getStatus, 1)
                .eq(Post::getReviewStatus, 1)
                .eq(Post::getIsDeleted, 0)
                .ne(Post::getId, postId)
                .last("LIMIT " + limit));
    }

    /**
     * 获取帖子详情
     */
    public Post getPostById(Long postId) {
        return postService.getById(postId);
    }



    /**
     * 创建帖子
     */
    public Resp<Post> createPost(PostCreateDTO createDTO) {
        log.info("代理层：创建帖子，参数：{}", createDTO);
        return postService.createPost(createDTO);
    }

    /**
     * 更新帖子
     */
    public Resp<Post> updatePost(PostUpdateDTO updateDTO) {
        log.info("代理层：更新帖子，参数：{}", updateDTO);
        return postService.updatePost(updateDTO);
    }

    /**
     * 删除帖子
     */
    public Resp<String> deletePost(Long id) {
        log.info("代理层：删除帖子，ID：{}", id);
        return postService.deletePost(id);
    }

    /**
     * 获取帖子详情
     */
    public Resp<Post> getPost(Long id) {
        log.info("代理层：获取帖子详情，ID：{}", id);
        return postService.getPost(id);
    }

    /**
     * 分页查询帖子
     */
    public Resp<Page<Post>> queryPosts(PostQueryDTO queryDTO) {
        log.info("代理层：分页查询帖子，参数：{}", queryDTO);
        return postService.queryPosts(queryDTO);
    }

    /**
     * 获取用户发帖总数
     */
    public Resp<Integer> getUserPostCount(Long userId) {
        log.info("代理层：获取用户发帖总数，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return postService.getUserPostCount(userId);
        } catch (Exception e) {
            log.error("获取用户发帖总数失败", e);
            return Resp.error(500, "获取发帖总数失败");
        }
    }

    /**
     * 增加帖子浏览量
     *
     * @param postId 帖子ID
     */
    public void incrementViewCount(Long postId) {
        log.info("代理层：增加帖子浏览量，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            log.error("无效的帖子ID: {}", postId);
            return;
        }
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                    .getAuthentication().getPrincipal();
            Long currentUserId = loginUser.getXxuser().getId();

            if (currentUserId == null) {
                log.error("获取当前用户ID失败");
                return;
            }

            postService.incrementViewCount(postId, currentUserId);
        } catch (Exception e) {
            log.error("增加帖子浏览量失败, postId: {}", postId, e);
        }
    }
    /**
     * 根据板块ID获取帖子列表
     *
     * @param sectionId 板块ID
     * @param page 页码
     * @param size 每页大小
     * @return 帖子分页列表
     */
    public Page<Post> getPostsBySection(Long sectionId, long page, long size) {
        return postService.searchPostsBySection(sectionId, null, page, size, null);
    }

    /**
     * 根据标签ID获取帖子列表
     *
     * @param tagId 标签ID
     * @param current 当前页
     * @param size 每页大小
     * @return 帖子分页列表
     */
    public Page<Post> getPostsByTag(Long tagId, long current, long size) {
        return postService.searchPostsByTag(tagId,current,size);
    }

    /**
     * 根据标签ID和关键词搜索帖子
     *
     * @param tagId 标签ID
     * @param current 当前页
     * @param size 每页大小
     * @param keyword 搜索关键词
     * @return 帖子分页列表
     */
    public Page<Post> searchPostsByTagAndKey(Long tagId, long current, long size, String keyword) {
        return postService.searchPostsByTagAndKey(tagId,current,size,keyword);
    }

    /**
     * 获取帖子排行榜
     *
     * @param frequency 时间频率(如:日榜、周榜、月榜等)
     * @return 帖子排行列表
     */
    public List<Post> getRankList(String frequency) {
        return postService.getRankList(frequency);
    }

    /**
     * 根据关键词搜索帖子
     *
     * @param page 分页参数
     * @param keyword 搜索关键词
     * @return 帖子分页列表
     */
    public Page<Post> selectPostsByKeyword(Page<Post> page, String keyword) {
        return postService.selectPostsByKeyword(page,keyword);
    }




    /**
     * 增加帖子点赞数
     *
     * @param postId 帖子ID
     */
    public Resp<Void> incrementLikeCount(Long postId) {
        log.info("代理层：增加帖子点赞数，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        try {
            return postService.incrementLikeCount(postId);
        } catch (Exception e) {
            log.error("增加帖子点赞数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加点赞数失败");
        }
    }

    /**
     * 减少帖子点赞数
     *
     * @param postId 帖子ID
     */
    public Resp<Void> decrementLikeCount(Long postId) {
        log.info("代理层：减少帖子点赞数，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        try {
            return postService.decrementLikeCount(postId);
        } catch (Exception e) {
            log.error("减少帖子点赞数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "减少点赞数失败");
        }
    }

    public Resp<Void> incrementShareCount(Long postId) {
        log.info("代理层：增加帖子分享数，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        try {
            return postService.incrementShareCount(postId);
        } catch (Exception e) {
            log.error("增加帖子点赞数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加点赞数失败");
        }
    }

    /**
     * 增加帖子评论数
     *
     * @param postId 帖子ID
     */
    public Resp<Void> incrementCommentCount(Long postId) {
        log.info("代理层：增加帖子评论数，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        try {
            return postService.incrementCommentCount(postId);
        } catch (Exception e) {
            log.error("增加帖子评论数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加评论数失败");
        }
    }

    /**
     * 增加帖子浏览记录
     *
     * @param postId 帖子ID
     * @param userId 用户ID
     * @return 操作结果
     */
    public Resp<Void> incrementViewCount(Long postId, Long userId) {
        log.info("代理层：增加帖子浏览记录，帖子ID：{}, 用户ID：{}", postId, userId);
        if (postId == null || postId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的帖子ID");
        }
        if (userId == null || userId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的用户ID");
        }

        try {
            return postService.incrementViewCount(postId, userId);
        } catch (Exception e) {
            log.error("增加帖子浏览记录失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加浏览记录失败");
        }
    }

    /**
     * 根据es，关键词查询帖子
     */
    public SearchResult<Post> searchPostsByKeyword(String keyword, Integer page, Integer size) throws IOException {
        SearchResponse<Post> response = esClient.search(s -> s
                        .index("post")
                        .query(q -> q
                                .bool(b -> b
                                        .must(m -> m
                                                .multiMatch(mm -> mm
                                                        .query(keyword)
                                                        .fields("title^3", "summary^2", "content", "tags")
                                                        .type(TextQueryType.BestFields)
                                                        .operator(Operator.Or)
                                                        .minimumShouldMatch("70%")
                                                )
                                        )
                                )
                        )
                        .highlight(h -> h
                                .fields("title", f -> f)
                                .fields("summary", f -> f)
                                .fields("content", f -> f)
                                .preTags("<em>")
                                .postTags("</em>")
                        )
                        .sort(s1 -> s1
                                .field(f -> f.field("_score").order(SortOrder.Desc))
                        )
                        .from((page - 1) * size)
                        .size(size),
                Post.class
        );

        // 处理搜索结果
        SearchResult<Post> result = new SearchResult<>();
        if (response.hits().total() != null) {
            result.setTotal(response.hits().total().value());
        }
        result.setHits(processSearchHits(response.hits().hits()));
        return result;
    }

    /**
     * 处理搜索结果，提取高亮内容
     */
    private List<SearchHit<Post>> processSearchHits(List<Hit<Post>> hits) {
        return hits.stream().map(hit -> {
            SearchHit<Post> searchHit = new SearchHit<>();
            searchHit.setSource(hit.source());
            searchHit.setScore(hit.score());

            // 处理高亮
            Map<String, List<String>> highlights = new HashMap<>();
            if (hit.highlight() != null) {
                highlights.putAll(hit.highlight());
            }
            searchHit.setHighlight(highlights);

            return searchHit;
        }).collect(Collectors.toList());
    }

    /**
     * 更新帖子
     *
     * @param posId 帖子ID
     * @param updates 更新字段
     * @return 更新的行数
     */
    public int updatePost(Long posId, Map<String, Object> updates) {
        return postService.updatePost(posId, updates);
    }

    public List<String> getSearchKeyword(List<String> history, int size) {
        try {
            // 1. 获取所有未删除的帖子的相关字段
            SearchResponse<PostByEsVO> response = esClient.search(s -> s
                .index("post")
                .source(src -> src
                    .filter(f -> f
                        .includes("title", "summary", "tags", "sectionName")
                    )
                )
                .size(1000),
                PostByEsVO.class
            );

            // 2. 收集所有字段值
            Set<String> allFields = new HashSet<>();
            response.hits().hits().forEach(hit -> {
                PostByEsVO post = hit.source();
                if (post != null) {
                    addFieldValueIfNotEmpty(allFields, post.getTitle());
                    addFieldValueIfNotEmpty(allFields, post.getSummary());
                    addFieldValueIfNotEmpty(allFields, post.getTags());
                    addFieldValueIfNotEmpty(allFields, post.getSectionName());
                }
            });

            // 3. 使用 ik_max_word 进行分词
            Set<String> keywords = new HashSet<>();
            for (String field : allFields) {
                if (StringUtils.hasText(field)) {
                    try {
                        AnalyzeResponse analyzeResponse = esClient.indices().analyze(a -> a
                            .index("post")
                            .analyzer("ik_max_word")
                            .text(field)
                        );

                        analyzeResponse.tokens().stream()
                            .map(AnalyzeToken::token)
                            .forEach(keywords::add);
                    } catch (Exception e) {
                        log.warn("分词失败: {}", field, e);
                        keywords.add(field);
                    }
                }
            }

           if(Objects.isNull(history)){
               return keywords.stream()
                   .limit(size)
                   .collect(Collectors.toList());
           }
           // 4. 根据用户搜索历史进行过滤
            else {
               Set<String> historykeywords = new HashSet<>();
               Set<String> histories = new HashSet<>(history);
               for (String his : histories) {
                   if (StringUtils.hasText(his)) {
                       try {
                           AnalyzeResponse analyzeResponse = esClient.indices().analyze(a -> a
                                   .index("post")
                                   .analyzer("ik_max_word")
                                   .text(his)
                           );

                           analyzeResponse.tokens().stream()
                                   .map(AnalyzeToken::token)
                                   .forEach(historykeywords::add);
                       } catch (Exception e) {
                           log.warn("分词失败: {}", his, e);
                       }
                   }
               }
               return historykeywords.stream()
                   .limit(size)
                   .collect(Collectors.toList());
           }

        } catch (Exception e) {
            log.error("获取搜索关键词失败: {}", history, e);
            return new ArrayList<>();
        }
    }

    private void addFieldValueIfNotEmpty(Set<String> fields, String value) {
        if (StringUtils.hasText(value)) {
            fields.add(value);
        }
    }


    /**
     * 获取帖子引用信息
     * @param id 帖子ID
     * @return 帖子引用信息列表
     */
    public Citation getCitation(Long id) {
        LambdaQueryWrapper<Citation> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Citation::getPostId, id)
                .eq(Citation::getIsDeleted, 0);
        return citationService.getOne(queryWrapper);
    }

    public List<Post> getUserRecentPosts(Long userId, int i) {
        LambdaQueryWrapper<Post> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Post::getUserId, userId);
        queryWrapper.orderByDesc(Post::getPublishTime);
        return postService.list(queryWrapper).stream().limit(i).collect(Collectors.toList());
    }

    public List<Post> getUserViewHistory(Long userId, int i) {
        Page<View> userViews = viewServiceProxy.getUserViews(userId, 1, i);
        return userViews.getRecords()
                .stream()
                .map(View::getPostId)
                .map(postService::getById)
                .collect(Collectors.toList());
    }
}
