package com.example.ksp.modules.client.homepage.service.impl;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.homepage.service.ClientHomePageService;
import com.example.ksp.modules.client.homepage.vo.*;
import com.example.ksp.modules.proxy.HomePageServiceProxy;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.client.recommendation.dto.RecommendationDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClientHomePageServiceImpl implements ClientHomePageService {

    private final HomePageServiceProxy homePageServiceProxy;

    private final PostServiceProxy postServiceProxy;

    private final UserServiceProxy userServiceProxy;
    @Override
    public Resp<HomePageVO> getHomePageData(Long userId) {
        if (userId == null) {
            return Resp.error(HttpStatus.UNAUTHORIZED, "用户未登录");
        }

        try {
            HomePageVO homePageVO = new HomePageVO();
            
            // 获取用户信息
            User user = homePageServiceProxy.getUserInfo(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND, "用户不存在");
            }
            homePageVO.setUserInfo(convertToUserBriefVO(user));
            
            // 获取推荐内容（默认10条）
            List<RecommendContentVO> vos = homePageServiceProxy.getRecommendContents(10);

            homePageVO.setRecommendContents(vos);
            // 获取分区列表
            homePageVO.setSections(convertToSectionVOList(homePageServiceProxy.getSections()));
            
            // 获取通知列表（默认5条）
            List<Notification> notifications = homePageServiceProxy.getUserNotifications(userId, 5);
            homePageVO.setNotifications(convertToNotificationVOList(notifications));
            
            // 获取未读通知数量
            homePageVO.setUnreadNotificationCount(
                    homePageServiceProxy.getUnreadNotificationCount(userId));
            
            return Resp.success(homePageVO);
        } catch (Exception e) {
            log.error("获取首页数据失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取首页数据失败");
        }
    }

    @Override
    public Resp<UserBriefVO> getUserBrief(Long userId) {
        if (userId == null) {
            return Resp.error(HttpStatus.UNAUTHORIZED, "用户未登录");
        }

        try {
            User user = homePageServiceProxy.getUserInfo(userId);
            if (user == null) {
                return Resp.error(HttpStatus.NOT_FOUND, "用户不存在");
            }
            return Resp.success(convertToUserBriefVO(user));
        } catch (Exception e) {
            log.error("获取用户简要信息失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取用户信息失败");
        }
    }

    @Override
    public Resp<List<RecommendContentVO>> getRecommendContents(Integer limit) {
        try {
            List<RecommendContentVO> vos = homePageServiceProxy.getRecommendContents(limit);

            return Resp.success(vos);
        } catch (Exception e) {
            log.error("获取推荐内容失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取推荐内容失败");
        }
    }

    @Override
    public Resp<List<SectionVO>> getSections() {
        try {
            List<Section> sections = homePageServiceProxy.getSections();
            return Resp.success(convertToSectionVOList(sections));
        } catch (Exception e) {
            log.error("获取分区列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取分区列表失败");
        }
    }

    @Override
    public Resp<List<NotificationVO>> getNotifications(Long userId, Integer limit) {
        if (userId == null) {
            return Resp.error(HttpStatus.UNAUTHORIZED, "用户未登录");
        }

        try {
            List<Notification> notifications = homePageServiceProxy.getUserNotifications(userId, limit);
            return Resp.success(convertToNotificationVOList(notifications));
        } catch (Exception e) {
            log.error("获取通知列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "获取通知列表失败");
        }
    }

    // 转换方法
    private UserBriefVO convertToUserBriefVO(User user) {
        if (user == null) {
            return null;
        }
        UserBriefVO vo = new UserBriefVO();
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setAvatarUrl(user.getAvatar());
        return vo;
    }

    private List<RecommendContentVO> convertToRecommendContentVOList(List<RecommendationDTO> dtoList) {
        if (dtoList == null) {
            return new ArrayList<>();
        }
        return dtoList.stream()
                .map(this::convertToRecommendContentVO)
                .collect(Collectors.toList());
    }

    private RecommendContentVO convertToRecommendContentVO(RecommendationDTO dto) {
        RecommendContentVO vo = new RecommendContentVO();
        Post post = postServiceProxy.getPostById(dto.getPostId());
        vo.setPost(post);
        User userInfo = homePageServiceProxy.getUserInfo(post.getUserId());
        vo.setAuthor(convertToUserBriefVO(userInfo));
        return vo;
    }

    private List<SectionVO> convertToSectionVOList(List<Section> sections) {
        if (sections == null) {
            return new ArrayList<>();
        }
        return sections.stream()
                .map(this::convertToSectionVO)
                .collect(Collectors.toList());
    }

    private SectionVO convertToSectionVO(Section section) {
        SectionVO vo = new SectionVO();
        BeanUtils.copyProperties(section, vo);
        return vo;
    }

    private List<NotificationVO> convertToNotificationVOList(List<Notification> notifications) {
        if (notifications == null) {
            return new ArrayList<>();
        }
        return notifications.stream()
                .map(this::convertToNotificationVO)
                .collect(Collectors.toList());
    }

    private NotificationVO convertToNotificationVO(Notification notification) {
        NotificationVO vo = new NotificationVO();
        BeanUtils.copyProperties(notification, vo);
        return vo;
    }
} 