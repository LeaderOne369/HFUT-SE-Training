package com.example.ksp.modules.system.report.reporttype.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReportTypeMapper extends BaseMapper<ReportType> {
} 