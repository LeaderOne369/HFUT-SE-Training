package com.example.ksp.modules.client.feedback.service.impl;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.feedback.dto.FeedbackDTO;
import com.example.ksp.modules.client.feedback.service.ClientFeedbackService;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClientFeedbackServiceImpl implements ClientFeedbackService {

    private final FeedbackService feedbackService;

    private  final UserServiceProxy userServiceProxy;
    @Override
    public Resp<Boolean> submitFeedback(String token, FeedbackDTO feedbackDTO) {
        try {
            String username = JwtUtil.parseJWT(token).getSubject();
            Resp<Long> id = userServiceProxy.getUserIdByUsername(username);
            Feedback feedback = new Feedback();
            feedback.setUserId(id.getData());
            feedback.setFeedbackContent(feedbackDTO.getFeedbackContent());
            
            boolean result = feedbackService.submitFeedback(feedback);
            if (result) {
                return Resp.success(true);
            }
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "提交反馈失败");
        } catch (Exception e) {
            log.error("提交反馈失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "提交反馈失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<List<Feedback>> getUserFeedbacks(Long userId) {
        try {
            List<Feedback> feedbacks = feedbackService.getUserFeedbacks(userId, null, 1, 100).getRecords();
            return Resp.success(feedbacks);
        } catch (Exception e) {
            log.error("获取用户反馈列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取用户反馈列表失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Boolean> deleteFeedback(Long id) {
        try {
            boolean result = feedbackService.deleteFeedback(id);
            if (result) {
                return Resp.success(true);
            }
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "删除反馈失败");
        } catch (Exception e) {
            log.error("删除反馈失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除反馈失败: " + e.getMessage());
        }
    }
} 