package com.example.ksp.modules.client.personal.statistics.service;

import com.example.ksp.common.variable.Resp;

import java.util.Map;

public interface PersonalStatisticsService {
    /**
     * 获取用户的社交统计数据
     * @param userId 用户ID
     * @return 包含粉丝数、关注数的统计信息
     */
    Resp<Map<String, Integer>> getSocialStats(Long userId);
    
    /**
     * 获取用户的内容创作统计数据
     * @param userId 用户ID
     * @return 包含发帖数、发布合集数的统计信息
     */
    Resp<Map<String, Integer>> getContentStats(Long userId);
    
    /**
     * 获取用户的互动数据统计
     * @param userId 用户ID
     * @return 包含收到的评论数、点赞数、收藏数的统计信息
     */
    Resp<Map<String, Integer>> getInteractionStats(Long userId);
    
    /**
     * 获取用户的所有统计数据
     * @param userId 用户ID
     * @return 包含所有统计信息的集合
     */
    Resp<Map<String, Integer>> getAllStats(Long userId);
} 