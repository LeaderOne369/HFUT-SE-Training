package com.example.ksp.modules.proxy;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.homepage.vo.UserBriefVO;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.service.NotificationService;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.section.service.SectionService;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import com.example.ksp.modules.client.recommendation.service.RecommendationService;
import com.example.ksp.modules.client.recommendation.dto.RecommendationDTO;
import com.example.ksp.modules.client.homepage.vo.RecommendContentVO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class HomePageServiceProxy {

    private final UserService userService;
    private final RecommendationService recommendationService;
    private final SectionService sectionService;
    private final NotificationService notificationService;
    private  final PostServiceProxy postServiceProxy;

    /**
     * 获取用户信息
     */
    public User getUserInfo(Long userId) {
        log.info("代理层：获取用户信息，用户ID：{}", userId);
        return userService.getById(userId);
    }

    /**
     * 获取推荐内容列表
     */
    public List<RecommendContentVO> getRecommendContents(Integer limit) {
        log.info("代理层：获取推荐内容列表，限制数量：{}", limit);
        // 使用空字符串作为关键词，获取通用推荐
        Resp<List<RecommendationDTO>> resp = recommendationService.getSearchRecommendations("", limit);
        if (resp.getCode() != 200 || resp.getData() == null) {
            return new ArrayList<>();
        }

        // 转换为 RecommendContentVO 列表
        List<RecommendContentVO> voList = new ArrayList<>();
        for (RecommendationDTO dto : resp.getData()) {
            RecommendContentVO vo = new RecommendContentVO();
            Post post = postServiceProxy.getPostById(dto.getPostId());
            vo.setPost( post );
            User userInfo = getUserInfo(post.getUserId());
            vo.setAuthor(convertToUserBriefVO(userInfo));
            voList.add(vo);
        }
        return voList;
    }

    private UserBriefVO convertToUserBriefVO(User user) {
        if (user == null) {
            return null;
        }
        UserBriefVO vo = new UserBriefVO();
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setAvatarUrl(user.getAvatar());
        return vo;
    }
    /**
     * 获取分区列表
     */
    public List<Section> getSections() {
        log.info("代理层：获取分区列表");
        return sectionService.list();
    }

    /**
     * 获取用户通知列表
     *
     */
    public List<Notification> getUserNotifications(Long userId, Integer limit) {
        log.info("代理层：获取用户通知列表，用户ID：{}，限制数量：{}", userId, limit);
        Page<Notification> page = notificationService.getUserNotifications(userId, limit, 1L, limit);
        return page.getRecords();
    }

    /**
     * 获取用户未读通知数量
     *
     */
    public Integer getUnreadNotificationCount(Long userId) {
        log.info("代理层：获取用户未读通知数量，用户ID：{}", userId);
        return Math.toIntExact(notificationService.getUnreadCount(userId));
    }
}