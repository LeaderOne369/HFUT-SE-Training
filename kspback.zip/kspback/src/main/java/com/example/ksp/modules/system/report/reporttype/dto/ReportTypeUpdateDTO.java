package com.example.ksp.modules.system.report.reporttype.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "更新举报类型请求参数")
public class ReportTypeUpdateDTO {
    
    @NotNull(message = "举报类型ID不能为空")
    @Schema(description = "举报类型ID")
    private Long id;
    
    @Schema(description = "举报类型名称")
    private String typeName;
    
    @Schema(description = "举报类型描述")
    private String typeDescription;
    
    @Schema(description = "是否启用(1:启用 0:未启用)")
    private Integer isActive;
} 