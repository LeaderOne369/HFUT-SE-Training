package com.example.ksp.common.async.impl;

import com.example.ksp.common.async.AsyncService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AsyncServiceImpl implements AsyncService {

    @Async
    @Override
    public void execute(Runnable runnable) {
        runnable.run();
    }
} 