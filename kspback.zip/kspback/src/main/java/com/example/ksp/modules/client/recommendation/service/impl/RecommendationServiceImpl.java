package com.example.ksp.modules.client.recommendation.service.impl;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.recommendation.dto.RecommendationDTO;
import com.example.ksp.modules.client.recommendation.service.RecommendationService;
import com.example.ksp.modules.client.search.dto.SearchHit;
import com.example.ksp.modules.client.search.dto.SearchResult;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.system.post.entity.Post;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Slf4j
@Service("recommendationService")
@RequiredArgsConstructor
public class RecommendationServiceImpl implements RecommendationService {

    private final PostServiceProxy postServiceProxy;

    private final Random random = new Random();

    @Override
    public Resp<List<RecommendationDTO>> getSearchRecommendations(String keyword, int size) {
        try {
            // 使用代理类搜索帖子
            List<Post> posts = postServiceProxy.searchPostsByKeyword(keyword, 1,size)
                    .getHits()
                    .stream()
                    .map(SearchHit::getSource)
                    .collect(Collectors.toList());
            
            if (posts.isEmpty()) {
                // 如果没有找到相关帖子，返回随机推荐
                posts = postServiceProxy.getRandomPosts(100);
            }
            
            Collections.shuffle(posts);
            List<RecommendationDTO> recommendations = posts.stream()
                    .limit(size)
                    .map(this::convertPostToRecommendation)
                    .collect(Collectors.toList());
                    
            return Resp.success(recommendations);
            
        } catch (Exception e) {
            log.error("获取搜索推荐失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取搜索推荐失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<List<RecommendationDTO>> getRelatedPosts(Long postId, int size) {
        try {
            Post currentPost = postServiceProxy.getPostById(postId);
            if (currentPost == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            // 使用代理类获取相关帖子
            List<Post> relatedPosts = postServiceProxy.getRelatedPosts(postId, 100);
            
            Collections.shuffle(relatedPosts);
            List<RecommendationDTO> recommendations = relatedPosts.stream()
                    .limit(size)
                    .map(this::convertPostToRecommendation)
                    .collect(Collectors.toList());
                    
            return Resp.success(recommendations);
            
        } catch (Exception e) {
            log.error("获取相关帖子推荐失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取相关帖子推荐失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<List<String>> getSearchRecommendationKeyword(List<String> history, int size) {
        List<String> searchKeywords = postServiceProxy.getSearchKeyword(history,  size);
        return Resp.success(searchKeywords);

    }

    private RecommendationDTO convertPostToRecommendation(Post post) {
        RecommendationDTO dto = new RecommendationDTO();
        dto.setPostId(post.getId());
        dto.setTitle(post.getTitle());
        dto.setDescription(post.getSummary());
        dto.setCoverUrl(post.getCover());
        dto.setScore(random.nextDouble() * 100);
        return dto;
    }
} 