package com.example.ksp.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * 跨域配置类
 * 用于解决前后端分离项目的跨域问题
 */
@Configuration
public class CorsConfig {

    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        
        // 允许跨域的源地址
        config.addAllowedOriginPattern("*");  // 使用 addAllowedOriginPattern 替代 addAllowedOrigin
        
        // 允许跨域的请求头
        config.addAllowedHeader("*");
        
        // 允许跨域的请求方法
        config.addAllowedMethod("*");
        
        // 是否允许携带cookie信息
        config.setAllowCredentials(true);
        
        // 预检请求的缓存时间（秒），即在这个时间段里，对于相同的跨域请求不会再次预检
        config.setMaxAge(3600L);
        
        // 配置所有接口都支持跨域
        source.registerCorsConfiguration("/**", config);
        
        return new CorsFilter(source);
    }
} 