package com.example.ksp.modules.system.like.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.like.entity.Like;

import java.util.List;

public interface LikeService extends IService<Like> {

    /**
     * 添加点赞
     */
    boolean addLike(Long userId, Long objectId, Integer objectType);

    /**
     * 取消点赞
     */
    boolean cancelLike(Long userId, Long objectId, Integer objectType);

    /**
     * 检查是否已点赞
     */
    boolean checkLiked(Long userId, Long objectId, Integer objectType);

    /**
     * 获取用户所有点赞记录
     *
     * @param userId 用户ID
     * @return 点赞记录列表
     */
    Resp<List<Like>> getAllLikesByUser(Long userId);

    /**
     * 获取用户对特定对象类型的点赞记录
     *
     * @param userId 用户ID
     * @param objectType 点赞对象类型（1：帖子，2：合集，3：评论）
     * @return 点赞记录列表
     */
    Resp<List<Like>> getLikesByUserAndType(Long userId, Integer objectType);

    /**
     * 获取用户点赞的总数
     *
     * @param userId 用户ID
     * @return 点赞总数
     */
    Resp<Integer> getLikeCountByUser(Long userId);

    Resp<Integer> getReceivedLikeCount(Long userId);
}
