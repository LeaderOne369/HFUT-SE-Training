package com.example.ksp.modules.system.feedback.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("feedback")
@Schema(name = "Feedback对象", description = "反馈信息")
public class Feedback {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "用户ID")
    private Long userId;

    @Schema(description = "反馈内容")
    private String feedbackContent;

    @Schema(description = "反馈时间")
    private LocalDateTime feedbackTime;

    @Schema(description = "处理状态(0:未处理 1:已处理 2:已回复)")
    private Integer status;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;
} 