package com.example.ksp.modules.system.favoritefolder.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("favorite_folder")
@Schema(name = "FavoriteFolder对象", description = "收藏夹信息")
public class FavoriteFolder {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "用户ID")
    private Long userId;

    @Schema(description = "收藏夹名称")
    private String folderName;

    @Schema(description = "创建时间")
    private LocalDateTime creationTime;

    @Schema(description = "更新时间")
    private LocalDateTime updateTime;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;

    @Schema(description = "审核状态(0:待审核 1:已通过 2:已拒绝)")
    private Integer reviewStatus;

    @Schema(description = "可见性(0:自己可见 1:公开可见)")
    private Integer visibility;
} 