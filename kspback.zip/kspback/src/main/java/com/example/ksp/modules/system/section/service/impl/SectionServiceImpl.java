package com.example.ksp.modules.system.section.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.mapper.PostMapper;
import com.example.ksp.modules.system.post.service.PostService;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.section.mapper.SectionMapper;
import com.example.ksp.modules.system.section.service.SectionService;
import com.example.ksp.modules.system.tag.entity.Tag;
import com.example.ksp.modules.system.tag.mapper.TagMapper;
import com.example.ksp.modules.system.tag.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SectionServiceImpl extends ServiceImpl<SectionMapper, Section> implements SectionService {
    @Autowired
    private TagService tagService;
    @Autowired
    private PostService postService;
    @Autowired
    private SectionMapper sectionMapper;


    @Override
    public boolean createSection(Section section) {
        section.setCreationTime(LocalDateTime.now());
        section.setUpdateTime(LocalDateTime.now());
        section.setIsDeleted(0);
        return save(section);
    }

    @Override
    public boolean updateSection(Section section) {
        section.setUpdateTime(LocalDateTime.now());
        return updateById(section);
    }

    @Override
    public boolean deleteSection(Long id) {
        return removeById(id);
    }

    @Override
    public boolean toggleVisibility(Long id) {
        Section section = getById(id);
        if (section == null) {
            return false;
        }

        section.setVisibility(section.getVisibility() == 1 ? 0 : 1);
        section.setUpdateTime(LocalDateTime.now());
        return updateById(section);
    }

    @Override
    public List<Section> getAllSections() {
        return list();
    }

    @Override
    public Resp<List<Tag>> getTagsBySection(Long sectionId) {
        return tagService.getTagsBySection(sectionId);
    }

    @Override
    public Page<Post> getPostsBySectionOrTag(Long sectionId, Long tagId, long current, long size) {
        // 创建分页对象
        Page<Post> page = new Page<>(current, size);
        return sectionMapper.selectPostsBySectionOrTag(page, sectionId, tagId);
    }

    @Override
    public Page<Post> searchPostsBySection(Long sectionId, String keyword, long current, long size,String sortBy) {
        return postService.searchPostsBySection(sectionId,keyword,current,size,sortBy);
    }
}
