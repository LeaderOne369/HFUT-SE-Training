package com.example.ksp.modules.system.comment.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.mapper.CollectionMapper;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.post.mapper.PostMapper;
import lombok.extern.slf4j.Slf4j;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.comment.mapper.CommentMapper;
import com.example.ksp.modules.system.comment.service.CommentService;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {
    @Resource
    private final CommentMapper commentMapper;

    @Autowired
    PostMapper postMapper;

    @Autowired
    private CollectionMapper collectionMapper;


    @Override
    public Resp<Comment> createComment(CommentCreateDTO createDTO) {
        log.info("创建评论, 参数: {}", createDTO);

        // 1. 参数校验
        if (createDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "参数不能为空");
        }
        if (createDTO.getCommenterId() == null || createDTO.getCommenterId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论者ID无效");
        }
        if (createDTO.getCommentableId() == null || createDTO.getCommentableId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象ID无效");
        }
        if (createDTO.getCommentableType() == null || createDTO.getCommentableType() < 1 || createDTO.getCommentableType() > 3) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象类型无效");
        }
        if (StringUtils.isBlank(createDTO.getContent())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }

        try {
            // 2. 构建评论实体
            Comment comment = new Comment();
            comment.setCommenterId(createDTO.getCommenterId());
            comment.setCommentableId(createDTO.getCommentableId());
            comment.setCommentableType(createDTO.getCommentableType());
            comment.setContent(createDTO.getContent());
            comment.setParentCommentId(createDTO.getParentCommentId());
            comment.setIsPublic(createDTO.getIsPublic());
            comment.setCreationTime(LocalDateTime.now());
            comment.setLikeCount(0);
            comment.setReplyCount(0);
            comment.setIsDeleted(0);
            comment.setReviewStatus(1); // 默认审核通过

            // 3. 保存评论
            boolean success = save(comment);
            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "保存评论失败");
            }

            return Resp.success(comment);
        } catch (Exception e) {
            log.error("创建评论失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建评论失败");
        }
    }

    @Override
    public Resp<Comment> replyComment(CommentCreateDTO createDTO) {
        log.info("创建评论, 参数: {}", createDTO);

        // 1. 参数校验
        if (createDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "参数不能为空");
        }
        if (createDTO.getCommenterId() == null || createDTO.getCommenterId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论者ID无效");
        }
        if (createDTO.getCommentableId() == null || createDTO.getCommentableId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象ID无效");
        }
        if (createDTO.getCommentableType() == null || createDTO.getCommentableType() < 1 || createDTO.getCommentableType() > 3) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象类型无效");
        }
        if (StringUtils.isBlank(createDTO.getContent())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }

        try {
            // 2. 构建评论实体
            Comment comment = new Comment();
            comment.setCommenterId(createDTO.getCommenterId());
            comment.setCommentableId(createDTO.getCommentableId());
            comment.setCommentableType(createDTO.getCommentableType());
            comment.setContent(createDTO.getContent());
            comment.setParentCommentId(createDTO.getParentCommentId());
            comment.setIsPublic(createDTO.getIsPublic());
            comment.setCreationTime(LocalDateTime.now());
            comment.setLikeCount(0);
            comment.setReplyCount(0);
            comment.setIsDeleted(0);
            comment.setReviewStatus(1); // 默认审核通过

            // 3. 保存评论
            boolean success = save(comment);
            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "保存评论失败");
            }
            // 4. 更新父评论的回复数
            if (comment.getParentCommentId() != null) {
                Comment parentComment = getById(comment.getParentCommentId());
                if (parentComment != null && parentComment.getIsDeleted() == 0) {
                    parentComment.setReplyCount(parentComment.getReplyCount() + 1);
                    updateById(parentComment);
                }
            }
            return Resp.success(comment);
        } catch (Exception e) {
            log.error("创建评论失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建评论失败");
        }
    }

    @Override
    public Resp<Void> deleteComment(Long id) {
        try {
            Comment comment = getById(id);
            if (comment == null || comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在或已删除");
            }

            // 如果是回复，更新父评论的回复数
            if (comment.getParentCommentId() != null) {
                Comment parentComment = getById(comment.getParentCommentId());
                if (parentComment != null && parentComment.getIsDeleted() == 0) {
                    parentComment.setReplyCount(parentComment.getReplyCount() - 1);
                    updateById(parentComment);
                }
            }

            comment.setIsDeleted(1);
            updateById(comment);

            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除评论失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Comment> getComment(Long id) {
        try {
            Comment comment = getById(id);
            if (comment == null || comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在或已删除");
            }
            return Resp.success(comment);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<Comment>> queryComments(CommentQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<Comment> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Comment::getIsDeleted, 0);

            if (queryDTO.getCommenterId() != null) {
                wrapper.eq(Comment::getCommenterId, queryDTO.getCommenterId());
            }
            if (queryDTO.getCommentableId() != null) {
                wrapper.eq(Comment::getCommentableId, queryDTO.getCommentableId());
            }
            if (queryDTO.getCommentableType() != null) {
                wrapper.eq(Comment::getCommentableType, queryDTO.getCommentableType());
            }
            if (queryDTO.getParentCommentId() != null) {
                wrapper.eq(Comment::getParentCommentId, queryDTO.getParentCommentId());
            }
            if (queryDTO.getReviewStatus() != null) {
                wrapper.eq(Comment::getReviewStatus, queryDTO.getReviewStatus());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(Comment::getCreationTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(Comment::getCreationTime, queryDTO.getEndTime());
            }

            if(StringUtils.isNotBlank(queryDTO.getKeyword())){
                wrapper.like(Comment::getContent, queryDTO.getKeyword());
            }

            wrapper.orderByDesc(Comment::getCreationTime);

            Page<Comment> page = new Page<>(queryDTO.getCurrent(), queryDTO.getSize());
            page = page(page, wrapper);

            return Resp.success(page);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询评论列表失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> updateReviewStatus(Long id, Integer reviewStatus) {
        try {
            Comment comment = getById(id);
            if (comment == null || comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在或已删除");
            }

            comment.setReviewStatus(reviewStatus);
            updateById(comment);

            return Resp.success("更新审核状态成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新审核状态失败: " + e.getMessage());
        }
    }

    /**
     * 获取用户所有评论记录
     */
    @Override
    public Resp<List<Comment>> getAllCommentsByUser(Long userId) {
        log.info("查询用户所有评论记录，用户ID: {}", userId);
        List<Comment> comments = commentMapper.selectList(
                new QueryWrapper<Comment>()
                        .eq("commenter_id", userId)
                        .eq("is_deleted", 0)
                        .orderByDesc("creation_time")
        );
        return Resp.success(comments);
    }

    /**
     * 获取用户对特定类型对象的评论记录
     */
    @Override
    public Resp<List<Comment>> getCommentsByUserAndType(Long userId, Integer objectType) {
        log.info("查询用户特定类型评论记录，用户ID: {}, 对象类型: {}", userId, objectType);
        List<Comment> comments = commentMapper.selectList(
                new QueryWrapper<Comment>()
                        .eq("commenter_id", userId)
                        .eq("commentable_type", objectType)
                        .eq("is_deleted", 0)
                        .orderByDesc("creation_time")
        );
        return Resp.success(comments);
    }

    /**
     * 获取用户评论总数
     */
    @Override
    public Resp<Integer> getCommentCountByUser(Long userId) {
        log.info("查询用户评论总数，用户ID: {}", userId);
        Integer count = Math.toIntExact(commentMapper.selectCount(
                new QueryWrapper<Comment>()
                        .eq("commenter_id", userId)
                        .eq("is_deleted", 0)
        ));
        return Resp.success(count);
    }

    /**
     * 清空用户所有评论记录 (逻辑删除)
     */
    @Override
    public Resp<Void> clearAllCommentsByUser(Long userId) {
        log.info("清空用户所有评论记录，用户ID: {}", userId);
        UpdateWrapper<Comment> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("is_deleted", 1).eq("commenter_id", userId);
        commentMapper.update(null, updateWrapper);
        return Resp.success(null);
    }

    @Override
    public Resp<Integer> getReceivedCommentCount(Long userId) {
        try {
            // 1. 获取用户的所有帖子ID
            LambdaQueryWrapper<Post> postLqw = Wrappers.lambdaQuery();
            postLqw.select(Post::getId)
                   .eq(Post::getUserId, userId)
                   .eq(Post::getIsDeleted, 0);
            List<Long> postIds = postMapper.selectList(postLqw)
                    .stream()
                    .map(Post::getId)
                    .collect(Collectors.toList());

            // 2. 获取用户的所有合集ID
            LambdaQueryWrapper<Collection> collectionLqw = Wrappers.lambdaQuery();
            collectionLqw.select(Collection::getId)
                        .eq(Collection::getCreatorId, userId)
                        .eq(Collection::getIsDeleted, 0);

            List<Long> collectionIds = collectionMapper.selectList(collectionLqw)
                    .stream()
                    .map(Collection::getId)
                    .collect(Collectors.toList());

            // 3. 获取用户的所有评论ID
            LambdaQueryWrapper<Comment> userCommentLqw = Wrappers.lambdaQuery();
            userCommentLqw.select(Comment::getId)
                         .eq(Comment::getCommenterId, userId)
                         .eq(Comment::getIsDeleted, 0)
                         .eq(Comment::getReviewStatus, 1);
            List<Long> commentIds = list(userCommentLqw)
                    .stream()
                    .map(Comment::getId)
                    .collect(Collectors.toList());

            // 4. 统计这些内容收到的评论数
            LambdaQueryWrapper<Comment> commentLqw = Wrappers.lambdaQuery();
            commentLqw.eq(Comment::getIsDeleted, 0)
                     .eq(Comment::getReviewStatus, 1)
                     .eq(Comment::getIsPublic, 1);

            // 统计帖子评论
            if (!postIds.isEmpty()) {
                commentLqw.and(wrapper -> wrapper
                    .in(Comment::getCommentableId, postIds)
                    .eq(Comment::getCommentableType, 1));
            }

            // 统计合集评论
            if (!collectionIds.isEmpty()) {
                commentLqw.or(wrapper -> wrapper
                    .in(Comment::getCommentableId, collectionIds)
                    .eq(Comment::getCommentableType, 2));
            }

            // 统计评论的回复
            if (!commentIds.isEmpty()) {
                commentLqw.or(wrapper -> wrapper
                    .in(Comment::getCommentableId, commentIds)
                    .eq(Comment::getCommentableType, 3));
            }

            // 如果用户没有任何内容，直接返回0
            if (postIds.isEmpty() && collectionIds.isEmpty() && commentIds.isEmpty()) {
                return Resp.success(0);
            }

            int count = Math.toIntExact(count(commentLqw));
            return Resp.success(count);
        } catch (Exception e) {
            log.error("获取用户收到的评论数量失败, userId: {}", userId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论数量失败");
        }
    }

    @Override
    public Resp<Void> incrementLikeCount(Long commentId) {
        log.info("增加评论点赞数, commentId: {}", commentId);
        try {
            // 1. 检查评论是否存在
            Comment comment = getById(commentId);
            if (comment == null || comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在或已删除");
            }

            // 2. 更新点赞数
            comment.setLikeCount(comment.getLikeCount() + 1);
            boolean success = updateById(comment);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新点赞数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("增加评论点赞数失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加点赞数失败");
        }
    }

    @Override
    public Resp<Void> decrementLikeCount(Long commentId) {
        log.info("减少评论点赞数, commentId: {}", commentId);
        try {
            // 1. 检查评论是否存在
            Comment comment = getById(commentId);
            if (comment == null || comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在或已删除");
            }

            // 2. 更新点赞数（确保不会小于0）
            comment.setLikeCount(Math.max(comment.getLikeCount() - 1, 0));
            boolean success = updateById(comment);

            if (!success) {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新点赞数失败");
            }

            return Resp.success(null);
        } catch (Exception e) {
            log.error("减少评论点赞数失败, commentId: {}", commentId, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "减少点赞数失败");
        }
    }
}
