package com.example.ksp.modules.admin.management.reviewmg.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "审核处理DTO")
public class ReviewManageDTO {
    
    @Schema(description = "审核记录ID")
    @NotNull(message = "审核记录ID不能为空")
    private Long id;
    
    @Schema(description = "审核对象ID")
    @NotNull(message = "审核对象ID不能为空")
    private Long targetId;
    
    @Schema(description = "审核类型：1-帖子 2-用户 3-合集 4-收藏夹")
    @NotNull(message = "审核类型不能为空")
    @Min(value = 1, message = "审核类型不正确")
    @Max(value = 4, message = "审核类型不正确")
    private Integer type;
    
    @Schema(description = "审核状态：0-待处理 1-通过 2-拒绝")
    @NotNull(message = "审核状态不能为空")
    @Min(value = 0, message = "审核状态不正确")
    @Max(value = 2, message = "审核状态不正确")
    private Integer status;
    
    @Schema(description = "处理原因")
    @NotBlank(message = "处理原因不能为空")
    @Size(max = 500, message = "处理原因长度不能超过500个字符")
    private String reason;
} 