package com.example.ksp.modules.client.personal.center.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderCreateDTO;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalFavoriteService;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端个人中心个人收藏管理")
@RestController
@RequestMapping("/api/client/personal/favorite")
@RequiredArgsConstructor
public class PersonalFavoriteController {

    private final PersonalFavoriteService personalFavoriteService;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
            .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    @Operation(summary = "创建收藏夹")
    @PostMapping("/folder")
    public Resp<FavoriteFolder> createFolder(@RequestBody @Valid FavoriteFolderCreateDTO folderDTO) {
        return personalFavoriteService.createFolder(getCurrentUserId(), folderDTO);
    }

    @Operation(summary = "修改收藏夹")
    @PutMapping("/folder")
    public Resp<Boolean> updateFolder(@RequestBody @Valid FavoriteFolderDTO folderDTO) {
        return personalFavoriteService.updateFolder(getCurrentUserId(), folderDTO);
    }

    @Operation(summary = "删除收藏夹")
    @DeleteMapping("/folder/{folderId}")
    public Resp<Boolean> deleteFolder(@PathVariable Long folderId) {
        return personalFavoriteService.deleteFolder(getCurrentUserId(), folderId);
    }

    @Operation(summary = "获取收藏夹列表")
    @GetMapping("/folder/list")
    public Resp<Page<FavoriteFolder>> getFolderList(
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalFavoriteService.getFolderList(getCurrentUserId(), current, size);
    }

    @Operation(summary = "获取收藏列表")
    @GetMapping("/list/{folderId}")
    public Resp<Page<Favorite>> getFavoriteList(
            @PathVariable Long folderId,
            @Parameter(description = "当前页") @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") @RequestParam(defaultValue = "10") long size) {
        return personalFavoriteService.getFavoriteList(getCurrentUserId(), folderId, current, size);
    }

    @Operation(summary = "删除收藏")
    @DeleteMapping("/{favoriteId}")
    public Resp<Boolean> deleteFavorite(@PathVariable Long favoriteId) {
        return personalFavoriteService.deleteFavorite(getCurrentUserId(), favoriteId);
    }

    @Operation(summary = "移动收藏")
    @PostMapping("/move/{favoriteId}")
    public Resp<Boolean> moveFavorite(
            @PathVariable Long favoriteId,
            @Parameter(description = "目标收藏夹ID") @RequestParam Long targetFolderId) {
        return personalFavoriteService.moveFavorite(getCurrentUserId(), favoriteId, targetFolderId);
    }
} 