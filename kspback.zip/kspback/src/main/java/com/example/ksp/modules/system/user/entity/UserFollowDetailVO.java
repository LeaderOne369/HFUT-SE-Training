package com.example.ksp.modules.system.user.entity;
import lombok.Data;

/**
 * 关注和被关注用户详情 VO
 */
@Data
public class UserFollowDetailVO {
    private Long userId; // 用户ID
    private String username; // 用户名
    private String avatar; // 用户头像
}
