package com.example.ksp.modules.client.personal.center.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.CreateCollectionDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;

public interface PersonalCollectionService {
    
    /**
     * 获取用户创建的合集列表
     */
    Resp<Page<Collection>> getUserCollections(Long userId, long current, long size);
    
    /**
     * 获取用户订阅的合集列表
     */
    Resp<Page<Collection>> getSubscribedCollections(Long userId, long current, long size);
    
    /**
     * 获取合集详情
     */
    Resp<Collection> getCollectionDetail(Long userId, Long collectionId);
    
    /**
     * 更新合集
     */
    Resp<Collection> updateCollection(Long userId, CollectionUpdateDTO updateDTO);
    
    /**
     * 删除合集
     */
    Resp<Boolean> deleteCollection(Long userId, Long collectionId);
    
    /**
     * 取消订阅合集
     */
    Resp<Boolean> unsubscribeCollection(Long userId, Long collectionId);

    Resp<Collection> createCollection(Long currentUserId, CreateCollectionDTO createDTO);
}