package com.example.ksp.modules.client.search;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.Operator;
import co.elastic.clients.elasticsearch._types.query_dsl.TextQueryType;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.search.dto.SearchHit;
import com.example.ksp.modules.client.search.dto.SearchResult;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.system.post.entity.Post;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
@Tag(name = "客户端搜索模块", description = "搜索模块相关接口")
@Slf4j
@RestController
@RequestMapping("/api/client/search")
public class SearchController {

    @Autowired
    private PostServiceProxy postService;



    @Autowired
    private ElasticsearchClient esClient;

    /**
     * 获取指定分区下的所有帖子
     *
     * @param sectionId 分区ID
     * @param page 页码
     * @param size 每页数量
     * @return 返回分页结果
     */
    @Operation(summary = "获取指定分区下的所有帖子")
    @GetMapping("/bySection/{sectionId}/posts")
    public Resp<Page<Post>> getPostsBySection(
            @PathVariable("sectionId") Long sectionId,
            @RequestParam("page") long page,
            @RequestParam("size") long size) {

        Page<Post> result = postService.getPostsBySection(sectionId, page, size);
        return Resp.success(result);
    }

    /**
     * 获取指定标签下的所有帖子
     *
     * @param tagId 标签ID
     * @param current 页码
     * @param size 每页数量
     * @return 返回分页结果
     */
    @Operation(summary = "获取指定标签下的所有帖子")
    @GetMapping("/byTag/{tagId}/posts")
    public Resp<Page<Post>> getPostsByTag(
            @PathVariable("tagId") Long tagId,
            @RequestParam("current") long current,
            @RequestParam("size") long size) {

        Page<Post> result = postService.getPostsByTag(tagId, current, size);
        return Resp.success(result);
    }

    /**
     * 通过标签和关键词搜索帖子
     *
     * @param tagId   标签ID
     * @param current 当前页码
     * @param size    每页大小
     * @param keyword 关键词
     * @return 分页的帖子列表
     */
    @Operation(summary = "通过标签和关键词搜索帖子")
    @GetMapping("/searchByTagAndKey")
    public Page<Post> searchPostsByTagAndKey(
            @RequestParam Long tagId,
            @RequestParam long current,
            @RequestParam long size,
            @RequestParam String keyword) {
        return postService.searchPostsByTagAndKey(tagId, current, size, keyword);
    }
    @Autowired
    private RedisCache redisCache;

    /**
     * 根据关键词搜索帖子，并保存搜索历史到Redis
     *
     * @param current 当前页码
     * @param size    每页大小
     * @param keyword 搜索的关键词
     * @param token   用户的token（通过header传递）
     * @return 分页的帖子列表
     */
    @Operation(summary = "根据关键词搜索帖子")
    @GetMapping("/searchByKeyword")
    public Page<Post> searchPostsByKeyword(
            @RequestParam long current,
            @RequestParam long size,
            @RequestParam String keyword,
            @RequestHeader String token) {

        // 获取用户名（假设token中包含了用户名，可以解析）
        String username = getUsernameFromToken(token);

        // 保存搜索历史到Redis
        saveSearchHistory(username, keyword);

        // 创建分页对象
        Page<Post> page = new Page<>(current, size);

        // 调用Service进行查询并返回分页结果
        return postService.selectPostsByKeyword(page, keyword);
    }

    /**
     * 从token中解析出用户名
     * 这里假设token已经包含了用户信息，具体解析方法取决于你的实现
     *
     * @param token 用户的token
     * @return 用户名
     */
    private String getUsernameFromToken(String token) {
        // 解析token获取用户名
        String username = null;
        try {
            username = JwtUtil.parseJWT(token).getSubject();
        } catch (Exception e) {
            log.info("解析token失败: {}", e.getMessage());
            throw new RuntimeException(e);
        }

        // 从Redis中获取用户信息
        String redisKey = "login:" + username;
        LoginUser loginUser = redisCache.getCacheObject(redisKey);
        return loginUser.getUsername();
    }

    /**
     * 将用户的搜索历史保存到Redis中，最多保留50条，不重复
     *
     * @param username 用户名
     * @param keyword  用户搜索的关键词
     */
    private void saveSearchHistory(String username, String keyword) {
        String key = "searchHistory:" + username;

        // 获取当前用户的搜索历史
        List<String> history = redisCache.getCacheList(key);

        // 如果搜索历史已经包含该关键词，则不再重复保存
        if (history.contains(keyword)) {
            return;
        }

        // 如果历史记录超过50条，则删除最旧的记录
        if (history.size() >= 50) {
            redisCache.deleteObject(key);
            redisCache.setCacheList(key, history.subList(1, history.size()));  // 删除最旧的记录
        }

        // 将新的搜索关键词添加到历史记录中
        redisCache.setCacheList(key, List.of(keyword));
    }


    /**
     * 获取用户的搜索历史
     *
     * @param token 用户的token
     * @return 用户的搜索历史
     */
    @Operation(summary = "获取用户的搜索历史")
    @GetMapping("/searchHistory")
    public List<String> getSearchHistory(@RequestHeader String token) {
        // 获用户名
        String username = getUsernameFromToken(token);

        // 从Redis中获取搜索历史
        String key = "searchHistory:" + username;
        return redisCache.getCacheList(key);
    }


    /**
     * ES全文搜索帖子
     *
     * @param keyword 搜索关键词
     * @param page 当前页码
     * @param size 每页大小
     * @return 搜索结果
     */
    @Operation(summary = "ES全文搜索帖子")
    @GetMapping("/es/posts")
    public Resp<SearchResult<Post>> searchPosts(
            @RequestHeader String token,
            @RequestParam String keyword,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            // 构建搜索请求
            SearchResult<Post> result = postService.searchPostsByKeyword(keyword, page, size);
            String username = getUsernameFromToken(token);

            // 保存搜索历史到Redis
            saveSearchHistory(username, keyword);
            return Resp.success(result);
            
        } catch (Exception e) {
            log.error("ES搜索异常: ", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR, "搜索服务异常");
        }
    }


}
