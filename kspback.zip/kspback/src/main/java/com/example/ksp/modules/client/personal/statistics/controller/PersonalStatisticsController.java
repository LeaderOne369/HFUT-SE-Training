package com.example.ksp.modules.client.personal.statistics.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.statistics.service.PersonalStatisticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "客户端个人统计接口", description = "提供用户个人数据统计相关的接口")
@RestController
@RequestMapping("/api/client/statistics")
@RequiredArgsConstructor
public class PersonalStatisticsController {

    private final PersonalStatisticsService personalStatisticsService;

    @Operation(summary = "获取用户社交统计数据")
    @GetMapping("/{userId}/social")
    public Resp<Map<String, Integer>> getSocialStats(@PathVariable Long userId) {
        return personalStatisticsService.getSocialStats(userId);
    }

    @Operation(summary = "获取用户内容创作统计数据")
    @GetMapping("/{userId}/content")
    public Resp<Map<String, Integer>> getContentStats(@PathVariable Long userId) {
        return personalStatisticsService.getContentStats(userId);
    }

    @Operation(summary = "获取用户互动统计数据")
    @GetMapping("/{userId}/interaction")
    public Resp<Map<String, Integer>> getInteractionStats(@PathVariable Long userId) {
        return personalStatisticsService.getInteractionStats(userId);
    }

    @Operation(summary = "获取用户所有统计数据")
    @GetMapping("/{userId}/all")
    public Resp<Map<String, Integer>> getAllStats(@PathVariable Long userId) {
        return personalStatisticsService.getAllStats(userId);
    }
} 