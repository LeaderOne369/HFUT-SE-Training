package com.example.ksp.modules.system.statistics.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface StatisticsMapper extends BaseMapper<Object> {

    /**
     * 统计总数量
     *
     * @param tableName 表名
     * @return 总数量
     */
    @Select("SELECT COUNT(*) FROM `${tableName}` WHERE is_deleted = 0")
    Long countTotal(@Param("tableName") String tableName);

    /**
     * 统计增量数量
     *
     * @param tableName 表名
     * @param timeField 时间字段
     * @param startTime 开始时间
     * @return 增量数量
     */
    @Select("SELECT COUNT(*) FROM `${tableName}` WHERE is_deleted = 0 AND `${timeField}` >= #{startTime}")
    Long countIncrement(@Param("tableName") String tableName, @Param("timeField") String timeField, @Param("startTime") String startTime);
}
