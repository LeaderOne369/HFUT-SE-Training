package com.example.ksp.modules.client.recommendation.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.recommendation.dto.RecommendationDTO;
import java.util.List;

public interface RecommendationService {
    /**
     * 获取搜索推荐
     * @param keyword 搜索关键词
     * @param size 推荐数量
     * @return 推荐内容列表
     */
    Resp<List<RecommendationDTO>> getSearchRecommendations(String keyword, int size);
    
    /**
     * 获取相关帖子推荐
     * @param postId 帖子ID
     * @param size 推荐数量
     * @return 推荐内容列表
     */
    Resp<List<RecommendationDTO>> getRelatedPosts(Long postId, int size);

    Resp<List<String>> getSearchRecommendationKeyword(List<String> history , int size);
}