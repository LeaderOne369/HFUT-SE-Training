package com.example.ksp.modules.admin.management.reportmg.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportHandleDTO;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportQueryDTO;
import com.example.ksp.modules.admin.management.reportmg.vo.ReportVO;

import java.util.Map;

public interface ReportManagementService {
    
    /**
     * 分页查询举报列表
     */
    Resp<Page<ReportVO>> getReportList(ReportQueryDTO queryDTO);
    
    /**
     * 获取举报详情
     */
    Resp<ReportVO> getReportDetail(Long reportId);
    
    /**
     * 处理举报
     */
    Resp<String> handleReport(ReportHandleDTO handleDTO);
    
    /**
     * 获取举报统计信息
     */
    Resp<Map<String, Object>> getReportStats();
} 