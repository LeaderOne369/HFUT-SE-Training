package com.example.ksp.modules.system.collection.collection.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collection.dto.CollectionCreateDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionQueryDTO;
import com.example.ksp.modules.system.collection.collection.dto.CollectionUpdateDTO;
import com.example.ksp.modules.system.collection.collection.entity.Collection;
import com.example.ksp.modules.system.collection.collection.service.CollectionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级合集管理")
@RestController
@RequestMapping("/api/system/collection")
@RequiredArgsConstructor
public class CollectionController {

    private final CollectionService collectionService;

    @Operation(summary = "创建合集")
    @PostMapping
    public Resp<Collection> createCollection(
            @RequestHeader("token") String token,
            @RequestBody @Valid CollectionCreateDTO createDTO) {
        return collectionService.createCollection(createDTO);
    }

    @Operation(summary = "更新合集")
    @PutMapping
    public Resp<Collection> updateCollection(
            @RequestHeader("token") String token,
            @RequestBody @Valid CollectionUpdateDTO updateDTO) {
        return collectionService.updateCollection(updateDTO);
    }

    @Operation(summary = "删除合集")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteCollection(
            @RequestHeader("token") String token,
            @Parameter(description = "合集ID") 
            @PathVariable Long id) {
        return collectionService.deleteCollection(id);
    }

    @Operation(summary = "获取合集详情")
    @GetMapping("/{id}")
    public Resp<Collection> getCollection(
            @RequestHeader("token") String token,
            @Parameter(description = "合集ID") 
            @PathVariable Long id) {
        return collectionService.getCollection(id);
    }

    @Operation(summary = "查询合集列表")
    @PostMapping("/list")
    public Resp<Page<Collection>> queryCollections(
            @RequestHeader("token") String token,
            @RequestBody CollectionQueryDTO queryDTO) {
        return collectionService.queryCollections(queryDTO);
    }
}