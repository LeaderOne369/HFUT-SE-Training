package com.example.ksp.modules.system.collection.collectionsubs.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CollectionSubscriptionsMapper extends BaseMapper<CollectionSubscriptions> {
} 