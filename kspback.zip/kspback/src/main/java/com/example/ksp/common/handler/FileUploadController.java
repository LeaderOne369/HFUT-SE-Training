package com.example.ksp.common.handler;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "文件上传接口")
@RestController
@RequestMapping("/api/file")
@RequiredArgsConstructor
public class FileUploadController {

    private final FileUploadHandler fileUploadHandler;

    private Long getCurrentUserId() {
        LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        return loginUser.getXxuser().getId();
    }

    @Operation(summary = "上传头像")
    @PostMapping("/avatar")
    @PreAuthorize("isAuthenticated()")
    public Resp<?> uploadAvatar(
            @Parameter(description = "头像文件") @RequestParam("file") MultipartFile file) {
        return fileUploadHandler.uploadFile(file, FileUploadHandler.FileType.AVATAR, getCurrentUserId());
    }

    @Operation(summary = "上传帖子内容")
    @PostMapping("/content")
    @PreAuthorize("isAuthenticated()")
    public Resp<?> uploadContent(
            @Parameter(description = "内容文件") @RequestParam("file") MultipartFile file) {
        return fileUploadHandler.uploadFile(file, FileUploadHandler.FileType.CONTENT, getCurrentUserId());
    }

    @Operation(summary = "上传帖子封面")
    @PostMapping("/cover")
    @PreAuthorize("isAuthenticated()")
    public Resp<?> uploadCover(
            @Parameter(description = "封面文件") @RequestParam("file") MultipartFile file) {
        return fileUploadHandler.uploadFile(file, FileUploadHandler.FileType.COVER, getCurrentUserId());
    }

    @Operation(summary = "上传图片")
    @PostMapping("/image")
    @PreAuthorize("isAuthenticated()")
    public Resp<?> uploadImage(
            @Parameter(description = "图片文件") @RequestParam("file") MultipartFile file) {
        return fileUploadHandler.uploadImage(file, getCurrentUserId());
    }
} 