package com.example.ksp.modules.system.collection.collectionsubs.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsCreateDTO;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsQueryDTO;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;

public interface CollectionSubscriptionsService extends IService<CollectionSubscriptions> {
    
    Resp<CollectionSubscriptions> createSubscription(CollectionSubscriptionsCreateDTO createDTO);
    
    Resp<Void> cancelSubscription(Long id);
    
    Resp<CollectionSubscriptions> getSubscription(Long id);
    
    Resp<Page<CollectionSubscriptions>> querySubscriptions(CollectionSubscriptionsQueryDTO queryDTO);
} 