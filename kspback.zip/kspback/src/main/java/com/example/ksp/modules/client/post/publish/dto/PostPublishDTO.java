package com.example.ksp.modules.client.post.publish.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@Data
@Schema(description = "帖子发布DTO")
public class PostPublishDTO {



    
    @Schema(description = "帖子标题")
    private String title;

    @Schema(description = "封面")
    private String cover;

    @Schema(description = "帖子内容的简短描述，用于快速预览")
    private String summary;

    @Schema(description = "内容文件ID，由文件上传接口返回")
    private String contentFileId;

    @Schema(description = "内容文件路径，由文件上传接口返回")
    private String contentFilePath;
    
    @Schema(description = "分区ID")
    private Long sectionId;
    
    @Schema(description = "帖子的标签，用于分类和搜索，可以是多个标签的字符串，例如 \"标签1, 标签2\"")
    private String tags;
    
    @Schema(description = "所属合集ID")
    private Long collectionId;


    @Schema(description = "是否包含引用(0:否 1:是)")
    private Integer hasCitation = 0;

    @Schema(description = "可见性(0:私密 1:公开 )")
    private Integer visibility;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Schema(description = "引用信息")
    private CitationDTO citation;
} 