package com.example.ksp.modules.system.citation.citation.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CitationMapper extends BaseMapper<Citation> {
} 