package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.share.dto.ShareCreateDTO;
import com.example.ksp.modules.system.share.dto.ShareQueryDTO;
import com.example.ksp.modules.system.share.entity.Share;
import com.example.ksp.modules.system.share.service.ShareService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class ShareServiceProxy {

    private final ShareService shareService;
    /**
     * 获取用户所有分享记录
     */
    public Resp<Page<Share>> getUserShares(Long userId, long current, long size) {
        return shareService.getUserShares(userId, current, size);
    }

    /**
     * 获取特定对象的分享记录
     */
    public Resp<Page<Share>> getObjectShares(Long objectId, Integer objectType, long current, long size) {
        return shareService.getObjectShares(objectId, objectType, current, size);
    }

    /**
     * 删除用户的分享记录
     */
    public Resp<Void> deleteShare(Long shareId) {
        return shareService.deleteShare(shareId);
    }

    /**
     * 获取用户分享的总数
     */
    public Resp<Long> getUserShareCount(Long userId) {
        return shareService.getUserShareCount(userId);
    }

    /**
     * 判断用户是否分享过帖子
     *
     * @param postId 帖子ID
     * @param objectType 对象类型（1:帖子 2:合集）
     * @param userId 用户ID
     * @return 是否已分享
     */
    public Resp<Boolean> isShared(Long postId, Integer objectType, Long userId) {
        log.info("代理层：判断用户是否分享帖子，用户ID: {}, 帖子ID: {}", userId, postId);
        if (userId == null || userId <= 0 || postId == null || postId <= 0) {
            return Resp.error(400, "用户ID或帖子ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 2) {
            return Resp.error(400, "分享对象类型无效");
        }

        try {
            // 使用 queryShares 方法查询特定用户对特定帖子的分享记录
            ShareQueryDTO queryDTO = new ShareQueryDTO();
            queryDTO.setUserId(userId);
            queryDTO.setShareObjectId(postId);
            queryDTO.setShareObjectType(objectType);
            queryDTO.setCurrent(1L);
            queryDTO.setSize(1L);
            
            Resp<Page<Share>> sharesResp = shareService.queryShares(queryDTO);
            if (sharesResp.getCode() != 200 || sharesResp.getData() == null) {
                return Resp.error(500, "获取分享记录失败");
            }
            
            boolean isShared = sharesResp.getData().getTotal() > 0;
            return Resp.success(isShared);
        } catch (Exception e) {
            log.error("检查帖子分享状态失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "检查分享状态失败");
        }
    }

    /**
     * 添加分享记录
     *
     * @param userId 用户ID
     * @param objectId 被分享对象ID
     * @param objectType 被分享对象类型(1:帖子 2:合集)
     * @return 操作结果
     */
    public Resp<Share> addShare(Long userId, Long objectId, Integer objectType) {
        log.info("代理层：添加分享记录，用户ID：{}，对象ID：{}，对象类型：{}", userId, objectId, objectType);
        
        // 参数校验
        if (userId == null || userId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的用户ID");
        }
        if (objectId == null || objectId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的对象ID");
        }
        if (objectType == null || objectType < 1 || objectType > 2) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的对象类型");
        }
        
        try {
            LambdaQueryWrapper<Share> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Share::getUserId, userId)
                            .eq(Share::getShareObjectId, objectId)
                            .eq(Share::getShareObjectType, objectType);

            Share one = shareService.getOne(queryWrapper);
            if (one != null) {
                one.setIsDeleted(0);
                boolean res = shareService.updateById(one);
                return  res ? Resp.success(one) : Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新分享记录失败");
            }
            // 创建分享记录
            ShareCreateDTO createDTO = new ShareCreateDTO();
            createDTO.setUserId(userId);
            createDTO.setShareObjectId(objectId);
            createDTO.setShareObjectType(objectType);
            
            Resp<Share> shareResp = shareService.createShare(createDTO);
            return Resp.success(shareResp.getData());
        } catch (Exception e) {
            log.error("添加分享记录失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "添加分享记录失败");
        }
    }
}
