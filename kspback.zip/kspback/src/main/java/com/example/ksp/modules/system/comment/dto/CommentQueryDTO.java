package com.example.ksp.modules.system.comment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "评论查询参数")
public class CommentQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "评论者ID")
    private Long commenterId;
    
    @Schema(description = "被评论对象ID")
    private Long commentableId;
    
    @Schema(description = "被评论对象类型")
    private Integer commentableType;
    
    @Schema(description = "父评论ID")
    private Long parentCommentId;
    
    @Schema(description = "审核状态")
    private Integer reviewStatus;

    @Schema(description = "关键词")
    private String keyword;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 