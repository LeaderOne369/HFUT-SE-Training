package com.example.ksp.modules.system.tag.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class TagUpdateDTO {
    @NotNull(message = "标签ID不能为空")
    private Long id;
    
    private String tagName;
    private String tagDescription;
    private Long sectionId;
} 