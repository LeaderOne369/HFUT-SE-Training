package com.example.ksp.modules.client.recommendation.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "推荐内容DTO")
public class RecommendationDTO {
    
    @Schema(description = "帖子ID")
    private Long postId;
    
    @Schema(description = "帖子标题")
    private String title;
    
    @Schema(description = "帖子描述")
    private String description;
    
    @Schema(description = "封面图片URL")
    private String coverUrl;
    
    @Schema(description = "推荐分数")
    private Double score;
} 