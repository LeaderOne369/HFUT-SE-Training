package com.example.ksp.modules.client.ai.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "聊天消息")
public class ChatMessage {
    
    @Schema(description = "角色(user/assistant)")
    private String role;
    
    @Schema(description = "消息内容")
    private String content;
    
    public static ChatMessage userMessage(String content) {
        ChatMessage message = new ChatMessage();
        message.setRole("user");
        message.setContent(content);
        return message;
    }
    
    public static ChatMessage assistantMessage(String content) {
        ChatMessage message = new ChatMessage();
        message.setRole("assistant");
        message.setContent(content);
        return message;
    }
} 