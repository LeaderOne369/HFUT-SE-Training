package com.example.ksp.modules.admin.statistics;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.StatisticsServiceProxy;
import com.example.ksp.modules.system.statistics.StatisticsRequest;
import com.example.ksp.modules.system.statistics.dto.StatisticsResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
@Tag(name = "管理端统计相关接口")
@RestController
@RequestMapping("/api/admin/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsServiceProxy statisticsService;

    /**
     * 获取统计数据
     *
     * @param request 统计请求
     * @return 统计响应
     */
    @Operation(summary = "获取统计数据")
    @PostMapping
    public Resp<StatisticsResponse> getStatistics(@Valid @RequestBody StatisticsRequest request) {
        StatisticsResponse response = statisticsService.getStatistics(request);
        return Resp.success(response);
    }
}
