package com.example.ksp.modules.system.reviewlog.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("review_log")
@Schema(name = "ReviewLog对象", description = "审核日志信息")
public class ReviewLog {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "被审核内容ID")
    private Long contentId;

    @Schema(description = "被审核内容类型(0:用户 1:帖子 2:合集 3:收藏夹)")
    private Integer contentType;

    @Schema(description = "审核人ID")
    private Long reviewerId;

    @Schema(description = "审核状态(0:待审核 1:已通过 2:已拒绝)")
    private Integer reviewStatus;

    @Schema(description = "审核时间")
    private LocalDateTime reviewTime;

    @Schema(description = "审核备注")
    private String reviewNotes;
} 