package com.example.ksp.modules.client.ai.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.ai.dto.AiWritingRequest;
import com.example.ksp.modules.client.ai.service.AiChatService;
import com.example.ksp.modules.client.ai.service.AiWriteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.ConcurrentHashMap;

@Tag(name = "客户端AI对话接口")
@RestController
@RequestMapping("/api/client/ai/chat")
@RequiredArgsConstructor
@CrossOrigin
public class AiChatController {

    private final AiChatService aiChatService;

    private final AiWriteService aiWriteService;

    @Operation(summary = "建立对话连接", description = "在发送消息前必须先调用此接口建立连接")
    @GetMapping("/connect")
    public ConcurrentHashMap<Object, Object> connect() {
        return aiChatService.createChatConnection();
    }

    @Operation(summary = "发送对话消息(流式)", description = "发送消息前需要先调用 /connect 接口获取 clientId")
    @PostMapping("/{clientId}")
    public Resp<Void> chat(
            @Parameter(description = "客户端ID(通过 /connect 接口获取)") 
            @PathVariable String clientId,
            @Parameter(description = "问题内容") 
            @RequestBody String question) {
        return aiChatService.chat(clientId, question);
    }

    @Operation(summary = "发送对话消息(非流式)", description = "直接发送消息并等待完整回复")
    @PostMapping("/sync/{clientId}")
    public Resp<String> chatSync(
            @Parameter(description = "客户端ID(通过 /connect 接口获取)") 
            @PathVariable String clientId,
            @Parameter(description = "问题内容") 
            @RequestBody String question) {
        return aiChatService.chatSync(clientId, question);
    }

    @Operation(summary = "关闭对话连接")
    @DeleteMapping("/{clientId}")
    public Resp<Void> close(
            @Parameter(description = "客户端ID") 
            @PathVariable String clientId) {
        aiChatService.closeChatConnection(clientId);
        return Resp.success(null);
    }

    @Operation(summary = "获取用户近期活动总结", description = "根据用户的发帖和浏览历史生成总结")
    @GetMapping("/summary")
    public Resp<String> getUserActivitySummary(
            @Parameter(description = "用户token") 
            @RequestHeader("token") String token) {
        return aiWriteService.generateUserActivitySummary(token);
    }

    @Operation(summary = "AI帮写文章", description = "根据提供的信息自动补全文章内容")
    @PostMapping("/write")
    public Resp<String> getAiWritingAssistance(
            @Parameter(description = "写作辅助请求") 
            @RequestBody AiWritingRequest request) {
        return aiWriteService.generateArticleContent(request);
    }

} 