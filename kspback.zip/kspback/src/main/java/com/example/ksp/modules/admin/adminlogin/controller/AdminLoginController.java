package com.example.ksp.modules.admin.adminlogin.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.adminlogin.dto.AdminLoginDTO;
import com.example.ksp.modules.admin.adminlogin.service.AdminLoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "管理员登录接口")
@RestController
@RequestMapping("/api/admin/login")
@RequiredArgsConstructor
public class AdminLoginController {

    private final AdminLoginService adminLoginService;

    @Operation(summary = "管理员登录")
    @PostMapping
    public Resp<Map<String, Object>> login(@RequestBody @Valid AdminLoginDTO adminLoginDTO) {
        return adminLoginService.login(adminLoginDTO);
    }

    @Operation(summary = "获取当前登录管理员信息")
    @GetMapping("/info")
    public Resp<Map<String, Object>> getLoginInfo() {
        return adminLoginService.getLoginInfo();
    }

    @Operation(summary = "管理员退出登录")
    @PostMapping("/logout")
    public Resp<Void> logout() {
        return adminLoginService.logout();
    }

    @Operation(summary = "刷新Token")
    @PostMapping("/refresh-token")
    public Resp<Map<String, String>> refreshToken() {
        return adminLoginService.refreshToken();
    }

    @Operation(summary = "检查Token有效性")
    @GetMapping("/check-token")
    public Resp<Boolean> checkToken(@RequestParam String token) {
        return adminLoginService.checkToken(token);
    }

    @Operation(summary = "获取IP地址信息")
    @GetMapping("/ip-info")
    public Resp<Map<String, String>> getIpInfo(
            @Parameter(description = "IP地址，为空则获取当前请求的IP") 
            @RequestParam(required = false) String ip) {
        return adminLoginService.getIpInfo(ip);
    }
} 