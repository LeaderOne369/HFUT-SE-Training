package com.example.ksp.modules.system.report.reporttype.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeCreateDTO;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeUpdateDTO;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;
import com.example.ksp.modules.system.report.reporttype.mapper.ReportTypeMapper;
import com.example.ksp.modules.system.report.reporttype.service.ReportTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class ReportTypeServiceImpl extends ServiceImpl<ReportTypeMapper, ReportType> implements ReportTypeService {

    @Override
    public Resp<ReportType> createReportType(ReportTypeCreateDTO createDTO) {
        try {
            // 检查是否已存在相同名称的举报类型
            if (checkTypeNameExists(createDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "举报类型名称已存在");
            }
            
            ReportType reportType = new ReportType();
            BeanUtils.copyProperties(createDTO, reportType);
            
            save(reportType);
            return Resp.success(reportType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建举报类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<ReportType> updateReportType(ReportTypeUpdateDTO updateDTO) {
        try {
            ReportType existingType = getById(updateDTO.getId());
            if (existingType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报类型不存在");
            }
            
            // 如果修改了类型名称，需要检查是否与其他记录重复
            if (StringUtils.hasText(updateDTO.getTypeName()) 
                && !updateDTO.getTypeName().equals(existingType.getTypeName())
                && checkTypeNameExists(updateDTO.getTypeName())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "举报类型名称已存在");
            }
            
            BeanUtils.copyProperties(updateDTO, existingType);
            updateById(existingType);
            
            return Resp.success(existingType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新举报类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> deleteReportType(Long id) {
        try {
            if (!removeById(id)) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报类型不存在");
            }
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除举报类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<ReportType> getReportType(Long id) {
        try {
            ReportType reportType = getById(id);
            if (reportType == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "举报类型不存在");
            }
            return Resp.success(reportType);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取举报类型失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<ReportType>> listReportTypes(Page<ReportType> page, String typeName, Integer isActive) {
        try {
            LambdaQueryWrapper<ReportType> wrapper = new LambdaQueryWrapper<>();
            
            // 添加查询条件
            if (StringUtils.hasText(typeName)) {
                wrapper.like(ReportType::getTypeName, typeName);
            }
            if (isActive != null) {
                wrapper.eq(ReportType::getIsActive, isActive);
            }
            
            // 执行分页查询
            Page<ReportType> result = page(page, wrapper);
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询举报类型列表失败: " + e.getMessage());
        }
    }

    private boolean checkTypeNameExists(String typeName) {
        LambdaQueryWrapper<ReportType> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ReportType::getTypeName, typeName);
        return count(wrapper) > 0;
    }
} 