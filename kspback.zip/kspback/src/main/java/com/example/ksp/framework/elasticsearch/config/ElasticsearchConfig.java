package com.example.ksp.framework.elasticsearch.config;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import lombok.Data;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;

@Configuration
@ConfigurationProperties(prefix = "elasticsearch")
@Data
public class ElasticsearchConfig {
    private String host = "192.168.182.30";
    private Integer port = 9200;
    private String scheme = "http";

    @Bean
    public ElasticsearchClient elasticsearchClient() {
        // 创建支持 Java 8 日期时间的 ObjectMapper
        ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"))
            .setTimeZone(TimeZone.getDefault())
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
            
        // 创建自定义的 JsonpMapper
        JacksonJsonpMapper jsonpMapper = new JacksonJsonpMapper(mapper);
        
        // 创建 RestClient
        RestClient restClient = RestClient.builder(
            new HttpHost(host, port, scheme)
        ).build();
            
        // 创建 Transport
        ElasticsearchTransport transport = new RestClientTransport(
            restClient, jsonpMapper);
            
        // 创建 ElasticsearchClient
        return new ElasticsearchClient(transport);
    }
}