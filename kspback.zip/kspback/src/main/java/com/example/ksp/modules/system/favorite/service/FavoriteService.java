package com.example.ksp.modules.system.favorite.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favorite.entity.Favorite;

public interface FavoriteService extends IService<Favorite> {
    
    /**
     * 添加收藏
     */
    boolean addFavorite(Long userId, Long postId, Long folderId);

    /**
     * 取消收藏
     */
    boolean cancelFavorite(Long userId, Long postId);

    /**
     * 移动收藏到其他收藏夹
     */
    boolean moveFavorite(Long id, Long newFolderId);

    /**
     * 获取用户的收藏列表
     */
    Page<Favorite> getUserFavorites(Long userId, Long folderId, long current, long size);

    /**
     * 获取帖子的收藏数量
     */
    long getPostFavoriteCount(Long postId);

    /**
     * 检查用户是否已收藏帖子
     */
    boolean checkFavorite(Long userId, Long postId);

    /**
     * 批量移动收藏
     */
    boolean batchMoveFavorites(Long[] ids, Long newFolderId);

    Resp<Integer> getReceivedFavoriteCount(Long userId);
}