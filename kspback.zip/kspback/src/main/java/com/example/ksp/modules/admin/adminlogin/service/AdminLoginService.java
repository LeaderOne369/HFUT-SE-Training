package com.example.ksp.modules.admin.adminlogin.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.adminlogin.dto.AdminLoginDTO;
import java.util.Map;

public interface AdminLoginService {
    /**
     * 管理员登录
     */
    Resp<Map<String, Object>> login(AdminLoginDTO adminLoginDTO);

    /**
     * 获取当前登录管理员信息
     */
    Resp<Map<String, Object>> getLoginInfo();

    /**
     * 退出登录
     */
    Resp<Void> logout();

    /**
     * 刷新Token
     */
    Resp<Map<String, String>> refreshToken();

    /**
     * 检查Token有效性
     */
    Resp<Boolean> checkToken(String token);

    /**
     * 获取IP地址信息
     */
    Resp<Map<String, String>> getIpInfo(String ip);
} 