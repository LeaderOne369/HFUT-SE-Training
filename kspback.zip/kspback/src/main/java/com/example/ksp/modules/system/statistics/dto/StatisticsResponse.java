package com.example.ksp.modules.system.statistics.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StatisticsResponse {

    /**
     * 总数量
     */
    private Long totalCount;

    /**
     * 最近时间尺度内的增量数量
     */
    private Long incrementalCount;
}
