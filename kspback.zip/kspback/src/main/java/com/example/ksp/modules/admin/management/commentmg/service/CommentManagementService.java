package com.example.ksp.modules.admin.management.commentmg.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.commentmg.dto.AdminCommentDTO;

/**
 * 管理员评论管理服务接口
 */
public interface CommentManagementService {
    
    /**
     * 获取评论列表
     *
     * @param current 当前页
     * @param size 每页大小
     * @param keyword 评论内容关键词
     * @param commentableType 评论类型(1:帖子 2:合集 3:评论)
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param status 评论状态(0:不可见 1:可见)
     * @return 评论列表分页数据
     */
    Resp<Page<AdminCommentDTO>> getCommentList(long current, long size, String keyword, 
            Integer commentableType, String startTime, String endTime, Integer status);
    
    /**
     * 获取评论详情
     *
     * @param id 评论ID
     * @return 评论详细信息
     */
    Resp<AdminCommentDTO> getCommentDetail(Long id);
    
    /**
     * 更新评论状态
     *
     * @param id 评论ID
     * @param status 状态(0:不可见 1:可见)
     * @return 操作结果
     */
    Resp<String> updateCommentStatus(Long id, Integer status);
    
    /**
     * 删除评论
     *
     * @param id 评论ID
     * @return 操作结果
     */
    Resp<String> deleteComment(Long id);
} 