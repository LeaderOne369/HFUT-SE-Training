package com.example.ksp.modules.system.like.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.like.entity.Like;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LikeMapper extends BaseMapper<Like> {
} 