package com.example.ksp.modules.proxy;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.like.entity.Like;
import com.example.ksp.modules.system.like.service.LikeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 点赞服务代理类
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class LikeServiceProxy {

    private final LikeService likeService;

    /**
     * 获取用户所有点赞记录
     *
     * @param userId 用户ID
     * @return 点赞记录列表
     */
    public Resp<List<Like>> getAllLikesByUser(Long userId) {
        log.info("代理层：获取用户所有点赞记录，用户ID: {}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "用户ID无效");
        }
        return likeService.getAllLikesByUser(userId);
    }

    /**
     * 获取用户对特定对象类型的点赞记录
     *
     * @param userId 用户ID
     * @param objectType 点赞对象类型（1：帖子，2：合集，3：评论）
     * @return 点赞记录列表
     */
    public Resp<List<Like>> getLikesByUserAndType(Long userId, Integer objectType) {
        log.info("代理层：获取用户特定类型点赞记录，用户ID: {}, 对象类型: {}", userId, objectType);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "用户ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 3) {
            return Resp.error(400, "点赞对象类型无效");
        }
        return likeService.getLikesByUserAndType(userId, objectType);
    }

    /**
     * 获取用户点赞的总数
     *
     * @param userId 用户ID
     * @return 点赞总数
     */
    public Resp<Integer> getLikeCountByUser(Long userId) {
        log.info("代理层：获取用户点赞总数，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return likeService.getLikeCountByUser(userId);
        } catch (Exception e) {
            log.error("获取用户点赞总数失败", e);
            return Resp.error(500, "获取点赞总数失败");
        }
    }

    /**
     * 判断用户是否对某个对象点赞
     *
     * @param userId 用户ID
     * @param objectId 点赞对象ID
     * @param objectType 点赞对象类型
     * @return 是否点赞
     */
    public Resp<Boolean> isLiked(Long userId, Long objectId, Integer objectType) {
        log.info("代理层：判断用户是否点赞，用户ID: {}, 对象ID: {}, 对象类型: {}", userId, objectId, objectType);
        if (userId == null || userId <= 0 || objectId == null || objectId <= 0) {
            return Resp.error(400, "用户ID或对象ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 3) {
            return Resp.error(400, "点赞对象类型无效");
        }

        List<Like> likes = likeService.getLikesByUserAndType(userId, objectType).getData();
        boolean isLiked = likes.stream()
                .anyMatch(like -> like.getLikeObjectId().equals(objectId));

        return Resp.success(isLiked);
    }

    /**
     * 获取用户收到的点赞数量
     */
    public Resp<Integer> getReceivedLikeCount(Long userId) {
        log.info("代理层：获取用户收到的点赞数量，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return likeService.getReceivedLikeCount(userId);
        } catch (Exception e) {
            log.error("获取用户收到的点赞数量失败", e);
            return Resp.error(500, "获取点赞数量失败");
        }
    }

    /**
     * 检查用户是否已点赞
     */
    public Resp<Boolean> checkLiked(Long userId, Long objectId, Integer objectType) {
        log.info("代理层：检查用户是否已点赞，用户ID：{}，对象ID：{}，对象类型：{}", userId, objectId, objectType);
        if (userId == null || userId <= 0 || objectId == null || objectId <= 0) {
            return Resp.error(400, "用户ID或对象ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 3) {
            return Resp.error(400, "点赞对象类型无效");
        }
        try {
            boolean isLiked = likeService.checkLiked(userId, objectId, objectType);
            return Resp.success(isLiked);
        } catch (Exception e) {
            log.error("检查用户点赞状态失败", e);
            return Resp.error(500, "检查点赞状态失败");
        }
    }

    /**
     * 添加点赞
     */
    public Resp<Boolean> addLike(Long userId, Long objectId, Integer objectType) {
        log.info("代理层：添加点赞，用户ID：{}，对象ID：{}，对象类型：{}", userId, objectId, objectType);
        if (userId == null || userId <= 0 || objectId == null || objectId <= 0) {
            return Resp.error(400, "用户ID或对象ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 3) {
            return Resp.error(400, "点赞对象类型无效");
        }
        try {
            boolean result = likeService.addLike(userId, objectId, objectType);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("添加点赞失败", e);
            return Resp.error(500, "添加点赞失败");
        }
    }

    /**
     * 取消点赞
     */
    public Resp<Boolean> cancelLike(Long userId, Long objectId, Integer objectType) {
        log.info("代理层：取消点赞，用户ID：{}，对象ID：{}，对象类型：{}", userId, objectId, objectType);
        if (userId == null || userId <= 0 || objectId == null || objectId <= 0) {
            return Resp.error(400, "用户ID或对象ID无效");
        }
        if (objectType == null || objectType < 1 || objectType > 3) {
            return Resp.error(400, "点赞对象类型无效");
        }
        try {
            boolean result = likeService.cancelLike(userId, objectId, objectType);
            return Resp.success(result);
        } catch (Exception e) {
            log.error("取消点赞失败", e);
            return Resp.error(500, "取消点赞失败");
        }
    }


}
