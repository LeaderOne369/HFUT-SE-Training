package com.example.ksp.modules.client.clientlogin.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class DeactivateAccountDTO {
    @NotBlank(message = "密码不能为空")
    private String password;
} 