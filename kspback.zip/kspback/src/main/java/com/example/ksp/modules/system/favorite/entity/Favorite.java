package com.example.ksp.modules.system.favorite.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("favorite")
@Schema(name = "Favorite对象", description = "收藏信息")
public class Favorite {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "用户ID")
    private Long userId;

    @Schema(description = "帖子ID")
    private Long postId;

    @Schema(description = "收藏夹ID")
    private Long folderId;

    @Schema(description = "收藏时间")
    private LocalDateTime favoriteTime;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;
} 