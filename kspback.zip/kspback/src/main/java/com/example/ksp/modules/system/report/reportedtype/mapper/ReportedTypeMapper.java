package com.example.ksp.modules.system.report.reportedtype.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReportedTypeMapper extends BaseMapper<ReportedType> {
} 