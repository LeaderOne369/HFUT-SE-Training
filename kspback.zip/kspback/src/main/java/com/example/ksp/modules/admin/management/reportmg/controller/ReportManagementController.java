package com.example.ksp.modules.admin.management.reportmg.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportHandleDTO;
import com.example.ksp.modules.admin.management.reportmg.dto.ReportQueryDTO;
import com.example.ksp.modules.admin.management.reportmg.service.ReportManagementService;
import com.example.ksp.modules.admin.management.reportmg.vo.ReportVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "管理端举报管理接口")
@RestController
@RequestMapping("/api/admin/management/report")
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('admin')")
public class ReportManagementController {

    private final ReportManagementService reportManagementService;

    @Operation(summary = "获取举报列表")
    @GetMapping("/list")
    public Resp<Page<ReportVO>> getReportList(ReportQueryDTO queryDTO) {
        return reportManagementService.getReportList(queryDTO);
    }

    @Operation(summary = "获取举报详情")
    @GetMapping("/{reportId}")
    public Resp<ReportVO> getReportDetail(
            @Parameter(description = "举报ID") 
            @PathVariable Long reportId) {
        return reportManagementService.getReportDetail(reportId);
    }

    @Operation(summary = "处理举报")
    @PostMapping("/handle")
    public Resp<String> handleReport(@RequestBody @Valid ReportHandleDTO handleDTO) {
        return reportManagementService.handleReport(handleDTO);
    }

    @Operation(summary = "获取举报统计信息")
    @GetMapping("/stats")
    public Resp<Map<String, Object>> getReportStats() {
        return reportManagementService.getReportStats();
    }
} 