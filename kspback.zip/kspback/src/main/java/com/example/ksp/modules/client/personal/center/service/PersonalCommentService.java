package com.example.ksp.modules.client.personal.center.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.comment.entity.Comment;

public interface PersonalCommentService {
    
    /**
     * 获取用户发布的评论列表
     */
    Resp<Page<Comment>> getUserComments(Long userId, long current, long size);
    
    /**
     * 获取用户收到的评论列表
     */
    Resp<Page<Comment>> getReceivedComments(Long userId, long current, long size);
    
    /**
     * 获取评论详情
     */
    Resp<Comment> getCommentDetail(Long userId, Long commentId);
    
    /**
     * 删除评论
     */
    Resp<Boolean> deleteComment(Long userId, Long commentId);
}