package com.example.ksp.modules.system.collection.collectionsubs.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("collection_subscriptions")
@Schema(description = "合集订阅实体")
public class CollectionSubscriptions {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "订阅ID")
    private Long id;
    
    @Schema(description = "用户ID")
    private Long usersId;
    
    @Schema(description = "合集ID")
    private Long collectionsId;
    
    @Schema(description = "是否删除(1:已删除 0:未删除)")
    private Integer isDeleted;
    
    @Schema(description = "订阅时间")
    private LocalDateTime subscriptionTime;
} 