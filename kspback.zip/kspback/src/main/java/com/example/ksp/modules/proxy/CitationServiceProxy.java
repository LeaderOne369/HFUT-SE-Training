package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citation.dto.CitationCreateDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationQueryDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationUpdateDTO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.citation.citation.service.CitationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class CitationServiceProxy {
    
    private final CitationService citationService;

    /**
     * 创建引用
     */
    public Resp<Citation> createCitation(CitationCreateDTO createDTO) {
        log.info("代理层：创建引用，参数：{}", createDTO);
        try {
            return citationService.createCitation(createDTO);
        } catch (Exception e) {
            log.error("创建引用失败", e);
            return Resp.error(500, "创建引用失败");
        }
    }

    /**
     * 更新引用
     */
    public Resp<Citation> updateCitation(CitationUpdateDTO updateDTO) {
        log.info("代理层：更新引用，参数：{}", updateDTO);
        try {
            return citationService.updateCitation(updateDTO);
        } catch (Exception e) {
            log.error("更新引用失败", e);
            return Resp.error(500, "更新引用失败");
        }
    }

    /**
     * 删除引用
     */
    public Resp<String> deleteCitation(Long id) {
        log.info("代理层：删除引用，ID：{}", id);
        try {
            return citationService.deleteCitation(id);
        } catch (Exception e) {
            log.error("删除引用失败", e);
            return Resp.error(500, "删除引用失败");
        }
    }

    /**
     * 获取引用详情
     */
    public Resp<Citation> getCitation(Long id) {
        log.info("代理层：获取引用详情，ID：{}", id);
        try {
            return citationService.getCitation(id);
        } catch (Exception e) {
            log.error("获取引用详情失败", e);
            return Resp.error(500, "获取引用详情失败");
        }
    }

    /**
     * 分页查询引用
     */
    public Resp<Page<Citation>> queryCitations(CitationQueryDTO queryDTO) {
        log.info("代理层：分页查询引用，参数：{}", queryDTO);
        try {
            return citationService.queryCitations(queryDTO);
        } catch (Exception e) {
            log.error("查询引用列表失败", e);
            return Resp.error(500, "查询引用列表失败");
        }
    }

    /**
     * 获取帖子的所有引用
     */
    public Resp<List<Citation>> getPostCitations(Long postId) {
        log.info("代理层：获取帖子的所有引用，帖子ID：{}", postId);
        if (postId == null || postId <= 0) {
            return Resp.error(400, "无效的帖子ID");
        }
        try {
            return citationService.getPostCitations(postId);
        } catch (Exception e) {
            log.error("获取帖子引用列表失败", e);
            return Resp.error(500, "获取引用列表失败");
        }
    }
} 