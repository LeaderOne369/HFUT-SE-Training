package com.example.ksp.modules.system.report.reportedtype.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeCreateDTO;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeUpdateDTO;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;

public interface ReportedTypeService extends IService<ReportedType> {
    
    Resp<ReportedType> createReportedType(ReportedTypeCreateDTO createDTO);
    
    Resp<ReportedType> updateReportedType(ReportedTypeUpdateDTO updateDTO);
    
    Resp<Void> deleteReportedType(Long id);
    
    Resp<ReportedType> getReportedType(Long id);
    
    Resp<Page<ReportedType>> listReportedTypes(Page<ReportedType> page, String typeName, Integer isActive);
} 