package com.example.ksp.modules.system.report.report.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建举报请求参数")
public class ReportCreateDTO {
    
    @NotNull(message = "举报人ID不能为空")
    @Schema(description = "举报人ID")
    private Long userId;
    
    @NotNull(message = "被举报内容ID不能为空")
    @Schema(description = "被举报内容ID")
    private Long reportedContentId;
    
    @NotNull(message = "举报对象类型ID不能为空")
    @Schema(description = "举报对象类型ID")
    private Long reportedTypeId;
    
    @NotNull(message = "举报类型ID不能为空")
    @Schema(description = "举报类型ID")
    private Long reportTypeId;
    
    @Schema(description = "举报理由")
    private String reason;
} 