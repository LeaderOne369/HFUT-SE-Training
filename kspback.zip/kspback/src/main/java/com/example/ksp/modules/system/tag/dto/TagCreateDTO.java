package com.example.ksp.modules.system.tag.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class TagCreateDTO {
    @NotBlank(message = "标签名称不能为空")
    private String tagName;
    
    private String tagDescription;
    
    @NotNull(message = "分区ID不能为空")
    private Long sectionId;
} 