package com.example.ksp.modules.system.favoritefolder.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import com.example.ksp.modules.system.favoritefolder.mapper.FavoriteFolderMapper;
import com.example.ksp.modules.system.favoritefolder.service.FavoriteFolderService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class FavoriteFolderServiceImpl extends ServiceImpl<FavoriteFolderMapper, FavoriteFolder> implements FavoriteFolderService {

    @Override
    public boolean createFolder(FavoriteFolder folder) {
        folder.setCreationTime(LocalDateTime.now());
        folder.setUpdateTime(LocalDateTime.now());
        folder.setIsDeleted(0);
        folder.setReviewStatus(0); // 默认待审核
        return save(folder);
    }

    @Override
    public boolean updateFolder(FavoriteFolder folder) {
        FavoriteFolder existingFolder = getById(folder.getId());
        if (existingFolder == null) {
            return false;
        }
        
        folder.setUpdateTime(LocalDateTime.now());
        return updateById(folder);
    }

    @Override
    public boolean deleteFolder(Long id) {
        return removeById(id);
    }

    @Override
    public Page<FavoriteFolder> getUserFolders(Long userId, long current, long size) {
        Page<FavoriteFolder> page = new Page<>(current, size);
        LambdaQueryWrapper<FavoriteFolder> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(FavoriteFolder::getUserId, userId)
                .orderByDesc(FavoriteFolder::getUpdateTime);
        
        return page(page, wrapper);
    }

    @Override
    public boolean updateVisibility(Long id, Integer visibility) {
        FavoriteFolder folder = getById(id);
        if (folder == null) {
            return false;
        }
        
        folder.setVisibility(visibility);
        folder.setUpdateTime(LocalDateTime.now());
        return updateById(folder);
    }

    @Override
    public Page<FavoriteFolder> getPublicFolders(long current, long size) {
        Page<FavoriteFolder> page = new Page<>(current, size);
        LambdaQueryWrapper<FavoriteFolder> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(FavoriteFolder::getVisibility, 1)
                .eq(FavoriteFolder::getReviewStatus, 1)
                .orderByDesc(FavoriteFolder::getUpdateTime);
        
        return page(page, wrapper);
    }

    @Override
    public boolean updateReviewStatus(Long id, Integer status) {
        FavoriteFolder folder = getById(id);
        if (folder == null) {
            return false;
        }
        
        folder.setReviewStatus(status);
        folder.setUpdateTime(LocalDateTime.now());
        return updateById(folder);
    }
} 