package com.example.ksp.modules.system.favoritefolder.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;
import com.example.ksp.modules.system.favoritefolder.service.FavoriteFolderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级收藏夹管理接口")
@RestController
@RequestMapping("/api/system/folder")
public class FavoriteFolderController {

    @Autowired
    private FavoriteFolderService favoriteFolderService;

    @Operation(summary = "创建收藏夹")
    @PostMapping("/create")
    public Resp<Boolean> createFolder(@RequestBody FavoriteFolder folder) {
        boolean result = favoriteFolderService.createFolder(folder);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "创建收藏夹失败");
    }

    @Operation(summary = "更新收藏夹")
    @PutMapping("/update")
    public Resp<Boolean> updateFolder(@RequestBody FavoriteFolder folder) {
        boolean result = favoriteFolderService.updateFolder(folder);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新收藏夹失败");
    }

    @Operation(summary = "删除收藏夹")
    @DeleteMapping("/delete/{id}")
    public Resp<Boolean> deleteFolder(
            @Parameter(description = "收藏夹ID", required = true) 
            @PathVariable Long id) {
        boolean result = favoriteFolderService.deleteFolder(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除收藏夹失败");
    }

    @Operation(summary = "获取用户的收藏夹列表")
    @GetMapping("/user/list")
    public Resp<Page<FavoriteFolder>> getUserFolders(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<FavoriteFolder> result = favoriteFolderService.getUserFolders(userId, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "更新收藏夹可见性")
    @PutMapping("/visibility/{id}")
    public Resp<Boolean> updateVisibility(
            @Parameter(description = "收藏夹ID", required = true) 
            @PathVariable Long id,
            @Parameter(description = "可见性(0:自己可见 1:公开可见)", required = true) 
            @RequestParam Integer visibility) {
        boolean result = favoriteFolderService.updateVisibility(id, visibility);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新可见性失败");
    }

    @Operation(summary = "获取公开的收藏夹列表")
    @GetMapping("/public/list")
    public Resp<Page<FavoriteFolder>> getPublicFolders(
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<FavoriteFolder> result = favoriteFolderService.getPublicFolders(current, size);
        return Resp.success(result);
    }

    @Operation(summary = "更新审核状态")
    @PutMapping("/review/{id}")
    public Resp<Boolean> updateReviewStatus(
            @Parameter(description = "收藏夹ID", required = true) 
            @PathVariable Long id,
            @Parameter(description = "审核状态(0:待审核 1:已通过 2:已拒绝)", required = true) 
            @RequestParam Integer status) {
        boolean result = favoriteFolderService.updateReviewStatus(id, status);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新审核状态失败");
    }
} 