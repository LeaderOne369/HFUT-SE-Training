package com.example.ksp.modules.client.clientlogin.service.impl;

import com.example.ksp.common.utils.CaptchaUtil;
import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.utils.IpLocationUtil;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.client.clientlogin.dto.*;
import com.example.ksp.modules.client.clientlogin.service.ClientLoginService;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
@Service
@RequiredArgsConstructor
public class ClientLoginServiceImpl implements ClientLoginService {
    
    private final UserServiceProxy userServiceProxy;
    private final RedisCache redisCache;
    private final IpLocationUtil ipLocationUtil;
    private final HttpServletRequest request;
    private final CaptchaUtil captchaUtil;
    
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Map<String, Object>> login(ClientLoginDTO clientLoginDTO) {
        try {
            // 获取客户端IP地址
            String ipAddress = getClientIp();
            // 获取IP地址对应的地理位置
            String location = ipLocationUtil.getLocationByIp(ipAddress);
            // 设置登录地点
            clientLoginDTO.setLastLoginLocation(location);
            
            // 调用系统登录接口
            Resp<User> loginResp = userServiceProxy.login(clientLoginDTO.toLoginDTO());
            
            // 如果登录失败，直接返回错误信息
            if (!HttpStatus.OK.getCode().equals(loginResp.getCode())) {
                return Resp.error(loginResp.getCode(), loginResp.getMsg());
            }
            
            User user = loginResp.getData();
            ClientLoginDTO.ClientLoginCheckConfig checkConfig = clientLoginDTO.getCheckConfig();
            
            // 如果没有配置检查项，使用默认配置
            if (checkConfig == null) {
                checkConfig = new ClientLoginDTO.ClientLoginCheckConfig();
            }
            
            // 检查用户状态
            if (checkConfig.getCheckDeleted() == 1 && user.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), HttpStatus.FORBIDDEN.getMsg());
            }
            
            if (checkConfig.getCheckFrozen() == 1 && user.getIsFrozen() == 1) {
                return Resp.error(HttpStatus.LOCKED.getCode(), HttpStatus.LOCKED.getMsg());
            }
            
            if (checkConfig.getCheckAdmin() == 1 && user.getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), HttpStatus.UNAUTHORIZED.getMsg());
            }
            
            if (checkConfig.getCheckReview() == 1 && user.getReviewStatus() != 1) {
                String reviewMsg = switch (user.getReviewStatus()) {
                    case 0 -> "账号待审核";
                    case 2 -> "账号审核未通过";
                    default -> "账号审核状态异常";
                };
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), reviewMsg);
            }
            
            // 更新用户登录信息
            LocalDateTime now = LocalDateTime.now();
            user.setLastLoginTime(clientLoginDTO.getLastLoginTime() != null ? 
                clientLoginDTO.getLastLoginTime() : now);
            user.setLastLoginLocation(clientLoginDTO.getLastLoginLocation());
            user.setLastUpdatedTime(now);
            
            // 调用代理更新用户信息
            boolean updated = userServiceProxy.updateUserLoginInfo(user);
            if (!updated) {
                throw new RuntimeException(HttpStatus.INTERNAL_ERROR.getMsg());
            }
            
            // 创建LoginUser对象，使用xxuser作为属性名
            LoginUser loginUser = new LoginUser();
            loginUser.setXxuser(user);
            loginUser.setPermissions(List.of("CLIENT_USER"));
            
            // 生成token
            String token = JwtUtil.createJWT(user.getUsername());
            
            // 存入Redis，key格式为 login:username
            String redisKey = "login:" + user.getUsername();
            redisCache.setCacheObject(redisKey, loginUser);
            
            // 把用户信息存入SecurityContextHolder
            UsernamePasswordAuthenticationToken authenticationToken = 
                new UsernamePasswordAuthenticationToken(loginUser, null, loginUser.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            
            // 构造返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("token", token);
            result.put("user", user);
            
            return Resp.success(result);
            
        } catch (Exception e) {
            throw new RuntimeException(HttpStatus.INTERNAL_ERROR.getMsg() + ": " + e.getMessage(), e);
        }
    }
    
    /**
     * 获取客户端真实IP地址
     */
    // private String getClientIp() {
    //     try {
    //         // 通过DNS解析获取真实IP
    //            Process process = Runtime.getRuntime().exec("nslookup myip.opendns.com resolver1.opendns.com");
    //            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
    //            String line;
    //            String ip = null;
    //            int addressCount = 0;
               
    //            while ((line = reader.readLine()) != null) {
    //                if (line.contains("Address:")) {
    //                    addressCount++;
    //                    // 获取第二个Address行的IP
    //                    if (addressCount == 2) {
    //                        ip = line.substring(line.lastIndexOf(" ") + 1).trim();
    //                        break;
    //                    }
    //                }
    //            }
               
    //            // 如果DNS解析成功则直接返回
    //            if (ip != null && !ip.isEmpty() && !"unknown".equalsIgnoreCase(ip)) {
    //                return ip;
    //            }
    //        } catch (Exception e) {
    //            log.error("DNS解析获取IP失败", e);
    //        }
           
        
    //     // DNS解析失败则通过请求头获取
    //     String[] headers = {
    //         "X-Forwarded-For",
    //         "Proxy-Client-IP",
    //         "WL-Proxy-Client-IP",
    //         "HTTP_CLIENT_IP",
    //         "HTTP_X_FORWARDED_FOR"
    //     };
        
    //     String ipv4Pattern = "^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
    //     String ip = null;
        
    //     // 遍历请求头获取IP
    //     for (String header : headers) {
    //         ip = request.getHeader(header);
    //         if (ip != null && !ip.isEmpty() && !"unknown".equalsIgnoreCase(ip)) {
    //             // 处理多个代理的情况
    //             if (ip.contains(",")) {
    //                 String[] ips = ip.split(",");
    //                 for (String tempIp : ips) {
    //                     tempIp = tempIp.trim();
    //                     if (tempIp.matches(ipv4Pattern)) {
    //                         return tempIp;
    //                     }
    //                 }
    //             } else if (ip.matches(ipv4Pattern)) {
    //                 return ip;
    //             }
    //         }
    //     }
        
    //     // 如果所有请求头都没有获取到有效IP，则使用RemoteAddr
    //     ip = request.getRemoteAddr();
    //     if (ip != null && ip.matches(ipv4Pattern) && !ip.equals("127.0.0.1")) {
    //         return ip;
    //     }
        
    //     // 如果都获取失败，返回null，让IpLocationUtil处理默认情况
    //     return null;
    // }
    private String getClientIp() {
        return request.getRemoteAddr();
    }


    @Override
    public Resp<Map<String, Object>> getLoginInfo() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            Map<String, Object> result = new HashMap<>();
            result.put("user", loginUser.getXxuser());
            result.put("permissions", loginUser.getPermissions());
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "未登录或登录已过期");
        }
    }

    @Override
    public Resp<Void> logout() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 删除Redis中的用户信息
            String redisKey = "login:" + loginUser.getXxuser().getUsername();
            redisCache.deleteObject(redisKey);
            
            // 清除SecurityContextHolder
            SecurityContextHolder.clearContext();
            
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "退出登录失败");
        }
    }

    @Override
    public Resp<Map<String, String>> refreshToken() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 生成新的token
            String newToken = JwtUtil.createJWT(loginUser.getXxuser().getUsername());
            
            // 更新Redis中的用户信息过期时间
            String redisKey = "login:" + loginUser.getXxuser().getUsername();
            redisCache.setCacheObject(redisKey, loginUser);
            
            Map<String, String> result = new HashMap<>();
            result.put("token", newToken);
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "刷新Token失败");
        }
    }

    @Override
    public Resp<Boolean> checkToken(String token) {
        try {
            // 解析token获取用户名
            String username = JwtUtil.parseJWT(token).getSubject();
            
            // 从Redis中获取用户信息
            String redisKey = "login:" + username;
            LoginUser loginUser = redisCache.getCacheObject(redisKey);
            
            // 如果Redis中存在用户信息，说明token有效
            return Resp.success(loginUser != null);
        } catch (Exception e) {
            return Resp.success(false);
        }
    }

    @Override
    public Resp<Map<String, String>> getIpInfo(String ip) {
        try {
            // 如果未提供IP，则获取当前请求的IP
            String ipAddress = (ip != null && !ip.isEmpty()) ? ip : getClientIp();
            // 获取IP地址对应的地理位置
            String location = ipLocationUtil.getLocationByIp(ipAddress);
            
            Map<String, String> result = new HashMap<>();
            result.put("ip", ipAddress);
            result.put("location", location);
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取IP信息失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> register(ClientRegisterDTO registerDTO) {
        try {
            // 使用 CaptchaUtil 验证验证码
            if (!captchaUtil.checkCaptcha(registerDTO.getPhoneNumber(), registerDTO.getCaptcha())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "验证码错误或已过期");
            }

            // 检查用户名是否已存在
            if (userServiceProxy.checkUsernameExists(registerDTO.getUsername())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "用户名已存在");
            }

            // 检查手机号是否已存在
            if (userServiceProxy.checkPhoneExists(registerDTO.getPhoneNumber())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "手机号已被注册");
            }

            // 调用系统注册接口
            RegisterDTO sysRegisterDTO = new RegisterDTO();
            BeanUtils.copyProperties(registerDTO, sysRegisterDTO);
            userServiceProxy.register(sysRegisterDTO);
            
            return Resp.success("注册成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "注册失败" );
        }
    }

    @Override
    public Resp<String> forgetPassword(ForgetPasswordDTO forgetPasswordDTO) {
        try {
            // 使用 CaptchaUtil 验证验证码
            if (!captchaUtil.checkCaptcha(forgetPasswordDTO.getPhoneNumber(), forgetPasswordDTO.getCaptcha())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "验证码错误或已过期");
            }

            // 检查手机号是否存在
            if (!userServiceProxy.checkPhoneExists(forgetPasswordDTO.getPhoneNumber())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "手机号未注册");
            }

            // 调用系统重置密码接口
            userServiceProxy.resetPassword(forgetPasswordDTO.getPhoneNumber(), 
                forgetPasswordDTO.getNewPassword());
            
            return Resp.success("密码重置成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "重置密码失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> changePassword(ChangePasswordDTO changePasswordDTO) {
        try {
            // 获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            User user = loginUser.getXxuser();

            // 验证原密码
            if (!userServiceProxy.verifyPassword(user.getId(), changePasswordDTO.getOldPassword())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "原密码错误");
            }

            // 调用系统修改密码接口
            userServiceProxy.updatePassword(user.getId(), changePasswordDTO.getNewPassword());
            
            // 密码修改成功后，清除登录状态
            String redisKey = "login:" + user.getUsername();
            redisCache.deleteObject(redisKey);
            SecurityContextHolder.clearContext();

            return Resp.success("密码修改成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "修改密码失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> deactivateAccount(DeactivateAccountDTO deactivateDTO) {
        try {
            // 获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            User user = loginUser.getXxuser();

            // 验证密码
            if (!userServiceProxy.verifyPassword(user.getId(), deactivateDTO.getPassword())) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "密码错误");
            }

            // 调用系统注销账号接口
            userServiceProxy.deactivateAccount(user.getId());
            
            // 注销成功后，清除登录状态
            String redisKey = "login:" + user.getUsername();
            redisCache.deleteObject(redisKey);
            SecurityContextHolder.clearContext();

            return Resp.success("账号注销成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "账号注销失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<String> sendCaptcha(String phoneNumber) {
        try {
            captchaUtil.sendsms(phoneNumber);
            return Resp.success("验证码发送成功");
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "验证码发送失败");
        }
    }
} 