package com.example.ksp.framework.elasticsearch.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import lombok.Data;
import java.util.Arrays;
import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "canal")
@Data
public class CanalConfig {
    private String host = "localhost";
    private Integer port = 11111;
    private String destination = "example";
    private String username = "canal";
    private String password = "canal";
    
    @Value("${spring.datasource.url}")
    private String mysqlUrl;
    
    // 需要同步的表名列表
    private List<String> tables = Arrays.asList(
        "post"

    );
} 