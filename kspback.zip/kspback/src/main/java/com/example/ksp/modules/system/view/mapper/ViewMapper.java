package com.example.ksp.modules.system.view.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.view.entity.View;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ViewMapper extends BaseMapper<View> {
} 