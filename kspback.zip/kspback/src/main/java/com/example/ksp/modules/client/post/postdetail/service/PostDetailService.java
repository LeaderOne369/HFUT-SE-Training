package com.example.ksp.modules.client.post.postdetail.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.postdetail.dto.PostStatsDTO;
import com.example.ksp.modules.client.post.postdetail.dto.CommentDTO;

import com.example.ksp.modules.system.report.report.entity.Report;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;

import java.util.List;

/**
 * 帖子详情服务接口
 */
public interface PostDetailService {
    
    /**
     * 获取帖子统计信息
     *
     * @param postId 帖子ID
     * @param token 用户token
     * @return 帖子统计信息
     */
    Resp<PostStatsDTO> getPostStats(Long postId, String token);

    /**
     * 获取帖子详细信息
     *
     * @param postId 帖子ID
     * @param token  用户token
     * @return 帖子详细信息
     */
    Resp<Object> getPostDetail(Long postId, String token);

    /**
     * 获取帖子评论列表
     *
     * @param postId  帖子ID
     * @param token   用户token
     * @param current 当前页码
     * @param size    每页大小
     * @return 评论列表
     */
    Resp<Page<CommentDTO>> getPostComments(Long postId, String token, Long current, Long size);

    /**
     * 获取评论的所有子评论
     *
     * @param commentId 评论ID
     * @param token 用户token
     * @param current 当前页码
     * @param size 每页大小
     * @return 子评论列表
     */
    Resp<Page<CommentDTO>> getChildComments(Long commentId, String token, Long current, Long size);

    /**
     * 点赞/取消点赞评论
     *
     * @param commentId 评论ID
     * @param token 用户token
     * @return 操作结果
     */
    Resp<String> toggleCommentLike(Long commentId, String token);

    /**
     * 点赞/取消点赞帖子
     *
     * @param postId 帖子ID
     * @param token 用户token
     * @return 操作结果
     */
    Resp<String> togglePostLike(Long postId, String token);

    /**
     * 分享帖子
     *
     * @param postId 帖子ID
     * @param token 用户token
     * @return 操作结果
     */
    Resp<String> sharePost(Long postId, String token);

    /**
     * 回复帖子
     *
     * @param postId 帖子ID
     * @param content 评论内容
     * @param token 用户token
     * @return 评论信息
     */
    Resp<CommentDTO> replyPost(Long postId, String content, String token);

    /**
     * 收藏/取消收藏帖子
     *
     * @param postId 帖子ID
     * @param token 用户token
     * @return 操作结果
     */
    Resp<String> togglePostFavorite(Long postId, Long folderId, String token);

    /**
     * 举报帖子
     *
     * @param postId         帖子ID
     * @param reportTypeId   举报类型ID
     * @param reportedTypeId 被举报对象类型ID
     * @param reason         举报理由
     * @param token          用户token
     * @return 操作结果
     */
    Resp<Report> reportPost(Long postId, Long reportTypeId, Long reportedTypeId, String reason, String token);

    /**
     * 获取所有举报类型
     *
     * @return 举报类型列表
     */
    Resp<List<ReportType>> getAllReportTypes();

    /**
     * 获取所有举报对象类型
     *
     * @return 举报对象类型列表
     */
    Resp<List<ReportedType>> getAllReportedTypes();

    /**
     * 浏览帖子
     *
     * @param postId 帖子ID
     * @param token 用户token
     * @return 操作结果
     */
    Resp<String> viewPost(Long postId, String token);
}