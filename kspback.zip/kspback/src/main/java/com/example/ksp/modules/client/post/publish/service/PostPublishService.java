package com.example.ksp.modules.client.post.publish.service;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.post.publish.dto.PostPublishDTO;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;

import java.util.List;

public interface PostPublishService  {
    
    /**
     * 获取所有分区
     */
    Resp<List<Section>> getAllSections();
    
    /**
     * 获取分区下的标签
     */
    Resp<Object> getTagsBySection(Long sectionId);
    
    /**
     * 获取用户的合集列表
     */
    Resp<Object> getUserCollections(Long userId);
    
    /**
     * 保存帖子
     */
    Resp<Long> addPost(PostPublishDTO publishDTO, Long userId,Integer status);
    
    /**
     * 获取所有引用类型
     */
    Resp<List<CitationType>> getAllCitationTypes();


    Resp<Post> updatePost(Long postId, PostPublishDTO updateDTO, Long currentUserId, int i);
} 