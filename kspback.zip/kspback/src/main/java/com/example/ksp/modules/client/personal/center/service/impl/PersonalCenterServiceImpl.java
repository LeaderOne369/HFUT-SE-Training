package com.example.ksp.modules.client.personal.center.service.impl;

import com.example.ksp.common.utils.MinioUtil;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.UpdateUserInfoDTO;
import com.example.ksp.modules.client.personal.center.service.PersonalCenterService;
import com.example.ksp.modules.client.personal.center.vo.UserInfoVO;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.user.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;



@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalCenterServiceImpl implements PersonalCenterService {

    private final UserServiceProxy userServiceProxy;
    private final MinioUtil minioUtil;
    private static final String AVATAR_BUCKET = "avatars";

    @Override
    public Resp<UserInfoVO> getUserInfo(Long userId) {
        User user = userServiceProxy.getUser(userId).getData();
        UserInfoVO userInfoVO = new UserInfoVO();
        BeanUtils.copyProperties(user, userInfoVO);
        return  Resp.success(userInfoVO);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<String> uploadAvatar(Long userId, MultipartFile file) {
        if (file.isEmpty()) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "请选择要上传的文件");
        }

        // 检查文件类型
        String contentType = file.getContentType();
        log.info("上传文件类型: {}", contentType);
        if (contentType == null || !contentType.startsWith("image/")) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "只能上传图片文件");
        }

        try {
            // 获取用户当前头像
            Resp<User> userResp = userServiceProxy.getUser(userId);
            if (userResp.getCode() != 200 || userResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "用户不存在");
            }
            User user = userResp.getData();
            String oldAvatar = user.getAvatar();

            // 生成新头像的文件名
            String fileName = "avatar_" + userId + "_" + System.currentTimeMillis() + getFileExtension(file.getOriginalFilename());
            
            // 上传新头像到MinIO并获取永久URL
            minioUtil.uploadFile(AVATAR_BUCKET, fileName, file);
            String fileUrl = minioUtil.getPermanentFileUrl(AVATAR_BUCKET, fileName);
            
            // 更新用户头像URL
            user.setAvatar(fileUrl);
            user.setLastUpdatedTime(LocalDateTime.now());
            
            // 更新用户信息
            Map<String, Object> updates = new HashMap<>();
            updates.put("avatar", fileUrl);
            updates.put("last_updated_time", user.getLastUpdatedTime());
            int result = userServiceProxy.updateUser(userId, updates);
            
            if (result > 0) {
                // 如果存在旧头像，则删除
                if (oldAvatar != null && !oldAvatar.isEmpty()) {
                    try {
                        String oldObjectName = extractObjectNameFromUrl(oldAvatar);
                        minioUtil.deleteFile(AVATAR_BUCKET, oldObjectName);
                    } catch (Exception e) {
                        log.warn("删除旧头像失败: {}", e.getMessage());
                    }
                }
                return Resp.success(fileUrl);
            } else {
                // 如果更新失败，删除已上传的新文件
                minioUtil.deleteFile(AVATAR_BUCKET, fileName);
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新头像失败");
            }
        } catch (Exception e) {
            log.error("上传头像失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "上传头像失败：" + e.getMessage());
        }
    }

    /**
     * 从文件名中获取扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null) return ".jpg";
        int lastDotIndex = filename.lastIndexOf(".");
        return lastDotIndex == -1 ? ".jpg" : filename.substring(lastDotIndex);
    }

    /**
     * 从URL中提取对象名称
     */
    private String extractObjectNameFromUrl(String url) {
        if (url == null || url.isEmpty()) {
            return null;
        }
        // 假设URL格式为: http://minio-server/bucket-name/object-name
        String[] parts = url.split("/");
        if (parts.length < 2) {
            return null;
        }
        return parts[parts.length - 1];
    }

    @Override
    public Resp<UserInfoVO> updateUserInfo(Long userId, UpdateUserInfoDTO updateUserInfoDTO) {
        try {
            User user1 = userServiceProxy.getUser(userId).getData();
            BeanUtils.copyProperties(updateUserInfoDTO, user1);
            log.info("user1:{}", user1);
            boolean result = userServiceProxy.updateUser(user1);
            if (result) {
                User user = userServiceProxy.getUser(userId).getData();
                UserInfoVO userInfoVO = new UserInfoVO();
                BeanUtils.copyProperties(user,userInfoVO);
                return Resp.success(userInfoVO);
            } else {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新用户信息失败");
            }
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新用户信息失败：" + e.getMessage());
        }
    }

    @Override
    public Resp<String> deactivateAccount(Long userId, String password) {
        // 验证密码
        if (!userServiceProxy.verifyPassword(userId, password)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "密码错误");
        }
        
        return userServiceProxy.deactivateAccount(userId);
    }



} 