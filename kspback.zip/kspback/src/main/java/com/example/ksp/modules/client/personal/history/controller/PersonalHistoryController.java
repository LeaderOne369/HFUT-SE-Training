package com.example.ksp.modules.client.personal.history.controller;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.proxy.*;
import com.example.ksp.modules.system.comment.entity.Comment;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.like.entity.Like;
import com.example.ksp.modules.system.view.entity.View;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.ksp.modules.system.share.entity.Share;

import java.util.List;

@Tag(name = "客户端历史接口", description = "提供用户个人历史相关的接口")
@RestController//返回json格式数据
@RequestMapping("/api/client/personal/history")
@RequiredArgsConstructor//自动注入
public class PersonalHistoryController {

    @Autowired//使用proxy下的userServiceProxy作为userService
    private final LikeServiceProxy likeService;

    @Autowired // 使用proxy下的ViewServiceProxy作为viewService
    private final ViewServiceProxy viewServiceProxy;

    @Autowired
    private final CommentServiceProxy commentService;

    @Autowired
    private final FavoriteServiceProxy favoriteServiceProxy;
    @Autowired
    private final ShareServiceProxy shareService;




    /**
     * 获取用户所有点赞记录
     */
    @Operation(summary = "获取用户所有点赞记录")
    @GetMapping("/like/user/all likes/{userId}")
    public Resp<List<Like>> getAllLikes(@PathVariable Long userId) {
        return likeService.getAllLikesByUser(userId);
    }

    /**
     * 获取用户对特定对象类型的点赞记录
     */
    @Operation(summary = "获取用户对特定对象类型的点赞记录")
    @GetMapping("/like/user/{userId}/type/{objectType}")
    public Resp<List<Like>> getLikesByType(@PathVariable Long userId, @PathVariable Integer objectType) {
        return likeService.getLikesByUserAndType(userId, objectType);
    }

    /**
     * 获取用户点赞总数
     */
    @Operation(summary = "获取用户点赞总数")
    @GetMapping("/user/{userId}/likeCount")
    public Resp<Integer> getLikeCount(@PathVariable Long userId) {
        return likeService.getLikeCountByUser(userId);
    }

    /**
     * 记录用户浏览记录
     */
//    @PostMapping("/post/record")
//    public Resp<Boolean> recordView(@RequestParam Long userId, @RequestParam Long postId) {
//        return Resp.success(viewServiceProxy.recordView(userId, postId));
//    }

    /**
     * 删除单条浏览记录
     */
    @Operation(summary = "删除单条浏览记录")
    @DeleteMapping("/post/delete/{id}")
    public Resp<Boolean> deleteView(@PathVariable Long id) {
        return Resp.success(viewServiceProxy.deleteView(id));
    }

    /**
     * 删除用户的所有浏览记录
     */
    @Operation(summary = "删除用户的所有浏览记录")
    @DeleteMapping("/post/{userId}/delete")
    public Resp<Boolean> deleteUserViews(@PathVariable Long userId) {
        return Resp.success(viewServiceProxy.deleteUserViews(userId));
    }

    /**
     * 获取用户的浏览记录（分页）
     */
    @Operation(summary = "获取用户的浏览记录（分页）")
    @GetMapping("/allPost/{userId}")
    public Resp<Page<View>> getUserViews(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {
        return Resp.success(viewServiceProxy.getUserViews(userId, current, size));
    }

    /**
     * 获取特定帖子的浏览记录（分页）
     */
    @Operation(summary = "获取特定帖子的浏览记录（分页）")
    @GetMapping("/postId/{postId}")
    public Resp<Page<View>> getPostViews(
            @PathVariable Long postId,
            @RequestParam(defaultValue = "1") long current,
            @RequestParam(defaultValue = "10") long size) {
        return Resp.success(viewServiceProxy.getPostViews(postId, current, size));
    }

    /**
     * 获取特定帖子的浏览次数
     */
    @Operation(summary = "获取特定帖子的浏览次数")
    @GetMapping("/post/{postId}/count")
    public Resp<Long> getPostViewCount(@PathVariable Long postId) {
        return Resp.success(viewServiceProxy.getPostViewCount(postId));
    }


    /**
     * 获取用户所有评论记录
     */
    @Operation(summary = "获取用户所有评论记录")
    @GetMapping("/comment/user/all comments/{userId}")
    public Resp<List<Comment>> getAllComments(@PathVariable Long userId) {
        return commentService.getAllCommentsByUser(userId);
    }

    /**
     * 获取用户对特定类型对象的评论记录
     */
    @Operation(summary = "获取用户对特定类型对象的评论记录")
    @GetMapping("/comment/user/{userId}/type/{objectType}")
    public Resp<List<Comment>> getCommentsByType(@PathVariable Long userId, @PathVariable Integer objectType) {
        return commentService.getCommentsByUserAndType(userId, objectType);
    }

    /**
     * 获取用户评论总数
     */
    @Operation(summary = "获取用户评论总数")
    @GetMapping("/comment/user/{userId}/count")
    public Resp<Integer> getCommentCount(@PathVariable Long userId) {
        return commentService.getCommentCountByUser(userId);
    }

    /**
     * 逻辑删除指定评论
     */
    @Operation(summary = "逻辑删除指定评论")
    @DeleteMapping("/comment/{commentId}")
    public Resp<Void> deleteComment(@PathVariable Long commentId) {
        return commentService.deleteComment(commentId);
    }

    /**
     * 清空用户所有评论记录
     */
    @Operation(summary = "清空用户所有评论记录")
    @DeleteMapping("/comment/user/{userId}/clear")
    public Resp<Void> clearAllComments(@PathVariable Long userId) {
        return commentService.clearAllCommentsByUser(userId);
    }

    /**
     * 添加收藏
     */
    @Operation(summary = "添加收藏")
    @PostMapping("/favorite/user/{userId}/post/{postId}/folder/{folderId}")
    public Resp<Boolean> addFavorite(@PathVariable Long userId,
                                     @PathVariable Long postId,
                                     @PathVariable Long folderId) {
        return favoriteServiceProxy.addFavorite(userId, postId, folderId);
    }

    /**
     * 取消收藏
     */
    @Operation(summary = "取消收藏")
    @DeleteMapping("/favorite/user/{userId}/post/{postId}")
    public Resp<Boolean> cancelFavorite(@PathVariable Long userId,
                                        @PathVariable Long postId) {
        return favoriteServiceProxy.cancelFavorite(userId, postId);
    }

    /**
     * 移动收藏到其他收藏夹
     */
    @Operation(summary = "移动收藏到其他收藏夹")
    @PutMapping("/favorite/move/{id}/folder/{newFolderId}")
    public Resp<Boolean> moveFavorite(@PathVariable Long id,
                                      @PathVariable Long newFolderId) {
        return favoriteServiceProxy.moveFavorite(id, newFolderId);
    }

    /**
     * 获取用户的收藏列表
     */
    @Operation(summary = "获取用户的收藏列表")
    @GetMapping("/favorite/user/{userId}/folder/{folderId}/page/{current}/{size}")
    public Resp<Page<Favorite>> getUserFavorites(@PathVariable Long userId,
                                                 @PathVariable Long folderId,
                                                 @PathVariable long current,
                                                 @PathVariable long size) {
        return favoriteServiceProxy.getUserFavorites(userId, folderId, current, size);
    }

    /**
     * 获取帖子的收藏数量
     */
//    @GetMapping("/favorite/post/{postId}/count")
//    public Resp<Long> getPostFavoriteCount(@PathVariable Long postId) {
//        return favoriteServiceProxy.getPostFavoriteCount(postId);
//    }

    /**
     * 检查用户是否已收藏帖子
     */
//    @GetMapping("/favorite/user/{userId}/post/{postId}/check")
//    public Resp<Boolean> checkFavorite(@PathVariable Long userId,
//                                       @PathVariable Long postId) {
//        return favoriteServiceProxy.checkFavorite(userId, postId);
//    }

    /**
     * 批量移动收藏
     */
    @Operation(summary = "批量移动收藏")
    @PutMapping("/favorite/batch/move")
    public Resp<Boolean> batchMoveFavorites(@RequestBody Long[] ids,
                                            @RequestParam @NotNull Long newFolderId) {
        return favoriteServiceProxy.batchMoveFavorites(ids, newFolderId);
    }

    /**
     * 获取用户所有分享记录
     */
    @Operation(summary = "获取用户所有分享记录")
    @GetMapping("/share/user/{userId}/page/{current}/{size}")
    public Resp<Page<Share>> getUserShares(@PathVariable Long userId,
                                           @PathVariable long current,
                                           @PathVariable long size) {
        return shareService.getUserShares(userId, current, size);
    }

    /**
     * 获取特定对象的分享记录
     */
    @Operation(summary = "获取特定对象的分享记录")
    @GetMapping("/share/object/{objectId}/type/{objectType}/page/{current}/{size}")
    public Resp<Page<Share>> getObjectShares(@PathVariable Long objectId,
                                             @PathVariable Integer objectType,
                                             @PathVariable long current,
                                             @PathVariable long size) {
        return shareService.getObjectShares(objectId, objectType, current, size);
    }

    /**
     * 删除用户的分享记录
     */
    @Operation(summary = "删除用户的分享记录")
    @DeleteMapping("/share/user/{userId}/share/{shareId}")
    public Resp<Void> deleteShare(@PathVariable Long shareId) {
        return shareService.deleteShare(shareId);
    }

    /**
     * 获取用户分享的总数
     */
    @Operation(summary = "获取用户分享的总数")
    @GetMapping("/share/user/{userId}/count")
    public Resp<Long> getUserShareCount(@PathVariable Long userId) {
        return shareService.getUserShareCount(userId);
    }



}
