package com.example.ksp.modules.client.collection.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.util.Date;

@Data
@Schema(description = "合集视图对象")
public class CollectionVO {
    
    @Schema(description = "合集ID", example = "1")
    private Long id;
    
    @Schema(description = "合集标题", example = "精选合集")
    private String title;
    
    @Schema(description = "合集描述", example = "这是一个精选合集")
    private String description;
    
    @Schema(description = "点赞数", example = "0")
    private Integer likeCount;
    
    @Schema(description = "分享数", example = "0")
    private Integer shareCount;
    
    @Schema(description = "评论数", example = "0")
    private Integer commentCount;
    
    @Schema(description = "订阅数", example = "0")
    private Integer subscribeCount;
    
    @Schema(description = "创建时间")
    private Date createTime;
} 