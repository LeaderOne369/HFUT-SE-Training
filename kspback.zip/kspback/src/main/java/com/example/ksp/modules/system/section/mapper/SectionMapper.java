package com.example.ksp.modules.system.section.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface SectionMapper extends BaseMapper<Section> {
    /**
     * 根据分区ID或标签ID查询帖子
     *
     * @param page 分页对象
     * @param sectionId 分区ID
     * @param tagId 标签ID
     * @return 帖子列表
     */
    @Select("<script>" +
            "SELECT * FROM post " +
            "WHERE (section_id = #{sectionId} AND FIND_IN_SET((SELECT tag_name FROM tag WHERE id = #{tagId}), tags)) " +
            "AND is_deleted = 0 " +
            "ORDER BY publish_time DESC" +
            "</script>")
    Page<Post> selectPostsBySectionOrTag(Page<Post> page,
                                         @Param("sectionId") Long sectionId,
                                         @Param("tagId") Long tagId);

}
