package com.example.ksp.modules.system.view.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("view")
@Schema(name = "View对象", description = "浏览记录信息")
public class View {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "用户ID")
    private Long userId;

    @Schema(description = "帖子ID")
    private Long postId;

    @Schema(description = "浏览时间")
    private LocalDateTime viewTime;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;
} 