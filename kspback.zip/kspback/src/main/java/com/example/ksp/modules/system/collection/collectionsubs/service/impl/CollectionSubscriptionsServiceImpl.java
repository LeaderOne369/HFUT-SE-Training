package com.example.ksp.modules.system.collection.collectionsubs.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsCreateDTO;
import com.example.ksp.modules.system.collection.collectionsubs.dto.CollectionSubscriptionsQueryDTO;
import com.example.ksp.modules.system.collection.collectionsubs.entity.CollectionSubscriptions;
import com.example.ksp.modules.system.collection.collectionsubs.mapper.CollectionSubscriptionsMapper;
import com.example.ksp.modules.system.collection.collectionsubs.service.CollectionSubscriptionsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class CollectionSubscriptionsServiceImpl extends ServiceImpl<CollectionSubscriptionsMapper, CollectionSubscriptions> implements CollectionSubscriptionsService {

    @Override
    public Resp<CollectionSubscriptions> createSubscription(CollectionSubscriptionsCreateDTO createDTO) {
        try {
            // 检查是否已经订阅
            LambdaQueryWrapper<CollectionSubscriptions> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CollectionSubscriptions::getUsersId, createDTO.getUsersId())
                   .eq(CollectionSubscriptions::getCollectionsId, createDTO.getCollectionsId())
                   .eq(CollectionSubscriptions::getIsDeleted, 0);
            
            if (count(wrapper) > 0) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "您已订阅该合集");
            }
            
            CollectionSubscriptions subscription = new CollectionSubscriptions();
            BeanUtils.copyProperties(createDTO, subscription);
            
            subscription.setSubscriptionTime(LocalDateTime.now());
            subscription.setIsDeleted(0);
            
            save(subscription);
            return Resp.success(subscription);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建订阅失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Void> cancelSubscription(Long id) {
        try {
            LambdaQueryWrapper<CollectionSubscriptions> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CollectionSubscriptions::getId, id)
                   .eq(CollectionSubscriptions::getIsDeleted, 0);
            
            CollectionSubscriptions subscription = getOne(wrapper);
            if (subscription == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "订阅记录不存在或已取消");
            }
            
            subscription.setIsDeleted(1);
            updateById(subscription);
            
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "取消订阅失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<CollectionSubscriptions> getSubscription(Long id) {
        try {
            LambdaQueryWrapper<CollectionSubscriptions> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CollectionSubscriptions::getId, id)
                   .eq(CollectionSubscriptions::getIsDeleted, 0);
            
            CollectionSubscriptions subscription = getOne(wrapper);
            if (subscription == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "订阅记录不存在或已取消");
            }
            return Resp.success(subscription);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取订阅记录失败: " + e.getMessage());
        }
    }

    @Override
    public Resp<Page<CollectionSubscriptions>> querySubscriptions(CollectionSubscriptionsQueryDTO queryDTO) {
        try {
            LambdaQueryWrapper<CollectionSubscriptions> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CollectionSubscriptions::getIsDeleted, 0);
            
            if (queryDTO.getUsersId() != null) {
                wrapper.eq(CollectionSubscriptions::getUsersId, queryDTO.getUsersId());
            }
            if (queryDTO.getCollectionsId() != null) {
                wrapper.eq(CollectionSubscriptions::getCollectionsId, queryDTO.getCollectionsId());
            }
            if (queryDTO.getStartTime() != null) {
                wrapper.ge(CollectionSubscriptions::getSubscriptionTime, queryDTO.getStartTime());
            }
            if (queryDTO.getEndTime() != null) {
                wrapper.le(CollectionSubscriptions::getSubscriptionTime, queryDTO.getEndTime());
            }
            
            wrapper.orderByDesc(CollectionSubscriptions::getSubscriptionTime);
            
            Page<CollectionSubscriptions> page = new Page<>(queryDTO.getCurrent(), queryDTO.getSize());
            page = page(page, wrapper);
            
            return Resp.success(page);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询订阅列表失败: " + e.getMessage());
        }
    }
} 