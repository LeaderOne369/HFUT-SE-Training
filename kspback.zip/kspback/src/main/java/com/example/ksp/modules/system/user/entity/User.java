package com.example.ksp.modules.system.user.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 用户实体类
 * @author loself
 * @date 2024-12-31 13:46
 */
@Schema(description = "用户实体")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("user")
public class User implements Serializable {
    private static final long serialVersionUID = -40356785423868312L;

    @Schema(description = "用户ID")
    @TableId(type = IdType.AUTO)
    private Long id;
    
    @Schema(description = "用户名")
    @NotBlank(message = "用户名不能为空")
    @Size(min = 4, max = 20, message = "用户名长度必须在4-20之间")
    private String username;
    
    @Schema(description = "密码")
    @JsonIgnore
    @NotBlank(message = "密码不能为空")
    @Size(min = 6, max = 20, message = "密码长度必须在6-20之间")
    private String password;
    
    @Schema(description = "盐值")
    @JsonIgnore
    private String salt;
    
    @Schema(description = "邮箱")
    @Email(message = "邮箱格式不正确")
    private String email;
    
    @Schema(description = "手机号")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phoneNumber;
    
    @Schema(description = "注册时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime registrationTime;
    
    @Schema(description = "最后登录时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastLoginTime;
    
    @Schema(description = "最后登录地点")
    private String lastLoginLocation;
    
    @Schema(description = "最后更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private LocalDateTime lastUpdatedTime;



    @Schema(description = "是否删除（0未删除 1已删除）")
    private Integer isDeleted;
    
    @Schema(description = "是否管理员（0否 1是）")
    private Integer isAdmin;
    
    @Schema(description = "是否冻结（0否 1是）")
    private Integer isFrozen;
    
    @Schema(description = "权限等级（0正常 1禁止评论 2禁止发帖）")
    private Integer permissionLevel;
    
    @Schema(description = "性别（0男 1女 2其他）")
    private Integer gender;
    
    @Schema(description = "出生日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private LocalDate birthDate;
    
    @Schema(description = "个人简介")
    @Size(max = 255, message = "个人简介不能超过255个字符")
    private String bio;
    
    @Schema(description = "头像URL")
    private String avatar;
    
    @Schema(description = "关注数")
    private Integer followingCount;
    
    @Schema(description = "粉丝数")
    private Integer followersCount;
    
    @Schema(description = "审核状态（0待审核 1已通过 2已拒绝）")
    private Integer reviewStatus;
}
