package com.example.ksp.modules.client.recommendation.controller;

import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.recommendation.dto.RecommendationDTO;
import com.example.ksp.modules.client.recommendation.service.RecommendationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "客户端推荐接口")
@RestController
@RequestMapping("/api/client/recommendation")
@RequiredArgsConstructor
public class RecommendationController {

    @Autowired
    private final RecommendationService recommendationService;

    private final RedisCache redisCache;



    @Operation(summary = "获取相关帖子推荐")
    @GetMapping("/posts/related")
    public Resp<List<RecommendationDTO>> getRelatedPosts(
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId,
            @Parameter(description = "推荐数量") 
            @RequestParam(defaultValue = "10") int size) {
        return recommendationService.getRelatedPosts(postId, size);
    }


    @Operation(summary = "获取搜索关键词推荐")
    @GetMapping("/search")
    public Resp<List<String>> getSearchRecommendations(
            @Parameter(description = "token" )@RequestHeader("token") String token,
            @Parameter(description = "推荐数量")
            @RequestParam(defaultValue = "10") int size) throws Exception {

        String username = JwtUtil.parseJWT(token).getSubject();
        String key = "searchHistory:" + username;
        List<String> history = redisCache.getCacheList(key);

        if (history.isEmpty()) {
            return recommendationService.getSearchRecommendationKeyword(null, size);
        }
        else {
            return recommendationService.getSearchRecommendationKeyword(history, size);
        }

    }
} 