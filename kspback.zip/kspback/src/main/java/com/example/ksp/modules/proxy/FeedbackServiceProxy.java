package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
public class FeedbackServiceProxy {

    private final FeedbackService feedbackService;

    /**
     * 提交反馈
     */
    public boolean submitFeedback(Feedback feedback) {
        return feedbackService.submitFeedback(feedback);
    }

    /**
     * 更新反馈状态
     */
    public boolean updateStatus(Long id, Integer status) {
        return feedbackService.updateStatus(id, status);
    }

    /**
     * 删除反馈
     */
    public boolean deleteFeedback(Long id) {
        return feedbackService.deleteFeedback(id);
    }

    /**
     * 获取用户的反馈列表
     */
    public Page<Feedback> getUserFeedbacks(Long userId, Integer status, long current, long size) {
        return feedbackService.getUserFeedbacks(userId, status, current, size);
    }

    /**
     * 获取所有反馈列表（管理员使用）
     */
    public Page<Feedback> getAllFeedbacks(Integer status, long current, long size) {
        return feedbackService.getAllFeedbacks(status, current, size);
    }

    /**
     * 按照各种条件查询反馈记录，并返回分页结果
     *
     * @param userId          用户ID
     * @param feedbackContent 反馈内容关键字
     * @param status          反馈状态
     * @param startTime       反馈提交的开始时间
     * @param endTime         反馈提交的结束时间
     * @param page            当前页码
     * @param size            每页记录数
     * @return 分页的反馈记录
     */
    public Page<Feedback> queryFeedbacks(Long userId, String feedbackContent, Integer status,
                                         LocalDateTime startTime, LocalDateTime endTime,
                                         int page, int size) {
        return feedbackService.queryFeedbacks(userId, feedbackContent, status, startTime, endTime, page, size);
    }
}
