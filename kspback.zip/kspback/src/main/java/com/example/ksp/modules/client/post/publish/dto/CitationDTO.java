package com.example.ksp.modules.client.post.publish.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "引用信息DTO")
public class CitationDTO {
    
    @NotNull(message = "引用类型ID不能为空")
    @Schema(description = "引用类型ID")
    private Long citationTypeId;
    
    @NotBlank(message = "引用内容不能为空")
    @Schema(description = "引用内容")
    private String citationContent;
    
    @NotBlank(message = "引用来源不能为空")
    @Schema(description = "引用来源")
    private String source;
} 