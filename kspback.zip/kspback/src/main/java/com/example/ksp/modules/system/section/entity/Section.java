package com.example.ksp.modules.system.section.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("section")
@Schema(name = "Section对象", description = "分区信息")
public class Section {
    
    @Schema(description = "主键ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @Schema(description = "分区名称")
    private String sectionName;

    @Schema(description = "分区描述")
    private String sectionDescription;

    @Schema(description = "创建时间")
    private LocalDateTime creationTime;

    @Schema(description = "更新时间")
    private LocalDateTime updateTime;

    @Schema(description = "是否删除(1:是 0:否)")
    @TableLogic
    private Integer isDeleted;

    @Schema(description = "可见性(0:隐藏 1:公开)")
    private Integer visibility;
} 