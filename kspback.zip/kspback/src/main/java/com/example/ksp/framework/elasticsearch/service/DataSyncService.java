package com.example.ksp.framework.elasticsearch.service;


import co.elastic.clients.elasticsearch.ElasticsearchClient;
import com.alibaba.otter.canal.client.CanalConnector;
import com.alibaba.otter.canal.client.CanalConnectors;


import com.alibaba.otter.canal.protocol.CanalEntry;
import com.alibaba.otter.canal.protocol.Message;
import com.example.ksp.framework.elasticsearch.config.CanalConfig;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataSyncService {
    
    private final ElasticsearchClient esClient;
    private final CanalConfig canalConfig;
    private volatile CanalConnector connector;
    private volatile boolean running = true;
    
    @PostConstruct
    public void init() {
        initConnector();
        startListening();
    }
    
    private synchronized void initConnector() {
        try {
            if (connector != null) {
                try {
                    connector.disconnect();
                } catch (Exception e) {
                    log.warn("关闭旧连接失败", e);
                }
            }
            
            connector = CanalConnectors.newSingleConnector(
                new InetSocketAddress(canalConfig.getHost(), canalConfig.getPort()),
                canalConfig.getDestination(),
                canalConfig.getUsername(),
                canalConfig.getPassword()
            );
            
            connector.connect();
            String subscribeTables = canalConfig.getTables().stream()
                .map(table -> "ksp2." + table)
                .collect(Collectors.joining(","));
            connector.subscribe(subscribeTables);
            log.info("Canal 连接初始化成功，已订阅表: {}", subscribeTables);
            
        } catch (Exception e) {
            log.error("Canal 连接初始化失败", e);
            throw new RuntimeException("Canal 连接初始化失败", e);
        }
    }
    
    private void startListening() {
        Thread thread = new Thread(() -> {
            while (running) {
                try {
                    if (connector == null || !connector.checkValid()) {
                        log.info("Canal 连接无效，尝试重新连接...");
                        initConnector();
                        continue;
                    }
                    
                    Message message = connector.getWithoutAck(100);
                    long batchId = message.getId();
                    
                    try {
                        if (batchId != -1 && !message.getEntries().isEmpty()) {
                            for (CanalEntry.Entry entry : message.getEntries()) {
                                if (entry.getEntryType() == CanalEntry.EntryType.ROWDATA) {
                                    handleDataChange(entry);
                                }
                            }
                            connector.ack(batchId);
                        } else {
                            Thread.sleep(1000);
                        }
                    } catch (Exception e) {
                        log.error("处理消息失败，回滚消息: {}", batchId, e);
                        connector.rollback(batchId);
                    }
                    
                } catch (Exception e) {
                    log.error("Canal 监听异常，等待重试", e);
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        });
        thread.setName("canal-sync-thread");
        thread.setDaemon(true);
        thread.start();
    }
    
    private void handleDataChange(CanalEntry.Entry entry) {
        try {
            CanalEntry.RowChange rowChange = CanalEntry.RowChange.parseFrom(entry.getStoreValue());
            String tableName = entry.getHeader().getTableName();
            CanalEntry.EventType eventType = rowChange.getEventType();
            
            log.info("检测到表 {} 的 {} 操作", tableName, eventType);
            
            for (CanalEntry.RowData rowData : rowChange.getRowDatasList()) {
                Map<String, Object> data = new HashMap<>();
                String id = null;
                
                List<CanalEntry.Column> columns = eventType == CanalEntry.EventType.DELETE 
                    ? rowData.getBeforeColumnsList() 
                    : rowData.getAfterColumnsList();
                
                for (CanalEntry.Column column : columns) {
                    if (column.getIsKey()) {
                        id = column.getValue();
                    }
                    data.put(column.getName(), column.getValue());
                }
                
                if (id == null) {
                    log.warn("未找到主键，跳过同步");
                    continue;
                }
                
                switch (eventType) {
                    case INSERT:
                    case UPDATE:
                        String finalId = id;
                        esClient.index(i -> i
                            .index(tableName.toLowerCase())
                            .id(finalId)
                            .document(data)
                        );
                        log.info("同步 {}/{} 到 ES 成功", tableName, id);
                        break;
                        
                    case DELETE:
                        String finalId1 = id;
                        esClient.delete(d -> d
                            .index(tableName.toLowerCase())
                            .id(finalId1)
                        );
                        log.info("从 ES 删除 {}/{} 成功", tableName, id);
                        break;
                        
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            log.error("处理数据变更失败", e);
        }
    }
    
    @PreDestroy
    public void destroy() {
        running = false;
        if (connector != null) {
            try {
                connector.disconnect();
            } catch (Exception e) {
                log.error("关闭 Canal 连接失败", e);
            }
        }
    }
} 