package com.example.ksp.modules.system.reviewlog.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级审核日志管理接口")
@RestController
@RequestMapping("/api/system/review")
public class ReviewLogController {

    @Autowired
    private ReviewLogService reviewLogService;

    @Operation(summary = "创建审核记录")
    @PostMapping("/create")
    public Resp<Boolean> createReviewLog(@RequestBody ReviewLog reviewLog) {
        boolean result = reviewLogService.createReviewLog(reviewLog);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "创建审核记录失败");
    }

    @Operation(summary = "更新审核状态")
    @PutMapping("/status/{id}")
    public Resp<Boolean> updateReviewStatus(
            @Parameter(description = "审核记录ID", required = true) 
            @PathVariable Long id,
            @Parameter(description = "审核状态(0:待审核 1:已通过 2:已拒绝)", required = true) 
            @RequestParam Integer status,
            @Parameter(description = "审核备注") 
            @RequestParam(required = false) String notes) {
        boolean result = reviewLogService.updateReviewStatus(id, status, notes);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "更新审核状态失败");
    }

    @Operation(summary = "获取内容的审核记录")
    @GetMapping("/content/list")
    public Resp<Page<ReviewLog>> getContentReviews(
            @Parameter(description = "内容ID", required = true) 
            @RequestParam Long contentId,
            @Parameter(description = "内容类型(0:用户 1:帖子 2:合集 3:收藏夹)", required = true) 
            @RequestParam Integer contentType,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<ReviewLog> result = reviewLogService.getContentReviews(contentId, contentType, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取审核人的审核记录")
    @GetMapping("/reviewer/list")
    public Resp<Page<ReviewLog>> getReviewerLogs(
            @Parameter(description = "审核人ID", required = true) 
            @RequestParam Long reviewerId,
            @Parameter(description = "审核状态(0:待审核 1:已通过 2:已拒绝)", required = false) 
            @RequestParam(required = false) Integer status,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<ReviewLog> result = reviewLogService.getReviewerLogs(reviewerId, status, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取待审核列表")
    @GetMapping("/pending/list")
    public Resp<Page<ReviewLog>> getPendingReviews(
            @Parameter(description = "内容类型(0:用户 1:帖子 2:合集 3:收藏夹)", required = false) 
            @RequestParam(required = false) Integer contentType,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<ReviewLog> result = reviewLogService.getPendingReviews(contentType, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "批量审核")
    @PutMapping("/batch")
    public Resp<Boolean> batchReview(
            @Parameter(description = "审核记录ID数组", required = true) 
            @RequestParam Long[] ids,
            @Parameter(description = "审核状态(1:通过 2:拒绝)", required = true) 
            @RequestParam Integer status,
            @Parameter(description = "审核备注") 
            @RequestParam(required = false) String notes) {
        boolean result = reviewLogService.batchReview(ids, status, notes);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "批量审核失败");
    }
}