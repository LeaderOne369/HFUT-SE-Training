package com.example.ksp.common.handler;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author loself
 * @date 2025-01-08 17:07
 */

@Slf4j
@RestController
@ControllerAdvice
public class GlobalExceptionHandler {

    // 捕获所有异常
    @ExceptionHandler(Exception.class)
    public Resp<?> handleException(Exception e) {
        // 打印异常信息
        log.info("发生异常:", e);
        // 返回错误信息
        return Resp.error(HttpStatus.INTERNAL_ERROR, e.getMessage());
    }

}
