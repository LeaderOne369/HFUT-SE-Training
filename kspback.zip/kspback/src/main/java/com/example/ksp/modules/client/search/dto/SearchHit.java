package com.example.ksp.modules.client.search.dto;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class SearchHit<T> {
    private T source;                                    // 原始文档
    private Double score;                                // 相关度分数
    private Map<String, List<String>> highlight;         // 高亮片段
} 