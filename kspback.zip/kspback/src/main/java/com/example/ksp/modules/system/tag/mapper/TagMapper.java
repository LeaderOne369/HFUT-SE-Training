package com.example.ksp.modules.system.tag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ksp.modules.system.tag.entity.Tag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface TagMapper extends BaseMapper<Tag> {
    /**
     * 获取分区下的所有标签
     */
    /**
     * 获取分区下的所有标签
     */
    @Select("SELECT t.* FROM tag t WHERE t.section_id = #{sectionId} AND t.is_deleted = 0")
    List<Tag> getTagsBySectionId(@Param("sectionId") Long sectionId);
}
