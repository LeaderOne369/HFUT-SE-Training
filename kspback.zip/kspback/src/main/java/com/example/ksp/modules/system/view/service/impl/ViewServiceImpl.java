package com.example.ksp.modules.system.view.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ksp.modules.system.view.entity.View;
import com.example.ksp.modules.system.view.mapper.ViewMapper;
import com.example.ksp.modules.system.view.service.ViewService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


//TODO 没有检测逻辑删除字段
@Service
public class ViewServiceImpl extends ServiceImpl<ViewMapper, View> implements ViewService {

    @Override
    public boolean recordView(Long userId, Long postId) {
        View view = new View();
        view.setUserId(userId);
        view.setPostId(postId);
        view.setViewTime(LocalDateTime.now());
        view.setIsDeleted(0);
        return save(view);
    }

    @Override
    public boolean deleteView(Long id) {
        return removeById(id);
    }

    @Override
    public boolean deleteUserViews(Long userId) {
        LambdaQueryWrapper<View> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(View::getUserId, userId);
        return remove(wrapper);
    }

    @Override
    public Page<View> getUserViews(Long userId, long current, long size) {
        Page<View> page = new Page<>(current, size);
        LambdaQueryWrapper<View> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(View::getUserId, userId)
                .orderByDesc(View::getViewTime);
        
        return page(page, wrapper);
    }

    @Override
    public Page<View> getPostViews(Long postId, long current, long size) {
        Page<View> page = new Page<>(current, size);
        LambdaQueryWrapper<View> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(View::getPostId, postId)
                .orderByDesc(View::getViewTime);
        
        return page(page, wrapper);
    }

    @Override
    public long getPostViewCount(Long postId) {
        LambdaQueryWrapper<View> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(View::getPostId, postId);
        return count(wrapper);
    }
} 