package com.example.ksp.modules.system.report.report.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "举报查询参数")
public class ReportQueryDTO {
    
    @Schema(description = "页码")
    private Long current = 1L;
    
    @Schema(description = "每页大小")
    private Long size = 10L;
    
    @Schema(description = "举报用户ID")
    private Long userId;
    
    @Schema(description = "举报对象类型ID")
    private Long reportedTypeId;
    
    @Schema(description = "举报类型ID")
    private Long reportTypeId;
    
    @Schema(description = "处理状态")
    private Integer status;
    
    @Schema(description = "开始时间")
    private LocalDateTime startTime;
    
    @Schema(description = "结束时间")
    private LocalDateTime endTime;
} 