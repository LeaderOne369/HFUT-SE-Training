package com.example.ksp.modules.client.personal.center.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderCreateDTO;
import com.example.ksp.modules.client.personal.center.dto.FavoriteFolderDTO;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;

public interface PersonalFavoriteService {
    
    /**
     * 创建收藏夹
     */
    Resp<FavoriteFolder> createFolder(Long userId, FavoriteFolderCreateDTO folderDTO);
    
    /**
     * 修改收藏夹
     */
    Resp<Boolean> updateFolder(Long userId, FavoriteFolderDTO folderDTO);
    
    /**
     * 删除收藏夹
     */
    Resp<Boolean> deleteFolder(Long userId, Long folderId);
    
    /**
     * 获取用户的收藏夹列表
     */
    Resp<Page<FavoriteFolder>> getFolderList(Long userId, long current, long size);
    
    /**
     * 获取收藏夹内的收藏列表
     */
    Resp<Page<Favorite>> getFavoriteList(Long userId, Long folderId, long current, long size);
    
    /**
     * 删除收藏
     */
    Resp<Boolean> deleteFavorite(Long userId, Long favoriteId);
    
    /**
     * 移动收藏到其他收藏夹
     */
    Resp<Boolean> moveFavorite(Long userId, Long favoriteId, Long targetFolderId);
} 