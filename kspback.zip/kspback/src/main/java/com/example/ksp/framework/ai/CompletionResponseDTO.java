package com.example.ksp.framework.ai;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Schema(description = "AI补全响应")
public class CompletionResponseDTO {
    
    @Schema(description = "响应ID")
    private String id;
    
    @Schema(description = "补全选项列表")
    private List<Choice> choices;
    
    @Schema(description = "创建时间戳")
    private Long created;
    
    @Schema(description = "使用的模型")
    private String model;
    
    @Schema(description = "系统指纹")
    @JsonProperty("system_fingerprint")
    private String systemFingerprint;
    
    @Schema(description = "对象类型")
    private String object;
    
    @Schema(description = "使用统计")
    private Usage usage;
    
    @Data
    @Schema(description = "补全选项")
    public static class Choice {
        @Schema(description = "结束原因")
        @JsonProperty("finish_reason")
        private String finishReason;
        
        @Schema(description = "选项索引")
        private Integer index;
        
        @Schema(description = "日志概率信息")
        private LogProbs logprobs;
        
        @Schema(description = "补全文本")
        private String text;
    }
    
    @Data
    @Schema(description = "日志概率信息")
    public static class LogProbs {
        @Schema(description = "文本偏移量")
        @JsonProperty("text_offset")
        private List<Integer> textOffset;
        
        @Schema(description = "token概率")
        @JsonProperty("token_logprobs")
        private List<Double> tokenLogprobs;
        
        @Schema(description = "tokens列表")
        private List<String> tokens;
        
        @Schema(description = "top概率")
        @JsonProperty("top_logprobs")
        private List<Map<String, Double>> topLogprobs;
    }
    
    @Data
    @Schema(description = "使用统计")
    public static class Usage {
        @Schema(description = "补全token数")
        @JsonProperty("completion_tokens")
        private Integer completionTokens;
        
        @Schema(description = "提示token数")
        @JsonProperty("prompt_tokens")
        private Integer promptTokens;
        
        @Schema(description = "提示缓存命中token数")
        @JsonProperty("prompt_cache_hit_tokens")
        private Integer promptCacheHitTokens;
        
        @Schema(description = "提示缓存未命中token数")
        @JsonProperty("prompt_cache_miss_tokens")
        private Integer promptCacheMissTokens;
        
        @Schema(description = "总token数")
        @JsonProperty("total_tokens")
        private Integer totalTokens;
    }
} 