package com.example.ksp.modules.system.tag.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.tag.dto.TagCreateDTO;
import com.example.ksp.modules.system.tag.dto.TagQueryDTO;
import com.example.ksp.modules.system.tag.dto.TagUpdateDTO;
import com.example.ksp.modules.system.tag.entity.Tag;

import java.util.List;

public interface TagService extends IService<Tag> {
    /**
     * 创建标签
     */
    Resp<Tag> createTag(TagCreateDTO createDTO);

    /**
     * 更新标签
     */
    Resp<Tag> updateTag(TagUpdateDTO updateDTO);

    /**
     * 删除标签
     */
    Resp<String> deleteTag(Long id);

    /**
     * 获取标签详情
     */
    Resp<Tag> getTag(Long id);

    /**
     * 分页查询标签
     */
    Resp<Page<Tag>> queryTags(TagQueryDTO queryDTO);

    /**
     * 根据分区ID获取标签列表
     */
    Resp<List<Tag>> getTagsBySection(Long sectionId);
} 