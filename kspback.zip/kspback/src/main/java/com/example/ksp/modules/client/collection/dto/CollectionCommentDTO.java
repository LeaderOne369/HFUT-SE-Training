package com.example.ksp.modules.client.collection.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
@Schema(description = "合集评论请求对象")
public class CollectionCommentDTO {
    
    @NotNull(message = "合集ID不能为空")
    @Schema(description = "合集ID", required = true, example = "1")
    private Long collectionId;
    
    @NotBlank(message = "评论内容不能为空")
    @Schema(description = "评论内容", required = true, example = "这是一条评论")
    private String content;

    @Schema(description = "用户ID", hidden = true)
    private Long userId;
} 