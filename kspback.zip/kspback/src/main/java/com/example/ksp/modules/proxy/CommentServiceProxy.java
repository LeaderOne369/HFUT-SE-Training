package com.example.ksp.modules.proxy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.comment.dto.CommentCreateDTO;
import com.example.ksp.modules.system.comment.dto.CommentQueryDTO;
import com.example.ksp.modules.system.comment.entity.Comment;

import com.example.ksp.modules.system.comment.service.CommentService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Objects;

@Slf4j
@Component
@RequiredArgsConstructor
public class CommentServiceProxy {

    private final CommentService commentService;

    public Resp<List<Comment>> getAllCommentsByUser(Long userId) {
        return commentService.getAllCommentsByUser(userId);
    }

    public Resp<List<Comment>> getCommentsByUserAndType(Long userId, Integer objectType) {
        return commentService.getCommentsByUserAndType(userId, objectType);
    }

    public Resp<Integer> getCommentCountByUser(Long userId) {
        return commentService.getCommentCountByUser(userId);
    }

    public Resp<Void> deleteComment(Long commentId) {
        return commentService.deleteComment(commentId);
    }

    public Resp<Void> clearAllCommentsByUser(Long userId) {
        return commentService.clearAllCommentsByUser(userId);
    }

    /**
     * 获取用户收到的评论数量
     */
    public Resp<Integer> getReceivedCommentCount(Long userId) {
        log.info("代理层：获取用户收到的评论数量，用户ID：{}", userId);
        if (userId == null || userId <= 0) {
            return Resp.error(400, "无效的用户ID");
        }
        try {
            return commentService.getReceivedCommentCount(userId);
        } catch (Exception e) {
            log.error("获取用户收到的评论数量失败", e);
            return Resp.error(500, "获取评论数量失败");
        }
    }

    /**
     * 查询评论列表
     *
     * @param queryDTO 查询条件
     * @return 评论列表
     */
    public Resp<Page<Comment>> queryComments(CommentQueryDTO queryDTO) {
        log.info("代理层：查询评论列表，参数：{}", queryDTO);
        if (queryDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "查询参数不能为空");
        }

        try {
            return commentService.queryComments(queryDTO);
        } catch (Exception e) {
            log.error("查询评论列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "查询评论列表失败");
        }
    }

    /**
     * 获取评论详情
     *
     * @param commentId 评论ID
     * @return 评论信息
     */
    public Resp<Comment> getComment(Long commentId) {
        log.info("代理层：获取评论详情，评论ID：{}", commentId);
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }

        try {
            return commentService.getComment(commentId);
        } catch (Exception e) {
            log.error("获取评论详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取评论详情失败");
        }
    }

    /**
     * 增加评论点赞数
     */
    public Resp<Void> incrementLikeCount(Long commentId) {
        log.info("代理层：增加评论点赞数，评论ID：{}", commentId);
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        try {
            return commentService.incrementLikeCount(commentId);
        } catch (Exception e) {
            log.error("增加评论点赞数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "增加点赞数失败");
        }
    }

    /**
     * 减少评论点赞数
     */
    public Resp<Void> decrementLikeCount(Long commentId) {
        log.info("代理层：减少评论点赞数，评论ID：{}", commentId);
        if (commentId == null || commentId <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        try {
            return commentService.decrementLikeCount(commentId);
        } catch (Exception e) {
            log.error("减少评论点赞数失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "减少点赞数失败");
        }
    }

    /**
     * 创建评论
     *
     * @param createDTO 创建评论参数
     * @return 创建的评论
     */
    public Resp<Comment> createComment(CommentCreateDTO createDTO) {
        log.info("代理层：创建评论，参数：{}", createDTO);

        // 参数校验
        if (createDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "参数不能为空");
        }
        if (createDTO.getCommenterId() == null || createDTO.getCommenterId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论者ID无效");
        }
        if (createDTO.getCommentableId() == null || createDTO.getCommentableId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象ID无效");
        }
        if (createDTO.getCommentableType() == null || createDTO.getCommentableType() < 1 || createDTO.getCommentableType() > 3) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象类型无效");
        }
        if (StringUtils.isBlank(createDTO.getContent())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }

        try {
            return commentService.createComment(createDTO);
        } catch (Exception e) {
            log.error("创建评论失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "创建评论失败");
        }
    }

    //回复评论的评论，先调用createComment方法其中再update方法  commentableId对应的ReplyCount
    public Resp<Comment> replyComment(CommentCreateDTO createDTO) {
        log.info("代理层：回复评论，参数：{}", createDTO);

        // 参数校验
        if (createDTO == null) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "参数不能为空");
        }
        if (createDTO.getCommenterId() == null || createDTO.getCommenterId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论者ID无效");
        }
        if (createDTO.getCommentableId() == null || createDTO.getCommentableId() <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象ID无效");
        }
        if (createDTO.getCommentableType() == null || createDTO.getCommentableType() < 1 || createDTO.getCommentableType() > 3) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "被评论对象类型无效");
        }
        if (StringUtils.isBlank(createDTO.getContent())) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论内容不能为空");
        }

        try {
            return commentService.replyComment(createDTO);
        } catch (Exception e) {
            log.error("回复评论失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "回复评论失败");
        }
    }
    /**
     * 更新评论可见性状态
     *
     * @param id 评论ID
     * @param status 状态(0:不可见 1:可见)
     * @return 操作结果
     */
    public Resp<String> updateCommentStatus(Long id, Integer status) {
        log.info("代理层：更新评论可见性状态，评论ID：{}，状态：{}", id, status);

        // 参数校验
        if (id == null || id <= 0) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的评论ID");
        }
        if (status == null || (status != 0 && status != 1)) {
            return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "无效的状态值，只能是0(不可见)或1(可见)");
        }

        try {
            // 先查询评论是否存在
            Resp<Comment> commentResp = getComment(id);
            if (!Objects.equals(commentResp.getCode(), HttpStatus.OK.getCode()) || commentResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "评论不存在");
            }

            Comment comment = commentResp.getData();
            // 检查评论是否已删除
            if (comment.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.BAD_REQUEST.getCode(), "评论已删除，无法更新状态");
            }

            // 如果状态相同，直接返回成功
            if (comment.getIsPublic().equals(status)) {
                return Resp.success("状态未改变");
            }

            // 更新评论可见性状态
            comment.setIsPublic(status);
            boolean updated = commentService.updateById(comment);

            if (updated) {
                return Resp.success("更新评论可见性状态成功");
            } else {
                return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新评论可见性状态失败");
            }

        } catch (Exception e) {
            log.error("更新评论可见性状态失败, commentId: {}, status: {}", id, status, e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新评论可见性状态失败: " + e.getMessage());
        }
    }
}
