package com.example.ksp.modules.system.collection.collectionsubs.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建合集订阅请求参数")
public class CollectionSubscriptionsCreateDTO {
    
    @NotNull(message = "用户ID不能为空")
    @Schema(description = "用户ID")
    private Long usersId;
    
    @NotNull(message = "合集ID不能为空")
    @Schema(description = "合集ID")
    private Long collectionsId;
} 