package com.example.ksp.modules.admin.management.usermg;

import jakarta.annotation.Resource;
import org.apache.ibatis.jdbc.SQL;

import java.util.Map;
@Resource
public class UserSqlProvider {

    // 动态构建更新 SQL 语句
    public String updateUser(Map<String, Object> parameters) {
        Long userId = (Long) parameters.get("userId");
        Map<String, Object> updates = (Map<String, Object>) parameters.get("updates");

        // 开始构建 SQL 语句
        SQL sql = new SQL().UPDATE("`user`");

        // 动态添加更新的字段
        for (Map.Entry<String, Object> entry : updates.entrySet()) {
            sql.SET(entry.getKey() + " = #{updates." + entry.getKey() + "}");
        }

        // 添加 WHERE 条件
        sql.WHERE("id = #{userId}");

        // 返回动态生成的 SQL
        return sql.toString();
    }
}
