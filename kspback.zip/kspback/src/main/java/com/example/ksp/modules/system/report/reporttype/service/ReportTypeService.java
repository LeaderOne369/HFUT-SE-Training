package com.example.ksp.modules.system.report.reporttype.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeCreateDTO;
import com.example.ksp.modules.system.report.reporttype.dto.ReportTypeUpdateDTO;
import com.example.ksp.modules.system.report.reporttype.entity.ReportType;

public interface ReportTypeService extends IService<ReportType> {
    
    Resp<ReportType> createReportType(ReportTypeCreateDTO createDTO);
    
    Resp<ReportType> updateReportType(ReportTypeUpdateDTO updateDTO);
    
    Resp<Void> deleteReportType(Long id);
    
    Resp<ReportType> getReportType(Long id);
    
    Resp<Page<ReportType>> listReportTypes(Page<ReportType> page, String typeName, Integer isActive);
} 