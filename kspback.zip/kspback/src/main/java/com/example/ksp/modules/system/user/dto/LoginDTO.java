package com.example.ksp.modules.system.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "登录请求参数")
public class LoginDTO {
    @Schema(description = "用户名")
    private String username;
    
    @Schema(description = "手机号")
    private String phoneNumber;
    
    @Schema(description = "密码")
    private String password;
    
    @Schema(description = "验证码")
    private String captcha;
    
    @Schema(description = "登录方式：1-用户名密码，2-手机号密码，3-手机号验证码")
    private Integer loginType;
} 