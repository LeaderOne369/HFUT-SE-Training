package com.example.ksp.modules.admin.adminlogin.service.impl;

import com.example.ksp.common.utils.IpLocationUtil;
import com.example.ksp.common.utils.JwtUtil;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.framework.security.dto.LoginUser;
import com.example.ksp.modules.admin.adminlogin.dto.AdminLoginDTO;
import com.example.ksp.modules.admin.adminlogin.service.AdminLoginService;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.user.entity.User;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AdminLoginServiceImpl implements AdminLoginService {

    private final UserServiceProxy userServiceProxy;
    private final RedisCache redisCache;
    private final IpLocationUtil ipLocationUtil;
    private final HttpServletRequest request;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Resp<Map<String, Object>> login(AdminLoginDTO adminLoginDTO) {
        try {
            // 获取客户端IP地址
            String ipAddress = getClientIp();
            // 获取IP地址对应的地理位置
            String location = ipLocationUtil.getLocationByIp(ipAddress);
            // 设置登录地点
            adminLoginDTO.setLastLoginLocation(location);
            
            // 调用系统登录接口
            Resp<User> loginResp = userServiceProxy.login(adminLoginDTO.toLoginDTO());
            
            // 如果登录失败，直接返回错误信息
            if (!HttpStatus.OK.getCode().equals(loginResp.getCode())) {
                return Resp.error(loginResp.getCode(), loginResp.getMsg());
            }
            
            User user = loginResp.getData();
            
            // 检查是否是管理员
            if (user.getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "非管理员账号，无权限登录");
            }
            
            // 检查用户状态
            if (user.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "账号已注销");
            }
            
            if (user.getIsFrozen() == 1) {
                return Resp.error(HttpStatus.LOCKED.getCode(), "账号已冻结");
            }
            
            // 更新用户登录信息
            LocalDateTime now = LocalDateTime.now();
            user.setLastLoginTime(adminLoginDTO.getLastLoginTime() != null ? 
                adminLoginDTO.getLastLoginTime() : now);
            user.setLastLoginLocation(adminLoginDTO.getLastLoginLocation());
            user.setLastUpdatedTime(now);
            
            // 调用代理更新用户信息
            boolean updated = userServiceProxy.updateUserLoginInfo(user);
            if (!updated) {
                throw new RuntimeException(HttpStatus.INTERNAL_ERROR.getMsg());
            }
            
            // 创建LoginUser对象
            LoginUser loginUser = new LoginUser();
            loginUser.setXxuser(user);
            loginUser.setPermissions(
                    List.of("admin")
            );
            
            // 生成token
            String token = JwtUtil.createJWT(user.getUsername());
            
            // 存入Redis
            String redisKey = "login:" + user.getUsername();
            redisCache.setCacheObject(redisKey, loginUser);
            
            // 存入SecurityContextHolder
            UsernamePasswordAuthenticationToken authenticationToken = 
                new UsernamePasswordAuthenticationToken(loginUser, null, loginUser.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            
            // 构造返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("token", token);
            result.put("user", user);
            
            return Resp.success(result);
            
        } catch (Exception e) {
            throw new RuntimeException(HttpStatus.INTERNAL_ERROR.getMsg() + ": " + e.getMessage(), e);
        }
    }

    /**
     * 获取客户端真实IP地址
     */
    private String getClientIp() {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        // 对于通过多个代理的情况，第一个IP为客户端真实IP
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }

    @Override
    public Resp<Map<String, Object>> getLoginInfo() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 检查是否是管理员
            if (loginUser.getXxuser().getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "非管理员账号");
            }
            
            Map<String, Object> result = new HashMap<>();
            result.put("user", loginUser.getXxuser());
            result.put("permissions", loginUser.getPermissions());
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "未登录或登录已过期");
        }
    }

    @Override
    public Resp<Void> logout() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 检查是否是管理员
            if (loginUser.getXxuser().getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "非管理员账号");
            }
            
            // 删除Redis中的用户信息
            String redisKey = "login:" + loginUser.getXxuser().getUsername();
            redisCache.deleteObject(redisKey);
            
            // 清除SecurityContextHolder
            SecurityContextHolder.clearContext();
            
            return Resp.success(null);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "退出登录失败");
        }
    }

    @Override
    public Resp<Map<String, String>> refreshToken() {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 检查是否是管理员
            if (loginUser.getXxuser().getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "非管理员账号");
            }
            
            // 生成新的token
            String newToken = JwtUtil.createJWT(loginUser.getXxuser().getUsername());
            
            // 更新Redis中的用户信息过期时间
            String redisKey = "admin:login:" + loginUser.getXxuser().getUsername();
            redisCache.setCacheObject(redisKey, loginUser);
            
            Map<String, String> result = new HashMap<>();
            result.put("token", newToken);
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "刷新Token失败");
        }
    }

    @Override
    public Resp<Boolean> checkToken(String token) {
        try {
            // 解析token获取用户名
            String username = JwtUtil.parseJWT(token).getSubject();
            
            // 从Redis中获取用户信息
            String redisKey = "admin:login:" + username;
            LoginUser loginUser = redisCache.getCacheObject(redisKey);
            
            // 检查是否存在且是管理员
            if (loginUser != null && loginUser.getXxuser().getIsAdmin() == 1) {
                return Resp.success(true);
            }
            return Resp.success(false);
        } catch (Exception e) {
            return Resp.success(false);
        }
    }

    @Override
    public Resp<Map<String, String>> getIpInfo(String ip) {
        try {
            // 从SecurityContextHolder获取当前登录用户
            LoginUser loginUser = (LoginUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
            
            // 检查是否是管理员
            if (loginUser.getXxuser().getIsAdmin() != 1) {
                return Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "非管理员账号");
            }
            
            // 如果未提供IP，则获取当前请求的IP
            String ipAddress = (ip != null && !ip.isEmpty()) ? ip : getClientIp();
            // 获取IP地址对应的地理位置
            String location = ipLocationUtil.getLocationByIp(ipAddress);
            
            Map<String, String> result = new HashMap<>();
            result.put("ip", ipAddress);
            result.put("location", location);
            
            return Resp.success(result);
        } catch (Exception e) {
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取IP信息失败: " + e.getMessage());
        }
    }
} 