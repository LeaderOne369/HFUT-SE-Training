package com.example.ksp.modules.system.post.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@Schema(description = "更新帖子请求参数")
public class PostUpdateDTO {
    @NotNull(message = "帖子ID不能为空")
    @Schema(description = "帖子ID")
    private Long id;
    
    @Schema(description = "分区ID")
    private Long sectionId;
    
    @Schema(description = "标签，多个标签用逗号分隔")
    private String tags;
    
    @Schema(description = "封面图片")
    private String cover;
    
    @Schema(description = "摘要")
    private String summary;
    
    @Schema(description = "引用信息")
    private String citation;
    
    @Schema(description = "所属合集ID")
    private Long collectionId;
    
    @Schema(description = "标题")
    private String title;

    @Schema(description = "内容文件ID，由文件上传接口返回")
    private String contentFileId;

    @Schema(description = "内容文件路径，由文件上传接口返回")
    private String contentFilePath;
    
    @Schema(description = "可见性(1:公开 2:私密)")
    private Integer visibility;
    
    @Schema(description = "状态(0:草稿 1:已发布)")
    private Integer status;
} 