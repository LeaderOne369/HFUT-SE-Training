package com.example.ksp.modules.system.view.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.view.entity.View;
import com.example.ksp.modules.system.view.service.ViewService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级浏览记录管理接口")
@RestController
@RequestMapping("/api/system/view")
public class ViewController {

    @Autowired
    private ViewService viewService;

    @Operation(summary = "记录浏览")
    @PostMapping("/record")
    public Resp<Boolean> recordView(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId) {
        boolean result = viewService.recordView(userId, postId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "记录浏览失败");
    }

    @Operation(summary = "删除浏览记录")
    @DeleteMapping("/delete/{id}")
    public Resp<Boolean> deleteView(
            @Parameter(description = "浏览记录ID", required = true) 
            @PathVariable Long id) {
        boolean result = viewService.deleteView(id);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除浏览记录失败");
    }

    @Operation(summary = "批量删除用户的浏览记录")
    @DeleteMapping("/delete/user/{userId}")
    public Resp<Boolean> deleteUserViews(
            @Parameter(description = "用户ID", required = true) 
            @PathVariable Long userId) {
        boolean result = viewService.deleteUserViews(userId);
        if (result) {
            return Resp.success(true);
        }
        return Resp.error(HttpStatus.BAD_REQUEST, "删除用户浏览记录失败");
    }

    @Operation(summary = "获取用户的浏览记录")
    @GetMapping("/user/list")
    public Resp<Page<View>> getUserViews(
            @Parameter(description = "用户ID", required = true) 
            @RequestParam Long userId,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<View> result = viewService.getUserViews(userId, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取帖子的浏览记录")
    @GetMapping("/post/list")
    public Resp<Page<View>> getPostViews(
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size) {
        Page<View> result = viewService.getPostViews(postId, current, size);
        return Resp.success(result);
    }

    @Operation(summary = "获取帖子的浏览次数")
    @GetMapping("/post/count")
    public Resp<Long> getPostViewCount(
            @Parameter(description = "帖子ID", required = true) 
            @RequestParam Long postId) {
        long count = viewService.getPostViewCount(postId);
        return Resp.success(count);
    }
} 