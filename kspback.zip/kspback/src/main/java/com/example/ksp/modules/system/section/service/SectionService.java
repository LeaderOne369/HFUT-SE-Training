package com.example.ksp.modules.system.section.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.tag.entity.Tag;

import java.util.List;

public interface SectionService extends IService<Section> {

    /**
     * 创建分区
     */
    boolean createSection(Section section);

    /**
     * 更新分区
     */
    boolean updateSection(Section section);

    /**
     * 删除分区
     */
    boolean deleteSection(Long id);

    /**
     * 切换分区可见性
     */
    boolean toggleVisibility(Long id);


    /**
     * 获取所有分区
     */
    List<Section> getAllSections();

    /**
     * 获取指定分区下的所有标签
     */
    Resp<List<Tag>> getTagsBySection(Long sectionId);

    /**
     * 获取指定分区或标签下的所有帖子
     */
    Page<Post> getPostsBySectionOrTag(Long sectionId, Long tagId, long current, long size);

    /**
     * 分区搜索，分页，排序
     */
    Page<Post> searchPostsBySection(Long sectionId, String keyword, long current, long size, String sortBy);
}

