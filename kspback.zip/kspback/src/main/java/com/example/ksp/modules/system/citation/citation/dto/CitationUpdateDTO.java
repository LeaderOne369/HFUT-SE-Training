package com.example.ksp.modules.system.citation.citation.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "更新引用请求参数")
public class CitationUpdateDTO {
    
    @NotNull(message = "引用ID不能为空")
    @Schema(description = "引用ID")
    private Long id;
    
    @Schema(description = "引用类型ID")
    private Long citationTypeId;
    
    @Schema(description = "引用内容")
    private String citationContent;
    
    @Schema(description = "引用来源")
    private String source;
} 