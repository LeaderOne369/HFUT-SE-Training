package com.example.ksp.modules.proxy;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.section.service.SectionService;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.post.entity.Post;
import com.example.ksp.modules.system.tag.entity.Tag;
import com.example.ksp.common.variable.Resp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SectionServiceProxy {

    @Autowired
    private SectionService sectionService;

    /**
     * 获取所有分区
     */
    public Resp<List<Section>> getAllSections() {
        List<Section> sections = sectionService.getAllSections();
        return Resp.success(sections);
    }

    /**
     * 获取分区下的所有标签
     */
    public Resp<List<Tag>> getTagsBySection(Long sectionId) {
        return sectionService.getTagsBySection(sectionId);
    }

    /**
     * 获取分区或标签下的所有帖子
     */
    public Resp<Page<Post>> getPostsBySectionOrTag(Long sectionId,Long tagId, long current, long size){
        Page<Post> posts = sectionService.getPostsBySectionOrTag(sectionId, tagId, current,size);
        return Resp.success(posts);
    }

    /**
     * 分区搜索，支持分页、排序
     */
    public Resp<Page<Post>> searchPostsBySection(Long sectionId, String keyword, long current, long size, String sortBy) {
        Page<Post> sections = sectionService.searchPostsBySection(sectionId,keyword,current,size,sortBy);
        return Resp.success(sections);
    }

    public Section getSectionById(Long sectionId) {
        return sectionService.getById(sectionId);
    }
}
