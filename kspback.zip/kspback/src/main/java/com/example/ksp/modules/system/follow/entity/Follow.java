package com.example.ksp.modules.system.follow.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("follow")
@Schema(description = "关注实体类")
public class Follow {
    
    @TableId(type = IdType.AUTO)
    @Schema(description = "主键，唯一标识一条关注记录")
    private Long id;

    @Schema(description = "关注者ID")
    private Long followerId;

    @Schema(description = "被关注者ID")
    private Long followeeId;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Schema(description = "关注时间")
    private LocalDateTime followTime;

    @Schema(description = "是否删除，1表示已删除，0表示未删除")
    private String isDeleted;
} 