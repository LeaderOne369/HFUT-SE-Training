package com.example.ksp.modules.admin.management.reviewmg.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Schema(description = "审核管理VO")
public class ReviewManageVO {
    
    @Schema(description = "审核记录ID")
    private Long id;
    
    @Schema(description = "审核对象ID")
    private Long contentId;
    
    @Schema(description = "被审核内容类型(0:用户 1:帖子 2:合集 3:收藏夹)")
    private Integer contentType;
    
    @Schema(description = "审核状态：0-待处理 1-通过 2-拒绝")
    private Integer reviewStatus;

    
    @Schema(description = "处理人ID")
    private Long reviewerId;
    
    @Schema(description = "处理人名称")
    private String reviewerName;

    @Schema(description = "审核时间")
    private LocalDateTime reviewTime;

    @Schema(description = "审核备注")
    private String reviewNotes;

} 