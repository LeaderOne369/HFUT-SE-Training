package com.example.ksp.modules.client.personal.center.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.personal.center.service.PersonalPostService;
import com.example.ksp.modules.proxy.PostServiceProxy;
import com.example.ksp.modules.system.post.dto.PostQueryDTO;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersonalPostServiceImpl implements PersonalPostService {

    private final PostServiceProxy postServiceProxy;

    @Override
    public Resp<Page<Post>> getUserPosts(Long userId, long current, long size) {
        try {
            PostQueryDTO queryDTO = new PostQueryDTO();
            queryDTO.setUserId(userId);
            queryDTO.setPageNum((int) current);
            queryDTO.setPageSize((int) size);
            // 只过滤掉已删除的帖子，其他状态都显示
            // 不设置status和reviewStatus，这样可以看到所有状态的帖子
            
            return postServiceProxy.queryPosts(queryDTO);
        } catch (Exception e) {
            log.error("获取用户帖子列表失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取帖子列表失败");
        }
    }

    @Override
    public Resp<Post> getPostDetail(Long userId, Long postId) {
        try {
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            Post post = postResp.getData();
            if (!post.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权查看此帖子");
            }
            
            if (post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子已删除");
            }
            
            return Resp.success(post);
        } catch (Exception e) {
            log.error("获取帖子详情失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "获取帖子详情失败");
        }
    }

    @Override
    public Resp<Post> updatePost(Long userId, PostUpdateDTO updateDTO) {
        try {
            // 验证帖子所有权
            Resp<Post> postResp = postServiceProxy.getPost(updateDTO.getId());
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            Post post = postResp.getData();
            if (!post.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权修改此帖子");
            }
            
            if (post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子已删除");
            }
            
            updateDTO.setStatus(0);
            
            return postServiceProxy.updatePost(updateDTO);
        } catch (Exception e) {
            log.error("更新帖子失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "更新帖子失败");
        }
    }

    @Override
    public Resp<Boolean> deletePost(Long userId, Long postId) {
        try {
            // 验证帖子所有权
            Resp<Post> postResp = postServiceProxy.getPost(postId);
            if (postResp.getCode() != 200 || postResp.getData() == null) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子不存在");
            }
            
            Post post = postResp.getData();
            if (!post.getUserId().equals(userId)) {
                return Resp.error(HttpStatus.FORBIDDEN.getCode(), "无权删除此帖子");
            }
            
            if (post.getIsDeleted() == 1) {
                return Resp.error(HttpStatus.NOT_FOUND.getCode(), "帖子已删除");
            }
            
            Resp<String> deleteResp = postServiceProxy.deletePost(postId);
            return Resp.success(deleteResp.getCode() == 200);
        } catch (Exception e) {
            log.error("删除帖子失败", e);
            return Resp.error(HttpStatus.INTERNAL_ERROR.getCode(), "删除帖子失败");
        }
    }
} 