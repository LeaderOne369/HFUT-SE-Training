package com.example.ksp.modules.system.report.reportedtype.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeCreateDTO;
import com.example.ksp.modules.system.report.reportedtype.dto.ReportedTypeUpdateDTO;
import com.example.ksp.modules.system.report.reportedtype.entity.ReportedType;
import com.example.ksp.modules.system.report.reportedtype.service.ReportedTypeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级举报对象类型管理")
@RestController
@RequestMapping("/api/system/reported-type")
@RequiredArgsConstructor
public class ReportedTypeController {

    private final ReportedTypeService reportedTypeService;

    @Operation(summary = "创建举报对象类型")
    @PostMapping
    @PreAuthorize("hasAuthority('admin')")
    public Resp<ReportedType> createReportedType(
            @RequestBody @Valid ReportedTypeCreateDTO createDTO) {
        return reportedTypeService.createReportedType(createDTO);
    }

    @Operation(summary = "更新举报对象类型")
    @PutMapping
    @PreAuthorize("hasAuthority('admin')")
    public Resp<ReportedType> updateReportedType(
            @RequestBody @Valid ReportedTypeUpdateDTO updateDTO) {
        return reportedTypeService.updateReportedType(updateDTO);
    }

    @Operation(summary = "删除举报对象类型")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('admin')")
    public Resp<Void> deleteReportedType(
            @Parameter(description = "举报对象类型ID") 
            @PathVariable Long id) {
        return reportedTypeService.deleteReportedType(id);
    }

    @Operation(summary = "获取举报对象类型详情")
    @GetMapping("/{id}")
    public Resp<ReportedType> getReportedType(
            @Parameter(description = "举报对象类型ID") 
            @PathVariable Long id) {
        return reportedTypeService.getReportedType(id);
    }

    @Operation(summary = "获取举报对象类型列表")
    @GetMapping("/list")
    public Resp<Page<ReportedType>> listReportedTypes(
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size,
            @Parameter(description = "举报对象类型名称") 
            @RequestParam(required = false) String typeName,
            @Parameter(description = "是否启用") 
            @RequestParam(required = false) Integer isActive) {
        return reportedTypeService.listReportedTypes(new Page<>(current, size), typeName, isActive);
    }
} 