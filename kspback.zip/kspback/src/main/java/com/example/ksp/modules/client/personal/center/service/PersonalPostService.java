package com.example.ksp.modules.client.personal.center.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.post.dto.PostUpdateDTO;
import com.example.ksp.modules.system.post.entity.Post;

public interface PersonalPostService {
    
    /**
     * 获取用户的帖子列表
     */
    Resp<Page<Post>> getUserPosts(Long userId, long current, long size);
    
    /**
     * 获取帖子详情
     */
    Resp<Post> getPostDetail(Long userId, Long postId);
    
    /**
     * 更新帖子
     */
    Resp<Post> updatePost(Long userId, PostUpdateDTO updateDTO);
    
    /**
     * 删除帖子
     */
    Resp<Boolean> deletePost(Long userId, Long postId);
} 