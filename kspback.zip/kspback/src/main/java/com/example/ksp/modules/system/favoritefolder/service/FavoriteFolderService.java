package com.example.ksp.modules.system.favoritefolder.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ksp.modules.system.favoritefolder.entity.FavoriteFolder;

public interface FavoriteFolderService extends IService<FavoriteFolder> {
    
    /**
     * 创建收藏夹
     */
    boolean createFolder(FavoriteFolder folder);

    /**
     * 更新收藏夹
     */
    boolean updateFolder(FavoriteFolder folder);

    /**
     * 删除收藏夹
     */
    boolean deleteFolder(Long id);

    /**
     * 获取用户的收藏夹列表
     */
    Page<FavoriteFolder> getUserFolders(Long userId, long current, long size);

    /**
     * 更新收藏夹可见性
     */
    boolean updateVisibility(Long id, Integer visibility);

    /**
     * 获取公开的收藏夹列表
     */
    Page<FavoriteFolder> getPublicFolders(long current, long size);

    /**
     * 更新审核状态
     */
    boolean updateReviewStatus(Long id, Integer status);
} 