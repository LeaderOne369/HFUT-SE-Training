package com.example.ksp.modules.system.citation.citationtype.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeCreateDTO;
import com.example.ksp.modules.system.citation.citationtype.dto.CitationTypeUpdateDTO;
import com.example.ksp.modules.system.citation.citationtype.entity.CitationType;
import com.example.ksp.modules.system.citation.citationtype.service.CitationTypeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@Tag(name = "系统级引用类型管理")
@RestController
@RequestMapping("/api/system/citation-type")
@RequiredArgsConstructor
public class CitationTypeController {

    private final CitationTypeService citationTypeService;

    @Operation(summary = "创建引用类型")
    @PostMapping
    public Resp<CitationType> createCitationType(
            @RequestHeader("token") String token,
            @RequestBody @Valid CitationTypeCreateDTO createDTO) {
        return citationTypeService.createCitationType(createDTO);
    }

    @Operation(summary = "更新引用类型")
    @PutMapping
    public Resp<CitationType> updateCitationType(
            @RequestHeader("token") String token,
            @RequestBody @Valid CitationTypeUpdateDTO updateDTO) {
        return citationTypeService.updateCitationType(updateDTO);
    }

    @Operation(summary = "删除引用类型")
    @DeleteMapping("/{id}")
    public Resp<Void> deleteCitationType(
            @RequestHeader("token") String token,
            @Parameter(description = "引用类型ID") 
            @PathVariable Long id) {
        return citationTypeService.deleteCitationType(id);
    }

    @Operation(summary = "获取引用类型详情")
    @GetMapping("/{id}")
    public Resp<CitationType> getCitationType(
            @RequestHeader("token") String token,
            @Parameter(description = "引用类型ID") 
            @PathVariable Long id) {
        return citationTypeService.getCitationType(id);
    }

    @Operation(summary = "获取引用类型列表")
    @GetMapping("/list")
    public Resp<Page<CitationType>> listCitationTypes(
            @RequestHeader("token") String token,
            @Parameter(description = "页码") 
            @RequestParam(defaultValue = "1") long current,
            @Parameter(description = "每页大小") 
            @RequestParam(defaultValue = "10") long size,
            @Parameter(description = "引用类型名称") 
            @RequestParam(required = false) String typeName,
            @Parameter(description = "是否启用") 
            @RequestParam(required = false) Integer isActive) {
        return citationTypeService.listCitationTypes(new Page<>(current, size), typeName, isActive);
    }
} 