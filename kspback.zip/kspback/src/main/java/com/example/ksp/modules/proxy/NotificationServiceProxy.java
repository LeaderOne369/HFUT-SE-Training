package com.example.ksp.modules.proxy;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.service.NotificationService;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class NotificationServiceProxy {

    private final NotificationService notificationService;

    /**
     * 接收消息（获取用户所有通知）
     */
    public Resp<List<Notification>> receiveMessages(Long userId, Integer type, long current, long size) {
        return Resp.success(notificationService.getUserNotifications(userId, type, current, size).getRecords());
    }

    /**
     * 查看消息详情
     */
    public Resp<Notification> getMessageDetails(Long id) {
        Notification notification = notificationService.getById(id);
        if (notification != null) {
            return Resp.success(notification);
        } else {
            return Resp.error(404, "Notification not found");
        }
    }

    /**
     * 标记消息为已读
     */
    public Resp<Boolean> markAsRead(Long id) {
        boolean result = notificationService.markAsRead(id);
        return result ? Resp.success(true) : Resp.error(500, "Failed to mark as read");
    }

    /**
     * 批量标记所有通知为已读
     */
    public Resp<Boolean> markAllAsRead(Long userId) {
        boolean result = notificationService.markAllAsRead(userId);
        return result ? Resp.success(true) : Resp.error(500, "Failed to mark all as read");
    }

    /**
     * 删除指定通知
     */
    public Resp<Boolean> deleteMessage(Long id) {
        boolean result = notificationService.deleteNotification(id);
        return result ? Resp.success(true) : Resp.error(500, "Failed to delete notification");
    }

    /**
     * 获取用户未读通知的数量
     */
    public Resp<Long> getUnreadCount(Long userId) {
        long unreadCount = notificationService.getUnreadCount(userId);
        return Resp.success(unreadCount);
    }
}
