package com.example.ksp.modules.client.homepage.dto;

import lombok.Data;

@Data
public class HomePageRecommendDTO {
    /**
     * 用户ID
     */
    private Long userId;
    
    /**
     * 推荐内容数量限制
     */
    private Integer limit = 10;
    
    /**
     * 推荐类型
     * 1: 最新内容
     * 2: 热门内容
     * 3: 关注内容
     */
    private Integer type = 1;
    
    /**
     * 是否包含已读内容
     */
    private Boolean includeRead = false;
} 