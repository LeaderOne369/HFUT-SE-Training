package com.example.ksp.modules.system.citation.citation.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.citation.citation.dto.CitationCreateDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationQueryDTO;
import com.example.ksp.modules.system.citation.citation.dto.CitationUpdateDTO;
import com.example.ksp.modules.system.citation.citation.entity.Citation;
import com.example.ksp.modules.system.citation.citation.service.CitationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "系统级引用管理")
@RestController
@RequestMapping("/api/system/citation")
@RequiredArgsConstructor
public class CitationController {
    
    private final CitationService citationService;

    @Operation(summary = "创建引用")
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Citation> createCitation(@RequestBody @Valid CitationCreateDTO createDTO) {
        return citationService.createCitation(createDTO);
    }

    @Operation(summary = "更新引用")
    @PutMapping
    @PreAuthorize("isAuthenticated()")
    public Resp<Citation> updateCitation(@RequestBody @Valid CitationUpdateDTO updateDTO) {
        return citationService.updateCitation(updateDTO);
    }

    @Operation(summary = "删除引用")
    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> deleteCitation(
            @Parameter(description = "引用ID") 
            @PathVariable Long id) {
        return citationService.deleteCitation(id);
    }

    @Operation(summary = "获取引用详情")
    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public Resp<Citation> getCitation(
            @Parameter(description = "引用ID") 
            @PathVariable Long id) {
        return citationService.getCitation(id);
    }

    @Operation(summary = "分页查询引用")
    @GetMapping("/list")
    @PreAuthorize("isAuthenticated()")
    public Resp<Page<Citation>> queryCitations(@Valid CitationQueryDTO queryDTO) {
        return citationService.queryCitations(queryDTO);
    }

    @Operation(summary = "获取帖子的所有引用")
    @GetMapping("/post/{postId}")
    @PreAuthorize("isAuthenticated()")
    public Resp<List<Citation>> getPostCitations(
            @Parameter(description = "帖子ID") 
            @PathVariable Long postId) {
        return citationService.getPostCitations(postId);
    }
} 