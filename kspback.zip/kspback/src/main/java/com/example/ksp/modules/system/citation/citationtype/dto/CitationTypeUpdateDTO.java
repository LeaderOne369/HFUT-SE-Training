package com.example.ksp.modules.system.citation.citationtype.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "更新引用类型请求参数")
public class CitationTypeUpdateDTO {
    
    @NotNull(message = "引用类型ID不能为空")
    @Schema(description = "引用类型ID")
    private Long id;
    
    @Schema(description = "引用类型名称")
    private String typeName;
    
    @Schema(description = "引用类型描述")
    private String typeDescription;
    
    @Schema(description = "是否启用(1:启用 0:未启用)")
    private Integer isActive;
} 