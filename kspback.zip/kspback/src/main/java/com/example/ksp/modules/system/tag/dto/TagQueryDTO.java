package com.example.ksp.modules.system.tag.dto;

import lombok.Data;

@Data
public class TagQueryDTO {
    private String keyword;
    private Long sectionId;
    private Integer pageNum = 1;
    private Integer pageSize = 10;
} 