package com.example.ksp.modules.client.clientlogin.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.clientlogin.dto.*;
import com.example.ksp.modules.client.clientlogin.service.ClientLoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "客户端登录接口")
@RestController
@RequestMapping("/api/client/login")
@RequiredArgsConstructor
public class ClientLoginController {

    private final ClientLoginService clientLoginService;

    @Operation(summary = "登录")
    @PostMapping
    public Resp<Map<String, Object>> login(@RequestBody ClientLoginDTO clientLoginDTO) {
        return clientLoginService.login(clientLoginDTO);
    }

    @Operation(summary = "获取当前登录用户信息")
    @GetMapping("/info")
    public Resp<Map<String, Object>> getLoginInfo() {
        return clientLoginService.getLoginInfo();
    }

    @Operation(summary = "退出登录")
    @PostMapping("/logout")
    public Resp<Void> logout() {
        return clientLoginService.logout();
    }

    @Operation(summary = "刷新Token")
    @PostMapping("/refresh")
    public Resp<Map<String, String>> refreshToken() {
        return clientLoginService.refreshToken();
    }

    @Operation(summary = "检查Token有效性")
    @GetMapping("/check")
    public Resp<Boolean> checkToken(@RequestParam String token) {
        return clientLoginService.checkToken(token);
    }

    @Operation(summary = "获取IP地址信息")
    @GetMapping("/ip")
    public Resp<Map<String, String>> getIpInfo(@RequestParam(required = false) String ip) {
        return clientLoginService.getIpInfo(ip);
    }

    @Operation(summary = "注册")
    @PostMapping("/register")
    public Resp<String> register(@RequestBody @Valid ClientRegisterDTO registerDTO) {
        return clientLoginService.register(registerDTO);
    }

    @Operation(summary = "忘记密码")
    @PostMapping("/forget-password")
    public Resp<String> forgetPassword(@RequestBody @Valid ForgetPasswordDTO forgetPasswordDTO) {
        return clientLoginService.forgetPassword(forgetPasswordDTO);
    }

    @Operation(summary = "修改密码")
    @PostMapping("/change-password")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> changePassword(@RequestBody @Valid ChangePasswordDTO changePasswordDTO) {
        return clientLoginService.changePassword(changePasswordDTO);
    }

    @Operation(summary = "账号注销")
    @PostMapping("/deactivate")
    @PreAuthorize("isAuthenticated()")
    public Resp<String> deactivateAccount(@RequestBody @Valid DeactivateAccountDTO deactivateDTO) {
        return clientLoginService.deactivateAccount(deactivateDTO);
    }

    @Operation(summary = "发送验证码")
    @PostMapping("/captcha")
    public Resp<String> sendCaptcha(@RequestParam String phoneNumber) {
        return clientLoginService.sendCaptcha(phoneNumber);
    }
} 