package com.example.ksp.modules.client.post.postdetail.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "评论信息")
public class CommentDTO {
    /**
     * 评论ID
     */
    @Schema(description = "评论ID")
    private Long id;
    
    /**
     * 评论内容
     */
    @Schema(description = "评论内容")
    private String content;
    
    /**
     * 评论者ID
     */
    @Schema(description = "评论者ID")
    private Long commenterId;
    
    /**
     * 评论者名称
     */
    @Schema(description = "评论者名称")
    private String commenterName;
    
    /**
     * 评论者头像
     */
    @Schema(description = "评论者头像")
    private String commenterAvatar;
    
    /**
     * 评论时间
     */
    @Schema(description = "评论时间")
    private LocalDateTime creationTime;
    
    /**
     * 点赞数
     */
    @Schema(description = "点赞数")
    private Integer likeCount;
    
    /**
     * 是否已点赞
     */
    @Schema(description = "是否已点赞")
    private Boolean isLiked;
    
    /**
     * 回复数
     */
    @Schema(description = "回复数")
    private Integer replyCount;
    
    /**
     * 父评论ID
     */
    @Schema(description = "父评论ID")
    private Long parentCommentId;
    
    /**
     * 被回复者ID
     */
    @Schema(description = "被回复者ID")
    private Long replyToCommenterId;
    
    /**
     * 被回复者名称
     */
    @Schema(description = "被回复者名称")
    private String replyToCommenterName;
    
    /**
     * 是否公开
     */
    @Schema(description = "是否公开")
    private Integer isPublic;
    
    /**
     * 审核状态
     */
    @Schema(description = "审核状态")
    private Integer reviewStatus;
}