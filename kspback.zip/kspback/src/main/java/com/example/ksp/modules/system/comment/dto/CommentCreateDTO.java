package com.example.ksp.modules.system.comment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "创建评论请求参数")
public class CommentCreateDTO {
    
    @NotNull(message = "评论者ID不能为空")
    @Schema(description = "评论者ID")
    private Long commenterId;
    
    @NotNull(message = "被评论对象ID不能为空")
    @Schema(description = "被评论对象ID")
    private Long commentableId;
    
    @NotNull(message = "被评论对象类型不能为空")
    @Schema(description = "被评论对象类型(1:帖子 2:合集 3:评论)")
    private Integer commentableType;
    
    @NotBlank(message = "评论内容不能为空")
    @Schema(description = "评论内容")
    private String content;
    
    @Schema(description = "父评论ID")
    private Long parentCommentId;
    
    @NotNull(message = "是否公开不能为空")
    @Schema(description = "是否公开(0:私密 1:公开)")
    private Integer isPublic;
} 