package com.example.ksp.modules.system.reviewlog.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import com.example.ksp.modules.system.reviewlog.service.ReviewLogService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewLogControllerTest {

    @Mock
    private ReviewLogService reviewLogService;

    @InjectMocks
    private ReviewLogController reviewLogController;

    @Test
    void createReviewLog_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        ReviewLog reviewLog = new ReviewLog();
        when(reviewLogService.createReviewLog(any(ReviewLog.class))).thenReturn(true);

        // Act
        Resp<Boolean> response = reviewLogController.createReviewLog(reviewLog);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void createReviewLog_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        ReviewLog reviewLog = new ReviewLog();
        when(reviewLogService.createReviewLog(any(ReviewLog.class))).thenReturn(false);

        // Act
        Resp<Boolean> response = reviewLogController.createReviewLog(reviewLog);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("创建审核记录失败", response.getMsg());
    }

    @Test
    void updateReviewStatus_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        Integer status = 1;
        String notes = "测试备注";
        when(reviewLogService.updateReviewStatus(id, status, notes)).thenReturn(true);

        // Act
        Resp<Boolean> response = reviewLogController.updateReviewStatus(id, status, notes);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getContentReviews_ShouldReturnPageResult() {
        // Arrange
        Long contentId = 1L;
        Integer contentType = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        when(reviewLogService.getContentReviews(contentId, contentType, current, size))
                .thenReturn(expectedPage);

        // Act
        Resp<Page<ReviewLog>> response = reviewLogController.getContentReviews(contentId, contentType, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getReviewerLogs_ShouldReturnPageResult() {
        // Arrange
        Long reviewerId = 1L;
        Integer status = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        when(reviewLogService.getReviewerLogs(reviewerId, status, current, size))
                .thenReturn(expectedPage);

        // Act
        Resp<Page<ReviewLog>> response = reviewLogController.getReviewerLogs(reviewerId, status, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getPendingReviews_ShouldReturnPageResult() {
        // Arrange
        Integer contentType = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        when(reviewLogService.getPendingReviews(contentType, current, size))
                .thenReturn(expectedPage);

        // Act
        Resp<Page<ReviewLog>> response = reviewLogController.getPendingReviews(contentType, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void batchReview_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long[] ids = {1L, 2L};
        Integer status = 1;
        String notes = "批量审核备注";
        when(reviewLogService.batchReview(ids, status, notes)).thenReturn(true);

        // Act
        Resp<Boolean> response = reviewLogController.batchReview(ids, status, notes);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void batchReview_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Long[] ids = {1L, 2L};
        Integer status = 1;
        String notes = "批量审核备注";
        when(reviewLogService.batchReview(ids, status, notes)).thenReturn(false);

        // Act
        Resp<Boolean> response = reviewLogController.batchReview(ids, status, notes);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("批量审核失败", response.getMsg());
    }
} 