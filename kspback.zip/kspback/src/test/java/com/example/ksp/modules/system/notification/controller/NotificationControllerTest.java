package com.example.ksp.modules.system.notification.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.service.NotificationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private NotificationController notificationController;

    @Test
    void sendNotification_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Notification notification = new Notification();
        notification.setTitle("测试通知");
        when(notificationService.sendNotification(any(Notification.class))).thenReturn(true);

        // Act
        Resp<Boolean> response = notificationController.sendNotification(notification);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void sendNotification_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Notification notification = new Notification();
        when(notificationService.sendNotification(any(Notification.class))).thenReturn(false);

        // Act
        Resp<Boolean> response = notificationController.sendNotification(notification);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("发送通知失败", response.getMsg());
    }

    @Test
    void markAsRead_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(notificationService.markAsRead(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = notificationController.markAsRead(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void markAllAsRead_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        when(notificationService.markAllAsRead(userId)).thenReturn(true);

        // Act
        Resp<Boolean> response = notificationController.markAllAsRead(userId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void deleteNotification_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(notificationService.deleteNotification(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = notificationController.deleteNotification(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getUnreadCount_ShouldReturnCount() {
        // Arrange
        Long userId = 1L;
        long expectedCount = 5L;
        when(notificationService.getUnreadCount(userId)).thenReturn(expectedCount);

        // Act
        Resp<Long> response = notificationController.getUnreadCount(userId);

        // Assert
        assertEquals(200, response.getCode());
        assertEquals(expectedCount, response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getUserNotifications_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Integer type = 1;
        long current = 1;
        long size = 10;
        Page<Notification> expectedPage = new Page<>();
        when(notificationService.getUserNotifications(userId, type, current, size)).thenReturn(expectedPage);

        // Act
        Resp<Page<Notification>> response = notificationController.getUserNotifications(userId, type, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }
} 