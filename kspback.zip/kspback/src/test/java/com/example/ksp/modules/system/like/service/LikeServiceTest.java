package com.example.ksp.modules.system.like.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.ksp.modules.system.like.entity.Like;
import com.example.ksp.modules.system.like.mapper.LikeMapper;
import com.example.ksp.modules.system.like.service.impl.LikeServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LikeServiceTest {

    @Mock
    private LikeMapper likeMapper;

    @Spy
    @InjectMocks
    private LikeServiceImpl likeService;

    @BeforeEach
    void setUp() {
        // 手动设置baseMapper
        ReflectionTestUtils.setField(likeService, "baseMapper", likeMapper);
    }

    @Test
    void addLike_WhenNotLikedBefore_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        // 模拟查询不存在
        doReturn(0L).when(likeMapper).selectCount(any());
        // 模拟插入成功
        doReturn(1).when(likeMapper).insert(any(Like.class));

        // Act
        boolean result = likeService.addLike(userId, objectId, objectType);

        // Assert
        assertTrue(result);
        verify(likeMapper).insert(any(Like.class));
    }

    @Test
    void addLike_WhenAlreadyLiked_ShouldReturnFalse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        // 模拟查询存在
        doReturn(1L).when(likeMapper).selectCount(any());

        // Act
        boolean result = likeService.addLike(userId, objectId, objectType);

        // Assert
        assertFalse(result);
        verify(likeMapper, never()).insert(any(Like.class));
    }

    @Test
    void cancelLike_WhenLikeExists_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        // 模拟删除成功
        doReturn(1).when(likeMapper).delete(any());

        // Act
        boolean result = likeService.cancelLike(userId, objectId, objectType);

        // Assert
        assertTrue(result);
        verify(likeMapper).delete(any());
    }

    @Test
    void checkLiked_WhenLikeExists_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        // 模拟查询存在
        doReturn(1L).when(likeMapper).selectCount(any());

        // Act
        boolean result = likeService.checkLiked(userId, objectId, objectType);

        // Assert
        assertTrue(result);
    }

    @Test
    void checkLiked_WhenLikeNotExists_ShouldReturnFalse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        // 模拟查询不存在
        doReturn(0L).when(likeMapper).selectCount(any());

        // Act
        boolean result = likeService.checkLiked(userId, objectId, objectType);

        // Assert
        assertFalse(result);
    }
} 