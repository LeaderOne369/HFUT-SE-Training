package com.example.ksp.modules.system.feedback.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.mapper.FeedbackMapper;
import com.example.ksp.modules.system.feedback.service.impl.FeedbackServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FeedbackServiceTest {

    @Mock
    private FeedbackMapper feedbackMapper;

    @Spy
    @InjectMocks
    private FeedbackServiceImpl feedbackService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(feedbackService, "baseMapper", feedbackMapper);
    }

    @Test
    void submitFeedback_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        Feedback feedback = new Feedback();
        feedback.setUserId(1L);
        feedback.setFeedbackContent("测试反馈内容");
        
        doReturn(1).when(feedbackMapper).insert(any(Feedback.class));

        // Act
        boolean result = feedbackService.submitFeedback(feedback);

        // Assert
        assertTrue(result);
        verify(feedbackMapper).insert(any(Feedback.class));
        assertNotNull(feedback.getFeedbackTime());
        assertEquals(0, feedback.getStatus());
        assertEquals(0, feedback.getIsDeleted());
    }

    @Test
    void updateStatus_WhenFeedbackExists_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        Integer newStatus = 1;
        Feedback feedback = new Feedback();
        feedback.setId(id);
        feedback.setStatus(0);
        
        doReturn(feedback).when(feedbackMapper).selectById(id);
        doReturn(1).when(feedbackMapper).updateById(any(Feedback.class));

        // Act
        boolean result = feedbackService.updateStatus(id, newStatus);

        // Assert
        assertTrue(result);
        verify(feedbackMapper).updateById(any(Feedback.class));
        assertEquals(newStatus, feedback.getStatus());
    }

    @Test
    void updateStatus_WhenFeedbackNotExists_ShouldReturnFalse() {
        // Arrange
        Long id = 1L;
        Integer newStatus = 1;
        doReturn(null).when(feedbackMapper).selectById(id);

        // Act
        boolean result = feedbackService.updateStatus(id, newStatus);

        // Assert
        assertFalse(result);
        verify(feedbackMapper, never()).updateById(any(Feedback.class));
    }

    @Test
    void deleteFeedback_WhenValidId_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        doReturn(1).when(feedbackMapper).deleteById(id);

        // Act
        boolean result = feedbackService.deleteFeedback(id);

        // Assert
        assertTrue(result);
        verify(feedbackMapper).deleteById(id);
    }

    @Test
    void getUserFeedbacks_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Integer status = 0;
        long current = 1;
        long size = 10;
        Page<Feedback> expectedPage = new Page<>();
        
        doReturn(expectedPage).when(feedbackMapper).selectPage(any(), any());

        // Act
        Page<Feedback> result = feedbackService.getUserFeedbacks(userId, status, current, size);

        // Assert
        assertNotNull(result);
        verify(feedbackMapper).selectPage(any(), any());
    }

    @Test
    void getAllFeedbacks_ShouldReturnPageResult() {
        // Arrange
        Integer status = 0;
        long current = 1;
        long size = 10;
        Page<Feedback> expectedPage = new Page<>();
        
        doReturn(expectedPage).when(feedbackMapper).selectPage(any(), any());

        // Act
        Page<Feedback> result = feedbackService.getAllFeedbacks(status, current, size);

        // Assert
        assertNotNull(result);
        verify(feedbackMapper).selectPage(any(), any());
    }
} 