package com.example.ksp.modules.system.notification.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.notification.entity.Notification;
import com.example.ksp.modules.system.notification.mapper.NotificationMapper;
import com.example.ksp.modules.system.notification.service.impl.NotificationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationMapper notificationMapper;

    @Spy
    @InjectMocks
    private NotificationServiceImpl notificationService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(notificationService, "baseMapper", notificationMapper);
    }

    @Test
    void sendNotification_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        Notification notification = new Notification();
        notification.setTitle("测试通知");
        notification.setContent("测试内容");
        notification.setUserSenderId(1L);
        notification.setUserReceiverId(2L);
        notification.setType(1);
        
        doReturn(1).when(notificationMapper).insert(any(Notification.class));

        // Act
        boolean result = notificationService.sendNotification(notification);

        // Assert
        assertTrue(result);
        verify(notificationMapper).insert(any(Notification.class));
        assertNotNull(notification.getCreationTime());
        assertEquals(0, notification.getStatus());
        assertEquals(0, notification.getIsDeleted());
    }

    @Test
    void markAsRead_WhenNotificationExists_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        Notification notification = new Notification();
        notification.setId(id);
        notification.setStatus(0);
        
        doReturn(notification).when(notificationMapper).selectById(id);
        doReturn(1).when(notificationMapper).updateById(any(Notification.class));

        // Act
        boolean result = notificationService.markAsRead(id);

        // Assert
        assertTrue(result);
        verify(notificationMapper).updateById(any(Notification.class));
        assertEquals(1, notification.getStatus());
        assertNotNull(notification.getReadTime());
    }

    @Test
    void markAsRead_WhenNotificationNotExists_ShouldReturnFalse() {
        // Arrange
        Long id = 1L;
        doReturn(null).when(notificationMapper).selectById(id);

        // Act
        boolean result = notificationService.markAsRead(id);

        // Assert
        assertFalse(result);
        verify(notificationMapper, never()).updateById(any(Notification.class));
    }

    @Test
    void markAllAsRead_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        @SuppressWarnings("unchecked")
        LambdaQueryWrapper<Notification> wrapper = any(LambdaQueryWrapper.class);
        doReturn(1).when(notificationMapper).update(any(Notification.class), wrapper);

        // Act
        boolean result = notificationService.markAllAsRead(userId);

        // Assert
        assertTrue(result);
        verify(notificationMapper).update(any(Notification.class), any());
    }

    @Test
    void deleteNotification_WhenValidId_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        doReturn(1).when(notificationMapper).deleteById(id);

        // Act
        boolean result = notificationService.deleteNotification(id);

        // Assert
        assertTrue(result);
        verify(notificationMapper).deleteById(id);
    }

    @Test
    void getUnreadCount_ShouldReturnCount() {
        // Arrange
        Long userId = 1L;
        long expectedCount = 5L;
        @SuppressWarnings("unchecked")
        LambdaQueryWrapper<Notification> wrapper = any(LambdaQueryWrapper.class);
        doReturn(expectedCount).when(notificationMapper).selectCount(wrapper);

        // Act
        long result = notificationService.getUnreadCount(userId);

        // Assert
        assertEquals(expectedCount, result);
        verify(notificationMapper).selectCount(any());
    }

    @Test
    void getUserNotifications_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Integer type = 1;
        long current = 1;
        long size = 10;
        Page<Notification> expectedPage = new Page<>();
        
        doReturn(expectedPage).when(notificationMapper).selectPage(any(), any());

        // Act
        Page<Notification> result = notificationService.getUserNotifications(userId, type, current, size);

        // Assert
        assertNotNull(result);
        verify(notificationMapper).selectPage(any(), any());
    }
} 