package com.example.ksp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KspApplicationTests {

    @Test
    void contextLoads() {
    }

}
