package com.example.ksp.modules.system.section.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.section.service.SectionService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SectionControllerTest {

    @Mock
    private SectionService sectionService;

    @InjectMocks
    private SectionController sectionController;

    @Test
    void createSection_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Section section = new Section();
        section.setSectionName("测试分区");
        when(sectionService.createSection(any(Section.class))).thenReturn(true);

        // Act
        Resp<Boolean> response = sectionController.createSection(section);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void createSection_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Section section = new Section();
        when(sectionService.createSection(any(Section.class))).thenReturn(false);

        // Act
        Resp<Boolean> response = sectionController.createSection(section);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("创建分区失败", response.getMsg());
    }

    @Test
    void updateSection_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Section section = new Section();
        section.setId(1L);
        when(sectionService.updateSection(any(Section.class))).thenReturn(true);

        // Act
        Resp<Boolean> response = sectionController.updateSection(section);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void deleteSection_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(sectionService.deleteSection(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = sectionController.deleteSection(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void toggleVisibility_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(sectionService.toggleVisibility(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = sectionController.toggleVisibility(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void listSections_ShouldReturnPageResult() {
        // Arrange
        Page<Section> page = new Page<>();
        when(sectionService.page(any(), any())).thenReturn(page);

        // Act
        Resp<Page<Section>> response = sectionController.listSections(1, 10);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getSection_WhenExists_ShouldReturnSection() {
        // Arrange
        Long id = 1L;
        Section section = new Section();
        section.setId(id);
        when(sectionService.getById(id)).thenReturn(section);

        // Act
        Resp<Section> response = sectionController.getSection(id);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertEquals(id, response.getData().getId());
    }

    @Test
    void getSection_WhenNotExists_ShouldReturnErrorResponse() {
        // Arrange
        Long id = 1L;
        when(sectionService.getById(id)).thenReturn(null);

        // Act
        Resp<Section> response = sectionController.getSection(id);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND.getCode(), response.getCode());
        assertEquals("分区不存在", response.getMsg());
    }
} 