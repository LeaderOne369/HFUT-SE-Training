package com.example.ksp.modules.system.section.service;

import com.example.ksp.modules.system.section.entity.Section;
import com.example.ksp.modules.system.section.mapper.SectionMapper;
import com.example.ksp.modules.system.section.service.impl.SectionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SectionServiceTest {

    @Mock
    private SectionMapper sectionMapper;

    @Spy
    @InjectMocks
    private SectionServiceImpl sectionService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(sectionService, "baseMapper", sectionMapper);
    }

    @Test
    void createSection_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        Section section = new Section();
        section.setSectionName("测试分区");
        section.setSectionDescription("测试分区描述");
        
        doReturn(1).when(sectionMapper).insert(any(Section.class));

        // Act
        boolean result = sectionService.createSection(section);

        // Assert
        assertTrue(result);
        verify(sectionMapper).insert(any(Section.class));
        assertNotNull(section.getCreationTime());
        assertNotNull(section.getUpdateTime());
        assertEquals(0, section.getIsDeleted());
    }

    @Test
    void updateSection_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        Section section = new Section();
        section.setId(1L);
        section.setSectionName("更新的分区名称");
        
        doReturn(1).when(sectionMapper).updateById(any(Section.class));

        // Act
        boolean result = sectionService.updateSection(section);

        // Assert
        assertTrue(result);
        verify(sectionMapper).updateById(any(Section.class));
        assertNotNull(section.getUpdateTime());
    }

    @Test
    void deleteSection_WhenValidId_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        doReturn(1).when(sectionMapper).deleteById(any(Long.class));

        // Act
        boolean result = sectionService.deleteSection(id);

        // Assert
        assertTrue(result);
        verify(sectionMapper).deleteById(id);
    }

    @Test
    void toggleVisibility_WhenSectionExists_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        Section section = new Section();
        section.setId(id);
        section.setVisibility(1);
        
        doReturn(section).when(sectionMapper).selectById(id);
        doReturn(1).when(sectionMapper).updateById(any(Section.class));

        // Act
        boolean result = sectionService.toggleVisibility(id);

        // Assert
        assertTrue(result);
        verify(sectionMapper).updateById(any(Section.class));
        assertEquals(0, section.getVisibility());
    }

    @Test
    void toggleVisibility_WhenSectionNotExists_ShouldReturnFalse() {
        // Arrange
        Long id = 1L;
        doReturn(null).when(sectionMapper).selectById(id);

        // Act
        boolean result = sectionService.toggleVisibility(id);

        // Assert
        assertFalse(result);
        verify(sectionMapper, never()).updateById(any(Section.class));
    }
} 