package com.example.ksp.modules.system.view.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.view.entity.View;
import com.example.ksp.modules.system.view.service.ViewService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ViewControllerTest {

    @Mock
    private ViewService viewService;

    @InjectMocks
    private ViewController viewController;

    @Test
    void recordView_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        when(viewService.recordView(userId, postId)).thenReturn(true);

        // Act
        Resp<Boolean> response = viewController.recordView(userId, postId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void recordView_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        when(viewService.recordView(userId, postId)).thenReturn(false);

        // Act
        Resp<Boolean> response = viewController.recordView(userId, postId);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("记录浏览失败", response.getMsg());
    }

    @Test
    void deleteView_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(viewService.deleteView(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = viewController.deleteView(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void deleteUserViews_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        when(viewService.deleteUserViews(userId)).thenReturn(true);

        // Act
        Resp<Boolean> response = viewController.deleteUserViews(userId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getUserViews_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        long current = 1;
        long size = 10;
        Page<View> expectedPage = new Page<>();
        when(viewService.getUserViews(userId, current, size)).thenReturn(expectedPage);

        // Act
        Resp<Page<View>> response = viewController.getUserViews(userId, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getPostViews_ShouldReturnPageResult() {
        // Arrange
        Long postId = 1L;
        long current = 1;
        long size = 10;
        Page<View> expectedPage = new Page<>();
        when(viewService.getPostViews(postId, current, size)).thenReturn(expectedPage);

        // Act
        Resp<Page<View>> response = viewController.getPostViews(postId, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getPostViewCount_ShouldReturnCount() {
        // Arrange
        Long postId = 1L;
        long expectedCount = 5L;
        when(viewService.getPostViewCount(postId)).thenReturn(expectedCount);

        // Act
        Resp<Long> response = viewController.getPostViewCount(postId);

        // Assert
        assertEquals(200, response.getCode());
        assertEquals(expectedCount, response.getData());
        assertNull(response.getMsg());
    }
} 