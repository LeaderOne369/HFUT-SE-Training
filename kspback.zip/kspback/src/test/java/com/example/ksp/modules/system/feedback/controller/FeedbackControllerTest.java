package com.example.ksp.modules.system.feedback.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.feedback.entity.Feedback;
import com.example.ksp.modules.system.feedback.service.FeedbackService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FeedbackControllerTest {

    @Mock
    private FeedbackService feedbackService;

    @InjectMocks
    private FeedbackController feedbackController;

    @Test
    void submitFeedback_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Feedback feedback = new Feedback();
        feedback.setFeedbackContent("测试反馈");
        when(feedbackService.submitFeedback(any(Feedback.class))).thenReturn(true);

        // Act
        Resp<Boolean> response = feedbackController.submitFeedback(feedback);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void submitFeedback_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Feedback feedback = new Feedback();
        when(feedbackService.submitFeedback(any(Feedback.class))).thenReturn(false);

        // Act
        Resp<Boolean> response = feedbackController.submitFeedback(feedback);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("提交反馈失败", response.getMsg());
    }

    @Test
    void updateStatus_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        Integer status = 1;
        when(feedbackService.updateStatus(id, status)).thenReturn(true);

        // Act
        Resp<Boolean> response = feedbackController.updateStatus(id, status);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void updateStatus_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Long id = 1L;
        Integer status = 1;
        when(feedbackService.updateStatus(id, status)).thenReturn(false);

        // Act
        Resp<Boolean> response = feedbackController.updateStatus(id, status);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("更新状态失败", response.getMsg());
    }

    @Test
    void deleteFeedback_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        when(feedbackService.deleteFeedback(id)).thenReturn(true);

        // Act
        Resp<Boolean> response = feedbackController.deleteFeedback(id);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getUserFeedbacks_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Integer status = 0;
        long current = 1;
        long size = 10;
        Page<Feedback> expectedPage = new Page<>();
        when(feedbackService.getUserFeedbacks(userId, status, current, size)).thenReturn(expectedPage);

        // Act
        Resp<Page<Feedback>> response = feedbackController.getUserFeedbacks(userId, status, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getAllFeedbacks_ShouldReturnPageResult() {
        // Arrange
        Integer status = 0;
        long current = 1;
        long size = 10;
        Page<Feedback> expectedPage = new Page<>();
        when(feedbackService.getAllFeedbacks(status, current, size)).thenReturn(expectedPage);

        // Act
        Resp<Page<Feedback>> response = feedbackController.getAllFeedbacks(status, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }
} 