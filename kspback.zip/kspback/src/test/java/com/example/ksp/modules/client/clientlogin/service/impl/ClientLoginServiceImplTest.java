package com.example.ksp.modules.client.clientlogin.service.impl;

import com.example.ksp.common.utils.IpLocationUtil;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.client.clientlogin.dto.ClientLoginDTO;
import com.example.ksp.modules.proxy.UserServiceProxy;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.example.ksp.modules.system.user.entity.User;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ClientLoginServiceImplTest {
    
    @Mock
    private UserServiceProxy userServiceProxy;
    
    @Mock
    private RedisCache redisCache;
    
    @Mock
    private IpLocationUtil ipLocationUtil;
    
    @Mock
    private HttpServletRequest request;
    
    @InjectMocks
    private ClientLoginServiceImpl clientLoginService;
    
    private ClientLoginDTO mockClientLoginDTO;
    private User mockUser;
    private LocalDateTime now;
    
    @BeforeEach
    void setUp() {
        now = LocalDateTime.now();
        
        // 初始化用户数据
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("testUser");
        mockUser.setPhoneNumber("13800138000");
        mockUser.setIsDeleted(0);
        mockUser.setIsFrozen(0);
        mockUser.setIsAdmin(0);
        mockUser.setReviewStatus(1);
        
        // 初始化登录DTO
        mockClientLoginDTO = new ClientLoginDTO();
        mockClientLoginDTO.setUsername("testUser");
        mockClientLoginDTO.setPassword("password");
        mockClientLoginDTO.setLoginType(1);
        mockClientLoginDTO.setLastLoginTime(now);
        mockClientLoginDTO.setLastLoginLocation("测试地点");
        
        // 设置检查配置
        ClientLoginDTO.ClientLoginCheckConfig checkConfig = new ClientLoginDTO.ClientLoginCheckConfig();
        checkConfig.setCheckDeleted(1);
        checkConfig.setCheckFrozen(1);
        checkConfig.setCheckAdmin(1);
        checkConfig.setCheckReview(1);
        mockClientLoginDTO.setCheckConfig(checkConfig);
    }
    
    @Test
    void login_ShouldSucceed() {
        // 准备测试数据
        mockUser.setIsAdmin(1);  // 设置为管理员用户，因为 checkConfig 中设置了检查管理员
        
        Resp<User> loginResp = new Resp<>();
        loginResp.setCode(HttpStatus.OK.getCode());
        loginResp.setMsg(HttpStatus.OK.getMsg());
        loginResp.setData(mockUser);
        
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(loginResp);
        when(userServiceProxy.updateUserLoginInfo(any(User.class))).thenReturn(true);
        doNothing().when(redisCache).setCacheObject(anyString(), any());
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.OK.getCode(), result.getCode());
        assertNotNull(result.getData());
        assertTrue(result.getData().containsKey("token"));
        assertTrue(result.getData().containsKey("user"));
        
        // 验证方法调用
        verify(userServiceProxy).login(any(LoginDTO.class));
        verify(userServiceProxy).updateUserLoginInfo(any(User.class));
        verify(redisCache).setCacheObject(anyString(), any());
    }
    
    @Test
    void login_ShouldFailWithDeletedUser() {
        // 准备测试数据
        mockUser.setIsDeleted(1);
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(Resp.success(mockUser));
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.FORBIDDEN.getCode(), result.getCode());
        assertEquals("禁止访问", result.getMsg());
    }
    
    @Test
    void login_ShouldFailWithFrozenUser() {
        // 准备测试数据
        mockUser.setIsFrozen(1);
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(Resp.success(mockUser));
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(423, result.getCode());
        assertEquals("已锁定", result.getMsg());
    }
    
    @Test
    void login_ShouldFailWithPendingReview() {
        // 准备测试数据
        mockUser.setReviewStatus(0);
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(Resp.success(mockUser));
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED.getCode(), result.getCode());
        assertEquals("未授权", result.getMsg());
    }
    
    @Test
    void login_ShouldFailWithUpdateError() {
        // 准备测试数据
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "未授权"));
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED.getCode(), result.getCode());
        assertEquals("未授权", result.getMsg());
    }
    
    @Test
    void login_ShouldFailWithLoginError() {
        // 准备测试数据
        when(userServiceProxy.login(any(LoginDTO.class)))
            .thenReturn(Resp.error(HttpStatus.UNAUTHORIZED.getCode(), "用户名或密码错误"));
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.UNAUTHORIZED.getCode(), result.getCode());
        assertEquals("用户名或密码错误", result.getMsg());
    }
    
    @Test
    void login_ShouldSetLocationFromIp() {
        // 准备测试数据
        String mockIp = "8.8.8.8";
        String mockLocation = "美国-加利福尼亚州-山景城";
        mockUser.setIsAdmin(1);
        
        when(request.getRemoteAddr()).thenReturn(mockIp);
        when(ipLocationUtil.getLocationByIp(mockIp)).thenReturn(mockLocation);
        when(userServiceProxy.login(any(LoginDTO.class))).thenReturn(Resp.success(mockUser));
        when(userServiceProxy.updateUserLoginInfo(any(User.class))).thenReturn(true);
        
        // 执行测试
        Resp<Map<String, Object>> result = clientLoginService.login(mockClientLoginDTO);
        
        // 验证结果
        assertNotNull(result);
        assertEquals(HttpStatus.OK.getCode(), result.getCode());
        User resultUser = (User) result.getData().get("user");
        assertEquals(mockLocation, resultUser.getLastLoginLocation());
        
        // 验证IP地址查询是否被调用
        verify(ipLocationUtil).getLocationByIp(mockIp);
    }
} 