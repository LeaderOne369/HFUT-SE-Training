package com.example.ksp.modules.system.favorite.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favorite.mapper.FavoriteMapper;
import com.example.ksp.modules.system.favorite.service.impl.FavoriteServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FavoriteServiceTest {

    @Mock
    private FavoriteMapper favoriteMapper;

    @Spy
    @InjectMocks
    private FavoriteServiceImpl favoriteService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(favoriteService, "baseMapper", favoriteMapper);
    }

    @Test
    void addFavorite_WhenNotExists_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        Long folderId = 1L;
        doReturn(0L).when(favoriteMapper).selectCount(any());
        doReturn(1).when(favoriteMapper).insert(any(Favorite.class));

        // Act
        boolean result = favoriteService.addFavorite(userId, postId, folderId);

        // Assert
        assertTrue(result);
        verify(favoriteMapper).insert(any(Favorite.class));
    }

    @Test
    void addFavorite_WhenAlreadyExists_ShouldReturnFalse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        Long folderId = 1L;
        doReturn(1L).when(favoriteMapper).selectCount(any());

        // Act
        boolean result = favoriteService.addFavorite(userId, postId, folderId);

        // Assert
        assertFalse(result);
        verify(favoriteMapper, never()).insert(any(Favorite.class));
    }

    @Test
    void cancelFavorite_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        doReturn(1).when(favoriteMapper).delete(any());

        // Act
        boolean result = favoriteService.cancelFavorite(userId, postId);

        // Assert
        assertTrue(result);
        verify(favoriteMapper).delete(any());
    }

    @Test
    void moveFavorite_WhenExists_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        Long newFolderId = 2L;
        Favorite favorite = new Favorite();
        favorite.setId(id);
        favorite.setFolderId(1L);
        
        doReturn(favorite).when(favoriteMapper).selectById(id);
        doReturn(1).when(favoriteMapper).updateById(any(Favorite.class));

        // Act
        boolean result = favoriteService.moveFavorite(id, newFolderId);

        // Assert
        assertTrue(result);
        verify(favoriteMapper).updateById(any(Favorite.class));
        assertEquals(newFolderId, favorite.getFolderId());
    }

    @Test
    void moveFavorite_WhenNotExists_ShouldReturnFalse() {
        // Arrange
        Long id = 1L;
        Long newFolderId = 2L;
        doReturn(null).when(favoriteMapper).selectById(id);

        // Act
        boolean result = favoriteService.moveFavorite(id, newFolderId);

        // Assert
        assertFalse(result);
        verify(favoriteMapper, never()).updateById(any(Favorite.class));
    }

    @Test
    void getUserFavorites_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Long folderId = 1L;
        long current = 1;
        long size = 10;
        Page<Favorite> expectedPage = new Page<>();
        doReturn(expectedPage).when(favoriteMapper).selectPage(any(), any());

        // Act
        Page<Favorite> result = favoriteService.getUserFavorites(userId, folderId, current, size);

        // Assert
        assertNotNull(result);
        verify(favoriteMapper).selectPage(any(), any());
    }

    @Test
    void getPostFavoriteCount_ShouldReturnCount() {
        // Arrange
        Long postId = 1L;
        long expectedCount = 5L;
        doReturn(expectedCount).when(favoriteMapper).selectCount(any());

        // Act
        long result = favoriteService.getPostFavoriteCount(postId);

        // Assert
        assertEquals(expectedCount, result);
        verify(favoriteMapper).selectCount(any());
    }

    @Test
    void checkFavorite_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        doReturn(1L).when(favoriteMapper).selectCount(any());

        // Act
        boolean result = favoriteService.checkFavorite(userId, postId);

        // Assert
        assertTrue(result);
        verify(favoriteMapper).selectCount(any());
    }

    @Test
    void batchMoveFavorites_WhenAllSuccess_ShouldReturnTrue() {
        // Arrange
        Long[] ids = {1L, 2L};
        Long newFolderId = 2L;
        
        Favorite favorite1 = new Favorite();
        favorite1.setId(1L);
        Favorite favorite2 = new Favorite();
        favorite2.setId(2L);
        
        doReturn(favorite1).when(favoriteMapper).selectById(1L);
        doReturn(favorite2).when(favoriteMapper).selectById(2L);
        doReturn(1).when(favoriteMapper).updateById(any(Favorite.class));

        // Act
        boolean result = favoriteService.batchMoveFavorites(ids, newFolderId);

        // Assert
        assertTrue(result);
        verify(favoriteMapper, times(2)).updateById(any(Favorite.class));
    }
} 