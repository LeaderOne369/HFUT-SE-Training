package com.example.ksp.modules.system.user.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.ksp.common.utils.RedisCache;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.user.dto.LoginDTO;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.mapper.UserMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserMapper userMapper;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private RedisCache redisCache;

    @InjectMocks
    private UserServiceImpl userService;

    private User mockUser;
    private RegisterDTO mockRegisterDTO;
    private LoginDTO mockLoginDTO;

    @BeforeEach
    void setUp() {
        // 设置测试数据
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("testUser");
        mockUser.setPassword("encodedPassword");
        mockUser.setPhoneNumber("13800138000");
        mockUser.setSalt("testSalt");
        
        mockRegisterDTO = new RegisterDTO();
        mockRegisterDTO.setUsername("testUser");
        mockRegisterDTO.setPassword("password");
        mockRegisterDTO.setPhoneNumber("13800138000");
        mockRegisterDTO.setCaptcha("1234");
        
        mockLoginDTO = new LoginDTO();
        mockLoginDTO.setUsername("testUser");
        mockLoginDTO.setPassword("password");
        mockLoginDTO.setPhoneNumber("13800138000");
        mockLoginDTO.setCaptcha("1234");
        
        // 设置通用的mock行为
        lenient().when(redisCache.getCacheObject(anyString())).thenReturn("1234");
        lenient().when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        lenient().when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);
        
        // 初始化 MyBatis-Plus 的 baseMapper
        ReflectionTestUtils.setField(userService, "baseMapper", userMapper);
    }

    @Test
    void selectUserByPhoneNumber_ShouldReturnUser() {
        // 使用 doReturn 语法来避免 when 的问题
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        
        User result = userService.selectUserByPhoneNumber("13800138000");
        
        assertNotNull(result);
        assertEquals(mockUser, result);
    }

    @Test
    void register_ShouldSucceed() {
        // 模拟用户名和手机号都不存在
        doReturn(null).when(userMapper).selectOne(any(), anyBoolean());
        when(userMapper.insert(any(User.class))).thenReturn(1);
        
        Resp<User> result = userService.register(mockRegisterDTO);
        
        assertNotNull(result);
        assertEquals(200, result.getCode());
        verify(userMapper).insert(any(User.class));
    }

    @Test
    void register_ShouldFailWithExistingUsername() {
        // 模拟用户名已存在
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        
        Resp<User> result = userService.register(mockRegisterDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("用户名已存在", result.getMsg());
        verify(userMapper, never()).insert(any(User.class));
    }

    @Test
    void register_ShouldFailWithExistingPhone() {
        // 第一次调用返回null（用户名检查），第二次调用返回已存在用户（手机号检查）
        doReturn(null, mockUser).when(userMapper).selectOne(any(), anyBoolean());
        
        Resp<User> result = userService.register(mockRegisterDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("手机号已被注册", result.getMsg());
        verify(userMapper, never()).insert(any(User.class));
    }

    @Test
    void updateUserLoginInfo_ShouldSucceed() {
        when(userMapper.updateById(any(User.class))).thenReturn(1);
        
        boolean result = userService.updateUserLoginInfo(mockUser);
        
        assertTrue(result);
        verify(userMapper).updateById(any(User.class));
    }

    @Test
    void login_ShouldSucceedWithUsername() {
        mockLoginDTO.setLoginType(1);
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        doReturn(1).when(userMapper).updateById(any(User.class));
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(200, result.getCode());
        assertEquals(mockUser, result.getData());
        verify(userMapper).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldFailWithWrongUsername() {
        mockLoginDTO.setLoginType(1);
        doReturn(null).when(userMapper).selectOne(any(), anyBoolean());
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("用户名不存在", result.getMsg());
        verify(userMapper, never()).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldFailWithWrongPassword() {
        mockLoginDTO.setLoginType(1);
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("密码错误", result.getMsg());
        verify(userMapper, never()).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldSucceedWithPhone() {
        mockLoginDTO.setLoginType(2);
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        doReturn(1).when(userMapper).updateById(any(User.class));
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(200, result.getCode());
        assertEquals(mockUser, result.getData());
        verify(userMapper).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldSucceedWithPhoneCaptcha() {
        mockLoginDTO.setLoginType(3);
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        doReturn(1).when(userMapper).updateById(any(User.class));
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(200, result.getCode());
        assertEquals(mockUser, result.getData());
        verify(userMapper).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldFailWithWrongCaptcha() {
        mockLoginDTO.setLoginType(3);
        doReturn(mockUser).when(userMapper).selectOne(any(), anyBoolean());
        when(redisCache.getCacheObject(anyString())).thenReturn("wrong_code");
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("验证码错误或已过期", result.getMsg());
        verify(userMapper, never()).updateById(any(User.class));
    }
    
    @Test
    void login_ShouldFailWithInvalidLoginType() {
        mockLoginDTO.setLoginType(4);
        
        Resp<User> result = userService.login(mockLoginDTO);
        
        assertNotNull(result);
        assertEquals(400, result.getCode());
        assertEquals("不支持的登录方式", result.getMsg());
        verify(userMapper, never()).updateById(any(User.class));
    }
}