package com.example.ksp.modules.system.view.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.view.entity.View;
import com.example.ksp.modules.system.view.mapper.ViewMapper;
import com.example.ksp.modules.system.view.service.impl.ViewServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ViewServiceTest {

    @Mock
    private ViewMapper viewMapper;

    @Spy
    @InjectMocks
    private ViewServiceImpl viewService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(viewService, "baseMapper", viewMapper);
    }

    @Test
    void recordView_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        doReturn(1).when(viewMapper).insert(any(View.class));

        // Act
        boolean result = viewService.recordView(userId, postId);

        // Assert
        assertTrue(result);
        verify(viewMapper).insert(any(View.class));
    }

    @Test
    void deleteView_WhenValidId_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        doReturn(1).when(viewMapper).deleteById(id);

        // Act
        boolean result = viewService.deleteView(id);

        // Assert
        assertTrue(result);
        verify(viewMapper).deleteById(id);
    }

    @Test
    void deleteUserViews_WhenValidUserId_ShouldReturnTrue() {
        // Arrange
        Long userId = 1L;
        doReturn(1).when(viewMapper).delete(any());

        // Act
        boolean result = viewService.deleteUserViews(userId);

        // Assert
        assertTrue(result);
        verify(viewMapper).delete(any());
    }

    @Test
    void getUserViews_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        long current = 1;
        long size = 10;
        Page<View> expectedPage = new Page<>();
        doReturn(expectedPage).when(viewMapper).selectPage(any(), any());

        // Act
        Page<View> result = viewService.getUserViews(userId, current, size);

        // Assert
        assertNotNull(result);
        verify(viewMapper).selectPage(any(), any());
    }

    @Test
    void getPostViews_ShouldReturnPageResult() {
        // Arrange
        Long postId = 1L;
        long current = 1;
        long size = 10;
        Page<View> expectedPage = new Page<>();
        doReturn(expectedPage).when(viewMapper).selectPage(any(), any());

        // Act
        Page<View> result = viewService.getPostViews(postId, current, size);

        // Assert
        assertNotNull(result);
        verify(viewMapper).selectPage(any(), any());
    }

    @Test
    void getPostViewCount_ShouldReturnCount() {
        // Arrange
        Long postId = 1L;
        long expectedCount = 5L;
        doReturn(expectedCount).when(viewMapper).selectCount(any());

        // Act
        long result = viewService.getPostViewCount(postId);

        // Assert
        assertEquals(expectedCount, result);
        verify(viewMapper).selectCount(any());
    }
} 