package com.example.ksp.modules.system.reviewlog.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.modules.system.reviewlog.entity.ReviewLog;
import com.example.ksp.modules.system.reviewlog.mapper.ReviewLogMapper;
import com.example.ksp.modules.system.reviewlog.service.impl.ReviewLogServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewLogServiceTest {

    @Mock
    private ReviewLogMapper reviewLogMapper;

    @Spy
    @InjectMocks
    private ReviewLogServiceImpl reviewLogService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(reviewLogService, "baseMapper", reviewLogMapper);
    }

    @Test
    void createReviewLog_WhenValidInput_ShouldReturnTrue() {
        // Arrange
        ReviewLog reviewLog = new ReviewLog();
        reviewLog.setContentId(1L);
        reviewLog.setContentType(1);
        reviewLog.setReviewerId(1L);
        
        doReturn(1).when(reviewLogMapper).insert(any(ReviewLog.class));

        // Act
        boolean result = reviewLogService.createReviewLog(reviewLog);

        // Assert
        assertTrue(result);
        verify(reviewLogMapper).insert(any(ReviewLog.class));
        assertNotNull(reviewLog.getReviewTime());
        assertEquals(0, reviewLog.getReviewStatus());
    }

    @Test
    void updateReviewStatus_WhenReviewLogExists_ShouldReturnTrue() {
        // Arrange
        Long id = 1L;
        Integer status = 1;
        String notes = "测试备注";
        ReviewLog reviewLog = new ReviewLog();
        reviewLog.setId(id);
        reviewLog.setReviewStatus(0);
        
        doReturn(reviewLog).when(reviewLogMapper).selectById(id);
        doReturn(1).when(reviewLogMapper).updateById(any(ReviewLog.class));

        // Act
        boolean result = reviewLogService.updateReviewStatus(id, status, notes);

        // Assert
        assertTrue(result);
        verify(reviewLogMapper).updateById(any(ReviewLog.class));
        assertEquals(status, reviewLog.getReviewStatus());
        assertEquals(notes, reviewLog.getReviewNotes());
    }

    @Test
    void updateReviewStatus_WhenReviewLogNotExists_ShouldReturnFalse() {
        // Arrange
        Long id = 1L;
        Integer status = 1;
        String notes = "测试备注";
        doReturn(null).when(reviewLogMapper).selectById(id);

        // Act
        boolean result = reviewLogService.updateReviewStatus(id, status, notes);

        // Assert
        assertFalse(result);
        verify(reviewLogMapper, never()).updateById(any(ReviewLog.class));
    }

    @Test
    void getContentReviews_ShouldReturnPageResult() {
        // Arrange
        Long contentId = 1L;
        Integer contentType = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        doReturn(expectedPage).when(reviewLogMapper).selectPage(any(), any());

        // Act
        Page<ReviewLog> result = reviewLogService.getContentReviews(contentId, contentType, current, size);

        // Assert
        assertNotNull(result);
        verify(reviewLogMapper).selectPage(any(), any());
    }

    @Test
    void getReviewerLogs_ShouldReturnPageResult() {
        // Arrange
        Long reviewerId = 1L;
        Integer status = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        doReturn(expectedPage).when(reviewLogMapper).selectPage(any(), any());

        // Act
        Page<ReviewLog> result = reviewLogService.getReviewerLogs(reviewerId, status, current, size);

        // Assert
        assertNotNull(result);
        verify(reviewLogMapper).selectPage(any(), any());
    }

    @Test
    void getPendingReviews_ShouldReturnPageResult() {
        // Arrange
        Integer contentType = 1;
        long current = 1;
        long size = 10;
        Page<ReviewLog> expectedPage = new Page<>();
        doReturn(expectedPage).when(reviewLogMapper).selectPage(any(), any());

        // Act
        Page<ReviewLog> result = reviewLogService.getPendingReviews(contentType, current, size);

        // Assert
        assertNotNull(result);
        verify(reviewLogMapper).selectPage(any(), any());
    }

    @Test
    void batchReview_WhenAllSuccess_ShouldReturnTrue() {
        // Arrange
        Long[] ids = {1L, 2L};
        Integer status = 1;
        String notes = "批量审核备注";
        
        ReviewLog reviewLog1 = new ReviewLog();
        reviewLog1.setId(1L);
        ReviewLog reviewLog2 = new ReviewLog();
        reviewLog2.setId(2L);
        
        doReturn(reviewLog1).when(reviewLogMapper).selectById(1L);
        doReturn(reviewLog2).when(reviewLogMapper).selectById(2L);
        doReturn(1).when(reviewLogMapper).updateById(any(ReviewLog.class));

        // Act
        boolean result = reviewLogService.batchReview(ids, status, notes);

        // Assert
        assertTrue(result);
        verify(reviewLogMapper, times(2)).updateById(any(ReviewLog.class));
    }
} 