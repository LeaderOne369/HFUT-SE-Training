package com.example.ksp.modules.system.like.controller;

import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.like.service.LikeService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LikeControllerTest {

    @Mock
    private LikeService likeService;

    @InjectMocks
    private LikeController likeController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addLike_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        when(likeService.addLike(userId, objectId, objectType)).thenReturn(true);

        // Act
        Resp<Boolean> response = likeController.addLike(userId, objectId, objectType);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void addLike_WhenAlreadyLiked_ShouldReturnErrorResponse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        when(likeService.addLike(userId, objectId, objectType)).thenReturn(false);

        // Act
        Resp<Boolean> response = likeController.addLike(userId, objectId, objectType);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("已经点赞过了", response.getMsg());
    }

    @Test
    void cancelLike_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        when(likeService.cancelLike(userId, objectId, objectType)).thenReturn(true);

        // Act
        Resp<Boolean> response = likeController.cancelLike(userId, objectId, objectType);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void cancelLike_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        
        when(likeService.cancelLike(userId, objectId, objectType)).thenReturn(false);

        // Act
        Resp<Boolean> response = likeController.cancelLike(userId, objectId, objectType);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("取消点赞失败", response.getMsg());
    }

    @Test
    void checkLiked_ShouldReturnCorrectStatus() {
        // Arrange
        Long userId = 1L;
        Long objectId = 1L;
        Integer objectType = 1;
        boolean expectedResult = true;
        
        when(likeService.checkLiked(userId, objectId, objectType)).thenReturn(expectedResult);

        // Act
        Resp<Boolean> response = likeController.checkLiked(userId, objectId, objectType);

        // Assert
        assertEquals(200, response.getCode());
        assertEquals(expectedResult, response.getData());
        assertNull(response.getMsg());
    }
} 