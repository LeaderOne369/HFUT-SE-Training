package com.example.ksp.modules.system.favorite.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ksp.common.variable.HttpStatus;
import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.favorite.entity.Favorite;
import com.example.ksp.modules.system.favorite.service.FavoriteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FavoriteControllerTest {

    @Mock
    private FavoriteService favoriteService;

    @InjectMocks
    private FavoriteController favoriteController;

    @Test
    void addFavorite_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        Long folderId = 1L;
        when(favoriteService.addFavorite(userId, postId, folderId)).thenReturn(true);

        // Act
        Resp<Boolean> response = favoriteController.addFavorite(userId, postId, folderId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void addFavorite_WhenFail_ShouldReturnErrorResponse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        Long folderId = 1L;
        when(favoriteService.addFavorite(userId, postId, folderId)).thenReturn(false);

        // Act
        Resp<Boolean> response = favoriteController.addFavorite(userId, postId, folderId);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST.getCode(), response.getCode());
        assertEquals("添加收藏失败", response.getMsg());
    }

    @Test
    void cancelFavorite_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        when(favoriteService.cancelFavorite(userId, postId)).thenReturn(true);

        // Act
        Resp<Boolean> response = favoriteController.cancelFavorite(userId, postId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void moveFavorite_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long id = 1L;
        Long newFolderId = 2L;
        when(favoriteService.moveFavorite(id, newFolderId)).thenReturn(true);

        // Act
        Resp<Boolean> response = favoriteController.moveFavorite(id, newFolderId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getUserFavorites_ShouldReturnPageResult() {
        // Arrange
        Long userId = 1L;
        Long folderId = 1L;
        long current = 1;
        long size = 10;
        Page<Favorite> expectedPage = new Page<>();
        when(favoriteService.getUserFavorites(userId, folderId, current, size))
                .thenReturn(expectedPage);

        // Act
        Resp<Page<Favorite>> response = favoriteController.getUserFavorites(userId, folderId, current, size);

        // Assert
        assertEquals(200, response.getCode());
        assertNotNull(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void getPostFavoriteCount_ShouldReturnCount() {
        // Arrange
        Long postId = 1L;
        long expectedCount = 5L;
        when(favoriteService.getPostFavoriteCount(postId)).thenReturn(expectedCount);

        // Act
        Resp<Long> response = favoriteController.getPostFavoriteCount(postId);

        // Assert
        assertEquals(200, response.getCode());
        assertEquals(expectedCount, response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void checkFavorite_ShouldReturnResult() {
        // Arrange
        Long userId = 1L;
        Long postId = 1L;
        when(favoriteService.checkFavorite(userId, postId)).thenReturn(true);

        // Act
        Resp<Boolean> response = favoriteController.checkFavorite(userId, postId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }

    @Test
    void batchMoveFavorites_WhenSuccess_ShouldReturnSuccessResponse() {
        // Arrange
        Long[] ids = {1L, 2L};
        Long newFolderId = 2L;
        when(favoriteService.batchMoveFavorites(ids, newFolderId)).thenReturn(true);

        // Act
        Resp<Boolean> response = favoriteController.batchMoveFavorites(ids, newFolderId);

        // Assert
        assertEquals(200, response.getCode());
        assertTrue(response.getData());
        assertNull(response.getMsg());
    }
} 