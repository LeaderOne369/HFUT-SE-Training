package com.example.ksp.modules.system.user.controller;

import com.example.ksp.common.variable.Resp;
import com.example.ksp.modules.system.user.dto.RegisterDTO;
import com.example.ksp.modules.system.user.entity.User;
import com.example.ksp.modules.system.user.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private MockMvc mockMvc;

    private User mockUser;
    private RegisterDTO mockRegisterDTO;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

        // 初始化测试用户数据
        mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("testUser");
        mockUser.setPhoneNumber("13800138000");
        mockUser.setRegistrationTime(LocalDateTime.now());
        mockUser.setIsDeleted(0);
        mockUser.setIsAdmin(0);
        mockUser.setIsFrozen(0);

        // 初始化注册DTO数据
        mockRegisterDTO = new RegisterDTO();
        mockRegisterDTO.setUsername("newUser");
        mockRegisterDTO.setPassword("password123");
        mockRegisterDTO.setPhoneNumber("13900139000");
        mockRegisterDTO.setCaptcha("1234");
    }

    @Test
    void getUserById_ShouldReturnUser() throws Exception {
        when(userService.getById(1L)).thenReturn(mockUser);

        mockMvc.perform(get("/api/system/user/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.username").value("testUser"))
                .andExpect(jsonPath("$.data.phoneNumber").value("13800138000"));
    }

    @Test
    void getUserByPhone_ShouldReturnUser() throws Exception {
        when(userService.selectUserByPhoneNumber("13800138000")).thenReturn(mockUser);

        mockMvc.perform(get("/api/system/user/phone/13800138000")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.username").value("testUser"));
    }

    @Test
    void register_ShouldReturnSuccess() throws Exception {
        when(userService.register(any(RegisterDTO.class))).thenReturn(Resp.success(mockUser));

        mockMvc.perform(post("/api/system/user/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        "  \"username\": \"newUser\",\n" +
                        "  \"password\": \"password123\",\n" +
                        "  \"phoneNumber\": \"13900139000\",\n" +
                        "  \"captcha\": \"1234\"\n" +
                        "}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data.username").value("testUser"));
    }

    @Test
    void update_ShouldReturnSuccess() throws Exception {
        when(userService.updateById(any(User.class))).thenReturn(true);

        mockMvc.perform(put("/api/system/user")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\n" +
                        "  \"id\": 1,\n" +
                        "  \"username\": \"updatedUser\",\n" +
                        "  \"phoneNumber\": \"13800138000\"\n" +
                        "}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(true));
    }

    @Test
    void delete_ShouldReturnSuccess() throws Exception {
        when(userService.removeById(1L)).thenReturn(true);

        mockMvc.perform(delete("/api/system/user/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.data").value(true));
    }
} 